exp $DBUSER/$DBPWD@$ORACLE_SID file=$HOME/Ora_Dmp/`date +%Y%m%d`
