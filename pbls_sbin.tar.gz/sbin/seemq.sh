while true
do
sleep 5;
clear;
echo "dis chs(*)" | runmqsc BBC_G_501290000012
echo "dis queue(Q_L_ICBC_G_REAL2)" | runmqsc BBC_G_501290000012
done
