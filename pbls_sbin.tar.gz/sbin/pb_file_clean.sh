echo "----begin clean files---"
echo "delete iodata files before $3"
find ${APPL}/iodata/ -type f -mtime +$3 -exec rm -f {} \;
echo "delete log files before $2"
find ${APPL}/log/ -type f -mtime +$2 -exec rm -f {} \;
find ${APPL}/icbcfe/log/ -type f -mtime +$2 -exec rm -f {} \;
echo "----end clean files----"
