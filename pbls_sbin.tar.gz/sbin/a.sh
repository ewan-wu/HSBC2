#!usr/bin/sh;
echo "Which is your favourite OS?"
select var in "UNIX" "LINUX" "WINDOWS"
do
break
done
echo "The answer is $var"
