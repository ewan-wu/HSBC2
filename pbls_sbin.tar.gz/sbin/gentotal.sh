#!/usr/bin/sh

if [ $# -ne 1 ]; then
    echo "Usage: $0 new-release-date "
	exit 1
fi

cd $HOME
find . -name "*.log" -print -exec rm -f {} \;
find . -name "ULOG*" -print -exec rm -f {} \;
find . -name "batchlog*" -print -exec rm -f {} \;
find . -name "*.o" -print -exec rm -f {} \;

tar cvf cds-total-$1.tar bin bhbin TXT db download fmt incl iodata lib mak sbin src tuxedo upload
compress cds-total-$1.tar 
