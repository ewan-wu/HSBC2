
FILENAME=$1
RServer=sinpsssrd1.sg.db.com 
RUser=coolopr
RPath=/rms/transfer/912/pbls

echo "scp /home/pbls/pbls/iodata/report/billrpt/$1 $RUser@$RServer:$RPath"
scp /home/pbls/pbls/iodata/report/billrpt/$1 $RUser@$RServer:$RPath
