grep RecCount $1 >$2
