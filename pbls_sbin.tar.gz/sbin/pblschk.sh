#!/bin/ksh

ps -u $LOGNAME|egrep "pberrsvr|pbtoctl_seq|pbtlrbdg|pbe3bdg|pbccbbdg|pbicbcbdg|pbciticbdg" > $HOME/pbls/log/tmp.cs
ps -u $LOGNAME|egrep "pbsysmng|pboprmng|pbfilemng|pbe3swt|pbe3swt_ack|pbccbswt|pbicbcswt|pbciticswt|pbsystmr|pboprtmr" >> $HOME/pbls/log/tmp.cs
ps -u $LOGNAME|egrep "pbtlrcomm|pbe3comm|pbccbcomm|pbicbccomm|pbddcomm" >> $HOME/pbls/log/tmp.cs

chkproc()
{
if [ $1 -eq $2 ]
then
        echo "Process OK!"
else
        echo "!!!!! WARNING !!!!! process error!!!!! CHECK!!!!!"
fi
}
chkproc_comm()
{
PROCESS=$1
IPADRE=$2
COUNT=0
COUNT=`ps -fu $LOGNAME | grep $PROCESS | grep $IPADRE | grep bin | grep -v grep | grep -v runprocess | wc -l`
if [ $COUNT -eq 0 ]
then
    echo "!!!!! WARNING !!!!! No process [$PROCESS]!!!!! CHECK!!!!!"
else
    echo "Process [$PROCESS] OK!"
fi
}
chkproc_b()
{
if [ $1 -ge $2 ]
then
        echo "Process OK!"
else
        echo "!!!!! WARNING !!!!! process error!!!!! CHECK!!!!!"
fi
}
clear

echo ""
banner                   $LOGNAME

I=`cat $HOME/pbls/log/tmp.cs | wc -l`
typeset -i I
echo "$LOGNAME system process : (  "$I" processes running )"


I=0

echo '+----- process name --+--- number --+---- should be ----+---status----+'
echo '+-------------------------------<ERRSVR>--------------------------------+'
P=`egrep -w -c pberrsvr < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pberrsvr       |      '$P'      |         1         | \c'
chkproc $P 1
echo '+-------------------------------<TOCTL>--------------------------------+'
P=`egrep -w -c pbtoctl_seq < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbtoctl_seq    |      '$P'      |         1         | \c'
chkproc $P 1
echo '+-------------------------------<BRIDGE>--------------------------------+'
P=`egrep -w -c pbtlrbdg < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbtlrbdg       |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pbe3bdg < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbe3bdg        |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pbccbbdg < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbccbbdg       |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pbicbcbdg < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbicbcbdg      |      '$P'      |         1         | \c'
chkproc $P 1
echo '+-------------------------------<MNGSVR>--------------------------------+'
P=`egrep -w -c pbsysmng < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbsysmng       |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pboprmng < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pboprmng       |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pbfilemng < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbfilemng      |      '$P'      |         1         | \c'
chkproc $P 1
echo '+-------------------------------<SWTSVR>--------------------------------+'
P=`egrep -w -c pbe3swt < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbe3swt        |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pbe3swt_ack < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbe3swt_ack    |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pbicbcswt < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbicbcswt      |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pbccbswt < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbccbswt       |      '$P'      |         1         | \c'
chkproc $P 1
echo '+-------------------------------<TIMER>--------------------------------+'
P=`egrep -w -c pbsystmr < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbsystmr       |      '$P'      |         1         | \c'
chkproc $P 1
P=`egrep -w -c pboprtmr < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pboprtmr       |      '$P'      |         1         | \c'
chkproc $P 1
echo '+-------------------------------<COMM>--------------------------------+'
P=`egrep -w -c pbtlrcomm < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbtlrcomm      |      '$P'      |       >=1         | \c'
chkproc_b $P 1
P=`egrep -w -c pbe3comm < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbe3comm       |      '$P'      |         2         | \c'
chkproc $P 2
P=`egrep -w -c pbicbccomm < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbicbccomm     |      '$P'      |         2         | \c'
chkproc $P 2
P=`egrep -w -c pbccbcomm < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbccbcomm      |      '$P'      |         2         | \c'
chkproc $P 2
P=`egrep -w -c pbddcomm < $HOME/pbls/log/tmp.cs`
I=I+P
echo '|      pbddcomm       |      '$P'      |         1         | \c'
chkproc $P 1
#echo '|       total        |      '$I'     |           >= 8                |'

echo '+-------------------------------------------------------------------+'

rm $HOME/pbls/log/tmp.cs

echo
echo "msgque status :"
ipcs -oq | grep $LOGNAME
