#!/usr/bin/sh

echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo "Please use this shell program VERY carefully!"
echo "Do not remove any important data files!"
echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

if [ $# != 1 ]
then
	echo "Usage: tmpfile_clear.sh [YYYYMMDD]"
	echo "Clear temp data files before date YYYYMMDD!"
	exit 1
fi

###############################################################################
# Remove E3 Temp Data Files
###############################################################################

FILES=`ls ${APPL}/iodata/e3/inrt/?????????????.????? ${APPL}/iodata/e3/inrt/?????????????.?????.temp ${APPL}/iodata/e3/outbk/?????????????.????? ${APPL}/iodata/e3/outrt/?????????????.?????`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c6-13`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

###############################################################################
# Remove CCB Temp Data Files
###############################################################################

FILES=`ls ${APPL}/iodata/ccb/inrt/RECV_??????????????.XML ${APPL}/iodata/ccb/outbk/SEND_??????????????_????????.XML ${APPL}/iodata/ccb/outrt/SEND_??????????????_????????.XML`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c6-13`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

FILES=`ls ${APPL}/iodata/ccb/outbk/CCB_OUT?????????_??.ccb ${APPL}/iodata/ccb/outrt/CCB_OUT?????????_??.ccb ${APPL}/iodata/ccb/ddfile/CCB_OUT?????????_??.ccb`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c8-15`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

FILES=`ls ${APPL}/iodata/ccb/ddfile/RECV_??????????????.DAT`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c6-13`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

FILES=`ls ${APPL}/iodata/ccb/ddfile/RECV????_??????????????.XML ${APPL}/iodata/ccb/ddfile/SEND????_??????????????.XML`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c10-17`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done


###############################################################################
# Remove ICBC Temp Data Files
###############################################################################

FILES=`ls ${APPL}/iodata/icbc/inrt/RECV_??????????????.MSG`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c6-13`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

###############################################################################
# Remove Old Night Batch Report Files
###############################################################################

FILES=`ls ${APPL}/iodata/report/rptb*.????????`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -f2 -d"."`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

FILES=`ls ${APPL}/iodata/TXT/SYS/rptb???_????????.txt`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c9-16`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

FILES=`ls ${APPL}/iodata/TXT/SYS/rptb????_????????.txt`

for file in ${FILES}
do
	filedate=`basename ${file} | cut -c10-17`
	if [ ${filedate} -lt $1 ]
	then
		echo "rm ${file}!"
		/usr/bin/rm -f ${file}
	fi
done

exit 0


