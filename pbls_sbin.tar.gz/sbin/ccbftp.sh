#!/usr/bin/sh

if [ $# != 5 ]
then
	echo "Usage: ccbftp.sh [PUT or GET] [CCB USER and IP] [CCB PATH] [CCB FILE] [LOCAL PATH and FILE]"
	exit 1
fi

if [ "$1" != "PUT" ] && [ "$1" != "GET" ]
then
	echo "Usage: ccbftp.sh [PUT or GET] [CCB USER and IP] [CCB PATH ] [CCB FILE] [LOCAL PATH and FILE]"
	echo "Please choose PUT or GET!"
	exit 1
fi

/usr/bin/rm -f ./ccbftp.input

echo "cd $3" > ./ccbftp.input
if [ "$1" = "PUT" ]
then
	echo "put $5 $4" >> ./ccbftp.input
fi

if [ "$1" = "GET" ]
then
	echo "get $4 $5" >> ./ccbftp.input
fi

echo "bye" >> ./ccbftp.input
sftp -b ./ccbftp.input $2

if [ $? -ne 0 ]; then
	echo "CCB: Exec sftp $2!"
	echo "CCB: Exec sftp Error!"
	exit 1
fi

exit 0

