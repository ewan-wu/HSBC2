if [ $# -ne 2 ];then
echo "usage: spfile.sh <source file> <target file> "
exit;
fi
a=`grep Record $1|wc -l`
echo $a
a=` expr $a / 4 + 1 `
echo $a
a=` expr $a \* 17 + 16 `
echo $a
split -l $a $1 $2
head -16 $1>tmp1
cat tmp1 $2ab>tmp2
/usr/bin/move -f tmp2 $2ab
/usr/bin/rm -rf tmp1
tail -6 $1>tmp1
cat $2aa tmp1>tmp2
/usr/bin/move -f tmp2 $2aa
/usr/bin/rm -rf tmp1
$APPL/bin/batch/spfile $2aa
$APPL/bin/batch/spfile $2ab
rm -rf $2aa.count
rm -rf $2ab.count
rm -rf $2aa
rm -rf $2ab
