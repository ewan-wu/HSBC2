#!usr/bin/sh;
for dir in `ls *.sh`
do
	ls -l $dir
done
