echo "start gzip dmp files"
find /opt/app/oracle/bak -name "*.dmp" -exec gzip {} \;
