#!/usr/bin/ksh
#************************************************************************
#  Product: Partner Bank Linking System (PBLS)
#   Module: batch
# Function: delhis.sh
#------------------------------------------------------------------------
# Description: ��ʷ�������
#------------------------------------------------------------------------
# Modification log:
#   Date            Author               Description
# --------       ------------         -----------------
# 20100811       Jasmine Ding         Initial
#************************************************************************

#����������DBUSER ���ݿ��û�����ʵ����DBPWD ���ݿ��û�����
#��Σ�����1 APPL·��

TMPFILE=$1/bin/batch/history_deldate.tmp
LOGFILE=$1/log/pb_olddata_clean.log

echo "TMPFILE:"$TMPFILE
echo "LOGFILE:"$LOGFILE

echo "" >> $LOGFILE
echo ">>>>>>>>>>>>>>>>>>> start[`date`] <<<<<<<<<<<<<<<<<<<" >> $LOGFILE

DELDATE=$2

echo "==========delete history data before $DELDATE==========" >> $LOGFILE

sqlplus -s ${DBUSER}/$DBPWD <<%% >> $LOGFILE

--������־��
prompt pbicbctxn
delete from pbicbctxn where vdate <= $DELDATE;
commit;

--��ѯ��־��
prompt pbicbcinq
delete from pbicbcinq where txdate <= $DELDATE;
commit;

--״̬���Ʊ�
prompt pbstatctl
delete from pbstatctl where espdate <= $DELDATE;
commit;

--״̬������ʷ��
prompt pbstatctlhis
delete from pbstatctlhis where espdate <= $DELDATE;
commit;

--������־��
prompt pberrlog
delete from pberrlog where txdate <= $DELDATE;
commit;

--�ͻ�����
prompt pbcustbal
delete from pbcustbal where txdate <= $DELDATE;
commit;

--�������ɼ�¼��
prompt pbrptlog
delete from pbrptlog where rptdate <= $DELDATE;
commit;

--����ͳ�Ʊ�
prompt pbbatchsts
delete from pbbatchsts where work_date <= $DELDATE;
commit;

--�ͻ�������ϸ��
prompt pbcustdtl
delete from pbcustdtl where txdate <= $DELDATE;
commit;

--����Ա������־��
prompt pbtlrlog
delete from pbtlrlog where act_time <= '$DELDATE'||'240000';
commit;

--����Ա��¼ʧ�ܱ�
prompt pbpswderr
delete from pbpswderr where work_date <= $DELDATE;
commit;

--��Ϣ��ر�
prompt pbmsgmonitor
delete from pbmsgmonitor where txdate <= $DELDATE;
commit;

--��Ϣ�����ʷ��
prompt pbmsgmonitorhis
delete from pbmsgmonitorhis where txdate <= $DELDATE;
commit;

--ϵͳ��־��
prompt pbsyslog
delete from pbsyslog where sys_log_time <= '$DELDATE'||'240000';
commit;

--HUB��Ϣ��
prompt pbhubmsg
delete from pbhubmsg where txdate <= '$DELDATE' and id <> 'PBLS-HUBH000H111';
commit;

--���ı�
prompt icbc_send_ctl
delete from icbc_send_ctl where snd_time <= '$DELDATE'||'240000';
commit;

prompt ICBC_DLTY_TXN
DELETE FROM ICBC_DLTY_TXN             WHERE TRANS_DATE <= $DELDATE;
commit;

prompt ICBC_10015_RSP_TXN
DELETE FROM ICBC_10015_RSP_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_10004_RSP_TXN
DELETE FROM ICBC_10004_RSP_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_10020_REQ_TXN
DELETE FROM ICBC_10020_REQ_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_10017_RSP_TXN
DELETE FROM ICBC_10017_RSP_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_10017_REQ_TXN
DELETE FROM ICBC_10017_REQ_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_10020_RSP_TXN
DELETE FROM ICBC_10020_RSP_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_40004_REQ_TXN
DELETE FROM ICBC_40004_REQ_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_40004_RSP_DETAIL_TXN
DELETE FROM ICBC_40004_RSP_DETAIL_TXN WHERE TRXDATE <= $DELDATE;
commit;

prompt ICBC_40004_RSP_TXN
DELETE FROM ICBC_40004_RSP_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_40005_REQ_TXN
DELETE FROM ICBC_40005_REQ_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_40005_RSP_TXN
DELETE FROM ICBC_40005_RSP_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_10004_REQ_TXN
DELETE FROM ICBC_10004_REQ_TXN        WHERE TXDATE <= $DELDATE;
commit;

prompt ICBC_10015_REQ_TXN
DELETE FROM ICBC_10015_REQ_TXN        WHERE TXDATE <= $DELDATE;
commit;

%%

echo ">>>>>>>>>>>>>>>>>>> end[`date`] <<<<<<<<<<<<<<<<<<<" >> $LOGFILE
