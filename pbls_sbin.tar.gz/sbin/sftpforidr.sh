#!/bin/sh

cd $HOME

echo $1

TMPFILE=/tmp/tmpfile$$
    echo "cd zorrot" >$TMPFILE
    echo "put $1" >>$TMPFILE
    echo "bye" >>$TMPFILE
#sftp -b $TMPFILE -oPort=51722 cnuctapp109\\tsaftp@10.24.128.170  >/dev/null 2>&1

sftp -b $TMPFILE zr@localhost >/dev/null 2>&1

echo "Send $1 to IDR OK"
