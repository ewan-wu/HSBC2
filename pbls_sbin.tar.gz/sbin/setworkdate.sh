if [ $# != 1 ]
then
	echo "Usage: setworkdate.sh [YYYYMMDD]"
	exit 1
fi

sqlplus -s $DBUSER/$DBPWD <<EOF >/dev/null
update pbsysctl set work_date = $1;
exit
EOF

exit 0

