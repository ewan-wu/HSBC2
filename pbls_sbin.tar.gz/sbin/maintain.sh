x=10
y=35
display()
{
  clear
  tput cup $x $y
  echo "************** PBLSά��ϵͳ ***************"
  tput cup `expr $x + 1` $y
  echo "*                                         *"
  tput cup `expr $x + 2` $y
  echo "*                                         *"
  tput cup `expr $x + 3` $y
  echo "*                                         *"
  tput cup `expr $x + 4` $y
  echo "*                                         *"
  tput cup `expr $x + 5` $y
  echo "*              1.�� ��  ά ��             *"
  tput cup `expr $x + 6` $y
  echo "*                                         *" 
  tput cup `expr $x + 7` $y
  echo "*                                         *"
  tput cup `expr $x + 8` $y     
  echo "*                                         *"
  tput cup `expr $x + 9` $y
  echo "*               0   �˳�                  *"
  tput cup `expr $x + 10` $y         
  echo "*                                         *"
  tput cup `expr $x + 11` $y
  echo "*                                         *"
  tput cup `expr $x + 12` $y
  echo "*******************************************"
}

display1_1()
{
  clear
  tput cup $x $y
  echo "************** PBLSά��ϵͳ ***************"
  tput cup `expr $x + 1` $y    
  echo "************** ��  ��  ά  �� *************"
  tput cup `expr $x + 2` $y
  echo "*                                         *"
  tput cup `expr $x + 3` $y
  echo "*                                         *"
  tput cup `expr $x + 4` $y
  echo "*         1.�� �� PBLS ϵ ͳ �� ��        *"
  tput cup `expr $x + 5` $y
  echo "*                                         *"
  tput cup `expr $x + 6` $y
  echo "*         2.��  ��  ��  Ϣ  ��  ��        *" 
  tput cup `expr $x + 7` $y
  echo "*                                         *"
  tput cup `expr $x + 8` $y   
  echo "*                                         *"
  tput cup `expr $x + 9` $y
  echo "*               0   ����                  *"
  tput cup `expr $x + 10` $y         
  echo "*                                         *"
  tput cup `expr $x + 11` $y
  echo "*                                         *"
  tput cup `expr $x + 12` $y
  echo "*******************************************"
}

display1_1_1()
{
  clear
  tput cup $x $y
  echo "************** PBLSά��ϵͳ ***************"
  tput cup `expr $x + 1` $y    
  echo "*              ��  ��  ά  ��             *"
  tput cup `expr $x + 2` $y
  echo "************* ���PBLSϵͳ���� ************"
  tput cup `expr $x + 3` $y
  echo "*                                         *"
  tput cup `expr $x + 4` $y
  echo "*                                         *"
  tput cup `expr $x + 5` $y
  echo "*                                         *"
  tput cup `expr $x + 6` $y
  echo "*            �������                   *" 
  tput cup `expr $x + 7` $y
  echo "*                                         *"
  tput cup `expr $x + 8` $y     
  echo "*                                         *"
  tput cup `expr $x + 9` $y
  echo "*               0   ����                  *"
  tput cup `expr $x + 10` $y         
  echo "*                                         *"
  tput cup `expr $x + 11` $y
  echo "*                                         *"
  tput cup `expr $x + 12` $y
  echo "*******************************************"
}

display1_1_2()
{
  clear
  tput cup $x $y
  echo "************** PBLSά��ϵͳ ***************"
  tput cup `expr $x + 1` $y    
  echo "*              ��  ��  ά  ��             *"
  tput cup `expr $x + 2` $y
  echo "********* �� �� �� Ϣ �� �� ״ ̬ *********"
  tput cup `expr $x + 3` $y
  echo "*                                         *"
  tput cup `expr $x + 4` $y
  echo "*                                         *"
  tput cup `expr $x + 5` $y
  echo "*          ��Ϣ����״̬��                 *"
  tput cup `expr $x + 6` $y
  echo "*                                         *" 
  tput cup `expr $x + 7` $y 
  echo "*                                         *"
  tput cup `expr $x + 8` $y     
  echo "*                                         *"
  tput cup `expr $x + 9` $y
  echo "*               0   ����                  *"
  tput cup `expr $x + 10` $y         
  echo "*                                         *"
  tput cup `expr $x + 11` $y
  echo "*                                         *"
  tput cup `expr $x + 12` $y
  echo "*******************************************"
}


pblschk()
{
rm -f tmp.txt
rm -f tmp.txt1
  pblschk.sh>tmp.txt
  grep "WARNING" tmp.txt>tmp1.txt
  if test $? -ne 0 ; then
	  echo "��������"
    else
    echo "�����쳣"
  fi
rm -f tmp.txt
rm -f tmp1.txt
}

seepbls_ipcs()
{
  rm -f tmp.txt
  rm -f tmp.txt1
  ipcs -oq | grep $LOGNAME >tmp.txt
  cut -c66-68 tmp.txt>tmp1.txt
  grep '[123456789]' tmp1.txt >tmp.txt
  if test $? -ne 0 ; then
	  echo "��Ϣ��������"
    else
    echo "��Ϣ�����쳣"
  fi
}
display_time()
{
#while sleep 1
#do
#SysDate=`date +%Y%m%d%H%M`
SysDate=`date +%D`
SysTimeH=`date +%H`
SysTimeM=`date +%M`
#SysTimeS=`date +%S`
echo "[40;31m" 
tput cup `expr $x + 11` `expr $y + 7`
echo "Date:$SysDate       Time:  $SysTimeH:$SysTimeM"
echo "[40;37m"
#tput chts
#done
}

clear
echo "[40;37m"
tput init
tput civis 
display
tput cup `expr $x + 11` `expr $y + 7`
display_time
while :
do
len=0
while [ $len -ne 1 ]
do
tput cup `expr $x + 13` $y
echo "��ѡ��"
tput cup `expr $x + 13` `expr $y + 8`
echo "                            "
tput cup `expr $x + 13` `expr $y + 8`
read  select
len=`echo $select|awk '{print length($0)}'`
done
tput cup `expr $x + 13` `expr $y + 8`
case $select in
1) 
   display1_1
   tput cup `expr $x + 11` `expr $y + 7`
   display_time
   tput cup `expr $x + 13` $y
   echo "��ѡ��"
   while :
   do
   len=0
   while [ $len -ne 1 ]
   do
   tput cup `expr $x + 13` `expr $y + 8`
   echo "                          "
   tput cup `expr $x + 13` `expr $y + 8`
   read select_1_1
   len=`echo $select_1_1|awk '{print length($0)}'`
   done
   tput cup `expr $x + 13` `expr $y + 8`
   case $select_1_1 in
   1)
     clear
     display1_1_1
     tput cup `expr $x + 11` `expr $y + 7`
     display_time     
     tput cup `expr $x + 6` `expr $y + 23`
     echo "          "
     tput cup `expr $x + 6` `expr $y + 23`
     pblschk
     tput cup `expr $x + 13` $y
     echo "��ѡ��"
     while :
     do
     len=0
     while [ $len -ne 1 ]
     do
     tput cup `expr $x + 13` `expr $y + 8`
     echo "                           "
     tput cup `expr $x + 13` `expr $y + 8`
     read select_1_1_1
     len=`echo $select_1_1_1|awk '{print length($0)}'`
     done
     tput cup `expr $x + 13` `expr $y + 8`
     case $select_1_1_1 in
     0) display1_1
        tput cup `expr $x + 11` `expr $y + 7`
        display_time     
        tput cup `expr $x + 13` $y
        echo "��ѡ��"
        break
        ;;
     *)
     ;;
     esac
     done
   ;;
   2) 
     clear
     display1_1_2
     tput cup `expr $x + 11` `expr $y + 7`
     display_time   
     tput cup `expr $x + 5` `expr $y + 25`
     echo "          "
     tput cup `expr $x + 5` `expr $y + 25`
     seepbls_ipcs
     tput cup `expr $x + 7` `expr $y + 25`
     tput cup `expr $x + 13` $y
     echo "��ѡ��"
     while :
     do
     len=0
     while [ $len -ne 1 ]
     do
     tput cup `expr $x + 13` `expr $y + 8`
     echo "                              "
     tput cup `expr $x + 13` `expr $y + 8`
     read select_1_1_2
     len=`echo $select_1_1_2|awk '{print length($0)}'`
     done
     tput cup `expr $x + 13` `expr $y + 8`
     case $select_1_1_2 in
     0) display1_1
        tput cup `expr $x + 11` `expr $y + 7`
        display_time     
        tput cup `expr $x + 13` $y
        echo "��ѡ��"
        break
        ;;
     *)
     ;;
     esac
     done
   ;;
   0) display
      tput cup `expr $x + 11` `expr $y + 7`
      display_time    
      break   
      ;;
   *)
   ;;
   esac
   done
;;

0)
  clear 
  echo "[40;32m"
  exit
  ;;
*)
;;
esac
done
