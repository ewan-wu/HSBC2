sqlplus -s $DBUSER/$DBPWD <<EOF >/dev/null
spool UserList.txt;
select dept_id,tlr_id,tlr_name,work_flag from pbtlrctl order by dept_id,tlr_id,work_flag;
spool off;
