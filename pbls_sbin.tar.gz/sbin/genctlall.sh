#!/usr/bin/sh

FILES=`ls ${APPL}/db/sql/*.sql`

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	echo ${table}
	genctl ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
done

exit 0

