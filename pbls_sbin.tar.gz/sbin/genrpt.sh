#!/usr/bin/sh

if [ $# != 3 ]
then
	echo "Usage: genrpt.sh [REPORT_NAME] [DEPT_ID] [TELLER_ID]"
	exit 1
fi

RPT_NM=$1
DPT_ID=$2
TLR_ID=$3

$APPL/bin/batch/$RPT_NM 251 O 1 1 $DPT_ID $TLR_ID
if [ $? -ne 0 ]; then
	echo "Exec $RPT_NM Error!"
	exit 1
fi

/usr/bin/rm -f $APPL/iodata/report/$RPT_NM.$DPT_ID.$TLR_ID

UNDERLINE="_"

$APPL/bin/ddrpt $APPL/iodata/TXT/$DPT_ID/$RPT_NM$UNDERLINE$TLR_ID.txt > $APPL/iodata/report/$RPT_NM.$DPT_ID.$TLR_ID
if [ $? -ne 0 ]; then
	echo "Exec ddrpt Error!"
	exit 1
fi

exit 0

