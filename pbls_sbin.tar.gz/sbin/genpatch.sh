#!/usr/bin/ksh

module=cds
phase=SIT2
alldiff=/tmp/alldiff.txt
allchanged=/tmp/allchanged.txt
allnew=/tmp/allnew.txt
allremove=/tmp/allremove.txt

if [ $# -ne 2 ]; then
	echo "Usage: $0 last-release-date new-release-date"
	exit 1
fi

echo "========= cvs commit ========="
cvs commit -m "Automatic cvs commit for ${phase}-$2 release."

echo "========= get different from last release [tag:version_$1_${phase}] ========="
cvs rdiff -r version_$1_${phase} -s ${module} > ${alldiff}

grep "changed from" ${alldiff} | cut -f2 -d " " > ${allchanged}
grep "is new" ${alldiff} | cut -f2 -d " " > ${allnew}
grep "is removed" ${alldiff} | cut -f2 -d " " > ${allremove}
echo "Changed Files:" > ${module}-modify-list.txt
cat ${allchanged} >> ${module}-modify-list.txt
echo "New Files:" >> ${module}-modify-list.txt
cat ${allnew} >> ${module}-modify-list.txt
echo "Remove Files:" >> ${module}-modify-list.txt
cat ${allremove} >> ${module}-modify-list.txt

echo "========= changed file list ========="
cat ${allchanged}

echo "========= new file list ========="
cat ${allnew}

echo "========= remove file list ========="
cat ${allremove}

echo "========= generate patch ========="
tar cvf ${module}.$2.tar `cat ${allchanged} ${allnew}`
compress ${module}.$2.tar

echo "========= cvs add tag version_$2_${phase} ========="
cvs rtag version_$2_${phase} ${module}

rm -f ${alldiff} ${allchanged} ${allnew} ${allremove}
