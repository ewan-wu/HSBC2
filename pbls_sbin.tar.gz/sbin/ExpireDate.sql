select EXPIRY_DATE from user_users;
