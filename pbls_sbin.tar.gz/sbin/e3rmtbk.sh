#!/usr/bin/sh

if [ $# != 3 ]
then
	echo "Usage: e3rmtbk.sh [E3-USER and IP] [E3-PATH] [E3-FILE]"
	exit 1
fi

/usr/bin/rm -f ./ftpinput

echo "rename $2/$3 $2/../outbk/$3" > ./ftpinput

sftp -b ./ftpinput $1

if [ $? -ne 0 ]; then
	echo "Exec sftp Error!"
	exit 1
fi

exit 0

