#!/bin/sh
echo "Please enter the 3DES key: "
read key
len=`expr length $key`

if [ "$len" -eq "24" ]
then
	echo "first key length key ok"
else
	echo "WARNING:The length of key you entered is [$len] do not equal 24, please reset it again!"
	exit -1
fi

echo "please enter the 3DES key again: "
read key2
len2=`expr length $key2`


if [ "$len2" -eq "24" ]
then
	echo "first key length key ok"
else
	echo "WARNING:The length of key you entered is [$len2] do not equal 24, please reset it again!"
	exit -1
fi

if test "$key" = "$key2"
then
	setkey $key
	sleep 1
	killicbcfe
	sleep 1
	starticbcfe && echo "restart process OK!"
else
	echo "WARNING: The key you entered twice are not the same:fist[$key] second[$key2]"
	echo "please reset it again!"
	exit -1
fi
exit 0
