#!/usr/bin/sh

if [ $# != 4 ]
then
	echo "Usage: genrpt_online.sh [REPORT_NAME] [DEPT_ID] [TELLER_ID] [BATCH_NO]"
	exit 1
fi

RPT_NM=$1
DPT_ID=$2
TLR_ID=$3
BATCHNO=$4

$APPL/bin/batch/$RPT_NM $BATCHNO O 1 1 $DPT_ID $TLR_ID
if [ $? -ne 0 ]; then
	echo "Exec $RPT_NM Error!"
	exit 1
fi

/usr/bin/rm -f $APPL/iodata/report/$RPT_NM.$DPT_ID.$TLR_ID

UNDERLINE="_"

$APPL/bin/ddrpt $APPL/iodata/TXT/$DPT_ID/$RPT_NM$UNDERLINE$TLR_ID.txt > $APPL/iodata/report/$RPT_NM.$DPT_ID.$TLR_ID
if [ $? -ne 0 ]; then
	echo "Exec ddrpt Error!"
	exit 1
fi

exit 0

