crtmqm -lf 4096 -lp 5 -ls 58 PAID_QMBOASH
strmqm PAID_QMBOASH
runmqsc PAID_QMBOASH
def ql(PAIDASIA.PBLS) maxdepth(10000) maxmsgl(1048576) defpsist(yes) replace;
def ql(PBLS.PAIDASIA) maxdepth(10000) maxmsgl(1048576) defpsist(yes) replace;
