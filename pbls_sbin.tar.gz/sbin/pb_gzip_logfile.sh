echo "----begin gzip log files---"
echo "gzip pbls log files"
find ${APPL}/log -name "*20[0-9][0-9]-[01][0-9]-[0-3][0-9]*.log" -exec gzip {} \;
echo "gzip icbcfe log files"
find ${APPL}/icbcfe/log -name "*20[0-9][0-9]-[01][0-9]-[0-3][0-9]*.log" -exec gzip {} \;
echo "----end gzip log files----"
