#!/usr/bin/sh

if [ $# != 3 ]
then
	echo "Usage: genrpt_batch.sh [REPORT_NAME] [DATE] [BATCH_NO]"
	exit 1
fi

RPT_NM=$1
RPT_DATE=$2
BATCHNO=$3

$APPL/bin/batch/$RPT_NM $BATCHNO N 1 1 SYS $RPT_DATE
if [ $? -ne 0 ]; then
	echo "Exec $RPT_NM Error!"
	exit 1
fi

/usr/bin/rm -f $APPL/iodata/report/$RPT_NM.$RPT_DATE

UNDERLINE="_"

$APPL/bin/ddrpt $APPL/iodata/TXT/SYS/$RPT_NM$UNDERLINE$RPT_DATE.txt > $APPL/iodata/report/$RPT_NM.$RPT_DATE
if [ $? -ne 0 ]; then
	echo "Exec ddrpt Error!"
	exit 1
fi
$APPL/bin/batch/rptbill_M $RPT_DATE
if [ $? -ne 0 ]; then
	echo "Exec ddrpt Error!"
	exit 1
fi

exit 0

