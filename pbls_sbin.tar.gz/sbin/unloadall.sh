#!/usr/bin/sh

FILES=`ls ${APPL}/db/sql/*/*.sql`

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	dir=`dirname ${file}`
	module=`basename ${dir}`
	echo ${module} ${table}
	unload.sh ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
done

