#!/usr/bin/sh

FILES=`ls ${APPL}/db/sql/*.sql`

cd ${APPL}/tmp
/usr/bin/rm -f libpbdbsvr.exp
/usr/bin/rm -f pbdbsvr.mak
/usr/bin/rm -f wd_incl.h

cat /dev/null > pbdbsvr.obj
cat /dev/null > libpbdbsvr.exp
/usr/bin/cp ${APPL}/src/tools/gendbs/tmp.mak ${APPL}/tmp
/usr/bin/cp ${APPL}/src/tools/gendbs/dbsvr_stub.pc ${APPL}/src/dbsvr

echo "#ifndef _WD_INCL_H" > wd_incl.h
echo "#define _WD_INCL_H" >> wd_incl.h

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	echo ${table}
	gendbs ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
	echo "\t\$(SRCHOME)/dbsvr_${table}.o \\" >> pbdbsvr.obj
	echo "\t\$(SRCHOME)/init_${table}_hvar.o \\" >> pbdbsvr.obj
	upcase=`echo $table | /usr/bin/awk '{print toupper($1)}'`
	#echo "Dbs${upcase}" >> libpbdbsvr.exp
	cat ${APPL}/incl/dbincl/${table}.wd >> wd_incl.h
done

echo "#endif" >> wd_incl.h

sed "/^PRGOBJS/r pbdbsvr.obj" tmp.mak > pbdbsvr.mak

/usr/bin/mv -f pbdbsvr.mak ${APPL}/src/dbsvr
#/usr/bin/mv -f libpbdbsvr.exp ${APPL}/mak/exp
/usr/bin/mv -f wd_incl.h ${APPL}/incl/dbincl
/usr/bin/rm -f ${APPL}/incl/dbincl/*.wd

