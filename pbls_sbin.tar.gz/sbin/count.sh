a=`grep Record $1|wc -l`
a=` expr $a / 2 `
echo $a > $2
