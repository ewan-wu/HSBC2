#!/bin/sh
echo "please enter the key:"
read key
echo "$key"
len=`expr length $key`
echo "$len"

