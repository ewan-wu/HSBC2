#!usr/bin/sh	
make -f ../src/tools/gendbs/gendbs.mak 
	make -f ../src/tools/genctl/genctl.mak 
	make -f ../src/tools/holiday/holiday.mak 
	make -f ../src/tools/ddrpt/ddrpt.mak 
	make -f ../src/tools/topsec/src/scubenc.mak 
	make -f ../src/tools/topsec/src/crmskey.mak 
	make -f ../src/tools/topsec/src/keymgr.mak 
	make -f ../src/dbsvr/pbdbsvr.mak 
	make -f ../src/common/pbcommon.mak 
	make -f ../src/others/msgque/pbrunque/pbrunque.mak 
	make -f ../src/others/msgque/pbkillque/pbkillque.mak 
	make -f ../src/others/msgque/pbdumpq/pbdumpq.mak 
	make -f ../src/comm/pbtlrcomm/pbtlrcomm.mak 
	make -f ../src/comm/pbhubcomm/pbhubcomm.mak 
#	make -f ../src/comm/pbe3comm/pbe3comm.mak 
#	make -f ../src/comm/pbccbcomm/pbccbcomm.mak 
#	make -f ../src/comm/pbicbccomm/pbicbccomm.mak 
#	make -f ../src/comm/pbddcomm/pbddcomm.mak 
	make -f ../src/toctl/pbtoctl_seq.mak 
	make -f ../src/errsvr/pberrsvr.mak 
	make -f ../src/bridge/pbtlrbdg/pbtlrbdg.mak 
	make -f ../src/bridge/pbhubbdg/pbhubbdg.mak 
#	make -f ../src/bridge/pbe3bdg/pbe3bdg.mak 
#	make -f ../src/bridge/pbccbbdg/pbccbbdg.mak 
#	make -f ../src/bridge/pbicbcbdg/pbicbcbdg.mak 
	make -f ../src/mngsvr/pbsysmng/pbsysmng.mak 
	make -f ../src/mngsvr/pboprmng/pboprmng.mak 
#	make -f ../src/mngsvr/pbfilemng/pbfilemng.mak 
#	make -f ../src/swtsvr/pbe3swt/pbe3swt.mak 
#	make -f ../src/swtsvr/pbccbswt/pbccbswt.mak 
	make -f ../src/swtsvr/pbrptswt/pbrptswt.mak 
	make -f ../src/swtsvr/pbhubswt/pbhubswt.mak 
	make -f ../src/swtsvr/pbicbcinswt/pbicbcinswt.mak 
	make -f ../src/swtsvr/pbicbcoutswt/pbicbcoutswt.mak 
	make -f ../src/timer/pbsystmr/pbsystmr.mak 
	make -f ../src/timer/pboprtmr/pboprtmr.mak 
#	make -f ../src/batch/rpt1004/rpt1004.mak 
#	make -f ../src/batch/rpt1005/rpt1005.mak 
#	make -f ../src/batch/rpt1007a/rpt1007a.mak 
#	make -f ../src/batch/rpt1007b/rpt1007b.mak 
#	make -f ../src/batch/rpt1051/rpt1051.mak 
#	make -f ../src/batch/rpt7000/rpt7000.mak 
#	make -f ../src/batch/rpt7011/rpt7011.mak 
#	make -f ../src/batch/rpt7012/rpt7012.mak 
#	make -f ../src/batch/rpt7050/rpt7050.mak 
#	make -f ../src/batch/rpt7100/rpt7100.mak 
#	make -f ../src/batch/rpt7110/rpt7110.mak 
#	make -f ../src/batch/rpt7160/rpt7160.mak 
#	make -f ../src/batch/rptb001/rptb001.mak 
#	make -f ../src/batch/rptb002/rptb002.mak 
#	make -f ../src/batch/rptb003a/rptb003a.mak 
#	make -f ../src/batch/rptb003b/rptb003b.mak 
#	make -f ../src/batch/rptb003c/rptb003c.mak 
#	make -f ../src/batch/rptb003d/rptb003d.mak 
#	make -f ../src/batch/rptb004a/rptb004a.mak 
#	make -f ../src/batch/rptb004b/rptb004b.mak 
#	make -f ../src/batch/rptb006/rptb006.mak 
	make -f ../src/batch/pbls_night_batch_mng/pbls_night_batch_mng.mak 
	make -f ../src/batch/pbls_night_batch_bchk/pbls_night_batch_bchk.mak 
	make -f ../src/batch/nb_day_switch/nb_day_switch.mak 
	make -f ../src/batch/nb_ctl_reset/nb_ctl_reset.mak 
	make -f ../src/batch/nb_data_clear/nb_data_clear.mak 

