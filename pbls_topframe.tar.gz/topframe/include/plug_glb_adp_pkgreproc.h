/*
 *
 * 
 * for pkg reproc.
 * 
 * 
 * FileName: plug_glb_adp_pkgreproc.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_GLB_ADP_PKGREPROC_H_20111103112754_
#define _PLUG_GLB_ADP_PKGREPROC_H_20111103112754_
/*--------------------------- Include files -----------------------------*/
#include "plug_mgr.h"

/*--------------------------- Macro define ------------------------------*/
#define CFG_GLB_PLUGADP_PKG_BUFLEN "buflen"
#define CFG_GLB_PLUGADP_PKG_PROCLIST "proclist"
#define CFG_GLB_PLUGADP_PKG_MODLIST "modlist"
#define CFG_GLB_PLUGADP_PKG_EVTTYPE "evttype"
/*---------------------------- Type define ------------------------------*/
typedef int (*PFN_PLUG_PKGREPROC_FUNC)(char *psIn, int iLen, char *psOut, int *piLen);
typedef PFN_PLUG_PKGREPROC_FUNC (*PFN_PLUG_PKGREPROC_GETFUNC)(char * psFunc);
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_PLUG_GLB_ADP_PKGREPROC_H_20111103112754_*/
/*-----------------------------  End ------------------------------------*/
