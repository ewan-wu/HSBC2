/*
 *
 * 
 * global define.
 * 
 * 
 * FileName: glb_dic.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _GLB_DIC_H_20100107092831_
#define _GLB_DIC_H_20100107092831_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_GLB_DIC_H_20100107092831_*/
/*-----------------------------  End ------------------------------------*/
