/*
 *
 * 
 * global ipc msg queue plug.
 * 
 * 
 * FileName: plug_glbmsgque.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_GLBMSGQUE_H_20100914180047_
#define _PLUG_GLBMSGQUE_H_20100914180047_
/*--------------------------- Include files -----------------------------*/
#include "plug_mgr.h"
#include "ipc_msgqueue.h"

/*--------------------------- Macro define ------------------------------*/
#define EVENT_PLUG_IPC_MSGQUE_NEWMSG 10001
#define EVENT_PLUG_IPC_MSGQUE_GETMSG 10002

#define ERR_PLUG_IPC_MSGQUE_BASE       (-200) 
#define ERR_PLUG_IPC_MSGQUE_SENDMSG (ERR_PLUG_IPC_MSGQUE_BASE - 1);
#define ERR_PLUG_IPC_MSGQUE_RCVMSG (ERR_PLUG_IPC_MSGQUE_BASE - 2);

#define CFG_IPC_MSGQUE_DATALIB "datalib"
/*#define CFG_IPC_MSGQUE_DATAFUN "datalibfun"*/
#define CFG_IPC_MSGQUE_DATACFG "datalibcfg"
#define CFG_IPC_MSGQUE_TRYTIME "trytime"
#define CFG_IPC_MSGQUE_MSGBUF_MAX "bufmax"
#define CFG_IPC_MSGQUE_LOADFILEMSG "loadfilemsg"

#define CFG_IPC_MSGQUE_MQITFS "mqitfs"
#define CFG_IPC_MSGQUE_HOOKS "hooks"

#define CFG_IPC_MSGQUE_MQITF_MQTYPE "mqtype"
#define CFG_IPC_MSGQUE_MQITF_LIB "lib"
#define CFG_IPC_MSGQUE_MQITF_CREATECTX "CreateCtx"
#define CFG_IPC_MSGQUE_MQITF_INIT "Init"
#define CFG_IPC_MSGQUE_MQITF_PUT "Put"
#define CFG_IPC_MSGQUE_MQITF_GET "Get"
#define CFG_IPC_MSGQUE_MQITF_CFM "Cfm"
#define CFG_IPC_MSGQUE_MQITF_ATTR_SET "AttrSet"
#define CFG_IPC_MSGQUE_MQITF_ATTR_GET "AttrGet"
#define CFG_IPC_MSGQUE_MQITF_FINAL "Final"

#define ENV_IPC_MSGQUE_WAITEXIT "_IPC_WAIT4EXIT"

/*---------------------------- Type define ------------------------------*/
typedef struct {
    T_IPC_MSGQ_MD tMsgMd;
    int iMsgLen;
    void *pMsgBody;
    int iOption;
    int iExtData;
    void *pExtData;
} T_PLUG_IPC_MSGQUEUE_EVENTDATA;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_PLUG_GLBMSGQUE_H_20100914180047_*/
/*-----------------------------  End ------------------------------------*/
