/*
 *
 * 
 * process onstart glb plug.
 * 
 * 
 * FileName: plug_glbstart.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_GLBSTART_H_20100603175410_
#define _PLUG_GLBSTART_H_20100603175410_
/*--------------------------- Include files -----------------------------*/
#include "plug_mgr.h"

/*--------------------------- Macro define ------------------------------*/
#define CFG_BASE_APP_DEF_SECTION "general"
#define CFG_BASE_APP_PREFIX "prefix"
#define CFG_BASE_APP_LOGFILE "logfile"
#define CFG_BASE_APP_RUNLEVEL "runlevel"

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_PLUG_GLBSTART_H_20100603175410_*/
/*-----------------------------  End ------------------------------------*/
