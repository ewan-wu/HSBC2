/*
 *
 *
 * msg_report svrid helper.
 *
 *
 * FileName: msg_report_svrid.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _MSG_REPORT_SVRID_H_20101203143330_
#define _MSG_REPORT_SVRID_H_20101203143330_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: MSG_SetSvrId
 *
 * @desc: ����msgsvr��svrid
 *
 * @param pnMsgSvrId: msgsvr��svrid
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int MSG_SetSvrId(int *pnMsgSvrId);

/**
 * @function: MSG_GetSvrId
 *
 * @desc: ���msgsvr��svrid
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int MSG_GetSvrId(void);

#ifdef __cplusplus
}
#endif

#endif /*_MSG_REPORT_SVRID_H_20101203143330_*/
/*-----------------------------  End ------------------------------------*/
