/*
 *
 *
 * tcp listener functions.
 *
 *
 * FileName: net_tcp_listener.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _NET_TCP_LISTENER_H_20100408163037_
#define _NET_TCP_LISTENER_H_20100408163037_
/*--------------------------- Include files -----------------------------*/
#include "net_tcp_def.h"
#include "log_info.h"

/*--------------------------- Macro define ------------------------------*/
#define NET_TCP_LISTENER_LISTENDEPTH 200

/*---------------------------- Type define ------------------------------*/
typedef int (*PFN_NET_TCPBIND)(void *this, int iOptions);
typedef int (*PFN_NET_TCPACCEPT)(void *this, int iOptions);

typedef struct {
    char sLocalAddr[DLEN_NET_TCP_FILENAME];
    int iLocalPort;
    
    /*ֻ������*/
    int iSocketNo;
    char sErrorStr[DLEN_NET_TCP_ERRORSTR];
    int iErrorCode;
    
    /*����*/
    PFN_NET_TCPOBJINIT pfnInit;
    PFN_NET_TCPBIND pfnBind;
    PFN_NET_TCPACCEPT pfnAccept;
    PFN_NET_TCPOBJCLOSE pfnClose;
    PFN_NET_TCP_LOGPRINT pfnLogPrint;
} T_NET_TCPLISTENER;

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: netTcpListenerCreate
 *
 * @desc: ����TCPLISTENER����
 *
 * @param ptTcpListener: listener����
 * @param pfnLogPrint: ��־����
 *
 * @return int : 0:�ɹ� <0:����
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int netTcpListenerCreate( T_NET_TCPLISTENER * ptTcpListener, PFN_NET_TCP_LOGPRINT pfnLogPrint);

#ifdef __cplusplus
}
#endif

#endif /*_NET_TCP_LISTENER_H_20100408163037_*/
/*-----------------------------  End ------------------------------------*/
