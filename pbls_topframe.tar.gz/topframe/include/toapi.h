/*
 *
 *
 *  Time Out Api.
 *
 *
 * FileName: toapi.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *
 */

#ifndef _TOAPI_H_20101130112748_
#define _TOAPI_H_20101130112748_

/*------------------------ Include files ------------------------*/

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define TOC_RET_OK         0
#define TOC_RET_TIMEOUT    1
#define TOC_RET_OTHER_ERR -1

#define DLEN_TO_KEY_LEN 64
#define DLEN_TO_INFO_LEN 4086

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/

#if 0
#pragma mark -
#pragma mark < Global functions declaration >
#endif
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif


/**
 * @function: tocInit
 *
 * @desc: Init to all info
 *
 * @param psFileName: to ini file name
 * @param psSection: to ini section name
 *
 * @return int: 0 - ok ; <0 - err
 *
 */
int tocInit(char *psFileName, char *psSection);

/**
 * @function: tocStart
 *
 * @desc: start to by Key
 *
 * @param psKey: key of message
 * @param psMsg: time out message
 *
 * @return int: 0 - ok ; <0 - err
 *
 */
int tocStart(char *psKey, char *psMsg);

/**
 * @function: tocStartSendMsg
 *
 * @desc: start to by key , when to send message
 *
 * @param psKey: key of message
 * @param psMsg: time out message
 * @param nSendId: message send id
 * @param nTimeOut: message time out time
 *
 * @return int: 0 - ok ; <0 - err
 *
 */
int tocStartSendMsg(char *psKey, char *psMsg, int nSendId, int nTimeOut);

/**
 * @function: tocEnd
 *
 * @desc: end of message
 *
 * @param psKey: key of message
 *
 * @return int: 0 - ok ; <0 - err
 *
 */
int tocEnd(char *psKey);
    
#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /* _TOAPI_H_20101130112748_ */
/*--------------------- End -------------------------------------*/
