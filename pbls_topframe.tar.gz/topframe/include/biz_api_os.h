/*
 *
 *
 * os api for biz.
 *
 *
 * FileName: biz_api_os.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _BIZ_API_OS_H_20110804201706_
#define _BIZ_API_OS_H_20110804201706_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: BIZ_OSProcExists
 *
 * @desc: �鿴ָ�������Ƿ����
 *
 * @param psPID: ����PID
 * @param psTag: �����Tag
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int BIZ_OSProcExists(char *psPID, char *psTag);

#ifdef __cplusplus
}
#endif

#endif /*_BIZ_API_OS_H_20110804201706_*/
/*-----------------------------  End ------------------------------------*/
