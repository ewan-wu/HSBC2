/*
 *
 * 
 * thread functions.
 * 
 * 
 * FileName: os_thread.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _OS_THREAD_H_20100317165714_
#define _OS_THREAD_H_20100317165714_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_OS_THREAD_H_20100317165714_*/
/*-----------------------------  End ------------------------------------*/
