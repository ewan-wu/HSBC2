/*
 *
 *
 * config file operator.
 *
 *
 * FileName: cfg_oper.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _CFG_OPER_H_20100528230015_
#define _CFG_OPER_H_20100528230015_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#define CFG_PLUG_LOADCFG(KEY,VALUE) \
        iRet = CfgOperGetStr(f_ptRTCoreCtx->sCfgSection, f_ptPlugVar->sCfgSection, KEY, NULL, VALUE, sizeof(VALUE), f_ptRTCoreCtx->sCfgFile)

#define CFG_PLUG_LOADCFG2(KEY,VALUE) \
    do {                                                \
         iRet = CfgOperGetStr(f_ptRTCoreCtx->sCfgSection, f_ptPlugVar->sCfgSection, KEY, NULL, VALUE, sizeof(VALUE), f_ptRTCoreCtx->sCfgFile);             \
         if(strlen(VALUE) == 0) {                                                                                   \
             _LOGPRINT(LOG_ERR, "get [%s,%s,%s] cfgfile:[%s] ret:[%d]", f_ptRTCoreCtx->sCfgSection, f_ptPlugVar->sCfgSection, KEY, f_ptRTCoreCtx->sCfgFile, iRet); \
             return ERR_PLUG_MGR_CFG;                                                                   \
         }                                                                                              \
         _LOGPRINT(LOG_TRC, "%s[%s]", KEY, VALUE);                       \
     } while(0)
             
#define CFG_PLUG_LOADCFG3(KEY,VALUE) \
    do {                                                \
         iRet = CfgOperGetStr(f_ptRTCoreCtx->sCfgSection, f_ptPlugVar->sCfgSection, KEY, NULL, VALUE, sizeof(VALUE), f_ptRTCoreCtx->sCfgFile);             \
         if(strlen(VALUE) == 0) {                                                                                   \
             _LOGPRINT(LOG_TRC, "get [%s,%s,%s] cfgfile:[%s] ret:[%d]", f_ptRTCoreCtx->sCfgSection, f_ptPlugVar->sCfgSection, KEY, f_ptRTCoreCtx->sCfgFile, iRet); \
             iRet = CfgOperGetStr(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, KEY, NULL, VALUE, sizeof(VALUE), f_ptRTCoreCtx->sCfgFile);             \
             if(strlen(VALUE) == 0) {                                                                                                               \
                 _LOGPRINT(LOG_ERR, "get [%s,%s,%s] cfgfile:[%s] error:[%d] ", f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, KEY, f_ptRTCoreCtx->sCfgFile, iRet); \
                 return ERR_PLUG_MGR_CFG;                                                                   \
             }                                                                                               \
         }                                                                                              \
         _LOGPRINT(LOG_TRC, "%s[%s]", KEY, VALUE);                       \
     } while(0)

#define CFG_PLUG_LOADCFG4(KEY,VALUE) \
    do {                                                \
         iRet = CfgOperGetStr(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, KEY, NULL, VALUE, sizeof(VALUE), f_ptRTCoreCtx->sCfgFile);             \
         if(strlen(VALUE) == 0) {                                                                                                               \
             _LOGPRINT(LOG_ERR, "get [%s,%s,%s] cfgfile:[%s] error:[%d] ", f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, KEY, f_ptRTCoreCtx->sCfgFile, iRet); \
             return ERR_PLUG_MGR_CFG;                                                                   \
         }                                                                                               \
         _LOGPRINT(LOG_TRC, "%s[%s]", KEY, VALUE);                       \
     } while(0)

#define CFG_PLUG_LOADCFG5(KEY,VALUE) \
    do {                                                \
         iRet = CfgOperGetStr(f_ptRTCoreCtx->sCfgSection, f_ptPlugVar->sCfgSection, KEY, NULL, VALUE, sizeof(VALUE), f_ptRTCoreCtx->sCfgFile);             \
         if(strlen(VALUE) == 0) {                                                                                   \
             _LOGPRINT(LOG_TRC, "get [%s,%s,%s] cfgfile:[%s] ret:[%d]", f_ptRTCoreCtx->sCfgSection, f_ptPlugVar->sCfgSection, KEY, f_ptRTCoreCtx->sCfgFile, iRet); \
             iRet = CfgOperGetStr(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, KEY, NULL, VALUE, sizeof(VALUE), f_ptRTCoreCtx->sCfgFile);             \
             if(strlen(VALUE) == 0) {                                                                                                               \
                 _LOGPRINT(LOG_TRC, "get [%s,%s,%s] cfgfile:[%s] ret:[%d] ", f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, KEY, f_ptRTCoreCtx->sCfgFile, iRet); \
             }                                                                                               \
         }                                                                                              \
         _LOGPRINT(LOG_TRC, "%s[%s]", KEY, VALUE);                       \
     } while(0)
/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @function: CfgOperGetStr
 *
 * @desc: ��ȡ����
 *
 * @param psSection: ���ö�
 * @param psObj: ����
 * @param psKey: ��
 * @param psDefault: Ĭ��ֵ
 * @param psOutBuf: ���������
 * @param iLenBuf: �������������
 * @param psCfgFile: �����ļ�
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int CfgOperGetStr(char *psSection, char *psObj, char *psKey,
        char *psDefault,  char *psOutBuf, int iLenBuf, char *psCfgFile);


/**
 * @function: CfgOperMGetStr
 *
 * @desc: �Ӷ�������ļ��л�ȡ����
 *
 * @param psSection: ���ö�
 * @param psObj: ����
 * @param psKey: ��
 * @param psDefault: Ĭ��ֵ
 * @param psOutBuf: ���������
 * @param iLenBuf: �������������
 * @param psCfgFile: �����ļ�
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int CfgOperMGetStr(char *psSection, char *psObj, char *psKey,
        char *psDefault,  char *psOutBuf, int iLenBuf, char *psCfgFile[]);


/**
 * @function: CfgOperGetInt
 *
 * @desc: �������ļ��л�ȡ����
 *
 * @param psSection: ���ö�
 * @param psObj: ����
 * @param psKey: ��
 * @param iDefault: Ĭ��ֵ
 * @param psCfgFile: �����ļ�
 *
 * @return int: ����ֵ
 *
 */
int CfgOperGetInt(char *psSection, char *psObj, char *psKey, int iDefault, char *psCfgFile);

#ifdef __cplusplus
}
#endif

#endif /*_CFG_OPER_H_20100528230015_*/
/*-----------------------------  End ------------------------------------*/
