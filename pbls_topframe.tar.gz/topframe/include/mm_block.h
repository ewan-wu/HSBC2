/*
 *
 * 
 * block mode memory manager.
 * 
 * 
 * FileName: mm_block.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _MM_BLOCK_H_20100129144043_
#define _MM_BLOCK_H_20100129144043_
/*--------------------------- Include files -----------------------------*/
#include "os_shm.h"

/*--------------------------- Macro define ------------------------------*/
#define DLEN_MM_BLK_HDL_BITMAP 1024

/*---------------------------- Type define ------------------------------*/
typedef struct {
    int iUsed;
    int aiBlkInx[DLEN_MM_BLK_HDL_BITMAP];
} T_MM_BLK_ALLOC_HANDLE;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @function: mmBlkInit
 *
 * @desc: 
 *
 * @param iSize: 
 * @param iKey: 
 * @param iMode: 
 * @param iBlkSize: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkInit(int iSize, int iKey, int iMode, int iBlkSize);

/**
 * @function: mmBlkFinal
 *
 * @desc: 
 *
 * @param iBlkId: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkFinal(int iBlkId);

/**
 * @function: mmBlkOpen
 *
 * @desc: 
 *
 * @param iKey: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkOpen(int iKey);

/**
 * @function: mmBlkClose
 *
 * @desc: 
 *
 * @param iBlkId: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkClose(int iBlkId);

/**
 * @function: mmBlkLock
 *
 * @desc: 
 *
 * @param iBlkId: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkLock(int iBlkId);

/**
 * @function: mmBlkUnLock
 *
 * @desc: 
 *
 * @param iBlkId: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkUnLock(int iBlkId);

/**
 * @function: mmBlkAlloc
 *
 * @desc: 
 *
 * @param iBlkId: 
 * @param iSize: 
 * @param piAllocId: 
 * @param iFlg: 
 *
 * @return void * : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
void * mmBlkAlloc(int iBlkId, int iSize, int *piAllocId, int iFlg);

/**
 * @function: mmBlkReAlloc
 *
 * @desc: 
 *
 * @param iBlkId: 
 * @param iSize: 
 * @param iOAllocId: 
 * @param piAllocId: 
 * @param iFlg: 
 *
 * @return void * : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
void * mmBlkReAlloc(int iBlkId, int iSize, int iOAllocId, int *piAllocId, int iFlg);

/**
 * @function: mmBlkFree
 *
 * @desc: 
 *
 * @param iBlkId: 
 * @param iAllocId: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkFree(int iBlkId, int iAllocId);

/**
 * @function: mmBlkCpToUser
 *
 * @desc: 
 *
 * @param iBlkId: 
 * @param iAllocId: 
 * @param pBuf: 
 * @param iLen: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkCpToUser(int iBlkId, int iAllocId, void *pBuf, int iLen);

/**
 * @function: mmBlkCpFromUser
 *
 * @desc: 
 *
 * @param iBlkId: 
 * @param iAllocId: 
 * @param pBuf: 
 * @param iLen: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmBlkCpFromUser(int iBlkId, int iAllocId, void *pBuf, int iLen);

/**
 * @function: mmBlkGetAddr
 *
 * @desc: 
 *
 * @param iBlkId: 
 * @param iBlkIdx: 
 *
 * @return void * : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
void * mmBlkGetAddr(int iBlkId, int iBlkIdx);

/**
 * @function: mmBlkGetAllocHdl
 *
 * @desc: 
 *
 * @param iBlkId: 
 * @param iAllocId: 
 *
 * @return T_MM_BLK_ALLOC_HANDLE * : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
T_MM_BLK_ALLOC_HANDLE * mmBlkGetAllocHdl(int iBlkId, int iAllocId);

#ifdef __cplusplus
}
#endif

#endif /*_MM_BLOCK_H_20100129144043_*/
/*-----------------------------  End ------------------------------------*/
