/*
 *
 *
 * convert datasource.
 *
 *
 * FileName: poc_datasource_cvt.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _POC_DATASOURCE_CVT_H_20101105162641_
#define _POC_DATASOURCE_CVT_H_20101105162641_
/*--------------------------- Include files -----------------------------*/
#include "poc_itf.h"
/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: POC_Datasource4CvtCreateCTX
 *
 * @desc: ������ʽת��poc����Դ�ӿڻ���
 *
 * @param ptDataSource: ����Դ
 * @param ptCrtCtxOpts: ����ѡ��
 * @param ptInitParams: ����Դ��ʼ������
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_Datasource4CvtCreateCTX(T_POC_DATASOURCE *ptDataSource, T_POC_DATASOURCE_CRTCTX_OPTS *ptCrtCtxOpts, T_DATASOURCE_ARG *ptInitParams);

/**
 * @function: POC_Datasource4CvtReleaseCTX
 *
 * @desc: �ͷŸ�ʽת��poc����Դ����
 *
 * @param iOptions: ѡ��
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_Datasource4CvtReleaseCTX(int iOptions);

#ifdef __cplusplus
}
#endif

#endif /*_POC_DATASOURCE_CVT_H_20101105162641_*/
/*-----------------------------  End ------------------------------------*/
