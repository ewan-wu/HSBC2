/*
 *
 *
 *  Plug Ctl.
 *
 *
 * FileName: plug_ctl.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *
 */

#ifndef _PLUG_CTL_H_20101223162323_
#define _PLUG_CTL_H_20101223162323_

/*------------------------ Include files ------------------------*/

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define RT_PLUG_OK 0
#define RT_PLUG_PLUG_NOT_DEFINE -1
#define RT_PLUG_DEFINE_BUF_ERR  -2
#define RT_PLUG_SET_DEFAULT_ERR -3
#define RT_PLUG_CONFIG_ERR      -4
#define RT_PLUG_ALREADY_DEFINE  -5

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/
typedef int (*fncSetDefault)(int nVersion, char *psPlugName, void *ptPlugInfo);

#if 0
#pragma mark -
#pragma mark < Global functions declaration >
#endif
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif
    

/**
 * @function: plugInitInterface
 *
 * @desc: Init All Info
 *
 * @param psFile: interface ini file name
 * @param psSecation: interface ini section name
 *
 * @return int: 0 - ok ; <0 - err
 *
 */
    int plugInitInterface(char *psFile, char *psSecation);

/**
 * @function: plugAddInterface
 *
 * @desc: add iterface to global 
 *
 * @param nVersion: version of interface
 * @param psName: interface name
 * @param fpSetDefault: default function of interface
 *
 * @return int: 0 - ok ; <0 - err
 *
 */
    int plugAddInterface(int nVersion, char *psName, fncSetDefault fpSetDefault);

/**
 * @function: plugAddPlug
 *
 * @desc: add plug to global
 *
 * @param nVersion: version of plug
 * @param psInterfaceName: plug 's interface name
 * @param psName: plug name
 * @param ptData: plug function
 *
 * @return int: 0 - ok ; <0 - err
 *
 */
    int plugAddPlug(int nVersion, char *psInterfaceName, char *psName, void *ptData);
    
#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /* _PLUG_CTL_H_20101223162323_ */
/*--------------------- End -------------------------------------*/
