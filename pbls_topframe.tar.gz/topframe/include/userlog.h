/*
 *
 *
 *  proc usr log.
 *
 *
 * FileName: userlog.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *
 */

#ifndef _USERLOG_H_201112061729_
#define _USERLOG_H_201112061729_

/*------------------------ Include files ------------------------*/
#include <stdarg.h>

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#ifdef  __GNUC__
#define __USELOG_GNUC_EXT__ __attribute__((format (printf, 3, 4)))
#define __USELOG_GNUC_EXT2__ __attribute__((format (printf, 5, 6)))
#else
#define __USELOG_GNUC_EXT__
#define __USELOG_GNUC_EXT2__
#endif

#define LOG_USER_OUT_PUT_END    1

#define LOG_USER_FILE_NO_FIND  -1
#define LOG_USER_FORMAT_ERROR  -2
#define LOG_USER_LINE_TOO_LONG -3
#define LOG_USER_ADD_ERROR     -4
#define LOG_USER_LINE_TOO_MORE -5

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/
typedef struct UserLog* TP_UserLog;

#if 0
#pragma mark -
#pragma mark < Global functions declaration >
#endif
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif
    
    TP_UserLog usrLogInit(int nMaxLevel, int nMaxBuffer);
    int usrLogLoadFile(TP_UserLog ptUserLog, char *psLanguage, char *psDir);
    int usrLogFree(TP_UserLog ptUserLog);
    
    int usrLogInputByList(TP_UserLog ptUserLog, int nErrno, char *psBuffer, va_list tVaList);
    int usrLogInput(TP_UserLog ptUserLog, int nErrno, char *psBuffer, ...)__USELOG_GNUC_EXT__;
    int usrLogClean(TP_UserLog ptUserLog);
    int usrLogOutPut(TP_UserLog ptUserLog, FILE *ptFp, int nIndex);
    int usrLogGetOutPutNum(TP_UserLog ptUserLog);
    
    int usrLogMemOutPutOne(TP_UserLog ptUserLog, char *psBuffer, int nMaxBufferLen, int nErrno, char *psString, ... )__USELOG_GNUC_EXT2__;
    int usrLogMemOutPutOneByList(TP_UserLog ptUserLog, char *psBuffer, int nMaxBufferLen, int nErrno, char *psString, va_list tVaList);
    
#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /* _USERLOG_H_201112061729_ */
/*--------------------- End -------------------------------------*/
