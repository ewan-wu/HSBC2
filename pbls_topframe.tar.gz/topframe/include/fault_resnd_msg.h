/*
 *
 *
 * resend msg.
 *
 *
 * FileName: fault_resnd_msg.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _FAULT_RESND_MSG_H_20110318151851_
#define _FAULT_RESND_MSG_H_20110318151851_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: faultSetPkgdtlTable
 *
 * @desc: �����ݴ��������ñ�
 *
 * @param psTableName: ����
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int faultSetPkgdtlTable(char *psTableName);

/**
 * @function: faultResndMsg
 *
 * @desc: ���·�����Ϣ
 *
 * @param psMsgId: ��ϢID
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int faultResndMsg(char *psMsgId);

#ifdef __cplusplus
}
#endif

#endif /*_FAULT_RESND_MSG_H_20110318151851_*/
/*-----------------------------  End ------------------------------------*/
