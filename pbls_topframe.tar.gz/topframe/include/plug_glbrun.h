/*
 *
 * 
 * global run plug.
 * 
 * 
 * FileName: plug_glbrun.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_GLBRUN_H_20101013173405_
#define _PLUG_GLBRUN_H_20101013173405_
/*--------------------------- Include files -----------------------------*/
#include "plug_mgr.h"
#include "plug_glbpartner.h"
#include "plug_glbmsgque.h"
/*--------------------------- Macro define ------------------------------*/
#define CFG_PLUG_APP_RUN_MSGDIR "msgdir"
#define CFG_PLUG_APP_RUN_PKGLOGDIR "pkglog"
#define CFG_PLUG_APP_RUN_SSNFILE "ssnfile"
#define CFG_PLUG_APP_RUN_SSNPREFIX "ssnprefix"

#define CFG_PLUG_APP_RUN_SAVEMSG "savemsg"
#define CFG_PLUG_APP_RUN_MEMMSGMAX "memmsgmax"

#define VAR_PLUG_APP_RUN_TYPE_IN 2
#define VAR_PLUG_APP_RUN_TYPE_OUT 1

#define EVENT_PLUG_APP_RUN_INMSG        40001
#define EVENT_PLUG_APP_RUN_OUTMSG       40002

#define EVENT_PLUG_APP_RUN_BEGIN        40004
#define EVENT_PLUG_APP_RUN_WLOG         40005
#define EVENT_PLUG_APP_RUN_SAVEMSG      40006
#define EVENT_PLUG_APP_RUN_MSGINFO      40007
#define EVENT_PLUG_APP_RUN_END          40008

#define DLEN_PLUG_APP_RUN_MSGFILENAME 1024
#define DLEN_PLUG_APP_RUN_PATH 512

#define DLEN_PLUG_APP_RUN_MSG_MAX 32000

/*---------------------------- Type define ------------------------------*/
typedef struct {
    int iType;
    void *pMsg;
    int iOption;
    void *pOptData;
} T_PLUG_APP_RUN_MSG;

typedef struct {
    char sMsgId[DLEN_IPC_MSGQ_MSGID+1];
    char sCorrelId[DLEN_IPC_MSGQ_MSGID+1];
    char sMsgFileName[DLEN_PLUG_APP_RUN_MSGFILENAME];
    
    /*version 1*/
    int iVersion;
    int iOptions;
    char sMsgDir[DLEN_PLUG_APP_RUN_PATH];       /*���·�������msg�����ļ���·��+��·��, ����·����msg����ʵ��·��*/
    char sLogDir[DLEN_PLUG_APP_RUN_PATH];       /*���·�������pkglog�����ļ���·��+��·��, ����·����pkglog����ʵ��·��*/
    
} T_PLUG_APP_RUN_MSGINFO;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_PLUG_GLBRUN_H_20101013173405_*/
/*-----------------------------  End ------------------------------------*/
