/*
 *
 *
 * plug manager.
 *
 *
 * FileName: plug_mgr.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_MGR_H_20100524151234_
#define _PLUG_MGR_H_20100524151234_
/*--------------------------- Include files -----------------------------*/
#include "os_dll.h"
#include "rt_core.h"
#include "event_mgr.h"
#include "cfg_oper.h"


/*--------------------------- Macro define ------------------------------*/
#define DLEN_PLUG_MGR_PLUGNUM_MAX 1024
#define DLEN_PLUG_MGR_PLUGNAME_MAX 128

/*error num for plug manager*/
#define ERR_PLUG_MGR_OK 0
#define ERR_PLUG_MGR_BASE (-11000)
#define ERR_PLUG_MGR_NOSPACE  (ERR_PLUG_MGR_BASE-1)
#define ERR_PLUG_MGR_PARAM  (ERR_PLUG_MGR_BASE-2)
#define ERR_PLUG_MGR_CFG  (ERR_PLUG_MGR_BASE-3)
#define ERR_PLUG_MGR_LOAD (ERR_PLUG_MGR_BASE-4)
#define ERR_PLUG_MGR_INIT (ERR_PLUG_MGR_BASE-5)
#define ERR_PLUG_MGR_PROC (ERR_PLUG_MGR_BASE-6)
#define ERR_PLUG_MGR_UNKNOW (ERR_PLUG_MGR_BASE-100)

/*qmgr config*/
#define CFG_PLUG_MGR_OBJ "plugmgr"
#define CFG_PLUG_MGR_CFGFILE "cfgfile"
#define CFG_PLUG_MGR_ADDINS "add-ins"
#define CFG_PLUG_MGR_SECTION "section"
#define CFG_PLUG_MGR_EMAPSECTION "emapsection"
#define CFG_PLUG_MGR_EMAPSLIST "emapslist"

/*plug prop config*/
#define CFG_PLUG_MGR_PLUGVER "ver"
#define CFG_PLUG_MGR_PLUGNAME "name"
#define CFG_PLUG_MGR_PLUGCFGSECTIOSN "cfgsection"
#define CFG_PLUG_MGR_PLUGOBJ "obj"
#define CFG_PLUG_MGR_PLUGDESC "desc"
#define CFG_PLUG_MGR_PLUGLOADMOD "loadmod"
#define CFG_PLUG_MGR_PLUGLOADFUN "loadfun"
#define CFG_PLUG_MGR_PLUGDLL "dll"

/*plug mgr event*/
#define EVENT_PLUG_MGR_PLUG_INIT 00000001
#define EVENT_PLUG_MGR_PROC_RUN  00000002
#define EVENT_PLUG_MGR_PLUG_UNLOAD 00000003
#define EVENT_PLUG_MGR_PROC_EXIT 00000004

/*�¼�ӳ��*/
#define NAME_PLUG_MGR_EVENTHANLER EventHandlers
#define EVENTMAP_PLUG_MGR_BEGIN static int NAME_PLUG_MGR_EVENTHANLER(int iPlugId, int iEventId, void *pInData, void *pOutData) \
     {\
        switch(iEventId) {
#define EVENTMAP_PLUG_MGR_HANDLER(e, handler) case e: {return handler(iPlugId, iEventId, pInData, pOutData); } break;
#define EVENTMAP_PLUG_MGR_HANDLER_DEFAULT(handler)  default: {return handler(iPlugId, iEventId, pInData, pOutData);} break;
#define EVENTMAP_PLUG_MGR_END } }

#define EVENTMAP_PLUG_MGR_DEFINE static int NAME_PLUG_MGR_EVENTHANLER(int iPlugId, int iEventId, void *pInData, void *pOutData);

/*---------------------------- Type define ------------------------------*/
typedef enum {
      ePlugMgrStaticLoad = 1
    , ePlugMgrDllLoad

} E_PLUG_MGR_LOADMOD;


typedef struct {
    /*������Ϣ*/
    int  iId;
    int iVersion;
    char sName[DLEN_PLUG_MGR_PLUGNAME_MAX];
    char sCfgSection[DLEN_RTCORE_CTX_CFGOBJ_MAX];
    char sObj[DLEN_RTCORE_CTX_CFGOBJ_MAX];
    char sDesc[DLEN_RTCORE_CTX_CFGOBJ_MAX];
    PFN_EVENT_MGR_EHDL pfnEventHdl;

    /*������Ϣ*/
    E_PLUG_MGR_LOADMOD ePlugLoadMod;
    char sLoadFunName[DLEN_RTCORE_CTX_CFGOBJ_MAX];
    void * pfnPlugLoadFun;
    H_DllFile hDllFile;
    char sDllName[DLEN_RTCORE_CTX_CFGOBJ_MAX];

    T_RTCORE_CONTEXT *ptRTCoreCtx;

    /*��չ*/
    void *pExtData;
} T_PLUG_MGR_PLUG_VAR;

typedef int (*PFN_PLUG_MGR_PLUG_LOAD_FUN)(T_PLUG_MGR_PLUG_VAR *ptPlugVar);
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: PlugMgrRegPlug
 *
 * @desc: ע����
 *
 * @param psCfgSection: ���ö�
 * @param eLoadMod: ���ط�ʽ
 * @param pfnPlugFun: ���غ���
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int PlugMgrRegPlug(char *psCfgSection, E_PLUG_MGR_LOADMOD eLoadMod, PFN_PLUG_MGR_PLUG_LOAD_FUN pfnPlugFun);

/**
 * @function: PlugMgrLoadPlug
 *
 * @desc: ���ز��
 *
 * @param iId: ���ID
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int PlugMgrLoadPlug(int iId);

/**
 * @function: PlugMgrOnStart
 *
 * @desc: ����PlugMgr
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int PlugMgrOnStart(void);

/**
 * @function: PlugMgrGetPlugIdByName
 *
 * @desc: ͨ���������ȡ�ò��ID
 *
 * @param psPlugName: �������
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int PlugMgrGetPlugIdByName(char *psPlugName);

#ifdef __cplusplus
}
#endif

#endif /*_PLUG_MGR_H_20100524151234_*/
/*-----------------------------  End ------------------------------------*/
