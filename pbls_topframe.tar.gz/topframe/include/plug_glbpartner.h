/*
 *
 * 
 * partner glb plug extent point.
 * 
 * 
 * FileName: plug_glbpartner.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_GLBPARTNER_H_20100610092900_
#define _PLUG_GLBPARTNER_H_20100610092900_
/*--------------------------- Include files -----------------------------*/
#include "plug_mgr.h"
/*--------------------------- Macro define ------------------------------*/
#define EVENT_GLB_PARTER_NEWMSG 20001
#define EVENT_GLB_PARTER_GETMSG 20002
#define EVENT_GLB_PARTER_REQMSG 20003
#define EVENT_GLB_PARTER_RSPMSG 20004

#define EVENT_GLB_PARTER_TIMEOUT 20007
#define EVENT_GLB_PARTER_ERROR   20008

/**/
#define DLEN_GLB_PARTNER_MSGMAX (1024*100)

/*partner protocol field len define*/
#define DLEN_GLB_PARTNER_MSGID 32
#define DLEN_GLB_PARTNER_ADDR 512
#define DLEN_GLB_PARTNER_DATETIME 14
#define DLEN_GLB_PARTNER_CHARSET 14
#define DLEN_GLB_PARTNER_USERID 32
#define DLEN_GLB_PARTNER_AUTHTOKEN 64

#define DLEN_GLB_PARTNER_ATTACHNUM 30

/*err code define*/
#define ERR_GLB_PARTNER_BASE       (-100) 
#define ERR_GLB_PARTNER_SENDMSG (ERR_GLB_PARTNER_BASE - 1);
#define ERR_GLB_PARTNER_RCVMSG (ERR_GLB_PARTNER_BASE - 2);

/*log id define*/
#define RC_GLB_PARTNER_SSN                  "000030001^"
#define RC_GLB_PARTNER_FILEEXIST            "000030002^"
#define RC_GLB_PARTNER_QMGR                 "000030101^"
#define RC_GLB_PARTNER_OBJECT               "000030102^"
#define RC_GLB_PARTNER_RADDR                "000030201^"
#define RC_GLB_PARTNER_LADDR                "000030202^"
#define RC_GLB_PARTNER_SNDMSG               "000030203^"
#define RC_GLB_PARTNER_RCVMSG               "000030204^"
#define RC_GLB_PARTNER_DISCONN              "000030205^"

/*partner protocol var*/
#define VAR_GLB_PARTNER_VER_1 1
#define VAR_GLB_PARTNER_VER_2 2
#define VAR_GLB_PARTNER_VER_3 3


#define VAR_GLB_PARTNER_NET_SOCKID "_TOP_NET_SOCKID"
#define VAR_GLB_PARTNER_NET_LSR_SOCKID "_TOP_NET_LSRSOCKID"
#define VAR_GLB_PARTER_NET_LCONN 1
#define VAR_GLB_PARTER_NET_SCONN 2

/*partner common config key define*/
#define CFG_GLB_PARTER_MSGFILEDIR "filedir"
#define CFG_GLB_PARTER_MSGMAXSIZE "msgmax"
#define CFG_GLB_PARTER_BUGSIZE "bufsize"

#define CFG_GLB_PARTER_NET_CONNMOD "connmod"
#define CFG_GLB_PARTER_NET_CONNMAX "connmax"
#define CFG_GLB_PARTER_NET_MAXTRY "maxtry"
#define CFG_GLB_PARTER_NET_WAIT "wait"
#define CFG_GLB_PARTER_NET_RECONN_WAIT "reconnwait"
#define CFG_GLB_PARTER_NET_EXITWAIT "exitwait"

#define CFG_GLB_PARTER_NET_HOST "host"
#define CFG_GLB_PARTER_NET_URL "url"

#define CFG_GLB_PARTER_NET_LADDR "laddr"
#define CFG_GLB_PARTER_NET_RADDR "raddr"
#define CFG_GLB_PARTER_NET_LPORT "lport"
#define CFG_GLB_PARTER_NET_RPORT "rport"

#define CFG_GLB_PARTER_NET_FILTER_MOD  "filtermod"
#define CFG_GLB_PARTER_NET_ADDR_LIST  "addrlist"

/*ssl*/
#define CFG_GLB_PARTER_NET_SSL "usessl"
#define CFG_GLB_PARTER_NET_CA "ca"
#define CFG_GLB_PARTER_NET_CERT "cert"
#define CFG_GLB_PARTER_NET_KEY "key"
#define CFG_GLB_PARTER_NET_KEYPASS "keypass"
#define CFG_GLB_PARTER_NET_PEERCHK "peerchk"
#define CFG_GLB_PARTER_NET_NOCERT "nocert"

/*---------------------------- Type define ------------------------------*/
typedef enum {eParterMQ=1, eParterTcp, eParterIpcMsg, eParterSoap, eParterTopMQ} E_PARTER_TYPE;

typedef struct {
    char sMsgId[DLEN_GLB_PARTNER_MSGID+1];
    char sCorrelId[DLEN_GLB_PARTNER_MSGID+1];
    int iMsgType;
} T_GLB_PARTNER_MEGADATA;

typedef struct {
    E_PARTER_TYPE ePartnerType;                                     
    char chStoreType;                                               /*��Ϣ�洢����*/
    T_GLB_PARTNER_MEGADATA tMegaData;                               /*��ϢԪ����*/
    int iMsgLen;                                                    /*��Ϣ����*/
    void *pMsgBody;                                                 /*��Ϣ��*/
    void *pExtData;                                                 /*��չ����*/
                                                                    
    /*ver2*/                                                        
    int iVer;                                                       /*���ṹ�汾*/
    int iWait;                                                      /*�ȴ�ʱ��*/
    int iOptions;                                                   /*��Ϣѡ��*/
    char sAddr[DLEN_GLB_PARTNER_ADDR];                              /*Ŀ���ַ*/
                                                                    
    /*ver3*/                                                        
    int iUsage;                                                     /*��Ϣ��;*/
    int iExpiry;                                                    /*��ʱʱ��*/
    int iFeedback;                                                  /*���ر�־*/
    int iPriority;                                                  /*���ȼ�*/
    int iEncoding;                                                  /*����*/
    int iPersistence;                                               /*�־��Ա�־*/
    int iMsgSeqNo;                                                  /*��Ϣ���*/
    int iReportOpt;                                                 /*�ظ���Ϣѡ��*/
    char sCharSet[DLEN_GLB_PARTNER_CHARSET];                        /*�ַ���*/
    char sFromAddr[DLEN_GLB_PARTNER_ADDR];                          /*Դ��ַ*/
    char sReplyToAddr[DLEN_GLB_PARTNER_ADDR];                       /*�ظ���ַ*/
    char sAppId[DLEN_GLB_PARTNER_ADDR];                             /*Ӧ��id*/
    int iAppType;                                                   /*Ӧ������*/
    char sUserId[DLEN_GLB_PARTNER_USERID];                          /*�û�ID*/
    char sAuthToken[DLEN_GLB_PARTNER_AUTHTOKEN];                    /*��Ȩ����*/
    char sPutDateTime[DLEN_GLB_PARTNER_DATETIME+1];                 /*����ʱ��*/
    
    char *psAttach[DLEN_GLB_PARTNER_ATTACHNUM];                     /*��������������DLEN_GLB_PARTNER_ATTACHNUM-1*/
    
} T_GLB_PARTNER_EVENTDATA;

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_PLUG_GLBPARTNER_H_20100610092900_*/
/*-----------------------------  End ------------------------------------*/
