/*
 *
 * 
 * msg queue datasource itf.
 * 
 * 
 * FileName: ipc_msgque_datasource.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _IPC_MSGQUE_DATASOURCE_H_20100909163359_
#define _IPC_MSGQUE_DATASOURCE_H_20100909163359_
/*--------------------------- Include files -----------------------------*/
#include "log_info.h"

/*--------------------------- Macro define ------------------------------*/
/*msg queue init data feild len define*/
#define DLEN_IPC_MSGQDEF_SVR_DESC 20 
#define DLEN_IPC_MSGQDEF_OBJ_NAME 32
#define DLEN_IPC_MSGQDEF_FLG 1
#define DLEN_IPC_MSGQDEF_RSV 30
#define DLEN_IPC_MSGQDEF_DATETIME 14
#define DLEN_IPC_MSGQDEF_FILEPATH 255

#define DLEN_IPC_DATASOURCE_CONFIGLINE 1024


/*static value*/
#define VAR_IPC_MSGQ_CREATEITF "CreateItf"
#define VAR_IPC_MSGQ_RELEASE "Release"

/*---------------------------------------------*/
/*err code define*/
/*---------------------------------------------*/
#define ERR_IPC_MSGQ_DATASOURCE_OK 0                                                 /*�ɹ�*/

#define ERR_IPC_MSGQ_DATASOURCE_BASE (-4000)                                    
#define ERR_IPC_MSGQ_DATASOURCE_INIT        (ERR_IPC_MSGQ_DATASOURCE_BASE-1)          /*��ʼ������*/
#define ERR_IPC_MSGQ_DATASOURCE_PARAM       (ERR_IPC_MSGQ_DATASOURCE_BASE-2)          /*��������*/
#define ERR_IPC_MSGQ_DATASOURCE_END         (ERR_IPC_MSGQ_DATASOURCE_BASE-3)          /*��β*/
#define ERR_IPC_MSGQ_DATASOURCE_BEGIN       (ERR_IPC_MSGQ_DATASOURCE_BASE-4)          /*��ͷ*/
#define ERR_IPC_MSGQ_DATASOURCE_FIND        (ERR_IPC_MSGQ_DATASOURCE_BASE-5)          /*���Ҵ���*/
#define ERR_IPC_MSGQ_DATASOURCE_UNKNOW      (ERR_IPC_MSGQ_DATASOURCE_BASE-10)         /*δ֪����*/

/*---------------------------- Type define ------------------------------*/
/*���̶��ж���*/
typedef struct {
    int     iSvrId;
    char    sSvrIdDesc[DLEN_IPC_MSGQDEF_SVR_DESC+1];
    int     iDefDestSvrId;
    char    sDefDestSvrIdDesc[DLEN_IPC_MSGQDEF_SVR_DESC+1];
    char    sMsqName[DLEN_IPC_MSGQDEF_OBJ_NAME+1];
    char    sMsqQmname[DLEN_IPC_MSGQDEF_OBJ_NAME+1];
    char    sAutoCommit[DLEN_IPC_MSGQDEF_FLG+1];
    char    sMsqType[DLEN_IPC_MSGQDEF_FLG+1];
    char    sMsqFilepath[DLEN_IPC_MSGQDEF_FILEPATH+1];
    int     iMsqMemmaxlen;
    char    sMsqOption1[DLEN_IPC_MSGQDEF_RSV+1];
    char    sMsqOption2[DLEN_IPC_MSGQDEF_RSV+1];
    char    sMsqOption3[DLEN_IPC_MSGQDEF_RSV+1];
    char    sMsqOption4[DLEN_IPC_MSGQDEF_RSV+1];
    char    sMsqOption5[DLEN_IPC_MSGQDEF_RSV+1];
    char    sStatus[DLEN_IPC_MSGQDEF_FLG+1];
    char    sRecUpdtTime[DLEN_IPC_MSGQDEF_DATETIME+1];
    char    sRsv1[DLEN_IPC_MSGQDEF_RSV+1];
    char    sRsv2[DLEN_IPC_MSGQDEF_RSV+1];
    char    sRsv3[DLEN_IPC_MSGQDEF_RSV+1];
    char    sRsv4[DLEN_IPC_MSGQDEF_RSV+1];
    char    sRsv5[DLEN_IPC_MSGQDEF_RSV+1];
} T_IPC_MSGQDEF;

/*����Դ�ӿڶ���*/
typedef int (*PFN_IPC_MSGQ_DATASOURCE_COUNT)(void);
typedef int (*PFN_IPC_MSGQ_DATASOURCE_FIND)(int , T_IPC_MSGQDEF *);
typedef int (*PFN_IPC_MSGQ_DATASOURCE_NEXT)(T_IPC_MSGQDEF *);
typedef int (*PFN_IPC_MSGQ_DATASOURCE_PRE)(T_IPC_MSGQDEF *);
typedef int (*PFN_IPC_MSGQ_DATASOURCE_CUR)(T_IPC_MSGQDEF *);

typedef struct {
    PFN_IPC_MSGQ_DATASOURCE_COUNT pfnCount;
    PFN_IPC_MSGQ_DATASOURCE_FIND pfnFind;
    PFN_IPC_MSGQ_DATASOURCE_NEXT pfnNext;
    PFN_IPC_MSGQ_DATASOURCE_PRE pfnPre;
    PFN_IPC_MSGQ_DATASOURCE_CUR pfnCur;
} T_IPC_MSGQ_DATASOURCE;

typedef int (*PFN_IPC_MSGQ_DATA_LOGPRINT)(char *, int , char *, char *, int , const char *, char *, ...);

typedef struct {
    char sCfgLine[DLEN_IPC_DATASOURCE_CONFIGLINE];
    PFN_IPC_MSGQ_DATA_LOGPRINT pfnLogPrint; 
} T_IPC_MSGQ_DATASOURCE_CTX;

typedef int (*PFN_IPC_MSGQ_DATASOURCE_CREATEITF)(T_IPC_MSGQ_DATASOURCE_CTX *ptCtx, T_IPC_MSGQ_DATASOURCE *);
typedef int (*PFN_IPC_MSGQ_DATASOURCE_RELEASE)(void);

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_IPC_MSGQUE_DATASOURCE_H_20100909163359_*/
/*-----------------------------  End ------------------------------------*/
