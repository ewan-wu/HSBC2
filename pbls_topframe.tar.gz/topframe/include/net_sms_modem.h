/*
 *
 *
 * SMS Handler
 *
 *
 * FileName: net_sms_modem.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _NET_SMS_MODEM_H_20110408154009_
#define _NET_SMS_MODEM_H_20110408154009_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: smsSend
 *
 * @desc: ���Ͷ���Ϣ
 *
 * @param sTty: ����è�����豸��ַ
 * @param sDest: Ŀ��绰����
 * @param sBody: ��Ϣ��
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int smsSend(char *sTty, char *sDest, char *sBody);

#ifdef __cplusplus
}
#endif

#endif /*_NET_SMS_MODEM_H_20110408154009_*/
/*-----------------------------  End ------------------------------------*/
