#!/bin/sh

db2 connect to ${DB2DBNM} user ${DB2USER} using ${DB2PASS}

bindfiles=`ls *bnd`
for bindfile in $bindfiles
do
  echo "bind $bindfile"
  db2 bind $bindfile
done
echo "bind end."
