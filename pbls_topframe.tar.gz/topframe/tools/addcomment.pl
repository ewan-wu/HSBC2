#!/usr/bin/perl -w
#
# ����ע�͹���
#

#use strict;

#ȫ�ֱ�������

#
&main();

#
sub main()
{
    my $Argc = @ARGV;
    my $Fun;
    my $InHFile;
    my $OutHFile;
    my %FunInfo;
    my $paramname;
    my %params;
    my $i = 0;
    my $Line;
    my $State=0;
    my $CFun;
    my @InLines;
    my @paramkeys;
    my $k = 0;
    
    if ($Argc != 2) {
        printf("Usage: addcomment.pl <infile> <outfile>\n");
        exit;
    }
    
    
    $InHFile = $ARGV[0];
    $OutHFile = $ARGV[1];
    open(INHDRFILE, $InHFile)||die("open file error!:".$InHFile."\n");
    open(OUTHDRFILE, '>'.$OutHFile)||die("open file error!:".$OutHFile."\n");
    
    @InLines = <INHDRFILE>;
    
    #process
    for($i=0; $i<@InLines; $i++) {
        
        $Line = $InLines[$i];
        
        if(index($Line, "Global function declaration") > 0){
            $State=1;
        }
        
        if($State == 0) {
            print OUTHDRFILE ($InLines[$i]);
            next;
        }
        
        if(index($Line, '@function:') > 0) {
            $CFun = substr($Line, index($Line, '@function:')+11);
            print OUTHDRFILE ($InLines[$i]);
            next;
        }
        
        if(($Line =~ /\(.*/g) && !($Line =~ /^(\s|\t)+\*/)) {
            $Fun = substr($Line, 0, index($Line, "("));
            $Fun =~  s/^\s+//;
            $Fun =~  s/\s+$//;
            $Fun =~  s/\t/ /g;
            $Fun =~  s/\*/* /;
            $Fun = substr($Fun, rindex($Fun, " "));
            $Fun =~ s/\s+//g;
            
            if($CFun) {
                $CFun =~ s/\n//;
                $CFun =~  s/\s+$//;
            }
            
            if(!($CFun &&($Fun eq $CFun))) {
                
                print OUTHDRFILE ("\n/**\n * ".'@function: '.$Fun."\n *\n");
                print OUTHDRFILE (' * @desc: '."\n *\n");
                
                %FunInfo = &GetFunInfo($InHFile, $Fun);
                if($FunInfo{'params'}) {
                    %params = %{$FunInfo{'params'}};
                    @paramkeys = keys %params;
                    for($k=0; $k<@paramkeys; $k++) {
                        foreach $paramname (keys %params) {
                            if($params{$paramname}{'param_idx'} == $k){
                                print OUTHDRFILE (' * @param '.$paramname.": \n");
                            }
                        }
                    }
                }
                
                print OUTHDRFILE (" *\n *".' @return '.$FunInfo{'ret_type'}.": \n");
                
                print OUTHDRFILE (" *\n *".' @comment:'."\n *\n *\n");
                print OUTHDRFILE (" *\n *".' @sample:'."\n *\n *\n */\n");
            }
            
            print OUTHDRFILE ($InLines[$i]);
            if(index($Line, ")") <= 0) {
                $i += 1;
                for(; $i<@InLines; $i++) {
                    $Line = $InLines[$i];
                    print OUTHDRFILE ($InLines[$i]);
                    if(index($Line, ")") > 0) {
                        last;
                    }
                }
            }
            
            next;
            
        }
        
        print OUTHDRFILE ($InLines[$i]);
    }
    
    close(OUTHDRFILE);
}

sub GetFunInfo()
{
    my ($HdrFile, $Fun) = @_;
    my @Lines;
    my $i;
    my $j;
    my $Line;
    my %funinfo;
    my $rettype;
    my $paramsline;
    my @paramarray;
    my @paramkv;
    my $paramname;
    my $paramidx = 0;
    my $paramtmp;
    my $State = 0;
    my $pattern;
    my $express;
    
    open(HDRFILE, $HdrFile)||die("open file error!:".$HdrFile."\n");
    @Lines = <HDRFILE>;
    close(HDRFILE);
    
    print($Fun.">>\n");
    for($i=0; $i<@Lines; $i++) {
        if(index($Lines[$i], "Global function declaration") > 0){
            $State=1;
        }
        
        if($State == 0) {
            next;
        }
        
        $pattern = $Fun.'\s*\(.*';
        $express = qr/$pattern/;
        
        if((index($Lines[$i], "#define") < 0) 
            && (index($Lines[$i], $Fun) >= 0) 
            && ($Lines[$i] =~ /\(.*/g) 
            && ($Lines[$i] =~ $express) 
            && !($Lines[$i] =~ /^\s+\*/g)) {
            $Line = "";
            for($j=$i; $j<@Lines; $j++) {
                $Line .= $Lines[$j];
                if($Line =~ /.*\)/g) {
                    last;
                }
                
            }
            $i=$j;
            last; 
        }
    }
    
    if(! ($Line)) {
        die("$Line match error");
    }
    
    $Line =~ s/\s+/ /g;
    $Line =~ s/\t+/ /g;
    $Line =~ s/\n/ /;
    
    if(!($Line =~ /\(.*\)/g)) {
        die("$Line match error");
    }
    
    print($Line."\n");
    $funinfo{'declaration'} = $Line;
    
    $rettype = substr($Line, 0, index( $Line, $Fun));
    $rettype =~ s/\s+/ /g;
    $funinfo{'ret_type'} = $rettype;
    
    $paramsline = substr($Line, index($Line, "(")+1, index($Line, ")")-index($Line, "(") - 1);
    print($paramsline."\n");
    $funinfo{'params'} = ();
    $paramsline =~  s/^\s+//;
    $paramsline =~  s/\s+$//;
    if($paramsline =~ /^void$/g) {
        $funinfo{'param_num'} = 0;
        return %funinfo;
    }
    
    @paramarray = split(',', $paramsline);
    $funinfo{'param_num'} = @paramarray;
    foreach $paramname (@paramarray) {
        $paramname =~ s/\*/ * /g;
        $paramname =~ s/\s+/ /g;
        print($paramname."\n");
        if($paramname =~ /\.\.\./g) {
            $funinfo{'params'}{"..."}{'param_type'} = "...";
            $funinfo{'params'}{"..."}{"param_idx"} = $paramidx;
            $paramidx++;
        } else {
            $paramname =~  s/^\s+//;
            $paramname =~  s/\s+$//;
            $paramtmp = rindex($paramname, ' ');
            $paramkv[1] =  substr($paramname, $paramtmp+1);
            $paramkv[0] =  substr($paramname, 0, $paramtmp);
            
            $funinfo{'params'}{$paramkv[1]}{'param_type'} =  $paramkv[0];
            $funinfo{'params'}{$paramkv[1]}{'param_idx'} =  $paramidx;
            $paramidx++;
        }
        
    }
    
    return %funinfo;
}

0