#!/usr/bin/perl -w
#
# ���������ʼ������SQL���
#

use strict;

#ȫ�ֱ�������

#
&main();

#
sub main()
{
    my $Argc = @ARGV;
    my $ExpFile;
    my $i = 0;
    my $j = 0;
    my $SqlFile;
    my @Funs;
    my $Fun;
    my $HFile;
    my %FunInfo;
    my $paramname;
    my %params;
    
    if ($Argc != 1) {
        printf("Usage: genmodsql.pl <ModName>\n");
        exit;
    }
    
    
    $ExpFile = "$ENV{'TOPFRAME_HOME'}/mak/exp/$ARGV[0].exp";
    $SqlFile = "$ENV{'TOPFRAME_HOME'}/db/modssql/"."$ARGV[0]".".sql";
    open(SQLFILE, '>'.$SqlFile)||die("open file error!:".$SqlFile."\n");
    open(EXPFILE, $ExpFile)||die("open file error!:".$ExpFile."\n");
    @Funs = <EXPFILE>;
    
    #process
    print SQLFILE ("insert into TF_MOD(MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE) VALUES('$ARGV[0]', '', '$ARGV[0]', '', ''); \n");
    for($i=0; $i<@Funs; $i++) {
        $Fun = $Funs[$i];
        $Fun =~ s/\n|\t|\s//g;
        if(length($Fun) == 0) {
            next;
        }
        
       
        $HFile = &FindHeaderFile("$ENV{'TOPFRAME_HOME'}/include", $Fun);
        if(length($HFile) == 0) {
            next;
        }
        
        %FunInfo = &GetFunInfo("$ENV{'TOPFRAME_HOME'}/include/$HFile", $Fun);
                 
        print SQLFILE ("insert into TF_FUN(MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE) VALUES('$ARGV[0]', '$Fun', '"
                .$FunInfo{'declaration'}."', '$HFile', '".$FunInfo{'ret_type'}."','".$FunInfo{'ret_desc'}."', '".$FunInfo{'param_num'}."','".$FunInfo{'desc'}."', '', ''); \n");
        if($FunInfo{'params'}) {
            %params = %{$FunInfo{'params'}};
            print("##################\n");
            foreach $paramname (keys %params) {
                print($paramname."\n");
                print($params{$paramname}{'param_type'}."\n");
                print($params{$paramname}{'param_desc'}."\n");
                print($params{$paramname}{'param_idx'}."\n");
                
                print SQLFILE ("insert into TF_FUN_PARAMS(MOD_NAME, FUN_NAME, PARAM_NAME, TYPE,IDX, REMARKS, USAGE)"
                    ." VALUES('$ARGV[0]', '$Fun', '".$paramname."', '".$params{$paramname}{'param_type'}."', '".$params{$paramname}{'param_idx'}."','".$params{$paramname}{'param_desc'}."', ' '); \n");
            }
        }
    }
    
    close(SQLFILE);
}

sub FindHeaderFile()
{
    my ($HdrDir, $Fun) = @_;
    my @HdrFileLst;
    my $i = 0;
    my $Line;
    my $HdrFile;
    my $pattern;
    my $express;
    
    @HdrFileLst = `ls -1 "$HdrDir"`;
    
    $pattern = $Fun.'\s+$';
    $express = qr/$pattern/;
        
    for($i=0; $i< @HdrFileLst; $i++) {
        $HdrFile = $HdrFileLst[$i];
        $HdrFile =~ s/\n|\t|\s//g;
        
        open(HDRFILE, $HdrDir.'/'.$HdrFile)||die("open file error!:".$HdrDir.'/'.$HdrFile."\n");
        while($Line = <HDRFILE>) {
            if((index($Line, '@function: '.$Fun)>=0) && ($Line =~ $express)) {
                print($HdrDir.'/'.$HdrFile.":".$Fun."\n");
                close(HDRFILE);
                return $HdrFile;
            }
        }
        close(HDRFILE);
    }
    
}

sub GetFunInfo()
{
    my ($HdrFile, $Fun) = @_;
    my @Lines;
    my $i;
    my $j;
    my $Line;
    my %funinfo;
    my $rettype;
    my $paramsline;
    my @paramarray;
    my @paramkv;
    my $paramname;
    my $paramidx = 0;
    my $paramtmp;
    my $returnstr;
    my $rettmp = 0;
    my $state = 0;
    my $pattern;
    my $express;
    
    open(HDRFILE, $HdrFile)||die("open file error!:".$HdrFile."\n");
    @Lines = <HDRFILE>;
    close(HDRFILE);
    
    print($Fun.">>\n");
    for($i=0; $i<@Lines; $i++) {
        $pattern = $Fun.'\s+$';
        $express = qr/$pattern/;
        if((index($Lines[$i], '@function: '.$Fun) >= 0) && ($Lines[$i] =~ $express)) {
            last; 
        }
    }
    
    $funinfo{'params'} = ();
    
    for(; $i<@Lines; $i++) {
        $Line = $Lines[$i];
        $Line =~ s/\n//;
        if((index($Line, '@desc:') >= 0)) {
            $funinfo{'desc'} = substr($Line, index($Line, '@desc:')+7);
            $funinfo{'desc'} =~ s/'/''/g;
            print('@desc:'.$funinfo{'desc'}."\n");
        }
        
        if((index($Line, '@param') >= 0)) {
            $paramname = substr($Line, index($Line, '@param')+6);
            $paramname =~  s/^\s+//;
            $paramname =~  s/\s+$//;
            $paramtmp = index($paramname, ':');
            
            $paramkv[0] =  substr($paramname, 0, $paramtmp);
            $paramkv[1] =  substr($paramname, $paramtmp+1);
            
            $funinfo{'params'}{$paramkv[0]}{'param_desc'} =  $paramkv[1].'';
            $funinfo{'params'}{$paramkv[0]}{'param_desc'} =~ s/'/''/g;;
            $funinfo{'params'}{$paramkv[0]}{'param_idx'} =  $paramidx;
            
            $paramidx++;
            
            print('@param:'.$paramkv[0].':'.$paramkv[1]."\n");
            
        }
        
        if((index($Line, '@return') >= 0)) {
            $returnstr = substr($Line, index($Line, '@return')+7);
            $rettmp = index($returnstr, ":");
            $funinfo{'ret_type'} = substr($returnstr, 0, $rettmp);
            $funinfo{'ret_desc'} = substr($returnstr, $rettmp+1).'';
            $funinfo{'ret_desc'} =~ s/'/''/g;
            
            print('@return:'.$funinfo{'ret_type'}.':'.$funinfo{'ret_desc'}."\n");
        }
        
        if((index($Line, '*/') >= 0)) {
            last; 
        }
    }
    
    $funinfo{'param_num'} = $paramidx;
    
    for(; $i<@Lines; $i++) {
        if((index($Lines[$i], "#define") < 0) 
        && (index($Lines[$i], $Fun) >= 0) 
        && ($Lines[$i] =~ /\(.*/g) 
        && !($Lines[$i] =~ /^\s+\*/g)) {
            $Line = "";
            for($j=$i; $j<@Lines; $j++) {
                $Line .= $Lines[$j];
                if($Line =~ /.*\)/g) {
                    last;
                }
                
            }
            $i=$j;
            last; 
        }
    }
    
    $Line =~ s/\s+/ /g;
    $Line =~ s/\n/ /;
    
    if(!($Line =~ /\(.*\)/g)) {
        die("$Line match error");
    }
    
    print($Line."\n");
    $funinfo{'declaration'} = $Line;
    
    $paramsline = substr($Line, index($Line, "(")+1, index($Line, ")")-index($Line, "(") - 1);
    print($paramsline."\n");
    
    $paramsline =~  s/^\s+//;
    $paramsline =~  s/\s+$//;
    if($paramsline =~ /^void$/g) {
        return %funinfo;
    }
    
    @paramarray = split(',', $paramsline);
    
    foreach $paramname (@paramarray) {
        $paramname =~ s/\*/ * /g;
        $paramname =~ s/\s+/ /g;
        print($paramname."\n");
        if($paramname =~ /\.\.\./g) {
            $funinfo{'params'}{"..."}{'param_type'} = "...";
        } else {
            $paramname =~  s/^\s+//;
            $paramname =~  s/\s+$//;
            $paramtmp = rindex($paramname, ' ');
            $paramkv[1] =  substr($paramname, $paramtmp+1);
            $paramkv[0] =  substr($paramname, 0, $paramtmp);
            $paramkv[1] =~  s/^\s+//;
            $paramkv[0] =~  s/^\s+//;
             
            $funinfo{'params'}{$paramkv[1]}{'param_type'} =  $paramkv[0];
            print($paramkv[1].":".$paramkv[0]."\n");
        }
        
    }
    
    return %funinfo;
}

0