#!/bin/sh
for OLD in `find ${TOPFRAME_HOME}/src -name "Makefile" -o -name "*.mak"`; do
	NEW=`echo $OLD | sed 's/\/src\//\/srcraw\//'`
	mkdir -p `dirname $NEW`
	cp -f $OLD $NEW
done
mkdir -p ${TOPFRAME_HOME}/srcraw/version
cp -f ${TOPFRAME_HOME}/src/version/*.c ${TOPFRAME_HOME}/srcraw/version
