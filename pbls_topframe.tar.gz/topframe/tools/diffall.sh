#!/bin/sh

SELF=`basename "$0" | sed 's/\(.*\)\..*/\1/'`

usage()
{
	echo "  Usage: $SELF [-e ext] [-g grep] <dirA> <dirB>"
	echo "Example: $SELF -e 'c|ini' old_dir new_dir"
	exit 1
}

while getopts e:g: OPTION; do
	case $OPTION in
		e) EXT=$OPTARG ;;
		g) GREP=$OPTARG ;;
		?) usage ;;
	esac
done
shift `expr $OPTIND - 1`

if [ $# -lt 0 -o ! -d "$1" -o ! -d "$2" ]; then
	usage
fi

if [ ! -z "$EXT" ]; then
	EXT=.`echo "$EXT" | sed 's/|/$|./g'`\$
fi

T="/tmp/$SELF.$$.tmp"
A="/tmp/$SELF.$$.A.tmp"
B="/tmp/$SELF.$$.B.tmp"
CSV="$SELF.csv"
DIR="$SELF.dir"

files()
{
	CUR=`pwd`
	cd "$1"
	find . -type f | grep -Ev '/\.svn/|/CVS/' | cut -c3- | sort > "$2"
	cd $CUR

	if [ ! -z "$EXT" ]; then
		grep -E "$EXT" "$2" > "$T"
		mv -f "$T" "$2"
	fi

	if [ ! -z "$GREP" ]; then
		grep -E "$GREP" "$2" > "$T"
		mv -f "$T" "$2"
	fi

	rm -f "$T"
}


rm -fr "$CSV" "$DIR"

files "$1" "$A"
files "$2" "$B"

echo "diff $A $B"

if diff "$A" "$B" 2>&1 >"$T"; then
    echo "no file add or delete."
	#rm -f "$CSV" "$T" "$A" "$B"
	#exit 0
else
   cat "$T" | grep '^[<>]' | sed 's/^> /Added,/' | sed 's/^< /Deleted,/' | tee -a "$CSV"
fi

rm -f "$T"

mkdir -p "$DIR"
while read FILE; do
	DIFF="$DIR/`echo $FILE | sed 's/\//^/g'`.diff"
	diff "$1/$FILE" "$2/$FILE" 2>/dev/null >"$DIFF"
	if [ $? = 1 ]; then
		echo "Modified,$FILE" | tee -a "$CSV"
	else
		rm -f "$DIFF"
	fi
done < "$A"

rm -f "$A" "$B"
