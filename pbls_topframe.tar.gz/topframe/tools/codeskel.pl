#!/usr/bin/perl -w
#
# Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
# All Rights Reserved. 
# 
# create mod codeskel.
#
# FileName: codeskel.pl
# Author: Xilin.Gao
# 
# History:
#   2009-09-02 Xilin.Gao Create.
#
use strict;

################Global Variables###################

################Global Functions###################

&main();

##
sub main()
{
    my $iArgc = @ARGV;
    
    if($iArgc != 3) {
        print("Usage: codeskel.pl <modname> <author> <desc>\n");
        exit;
    }
    
    &CreateSrcFile();
    &CreateHdrFile();
}

################Local Functions###################
sub CreateSrcFile()
{
    my $sSrcFile;
    my $Date = `date +%Y/%m/%d`;
    
    $Date =~ s/\n//g;
    
    $sSrcFile = $ARGV[0].".c";
    open(CFILE, ">".$sSrcFile) or die("open $sSrcFile error.\n");
    print CFILE ('/*'."\n");
    print CFILE (' * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.'."\n");
    print CFILE (' * All Rights Reserved.'."\n");
    print CFILE (' *'."\n");
    print CFILE (' * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG'."\n");
    print CFILE (' * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT'."\n");
    print CFILE (' * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM'."\n");
    print CFILE (' * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF'."\n");
    print CFILE (' * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.'."\n");
    print CFILE (' * '."\n");
    print CFILE (' * '.$ARGV[2]."\n");
    print CFILE (' * '."\n");
    print CFILE (' * $I'.'d$'."\n");
    print CFILE (' * '."\n");
    print CFILE (' * FileName: '.$sSrcFile."\n");
    print CFILE (' * '."\n");
    print CFILE (' *  <Date>        <Author>       <Auditor>     <Desc>'."\n");
    printf CFILE (" * %10s%11s%11s%19s\n", $Date, $ARGV[1], "", "Create.");
    print CFILE (' */'."\n");
    print CFILE ('/*--------------------------- Include files -----------------------------*/'."\n");
    print CFILE ('#include "'.$ARGV[0].'.h"'."\n\n");
    print CFILE ('/*--------------------------- Macro define ------------------------------*/'."\n");
    print CFILE ("#define _DLEN_TINY_BUF 64\n"   );
    print CFILE ("#define _DLEN_MINI_BUF 256\n"  );
    print CFILE ("#define _DLEN_LARGE_BUF 1024\n");
    print CFILE ("#define _DLEN_HUGE_BUF 10240\n");
    print CFILE ('/*---------------------------- Type define ------------------------------*/'."\n\n");
    print CFILE ('/*---------------------- Local function declaration ---------------------*/'."\n\n");
    print CFILE ('/*-------------------------  Global variable ----------------------------*/'."\n\n");
    print CFILE ('/*-------------------------  Global functions ---------------------------*/'."\n\n");
    print CFILE ('/*-------------------------  Local functions ----------------------------*/'."\n\n");
    print CFILE ('/*-----------------------------  End ------------------------------------*/'."\n\n");
    close(CFILE);
}

sub CreateHdrFile()
{
    my $sHdrFile;
    my $Date = `date +%Y/%m/%d`;
    my $HMACRO  = `date +%Y%m%d%H%M%S`;
    
    $Date =~ s/\n//g;
    $HMACRO =~ s/\n//g;
    $HMACRO = "_".uc($ARGV[0])."_H_".$HMACRO."_";
    
    $sHdrFile = $ARGV[0].".h";
    open(HFILE, ">".$sHdrFile) or die("open $sHdrFile error");
    print HFILE ('/*'."\n");
    print HFILE (' * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.'."\n");
    print HFILE (' * All Rights Reserved.'."\n");
    print HFILE (' *'."\n");
    print HFILE (' * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG'."\n");
    print HFILE (' * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT'."\n");
    print HFILE (' * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM'."\n");
    print HFILE (' * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF'."\n");
    print HFILE (' * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.'."\n");
    print HFILE (' * '."\n");
    print HFILE (' * '.$ARGV[2]."\n");
    print HFILE (' * '."\n");
    print HFILE (' * $I'.'d$'."\n");
    print HFILE (' * '."\n");
    print HFILE (' * FileName: '.$sHdrFile."\n");
    print HFILE (' * '."\n");
    print HFILE (' *  <Date>        <Author>       <Auditor>     <Desc>'."\n");
    printf HFILE (" * %10s%11s%11s%19s\n", $Date, $ARGV[1], "", "Create.");
    print HFILE (' */'."\n");
    print HFILE ('#ifndef '.$HMACRO."\n");
    print HFILE ('#define '.$HMACRO."\n");
    print HFILE ('/*--------------------------- Include files -----------------------------*/'."\n\n");
    print HFILE ('/*--------------------------- Macro define ------------------------------*/'."\n\n");
    print HFILE ('/*---------------------------- Type define ------------------------------*/'."\n\n");
    print HFILE ('/*---------------------- Global function declaration --------------------*/'."\n\n");
    print HFILE ('#ifdef __cplusplus'."\n");
    print HFILE ('extern "C" {'."\n");
    print HFILE ('#endif'."\n");
    print HFILE ("\n");
    print HFILE ("\n");
    print HFILE ('#ifdef __cplusplus'."\n");
    print HFILE ('}'."\n");
    print HFILE ('#endif'."\n");
    print HFILE ("\n");
    print HFILE ('#endif /*'.$HMACRO."*/\n");
    print HFILE ('/*-----------------------------  End ------------------------------------*/'."\n");
    close(HFILE);
}

#######################END#####################
