#!/bin/sh

echo "------------------------------------"
echo "  ${TOPFRAME_HOME}/bin"
echo "------------------------------------"
cd ${TOPFRAME_HOME}/bin
bins=`ls`
for binname in $bins
do
   echo `top_ver ${binname}`" ${binname}"
   #echo ""
done

echo "------------------------------------"
echo "  ${TOPFRAME_HOME}/libs"
echo "------------------------------------"
cd ${TOPFRAME_HOME}/lib
libs=`ls lib*.*`
for libname in $libs
do
   echo `top_ver ${libname}`" ${libname}"
   #echo ""
done

echo "------------------------------------"
echo "  ${TOPMQ_HOME}/bin"
echo "------------------------------------"
cd ${TOPMQ_HOME}/bin
libs=`ls `
for libname in $libs
do
   echo `top_ver ${libname}`" ${libname}"
   #echo ""
done

echo "------------------------------------"
echo "  ${TOPMQ_HOME}/libs"
echo "------------------------------------"
cd ${TOPMQ_HOME}/lib
libs=`ls lib*.*`
for libname in $libs
do
   echo `top_ver ${libname}`" ${libname}"
   #echo ""
done
