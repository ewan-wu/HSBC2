#!/bin/sh
while [ $# -gt 0 ]; do
	SQL=`basename $1 | sed 's/\(.*\)\..*/\1.sql/'`
	sqlcreate.awk	$1 >	$SQL
	sqlcomment.awk	$1 >>	$SQL
	shift
done
