#!/usr/bin/perl -w
use strict;
use File::Basename;
use Getopt::Std;

our $opt_t;

my $Table;
my @Col;
my %ColKey;
my %ColType;
my %ColLen;

my @Key;
my %Var;
my %VarType;
my %VarInner;

&main();

sub main()
{
	getopts("t:");

	if (@ARGV < 1) {
		print(STDERR "Usage: ".fileparse($0)." [-t table] <csvfile> ...\n");
		exit 1;
	}

	if ($opt_t) {
		gendbs($ARGV[0]);

	} else {
		my $i = 0;
		for ($i = 0; $i < @ARGV; $i++) {
			gendbs($ARGV[$i]);
		}
	}
}

sub gendbs()
{
	my ($CsvFile) = @_;

	csv2var($CsvFile);
	genheader();
	gensource();
}

sub csv2var()
{
	my ($CsvFile) = @_;

	if ($opt_t) {
		$Table = uc($opt_t);
	} else {
		$Table = uc(fileparse($CsvFile, qr/\.[^.]*/));
	}

	my $DisFile;

	if ($CsvFile eq "-") {
		*CSVFILE = *STDIN;
		$DisFile = "STDIN";
	} else {
		open(CSVFILE, $CsvFile)
			or die(fileparse($0).": open <$CsvFile> error, $!\n");
		$DisFile = $CsvFile;
	}

	my @Lines = <CSVFILE>;
	my $Line;
	my @List;

	my $i;
	for ($i = 0; $i < @Lines; $i++) {
		$Line = $Lines[$i];
		$Line =~ s/\r|\n//g;
		@List = split("\t", $Line);

		die(fileparse($0).": file <$DisFile> format error\n") if (@List < 4);

		$Col[$i] = $List[0];

		$ColKey{$Col[$i]} = $List[1];
		$ColType{$Col[$i]} = $List[2];
		$ColLen{$Col[$i]} = $List[3];

		if ($ColKey{$Col[$i]} eq "Y") {
			$Key[@Key] = $Col[$i];
		}

		($Var{$Col[$i]}, $VarType{$Col[$i]}) = col2var($Col[$i],
		                                               $ColType{$Col[$i]},
		                                               $ColLen{$Col[$i]});

		if ($VarType{$Col[$i]} eq "char") {
			$VarInner{$Col[$i]} = "pt".varname($Table)."->$Var{$Col[$i]}";
		} else {
			$VarInner{$Col[$i]} = "sTmp".varname($Col[$i]);
		}
	}

#	print($Table."\n");
#	my $ColName;
#	foreach $ColName (@Col) {
#		print($ColName  . "\t" . $ColKey{$ColName} . "\t" .
#		      $ColType{$ColName} . "\t" . $ColLen{$ColName} . "\t" .
#		      $Var{$ColName} . "\t" . $VarType{$ColName} . "\n");
#	}

	close(CSVFILE) if ($CsvFile ne "-");
}

sub genheader()
{
	my $File = "dbsvr_".lc($Table).".h";

	open(FILE, ">", $File)
		or die(fileparse($0).": open <$File> error, $!\n");

	my $Time = curtime();

	print(FILE "/*\n");
	print(FILE " * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.\n");
	print(FILE " * All Rights Reserved.\n");
	print(FILE " *\n");
	print(FILE " * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG\n");
	print(FILE " * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT\n");
	print(FILE " * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM\n");
	print(FILE " * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF\n");
	print(FILE " * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.\n");
	print(FILE " *\n");
	print(FILE " * dbsvr for table ".lc($Table)." (auto generate)\n");
	print(FILE " *\n");
	print(FILE " * \$Id\$\n");
	print(FILE " *\n");
	print(FILE " * FileName: ${File}\n");
	print(FILE " *\n");
	print(FILE " */\n");
	print(FILE "#ifndef	_${Table}_H_${Time}_\n");
	print(FILE "#define	_${Table}_H_${Time}_\n");
	print(FILE "/*--------------------------- Include files -----------------------------*/\n");
	print(FILE "#include	\"top_dbs.h\"\n");
	print(FILE "\n");
	print(FILE "/*--------------------------- Macro define ------------------------------*/\n");
	print(FILE "\n");
	print(FILE "/*---------------------------- Type define ------------------------------*/\n");
	print(FILE "typedef struct {\n");

	my $ColName;
	foreach $ColName (@Col) {
		print(FILE "	$VarType{$ColName}	$Var{$ColName}");
		print(FILE "[$ColLen{$ColName}+1]") if ($VarType{$ColName} eq "char");
		print(FILE ";\n");
	}

	print(FILE "} T_TAB_$Table;\n");
	print(FILE "\n");
	print(FILE "/*---------------------- Global function declaration --------------------*/\n");
	print(FILE "#ifdef __cplusplus\n");
	print(FILE "extern \"C\" {\n");
	print(FILE "#endif\n");
	print(FILE "\n");
	print(FILE "int dbs".varname($Table)."(T_DBS_SVR_FUNC eFunc, T_TAB_$Table *pt".varname($Table).");\n");
	print(FILE "\n");
	print(FILE "#ifdef __cplusplus\n");
	print(FILE "}\n");
	print(FILE "#endif\n");
	print(FILE "\n");
	print(FILE "#endif	/* _${Table}_H_${Time}_ */\n");
	print(FILE "/*-----------------------------  End ------------------------------------*/\n");

	close(FILE);

	print("generate [$File]\n");
}

sub gensource()
{
	my $File = "dbsvr_".lc($Table).".c";

	open(FILE, ">", $File)
		or die(fileparse($0).": open <$File> error, $!\n");

	print(FILE "/*\n");
	print(FILE " * Copyright 2010, Shanghai Huateng Software Systems Co., Ltd.\n");
	print(FILE " * All Rights Reserved.\n");
	print(FILE " *\n");
	print(FILE " * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG\n");
	print(FILE " * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT\n");
	print(FILE " * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM\n");
	print(FILE " * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF\n");
	print(FILE " * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.\n");
	print(FILE " *\n");
	print(FILE " * dbsvr for table ".lc($Table)." (auto generate)\n");
	print(FILE " *\n");
	print(FILE " * \$Id\$\n");
	print(FILE " *\n");
	print(FILE " * FileName: ${File}\n");
	print(FILE " *\n");
	print(FILE " */\n");
	print(FILE "/*--------------------------- Include files -----------------------------*/\n");
	print(FILE "#include	\"dbsvr_".lc($Table).".h\"\n");
	print(FILE "\n");
	print(FILE "#include	<stdio.h>\n");
	print(FILE "#include	<stdlib.h>\n");
	print(FILE "#include	<string.h>\n");
	print(FILE "\n");
	print(FILE "/*--------------------------- Macro define ------------------------------*/\n");
	print(FILE "#define	arrayof(a)	(sizeof(a) / sizeof(*(a)))\n");
	print(FILE "\n");

	print(FILE "#define	SQL_SELECT	\\\n");
	my $i = 0;
	my $ColName;
	foreach $ColName (@Col) {
		if ($i == 0) {
			print(FILE "	\"SELECT $ColName");
		} else {
			print(FILE ", \"	\\\n");
			print(FILE "	       \"$ColName");
		}
		$i++;
	}
	print(FILE " \"	\\\n");
	print(FILE "	  \"FROM $Table");
	$i = 0;
	foreach $ColName (@Key) {
		print(FILE " \"	\\\n");
		if ($i == 0) {
			print(FILE "	 \"WHERE $ColName = :k$i");
		} else {
			print(FILE "	   \"AND $ColName = :k$i");
		}
		$i++;
	}
	print(FILE " \"\n");
	print(FILE "\n");

	print(FILE "#define	SQL_FOR_UPDATE	\"FOR UPDATE \"\n");
	print(FILE "\n");

	print(FILE "#define	SQL_UPDATE	\\\n");
	print(FILE "	\"UPDATE $Table \"	\\\n");
	$i = 0;
	foreach $ColName (@Col) {
		if ($i == 0) {
			print(FILE "	   \"SET $ColName = :x$i");
		} else {
			print(FILE ", \"	\\\n");
			print(FILE "	       \"$ColName = :x$i");
		}
		$i++;
	}
	$i = 0;
	foreach $ColName (@Key) {
		print(FILE " \"	\\\n");
		if ($i == 0) {
			print(FILE "	 \"WHERE $ColName = :k$i");
		} else {
			print(FILE "	   \"AND $ColName = :k$i");
		}
		$i++;
	}
	print(FILE " \"\n");
	print(FILE "\n");

	print(FILE "#define	SQL_DELETE	\\\n");
	print(FILE "	\"DELETE FROM $Table");
	$i = 0;
	foreach $ColName (@Key) {
		print(FILE " \"	\\\n");
		if ($i == 0) {
			print(FILE "	 \"WHERE $ColName = :k$i");
		} else {
			print(FILE "	   \"AND $ColName = :k$i");
		}
		$i++;
	}
	print(FILE " \"\n");
	print(FILE "\n");

	print(FILE "#define	SQL_INSERT	\\\n");
	print(FILE "	\"INSERT INTO $Table ( \"	\\\n");
	$i = 0;
	foreach $ColName (@Col) {
		if ($i == 0) {
			print(FILE "	       \"$ColName");
		} else {
			print(FILE ", \"	\\\n");
			print(FILE "	       \"$ColName");
		}
		$i++;
	}
	print(FILE " \"	\\\n");
	print(FILE "	\") VALUES ( \"	\\\n");
	$i = 0;
	foreach $ColName (@Col) {
		if ($i == 0) {
			print(FILE "	       \":x$i");
		} else {
			print(FILE ", \"	\\\n");
			print(FILE "	       \":x$i");
		}
		$i++;
	}
	print(FILE " \"	\\\n");
	print(FILE "	\") \"\n");
	print(FILE "\n");

	print(FILE "/*---------------------------- Type define ------------------------------*/\n");
	print(FILE "\n");
	print(FILE "\n");
	print(FILE "/*---------------------- Local function declaration ---------------------*/\n");
	print(FILE "\n");
	print(FILE "/*-------------------------  Global variable ----------------------------*/\n");
	print(FILE "\n");
	print(FILE "/*-------------------------  Global functions ---------------------------*/\n");
	print(FILE "int dbs".varname($Table)."(T_DBS_SVR_FUNC eFunc, T_TAB_$Table *pt".varname($Table).")\n");
	print(FILE "{\n");

	foreach $ColName (@Col) {
		if ($VarType{$ColName} ne "char") {
			print(FILE "	char	".$VarInner{$ColName}."[32];\n");
		}
	}
	print(FILE "\n");

	print(FILE "	T_DBS_SVR_COL	atCol[] = {\n");
	foreach $ColName (@Col) {
		print(FILE "		{$VarInner{$ColName}, sizeof($VarInner{$ColName}), ".keyflag($ColKey{$ColName})."},\n");
	}
	print(FILE "	};\n");
	print(FILE "\n");

	print(FILE "	int	iRet;\n");
	print(FILE "\n");

	foreach $ColName (@Col) {
		if ($VarType{$ColName} eq "int") {
			print(FILE "	sprintf($VarInner{$ColName}, \"%d\", pt".varname($Table)."->$Var{$ColName});\n");
		} elsif ($VarType{$ColName} eq "double") {
			print(FILE "	sprintf($VarInner{$ColName}, \"%.15g\", pt".varname($Table)."->$Var{$ColName});\n");
		}
	}
	print(FILE "\n");

	print(FILE "	switch (eFunc) {\n");
	print(FILE "		case E_DBS_FIND: {\n");
	print(FILE "			iRet = dbsSvrFind(SQL_SELECT, arrayof(atCol), atCol);\n");
	print(FILE "\n");

	foreach $ColName (@Col) {
		if ($VarType{$ColName} eq "int") {
			print(FILE "			pt".varname($Table)."->$Var{$ColName} = atoi($VarInner{$ColName});\n");
		} elsif ($VarType{$ColName} eq "double") {
			print(FILE "			pt".varname($Table)."->$Var{$ColName} = atof($VarInner{$ColName});\n");
		}
	}
	print(FILE "\n");

	print(FILE "			break;\n");
	print(FILE "		}\n");
	print(FILE "		case E_DBS_LOCK: {\n");
	print(FILE "			iRet = dbsSvrFind(SQL_SELECT SQL_FOR_UPDATE, arrayof(atCol), atCol);\n");
	print(FILE "\n");

	foreach $ColName (@Col) {
		if ($VarType{$ColName} eq "int") {
			print(FILE "			pt".varname($Table)."->$Var{$ColName} = atoi($VarInner{$ColName});\n");
		} elsif ($VarType{$ColName} eq "double") {
			print(FILE "			pt".varname($Table)."->$Var{$ColName} = atof($VarInner{$ColName});\n");
		}
	}
	print(FILE "\n");

	print(FILE "			break;\n");
	print(FILE "		}\n");
	print(FILE "		case E_DBS_CLOSE: {\n");
	print(FILE "			iRet = 0;\n");
	print(FILE "			break;\n");
	print(FILE "		}\n");
	print(FILE "		case E_DBS_UPDATE: {\n");
	print(FILE "			iRet = dbsSvrUpdate(SQL_UPDATE, arrayof(atCol), atCol);\n");
	print(FILE "			break;\n");
	print(FILE "		}\n");
	print(FILE "		case E_DBS_DELETE: {\n");
	print(FILE "			iRet = dbsSvrDelete(SQL_DELETE, arrayof(atCol), atCol);\n");
	print(FILE "			break;\n");
	print(FILE "		}\n");
	print(FILE "		case E_DBS_INSERT: {\n");
	print(FILE "			iRet = dbsSvrInsert(SQL_INSERT, arrayof(atCol), atCol);\n");
	print(FILE "			break;\n");
	print(FILE "		}\n");
	print(FILE "		default: {\n");
	print(FILE "			iRet = ERR_TOP_DBS_UNKNOW;\n");
	print(FILE "			break;\n");
	print(FILE "		}\n");
	print(FILE "	}\n");
	print(FILE "\n");
	print(FILE "	return iRet;\n");
	print(FILE "}\n");
	print(FILE "\n");
	print(FILE "/*-------------------------  Local functions ----------------------------*/\n");
	print(FILE "\n");
	print(FILE "/*-----------------------------  End ------------------------------------*/\n");

	close(FILE);

	print("generate [$File]\n");
}

sub col2var()
{
	my ($Col, $ColType, $ColLen) = @_;
	my $Var;
	my $VarType;

	if ($ColType eq "INTEGER" || $ColType eq "SERIAL" ||
	    $ColType eq "INT"     || $ColType eq "SMALLINT") {
		$Var = "i" . varname($Col);
		$VarType = "int";

	} elsif ($ColType eq "NUMBER" || $ColType eq "DECIMAL") {
		if ($ColLen < 10) {
			$Var = "i" . varname($Col);
			$VarType = "int";
		} else {
			$Var = "d" . varname($Col);
			$VarType = "double";
		}

	} elsif ($ColType eq "FLOAT") {
		$Var = "d" . varname($Col);
		$VarType = "double";

	} else {
		$Var = "s" . varname($Col);
		$VarType = "char";
	}

	return ($Var, $VarType);
}

sub varname()
{
	my ($Col) = @_;
	my @Words;
	my $Word;
	my $Var;

	@Words = split(/_/, $Col);
	foreach $Word (@Words) {
		$Var = $Var . ucfirst(lc($Word));
	}

	return $Var;
}

sub curtime
{
	my ($Sec, $Min, $Hour, $Day, $Mon, $Year) = localtime(time);
	return sprintf("%04d%02d%02d%02d%02d%02d",
	               $Year+1900, $Mon+1, $Day, $Hour, $Min, $Sec);
}

sub keyflag()
{
	my ($Flag) = @_;
	if ($Flag eq "Y") {
		return 1;
	} else {
		return 0;
	}
}
