#!/bin/sh

while [ $# -gt 0 ]; do
	exp=`basename $1 | sed 's/\.so$/.exp/'`
	echo "#!`basename $1`"
	nm -C $1 | grep ' T ' | awk '{print $3}' | grep -v "^_.*" | grep -v ".*::.*" | tee $exp
	shift
done
