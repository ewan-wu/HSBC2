#!/usr/bin/perl -w
#
# Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
# All Rights Reserved. 
# 
# gen global Makefile.
#
# FileName: genglbmak.pl
# Author: Xilin.Gao
# 
# History:
#   2011-12-26 Xilin.Gao Create.
#
use strict;

################Global Variables###################
my %tLibList;
my %tLibListE;
my %ModMaks;
my @ModDefInx;

################Global Functions###################

&main();

##
sub main()
{
    my $iArgc = @ARGV;
    my $MakefileList;
    my @Makefiles;
    my $Makefile;
    my $ModName;
    my $i = 0;
    my @Filters;
    my $ProjectHome;
    my $ProjectHomeDir;
    my $PWD;
    
    if($iArgc < 1) {
        print("Usage: genglbmak.pl <projecthome> <filterfile>\n");
        exit;
    }
    
    $ProjectHome = $ARGV[0];
    $ProjectHomeDir = $ENV{$ProjectHome};
    
    $PWD = `pwd`;
    $PWD =~ s/\s+//g;
    $PWD =~ s/\n//g;
    
    $MakefileList = `find $PWD -name "Makefile"`;
    $MakefileList .= `find $PWD -name "makefile"`;
    $MakefileList .= `find $PWD -name "*.mak"`;
    
    @Makefiles = split(/\n/, $MakefileList);
    
    foreach $Makefile (@Makefiles) {
        $Makefile =~ s/\s+//g;
        $Makefile =~ s/\n//g;
        &LoadMods($Makefile);
    }
    
    print("\n------------------prase depdens--------------------\n");
    
    while (1) {
        my @Mods = keys %tLibList;
        if(@Mods == 1) {
            print(@ModDefInx.":".$Mods[0]."\n");
            $ModDefInx[@ModDefInx] = $Mods[0];
            last;
        }
        
        foreach $ModName (@Mods) {
            my $ModName1 = substr($ModName, 0, index($ModName, ":"));
            my $Defs = $tLibList{$ModName};
            my $Flg = 0;
             
            for($i=0; $i<@Mods; $i++) {
                my $ModName2 = substr($Mods[$i], 0, index($Mods[$i], ":"));
                my $LibName = '-l'.$ModName2;
                my $idx = index($Defs, $LibName);
                my $idx2 = index($Defs, $LibName.' ');
                
                if($idx2 >= 0) {
                    $Flg = 1;
                    last;
                }
                
                if($idx >= 0 && (length($Defs) == ($idx + length($LibName)))){
                    $Flg = 1;
                    last;
                }
            }
            
            if($Flg == 0) {
                print(@ModDefInx.":".$ModName."\n");
                $ModDefInx[@ModDefInx] = $ModName;
                $tLibListE{$ModName} = $tLibList{$ModName};
                delete($tLibList{$ModName});
                last;
            }
        }
        
    }
    
    if($iArgc > 1) {
        open(INFILE, $ARGV[1])||die("open file error!:".$ARGV[1]."\n");
        @Filters = <INFILE>;
    }
    
    print("\n------------------create  glb file--------------------\n");
    
    &createmakhdr();
    
    open(MAKFILE, ">>Makefile")||die("open file error!:Makefile\n");
    print MAKFILE ('include $('.$ProjectHome.')/mak/platform.mak'."\n");

    print MAKFILE ("all: debug\n");
    print MAKFILE ("debug release clean:\n");
    print MAKFILE ("\t".'rm -f $('.$ProjectHome.')/src/version/.*.o'."\n");
    
    my $Mod;
    foreach $Mod (@ModDefInx) {
        
        my $MakDir = `dirname $ModMaks{$Mod}`;
        my $Makfile = `basename $ModMaks{$Mod}`;
        my $ModName1 = substr($Mod, 0, index($Mod, ":"));
        my $Find = 0;
        my $FindMod;
        
        $MakDir =~ s/\s+//g;
        $MakDir =~ s/\n//g;
        
        $MakDir = substr($MakDir, length($ProjectHomeDir));
        $MakDir = '$('.$ProjectHome.')/'.$MakDir;
    
        $Makfile =~ s/\s+//g;
        $Makfile =~ s/\n//g;
        
        foreach $FindMod (@Filters) {
            $FindMod =~ s/\s+//g;
            $FindMod =~ s/\n//g;
            if($FindMod eq $ModName1) {
                $Find = 1;
                last;
            }
        }
        
        if($Find) {
            next;
        }
        
        print($Mod."\n");
        print MAKFILE ("\tcd $MakDir; \\\n");
        print MAKFILE ('        $(MAKE) -f '.$Makfile.' $@;'."\n");
    }
    
}

################Local Functions###################
sub LoadMods()
{
    my ($MakPath) = @_;
    my $sMod;
    my $sDefs;
    my $sType;
    my $sLibName;
    
    $sMod = `cat $MakPath |grep PRGTARG|grep -v MAKE`;
    $sMod =~ s/\s+//g;
    $sMod =~ s/\n//g;
    if(length($sMod) == 0) {
        return;
    }
    
    $sMod =~ s/^.*=//g;
    
    $sDefs = `cat $MakPath |grep PRGLIBS|grep -v MAKE`;
    $sDefs =~ s/\n//g;
    $sDefs =~ s/^.*=\s*//g;
    
    $sType = `cat $MakPath |grep 'debug all'`;
    $sType =~ s/\n//g;
    $sType =~ s/^.*:\s*//g;
    
    print($sMod.':'.$sType.':'.$sDefs."\n");
    
    $tLibList{$sMod.':'.$sType} = $sDefs;
    $ModMaks{$sMod.':'.$sType} = $MakPath;
    
}

sub createmakhdr() {
	open(MAKFILE, ">Makefile")||die("open file error!:Makefile\n");
	
    print MAKFILE ('#|----------------------------------------------------------------------------|'."\n");
    print MAKFILE ('#|                           TOPMake 3.0                                      |'."\n");  
    print MAKFILE ('#| Copyright (c) 2010-2020 Shanghai Huateng Software Systems Co., Ltd.        |'."\n");  
    print MAKFILE ('#|    All Rights Reserved                                                     |'."\n");
    print MAKFILE ('#|----------------------------------------------------------------------------|'."\n");
    print MAKFILE ('#| FILE NAME    :                                                             |'."\n");
    print MAKFILE ('#| DESCRIPTIONS :                                                             |'."\n");
    print MAKFILE ('#|----------------------------------------------------------------------------|'."\n");
	
	close(MAKFILE);
}
#######################END#####################