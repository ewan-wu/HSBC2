#!/bin/sh

usage()
{
	echo "Usage: $0 [-h title] [-e] [-b title] [-t]"
	exit 1
}

HEADER="0"
TAILER="0"
TB="0"
TE="0"

while getopts h:eb:t OPTION; do
	case $OPTION in
		h) HEADER="1"; TITLE="$OPTARG";;
		t) TAILER="1" ;;
		b) TB="1"; TITLE2="$OPTARG" ;;
		e) TE="1" ;;
		?) usage ;;
	esac
done

genhead()
{
	echo '
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=GBK">
        <title>TOPSerials-TOPFrame</title>
        <link rel="stylesheet" type="text/css" href="styles/style.css">
    </head>
    <body>
        <div id="bodySection">
            <table border="0" cellspacing="0">
                <tr>
                    <td width="80%" valign="top" class="body">
                        <h2>'"$*"'</h2>
                        <div>
                            <table border="1" cellspacing="0" width="100%">
'
}

gentail()
{
	echo '
                            </table>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </body>
</html>
'
}

gentablebegin()
{
	echo '
                <tr>
                    <td width="80%" valign="top" class="body">
                        &nbsp;
                    </td>
                </tr>
                <tr>
                    <td width="80%" valign="top" class="body">
                        <h3>'"$*"'</h3>
                        <div>
                            <table border="1" cellspacing="0" width="100%">
'
}

gentableend()
{
	echo '
                            </table>
                        </div>
                    </td>
                </tr>
'
}

if [ "$HEADER" = "1" ]; then
	genhead "$TITLE"
fi

if [ "$TE" = "1" ]; then
	gentableend
fi

if [ "$TB" = "1" ]; then
	gentablebegin "$TITLE2"
fi

if [ "$TAILER" = "1" ]; then
	gentail
fi
