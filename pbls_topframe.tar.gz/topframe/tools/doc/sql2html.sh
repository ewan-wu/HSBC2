#!/bin/sh

PATH="`dirname $0`:$PATH"

usage()
{
	echo "Usage: $0 [-c connstr] [-t title] [-n] [-z] <sql>"
	exit 1
}

CONNSTR="$DBUSER/$DBPASS@$ORACLE_SID"
OPT_HEADER="-h"
OPT_TAILER="-t"
DEBUG="0"

while getopts c:t:nz OPTION; do
	case $OPTION in
		c) CONNSTR=$OPTARG ;;
		t) TITLE=$OPTARG ;;
		n) OPT_HEADER=""; OPT_TAILER="" ;;
		z) DEBUG="1" ;;
		?) usage ;;
	esac
done
shift `expr $OPTIND - 1`

if [ $# -lt 1 ]; then
	usage
fi

SQL=$1
if [ "$TITLE" = "" ]; then
	TITLE="$SQL"
fi

cutfile()
{
	HEAD=`expr $3 - 1`
	TAIL=`expr $HEAD - $2`
	head -n $HEAD $1 | tail -n $TAIL
}

TMP=sql2html.$$.tmp

sqlplus -S -M "HTML ON ENTMAP OFF" $CONNSTR <<! > $TMP
set pagesize 50000;
set linesize 32767;
$SQL;
!

if [ "$DEBUG" = "1" ]; then
	cat $TMP >&2
fi

genhtml.sh $OPT_HEADER "$TITLE"
cutfile $TMP 11 `grep -n '</table>' $TMP | cut -d: -f1` 2>/dev/null
genhtml.sh $OPT_TAILER

rm -f $TMP
