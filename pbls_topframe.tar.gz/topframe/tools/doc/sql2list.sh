#!/bin/sh

usage()
{
	echo "Usage: $0 [-c connstr] [-d delimiter] [-h] <sql>"
	exit 1
}


CONNSTR="$DBUSER/$DBPASS@$ORACLE_SID"
DELIMITER=""
HEADER="0"

while getopts c:d:h OPTION; do
	case $OPTION in
		c) CONNSTR=$OPTARG ;;
		d) DELIMITER=$OPTARG ;;
		h) HEADER="1" ;;
		?) usage ;;
	esac
done
shift `expr $OPTIND - 1`

if [ $# -lt 1 ]; then
	usage
fi

SQL=$1

TMP=sql2list.$$.tmp

sqlplus -S $CONNSTR <<! | sed 's/\s*'$DELIMITER'\s*/'$DELIMITER'/g' > $TMP
set colsep '$DELIMITER';
set feedback off;
set pagesize 50000;
set linesize 32767;
$SQL;
!

if [ "$HEADER" = "1" ]; then
	head -n 2 $TMP | tail -n 1
fi
L=`wc -l $TMP | cut -d' ' -f 1`
tail -n `expr $L - 3` $TMP

rm -f $TMP
