#!/bin/sh

PATH="`dirname $0`:$PATH"

usage()
{
	echo "Usage: $0 [-c connstr] [-t title] [-p path] [-b command] [-e command] <sql>"
	exit 1
}

CONNSTR="$DBUSER/$DBPASS@$ORACLE_SID"
DIR=""
COM_BEGIN="genhtml.sh -h"
COM_END="genhtml.sh -t"

while getopts c:t:p:b:e: OPTION; do
	case $OPTION in
		c) CONNSTR=$OPTARG ;;
		t) TITLE=$OPTARG ;;
		p) DIR=$OPTARG ;;
		b) COM_BEGIN=$OPTARG ;;
		e) COM_END=$OPTARG ;;
		?) usage ;;
	esac
done
shift `expr $OPTIND - 1`

if [ $# -lt 1 ]; then
	usage
fi

SQL=$1
if [ "$TITLE" = "" ]; then
	TITLE="$SQL"
fi

DELIMITER=""
TMP=sql2htmls.$$.tmp

if [ "$DIR" != "" ]; then
	mkdir $DIR > /dev/null 2>&1
fi

sql2list.sh -d "$DELIMITER" -c $CONNSTR -h "$SQL" > $TMP

awk 'BEGIN { FS = "'$DELIMITER'" }
NR == "1" {
	for (i = 1; i <= NF; i++) {
		title[i] = $i
	}
}
NR != "1" {
	if (length($1) == 0) {
		file = "'"$DIR"'" $2 ".html"
	} else {
		file = "'"$DIR"'" $1 "_" $2 ".html"
	}

	system("'"$COM_BEGIN"' \"'"$TITLE"'\" \"" $1 "\" \"" $2 "\" > " file)

	printf("<tr><th align=\"left\">%s</th><th align=\"left\">%s</th></tr>\n",
	       title[2], $2) >> file

	for (i = 3; i <= NF; i++) {
		printf("<tr><td>%s</td><td>%s</td></tr>\n", title[i], $i) >> file
	}

	system("'"$COM_END"' \"" $1 "\" \"" $2 "\" >> " file)

	printf("generate [%s]\n", file)
}' $TMP

rm -f $TMP
