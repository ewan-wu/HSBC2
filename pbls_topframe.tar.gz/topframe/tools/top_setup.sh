#!/bin/sh
TMPDIR=TOP_SETUP_DIR.`date +%Y%m%d`.$$
PKGOFFSET=427

mkdir -p ${TMPDIR}

#Extracts the data into a temporary directory.
echo "start Extracts pkg ..."
selffile=`pwd`/`basename "$0"`
cd ${TMPDIR}
dd if="$selffile" ibs="$PKGOFFSET" obs=1024 skip=1 | gzip -dc | tar -xvf -

dirlist=`ls`
if [ ! -d "./setup" ]; then
 cd ${dirlist}
fi

cd ./setup
sh ./main.sh

# Exit here to ensure we don't fall through into data.

exit
