#!/usr/bin/perl -w
#
# Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
# All Rights Reserved. 
# 
# gen table define file.
#
# FileName: gentabdef.pl
# Author: Xilin.Gao
# 
# History:
#   2010-05-05 Xilin.Gao Create.
#
use strict;

################Global Variables###################

################Global Functions###################

&main();

##
sub main()
{
    my $iArgc = @ARGV;
    my $Line;
    my @Lines;
    my @Words;
    my $i = 0;
    my $TabName;
    my $First = 1;
     
    if($iArgc != 1) {
        print("Usage: gentabdef.pl <tabdifines>\n");
        exit;
    }
    
    open(INFILE, $ARGV[0])||die("open file error!:".$ARGV[0]."\n");
    @Lines = <INFILE>;
    
    for($i = 0; $i < @Lines; $i++) {
        $Line = $Lines[$i];
        $Line =~ s/\n//g;
        
        if(!($Line =~ /\t/)) {
            next;
        }
        
        if($Line =~ /^[0-9]+\./) {
            $TabName = $Line;
            $TabName =~ s/^.*\(//g;
            $TabName =~ s/\).*$//g;
            
            if(!$First) {
                close(DEFFILE);
            }
            
            print("Parse ".$TabName."...\n");
            open(DEFFILE, ">".lc($TabName).".def") or die("open file error:"..$TabName.".def");
            $First = 0;
            
            $i += 3;
            
            next;
        }
        
        for(; $i < @Lines; $i++) {
            $Line = $Lines[$i];
            $Line =~ s/\n//g;
            
            @Words = split(/\t/, $Line);
            
            #����
            if(@Words == 3) { 
                last;
            }
            
            #���У��쳣��
            if(@Words < 6) { 
                next;
            }
            
            printf DEFFILE ("%s\t%s\t%s\t%s\t%s\t%s\n"
                , $Words[0]
                , $Words[1]
                , $Words[2]
                , $Words[3]
                , $Words[4]
                , $Words[5]
            );
        }
    }
    
    close(DEFFILE);
    close(INFILE);
    
}

################Local Functions###################

#######################END#####################