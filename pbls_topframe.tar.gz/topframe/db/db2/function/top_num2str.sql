create or replace function top_num2str(num in number, dot in integer)
	return varchar is
	n number := num;
	f varchar(32) := 'FM9999999999999990';
	d integer := dot;
	i integer;
begin
	if d is null then
		d := 0;
	end if;
	for i in 1 .. d loop
		n := n / 10;
	end loop;
	if d > 0 then
		f := f || '.';
		f := rpad(f, length(f) + d, '0');
	end if;
	return to_char(n, f);
end top_num2str;
