create or replace function top_sysdatetime return varchar is
begin
	return to_char(sysdate, 'YYYYMMDDHH24MISS');
end top_sysdatetime;
