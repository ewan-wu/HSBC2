drop table dual;
create table dual (dummy char(1));
insert into dual (dummy) values ('X');
