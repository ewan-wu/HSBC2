drop function top_systime;
create function top_systime() returns char(6)
	return date_format(now(), '%H%i%s');
