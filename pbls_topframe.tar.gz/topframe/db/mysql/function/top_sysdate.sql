drop function top_sysdate;
create function top_sysdate() returns char(8)
	return date_format(now(), '%Y%m%d');
