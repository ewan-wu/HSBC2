create table tbl_checkdb ( checkdb int );
insert into tbl_checkdb values( 1 );
