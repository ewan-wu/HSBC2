today=`date +%Y%m%d`
yesterday=`TZ=aaa24 date +%Y%m%d`
echo [`date`]startgetNFNFDTLfile...>>getfile.log
sftp hfyh@172.26.188.87 <<EOF
cd /app/hfyh/icbc2hfyh
get B_NFNFDTL_${today}.bin.gz
get B_NFNFDTL_${yesterday}.bin.gz
#get B_NFNFDTL_20110831.bin.gz
get B_DLTY01_${today}.bin.gz
get B_DLTY01_${yesterday}.bin.gz
#get B_DLTY01_20110831.bin.gz
exit
EOF

gzip -d B_NFNFDTL_${today}.bin.gz 
gzip -d B_NFNFDTL_${yesterday}.bin.gz
#gzip -d B_NFNFDTL_20110831.bin.gz
gzip -d B_DLTY01_${today}.bin.gz
gzip -d B_DLTY01_${yesterday}.bin.gz
#gzip -d B_DLTY01_20110831.bin.gz

mv B_NFNFDTL_${today}.bin ${HOME}/icbcfe/file/tmp/NFOCDTLZ_${today}.bin
mv B_NFNFDTL_${yesterday}.bin ${HOME}/icbcfe/file/tmp/NFOCDTLZ_${yesterday}.bin
mv B_DLTY01_${today}.bin  ${HOME}/icbcfe/file/tmp/.  
mv B_DLTY01_${yesterday}.bin  ${HOME}/icbcfe/file/tmp/.  
#mv B_NFNFDTL_20110831.bin ${HOME}/icbcfe/file/tmp/NFOCDTLZ_20110831.bin
#mv B_DLTY01_20110831.bin  ${HOME}/icbcfe/file/tmp/B_DLTY01_20110831.bin
echo [`date`]endgetNFNFDTLfile!>>getfile.log
