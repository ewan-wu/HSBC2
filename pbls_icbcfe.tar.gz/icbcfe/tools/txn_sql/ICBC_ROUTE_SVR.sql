delete from ICBC_ROUTE_SVR;
INSERT INTO "ICBC_ROUTE_SVR" VALUES ('2001', 'icbclocswt', '02', '0', '1', null, '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE_SVR" VALUES ('2002', 'icbcoutswt', '02', '0', '1', null, '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE_SVR" VALUES ('2003', 'icbcinswt', '02', '0', '1', null, '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE_SVR" VALUES ('2021', 'icbccomm', '01', '1', null, '99', '1', null, null, null, null, null);
COMMIT;
