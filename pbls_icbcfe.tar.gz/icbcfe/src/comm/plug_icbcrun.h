/*
 * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 * 
 * ibpsrun plug.
 * 
 * $Id$
 * 
 * FileName: plug_ibpsrun.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2010/07/07      gaoxl                       Create.
 */
#ifndef _PLUG_IBPSRUN_H_20100707155121_
#define _PLUG_IBPSRUN_H_20100707155121_
/*--------------------------- Include files -----------------------------*/
#include "plug_glbpartner.h"

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_PLUG_IBPSRUN_H_20100707155121_*/
/*-----------------------------  End ------------------------------------*/
