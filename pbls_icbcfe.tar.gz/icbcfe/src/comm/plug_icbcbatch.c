/*
 * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 * 
 * batchmsg for icbc2.
 * 
 * $Id$
 * 
 * FileName: plug_eftbatch.c
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2010/11/25      gaoxl                       Create.
 */
/*--------------------------- Include files -----------------------------*/
#include "util_str.h"
#include "glb_ipc.h"
#include "plug_glbrun.h"

/*--------------------------- Macro define ------------------------------*/
#define _DLEN_TINY_BUF 64
#define _DLEN_MINI_BUF 256
#define _DLEN_LARGE_BUF 1024
#define _DLEN_HUGE_BUF 10240

#define _LOGPRINT f_ptRTCoreCtx->pfnLogPrint

#define CFG_EFTRUN_DEST_DIR "destdir"
/*---------------------------- Type define ------------------------------*/

/*---------------------- Local function declaration ---------------------*/
static int InitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int OnRunEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int OnInMsgEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int ExitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int DefaultEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);

/*-------------------------  Global variable ----------------------------*/
static T_RTCORE_CONTEXT *f_ptRTCoreCtx = NULL; 
static T_PLUG_MGR_PLUG_VAR *f_ptPlugVar = NULL;

/*-------------------------  Global functions ---------------------------*/
/*----------------------------------*/
/*�¼�ӳ��*/                          
/*----------------------------------*/
EVENTMAP_PLUG_MGR_BEGIN
EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PLUG_INIT, InitEventHandler)
EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PROC_RUN, OnRunEventHandler)
EVENTMAP_PLUG_MGR_HANDLER(EVENT_GLB_PARTER_NEWMSG, OnInMsgEventHandler)
EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PROC_EXIT, ExitEventHandler)
EVENTMAP_PLUG_MGR_HANDLER_DEFAULT(DefaultEventHandler)
EVENTMAP_PLUG_MGR_END

/*�������غ���*/
int batchPlugLoad(T_PLUG_MGR_PLUG_VAR *ptPlugVar) 
{
    ptPlugVar->pfnEventHdl = NAME_PLUG_MGR_EVENTHANLER;
    f_ptPlugVar = ptPlugVar;
    f_ptRTCoreCtx = ptPlugVar->ptRTCoreCtx;

    return ERR_PLUG_MGR_OK;
}

/*-------------------------  Local functions ----------------------------*/
int InitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    return ERR_EVENT_MGR_OK;
}

int OnRunEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    return ERR_EVENT_MGR_OK;
}

int OnInMsgEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    int iRet = 0;

    /* Make Return Message File Info */
    T_GLB_PARTNER_EVENTDATA *ptPartnerEventData = (T_GLB_PARTNER_EVENTDATA *)pInData;
    T_IPC_MSGQ_ACCESSORIES_MD tAccessories;
    memset(&tAccessories, 0, sizeof(tAccessories));
    strcpy(tAccessories.sFiles[0], (char *)ptPartnerEventData->pExtData);
    tAccessories.iNum = 1;
    
    /* Make Pkg */
    char sBuffer[60];
    memset(sBuffer, '\0', sizeof(sBuffer));
    strncpy(sBuffer, strBaseName(tAccessories.sFiles[0]), sizeof(sBuffer));
    
    /* Make MQ Info */
    T_PLUG_IPC_MSGQUEUE_EVENTDATA tMsgQueEventData;
    memset(&tMsgQueEventData, 0, sizeof(tMsgQueEventData));
    tMsgQueEventData.tMsgMd.chMsgFmt = VAR_IPC_MSGQ_MSQFMT_MEM_ACCESSORIES;
    tMsgQueEventData.iMsgLen = sizeof(sBuffer);
    tMsgQueEventData.pMsgBody = sBuffer;
    tMsgQueEventData.tMsgMd.pOptData = &tAccessories;
    logDebug(tMsgQueEventData.pMsgBody, tMsgQueEventData.iMsgLen);
    
    iRet = EventMgrPostEvent(f_ptPlugVar->iId, EVENT_PLUG_IPC_MSGQUE_NEWMSG, &tMsgQueEventData, NULL, 0);
    if(iRet != ERR_EVENT_MGR_OK) {
        _LOGPRINT(LOG_ERR, "EventMgrPostEvent INIT EVENT error[%d]", iRet);
        return ERR_PLUG_MGR_PROC;
    }  
    
    return ERR_EVENT_MGR_OK;
}

int ExitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    return ERR_EVENT_MGR_OK;
}

int DefaultEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    return ERR_EVENT_MGR_OK;
}

/*-----------------------------  End ------------------------------------*/

