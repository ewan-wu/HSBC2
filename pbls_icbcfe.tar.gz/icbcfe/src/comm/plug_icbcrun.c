/*
 * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 * 
 * ibpsrun plug.
 * 
 * $Id$
 * 
 * FileName: plug_ibpsrun.c
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2010/07/07      gaoxl                       Create.
 */
/*--------------------------- Include files -----------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "cmqc.h"

#include "plug_glbmsgque.h"
#include "plug_glbpartner.h"
#include "util.h"
#include "mq_agent.h"

/*--------------------------- Macro define ------------------------------*/
#define _DLEN_MINI_BUF 256
#define _DLEN_LARGE_BUF 1024

#define _DLEN_ID_LEN       16
#define _DLEN_DATE_LEN     8
#define _DLEN_TIME_LEN     6
#define _DLEN_DATETIME_LEN (_DLEN_DATE_LEN + _DLEN_TIME_LEN)

#define _LOGPRINT f_ptRTCoreCtx->pfnLogPrint
#define LOG_FILE F_LOG_INFO(6)

/*---------------------------- Type define ------------------------------*/

/*---------------------- Local function declaration ---------------------*/
static int InitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int OnRunEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int ExitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int DefaultEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int OnNewSendEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);
static int NewMsgEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);

static int GetMQInfo(char *psMsgId);

/*-------------------------  Global variable ----------------------------*/
static T_RTCORE_CONTEXT *f_ptRTCoreCtx = NULL;
static T_PLUG_MGR_PLUG_VAR *f_ptPlugVar = NULL;

static char f_sMsgBuf[1024*1024*10];

/*-------------------------  Global functions ---------------------------*/
/*----------------------------------*/
/*�¼�ӳ��*/
/*----------------------------------*/
EVENTMAP_PLUG_MGR_BEGIN
EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PLUG_INIT, InitEventHandler)
EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PROC_RUN, OnRunEventHandler)
EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PROC_EXIT, ExitEventHandler)
EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_IPC_MSGQUE_NEWMSG, OnNewSendEventHandler)
EVENTMAP_PLUG_MGR_HANDLER(EVENT_GLB_PARTER_NEWMSG, NewMsgEventHandler)
EVENTMAP_PLUG_MGR_HANDLER_DEFAULT(DefaultEventHandler)
EVENTMAP_PLUG_MGR_END

/*�������غ���*/
int runPlugLoad(T_PLUG_MGR_PLUG_VAR *ptPlugVar) 
{
    ptPlugVar->pfnEventHdl = NAME_PLUG_MGR_EVENTHANLER;
    f_ptPlugVar = ptPlugVar;
    f_ptRTCoreCtx = ptPlugVar->ptRTCoreCtx;

    return ERR_PLUG_MGR_OK;
}

/*-------------------------  Local functions ----------------------------*/
int InitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    return ERR_EVENT_MGR_OK;
}

int OnRunEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    return ERR_EVENT_MGR_OK;
}

int OnNewSendEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    int iRet = 0;
        
    /* Make Msg Data */
    T_PLUG_IPC_MSGQUEUE_EVENTDATA *ptEventData = (T_PLUG_IPC_MSGQUEUE_EVENTDATA *)pInData;
    T_GLB_PARTNER_EVENTDATA tEventData;
    memset(&tEventData, 0, sizeof(tEventData));
    
    char sDateTime[_DLEN_DATETIME_LEN+1];
    dtmGetCurTime(sDateTime);
    memcpy(tEventData.tMegaData.sMsgId                   , ptEventData->pMsgBody   , _DLEN_ID_LEN  );
    memcpy(tEventData.tMegaData.sMsgId + _DLEN_ID_LEN    , sDateTime+_DLEN_DATE_LEN, _DLEN_TIME_LEN);
    memcpy(tEventData.tMegaData.sCorrelId                , ptEventData->pMsgBody   , _DLEN_ID_LEN  );
    memcpy(tEventData.tMegaData.sCorrelId + _DLEN_ID_LEN , sDateTime+_DLEN_DATE_LEN, _DLEN_TIME_LEN);
    
    tEventData.pMsgBody = ptEventData->pMsgBody + _DLEN_ID_LEN;
    tEventData.chStoreType = '1';
    tEventData.iMsgLen = ptEventData->iMsgLen - _DLEN_ID_LEN;
    
    /* Send Msg */
    logDebug(tEventData.pMsgBody, tEventData.iMsgLen);
    _LOGPRINT(LOG_BUG, "MsgId[%.*s]", sizeof(tEventData.tMegaData.sMsgId), tEventData.tMegaData.sMsgId);
    _LOGPRINT(LOG_BUG, "CorrelId[%.*s]", sizeof(tEventData.tMegaData.sCorrelId), tEventData.tMegaData.sCorrelId);
    iRet = EventMgrPostEvent(f_ptPlugVar->iId, EVENT_GLB_PARTER_NEWMSG, &tEventData, NULL, 0);
    if(iRet != ERR_EVENT_MGR_OK) {
        _LOGPRINT(LOG_ERR, "EventMgrPostEvent INIT EVENT error[%d]", iRet);
        return ERR_PLUG_MGR_INIT;
    }
    
    _LOGPRINT(LOG_FILE, "SEND[%.*s]", tEventData.iMsgLen, (char *)tEventData.pMsgBody);
    
    /*��ʼ����*/
    return ERR_EVENT_MGR_OK;  
}

int ExitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    return ERR_EVENT_MGR_OK;
}

int DefaultEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    _LOGPRINT(LOG_BUG, "recv plug[%d] eventid[%d]", iPlugId, iEventId);
    return ERR_EVENT_MGR_OK;
}

int NewMsgEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    /*---------------------------------------------*/
    /*��ʼ��*/
    /*---------------------------------------------*/
    T_GLB_PARTNER_EVENTDATA *ptEventData = (T_GLB_PARTNER_EVENTDATA *)pInData;
    _LOGPRINT(LOG_FILE, "RECV[%.*s]", ptEventData->iMsgLen, (char *)ptEventData->pMsgBody);
    _LOGPRINT(LOG_NOR, "Msg len[%d]", ptEventData->iMsgLen);
    logDebug(ptEventData->pMsgBody, ptEventData->iMsgLen);
    
    /* make pkg */
    memset(f_sMsgBuf, '\0', sizeof(f_sMsgBuf));
    GetMQInfo(f_sMsgBuf);
    _LOGPRINT(LOG_NOR, "Msg id[%.*s]", _DLEN_ID_LEN, f_sMsgBuf);
    memcpy(f_sMsgBuf + _DLEN_ID_LEN, ptEventData->pMsgBody, ptEventData->iMsgLen);
    int iLen = ptEventData->iMsgLen + _DLEN_ID_LEN;
    
    /*--------------------------*/
    /*�������*/
    /*--------------------------*/
    _LOGPRINT(LOG_TRC, "comMsgSend begin len[%d]", iLen);
    
    /* Make Send Struct */
    T_PLUG_IPC_MSGQUEUE_EVENTDATA tIpcMessage;
    memset(&(tIpcMessage), '\0', sizeof(tIpcMessage));
    tIpcMessage.pMsgBody = f_sMsgBuf;
    tIpcMessage.iMsgLen  = iLen;
    
    /* Send Message */
    _LOGPRINT(LOG_TRC, "Send Message ... ");
    int nRet = EventMgrPostEvent(f_ptPlugVar->iId, EVENT_PLUG_IPC_MSGQUE_NEWMSG, (void *)&(tIpcMessage), NULL, 0);
    if ( nRet != 0 ) {
        _LOGPRINT(LOG_TRC, "Send Message Msg Err!!");
        return (-1);
    }
    _LOGPRINT(LOG_NOR, "comMsgSend len[%d]", iLen);
    
    
    return ERR_EVENT_MGR_OK;
}

/**
 * GetMQInfo
 * Get MQMD some info
 *
 * @param psMsgId: return Mq Msg Id
 * @param psCorreId: return Mq Corre Id
 * @param plFeedback: return Mq Feedback
 *
 Corre* @return >0  : ok
 *         <0  : err
 */
static int GetMQInfo(char *psMsgId)
{
    int nRet;
    T_MQ_MD_SET tMqMd;
    
    memset(&(tMqMd), '\0', sizeof(tMqMd));
    nRet = mqGetMQMDSet(&(tMqMd));
    if ( nRet != 0 ) {
        _LOGPRINT(LOG_ERR, "mqGetMQMDSet err!!");
        return (-1);
    }
    
    _LOGPRINT(LOG_TRC, "MsgId[%s]", tMqMd.tRcvMd.MsgId);
    _LOGPRINT(LOG_TRC, "CorreId[%s]", tMqMd.tRcvMd.CorrelId);
    memcpy(psMsgId, tMqMd.tRcvMd.MsgId, _DLEN_ID_LEN);

    return (ERR_EVENT_MGR_OK);
}

/*-----------------------------  End ------------------------------------*/

