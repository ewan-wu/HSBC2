/*
 * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 * 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2010/12/28    kermit.shen                   Create.
 */
/*--------------------------- Include files -----------------------------*/
#include <stdio.h>
#include "poc_helper.h"
#include "poc_object.h"
#include "bizflow.h"
#include "glb_dbs.h"

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Local function declaration ---------------------*/

/*-------------------------  Global variable ----------------------------*/

/*-------------------------  Global functions ---------------------------*/

/*-------------------------  Local functions ----------------------------*/
int GenFlowProc(char *pFlowId)
{
    int iRet = 0;
    T_POC_VALUE RtCode;
    
    iRet = BizFlowProc(pFlowId, &RtCode);
    if(iRet != 0)
    {
        logInfo(LOG_ERR, "BizFlowProc error");
        return -1;
    }
    
    return 0;
}

/*
void GetTableName(char *pPkgno, char *pTableName)
{
    char    sTableName[100];
    char    sPkgno[DLEN_CP2_MSGNO + 1];
    
    memset(sTableName, 0, sizeof(sTableName));
    memset(sPkgno, 0, sizeof(sPkgno));
    memcpy(sPkgno, pPkgno, sizeof(sPkgno) - 1);
    
    if(0 == strcmp(sPkgno, "303"))
        strcpy(sTableName, "CCMS303");
    else if(0 == strcmp(sPkgno, "307"))
        strcpy(sTableName, "CCMS307");
    else if(0 == strcmp(sPkgno, "308"))
        strcpy(sTableName, "CCMS308");
    else if(0 == strcmp(sPkgno, "314"))
        strcpy(sTableName, "CCMS314");
    else if(0 == strcmp(sPkgno, "315"))
        strcpy(sTableName, "CCMS315");
    else if(0 == strcmp(sPkgno, "316"))
        strcpy(sTableName, "CCMS316");
    else if(0 == strcmp(sPkgno, "317"))
        strcpy(sTableName, "CCMS317");
    else if(0 == strcmp(sPkgno, "318"))
        strcpy(sTableName, "CCMS318");
    else if(0 == strcmp(sPkgno, "319"))
        strcpy(sTableName, "CCMS319");
    else if(0 == strcmp(sPkgno, "801"))
        strcpy(sTableName, "CCMS801");
    else if(0 == strcmp(sPkgno, "805"))
        strcpy(sTableName, "CCMS805");
    else if(0 == strcmp(sPkgno, "806"))
        strcpy(sTableName, "CCMS806");
    else if(0 == strcmp(sPkgno, "807"))
        strcpy(sTableName, "CCMS807");
    else if(0 == strcmp(sPkgno, "900"))
        strcpy(sTableName, "CCMS900");
    else if(0 == strcmp(sPkgno, "911"))
        strcpy(sTableName, "CCMS911");
    else if(0 == strcmp(sPkgno, "990"))
        strcpy(sTableName, "CCMS990");
    
    strcpy(pTableName, sTableName);
}

int OutswtErrPro(char *pPkgno, char *pId)
{
    int iRet = 0;
    char    sTableName[100];
    char    sSqlcmd[2048];
    
    memset(sTableName, 0, sizeof(sTableName));
    memset(sSqlcmd, 0, sizeof(sSqlcmd));
    
    GetTableName(pPkgno, sTableName);
    
    sprintf(sSqlcmd, "update %s set status = '%.2s' and STAT_TIME = to_char(sysdate, 'YYYYDDMMHH24MISS') where id = '%.20s'",
        sTableName, CP2_STATUS_REJECT, pId);
    
    iRet = POC_Helper_ExcSql(sSqlcmd);
    if(iRet != 0) {
        logInfo(LOG_ERR, "POC_Helper_ExcSql error, sqlcode[%d]", dbsSqlCode());
        return -1;
    }
    
    return 0;
}
*/

/*------------------------------ End ------------------------------------*/
