/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  Convert module all oracle proc c fucntion.
 *
 *
 * FileName: bizflow.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2010/11/16      eric                       Create.
 *             
 */
#ifndef _BIZFLOW_H_
#define _BIZFLOW_H_
/*------------------------ Include files ------------------------*/
#include "poc_itf.h"

/*--------------------- Macro define ----------------------------*/
#define FUNC_OK               0
#define FUNC_ERR              -1
#define FUNC_OTHER_ERR        999
#define FUNC_FLOW_CHECK       998

#define DLEN_COM_PREFIX       64
#define DLEN_BIZFLOW_ID       64
#define DLEN_BIZFLOW_SQLCODE  64
#define DLEN_BIZFLOW_TYPE     1
#define DLEN_BIZFLOW_FLAG     1
#define DLEN_BIZFLOW_DESC     256
#define DLEN_BIZFLOW_ERRCODE  18
#define DLEN_BIZFLOW_SQL      4000

#define TAG_RTCODE            "VAR.ERRCODE"
#define BIZ_SPLIT_CHAR        '|'
#define CHECK_OK              "0000"

#define BIZFLOW_TYPE_STD      0
#define BIZFLOW_TYPE_CUST     1
#define BIZFLOW_FLAG_TRUE     '1'
#define BIZFLOW_FLAG_FALSE    '0'

/* ��׼�� */
#define BizFlowProc(x, y) stdBizFlowProc((x), (y), BIZFLOW_TYPE_STD)

/* �ͻ��� */
#define custBizFlowProc(x, y) stdBizFlowProc((x), (y), BIZFLOW_TYPE_CUST)
/*--------------------- Type define -----------------------------*/
typedef struct TABLE_BIZFLOW_CFG {
    char    sFlowId[DLEN_BIZFLOW_ID + 1];           /* ����ID */
    int     iFlowQueue;                             /* ����˳�� */
    char    sFlowType[DLEN_BIZFLOW_TYPE + 1];       /* �������� */
    char    sSucSqlcode[DLEN_BIZFLOW_SQLCODE + 1];  /* ִ�гɹ�sqlcode */
    char    sNorQuitFlag[DLEN_BIZFLOW_FLAG + 1];    /* ִ�гɹ����Ƿ��˳����̱�־ */
    char    sSqlId[DLEN_BIZFLOW_ID + 1];            /* ִ��SQL ID */
    char    sFlowDesc[DLEN_BIZFLOW_DESC + 1];       /* �������� */
}T_BIZFLOW_CFG;
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif

int GenFlowProc(char *pFlowId);

/**
 * stdInitBizFlow
 *
 * @param f_sPrefix: ��ǰ׺
 * @param f_sEncryptFlag: ���ܱ�־
 *
 * @return  =0: ok
 *         <>0: err
 */
int stdInitBizFlow(char * psPrefix, char * psEncryptFlag);


/**
 * stdBizFlowProc
 *
 * @param psFlowId: ����ID
 * @param ptRtCode: ������
 * @param iOptions: ѡ�� 0 - ��׼����� 1 - �ͻ�������
 *
 * @return =0: ok
 *         <0 or =1403: SQLִ�д���
 *         =9998: ������͵�SQLִ�гɹ������Ǽ�����
 *         =9999: ��������
 */
int stdBizFlowProc(char * psFlowId, T_POC_VALUE * ptRtCode, int iOptions);


/**
 * BizFlowExecSqlById
 *
 * @param psSqlId: SQL ID
 *
 * @return =0: ok
 *         <0 or =1403: SQLִ�д���
 *         =9999: ��������
 */
int BizFlowExecSqlById(char *psSqlId);


/**
 * BizFlowExecSqlById
 *
 * @param psSqlId: SQL ID
 *
 * @return =0: ok
 *         <0 or =1403: SQLִ�д���
 *         =9999: ��������
 */
int custBizFlowExecSqlById(char *psSqlId);

#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /*_BIZFLOW_H_*/
/*--------------------- End -------------------------------------*/
