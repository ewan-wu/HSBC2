#include  <stdio.h> 

char *GetFlagName(int type, char *sFlag)
{
	static char sName[100+1]="";

	memset(sName, 0, sizeof(sName));

	switch(type)
	{
		case 1:
			if(memcmp(sFlag, "1",1) == 0)
			{
				strcpy(sName, "��¼��");
			}
			if(memcmp(sFlag, "2",1) == 0)
			{
				strcpy(sName, "�����");
			}
			if(memcmp(sFlag, "3",1) == 0)
			{
				strcpy(sName, "�ѷ���");
			}
			if(memcmp(sFlag, "4",1) == 0)
			{
				strcpy(sName, "�ɹ�");
			}
			if(memcmp(sFlag, "5",1) == 0)
			{
				strcpy(sName, "ʧ��");
			}
			if(memcmp(sFlag, "6",1) == 0)
			{
				strcpy(sName, "���޸�");
			}
			if(memcmp(sFlag, "7",1) == 0)
			{
				strcpy(sName, "��ɾ��");
			}
			if(memcmp(sFlag, "8",1) == 0)
			{
				strcpy(sName, "��ɾ��");
			}
			if(memcmp(sFlag, "9",1) == 0)
			{
				strcpy(sName, "����ʧ��");
			}

			break;

		case 2:
			if(memcmp(sFlag, "1",1) == 0)
			{
				strcpy(sName, "�ֹ��Ǽ�");
			}
			if(memcmp(sFlag, "2",1) == 0)
			{
				strcpy(sName, "�Զ��Ǽ�");
			}
			if(memcmp(sFlag, "3",1) == 0)
			{
				strcpy(sName, "ȫ��");
			}
			break;
		case 3:
			if(memcmp(sFlag, "0",1) == 0)
			{
				strcpy(sName, "��һ������");
			}
			if(memcmp(sFlag, "1",1) == 0)
			{
				strcpy(sName, "���ڷ�Χ");
			}
			break;
		case 4:
			if(strncmp(sFlag, "1", 1) == 1)
			{
				strcpy(sName, "��");
			}
			else
			{
				strcpy(sName, "��");
			}
			break;
		case 5:
			if(strncmp(sFlag, "0", 1) == 1)
			{
				strcpy(sName, "��Ȩ");
			}
			else
			{
				strcpy(sName, "�ܾ�");
			}
			break;
		case 6:
			if(memcmp(sFlag, "P",1) == 0 )
			{
				strcpy(sName, "����");
			}
			if(memcmp(sFlag, "C",1) == 0 )
			{
				strcpy(sName, "�տ�");
			}
			break;
		case 7:
			if(memcmp(sFlag, "A",1) == 0 )
			{
				strcpy(sName, "����");
			}
			if(memcmp(sFlag, "M",1) == 0 )
			{
				strcpy(sName, "�޸�");
			}
			if(memcmp(sFlag, "D",1) == 0 )
			{
				strcpy(sName, "ɾ��");
			}
			break;
		case 8:
			if(memcmp(sFlag, "1",1) == 0 )
			{
			    strcpy(sName,"��Ȩ");
			}
			if(memcmp(sFlag, "2",1) == 0 )
			{
				strcpy(sName, "�ܾ�");
			}
			break;
		case 9:
			if(memcmp(sFlag, "1",1) == 0 )
			{
			    strcpy(sName,"��Ȩ");
			}
			if(memcmp(sFlag, "0",1) == 0 )
			{
				strcpy(sName, "�ܾ�");
			}
			break;
		case 10:
			if(memcmp(sFlag, "1",1) == 0 )
			{
			    strcpy(sName,"��Ч");
			}
			if(memcmp(sFlag, "0",1) == 0 )
			{
				strcpy(sName, "ʧЧ");
			}
			break;
		case 11:
			if(memcmp(sFlag,"1",1) == 0 )
			{
				strcpy(sName, "������");
			}
			if(memcmp(sFlag,"0",1) == 0 )
			{
				strcpy(sName, "�ǹ�����");
			}
			break;
		case 12:
			if(memcmp(sFlag,"10",2) == 0 )
			{
				strcpy(sName, "������");
			}
			if(memcmp(sFlag,"00",2) == 0 )
			{
				strcpy(sName, "����");
			}
			break;
		default:
			break;
			
	}
	return sName;
}


char * RightTrim ( char *str )
{
	char	*s = str;

	while ( *s )
	    ++s;

	--s;
	while ( s >= str )
	    if ( (*s==' ') || (*s=='\t') || (*s=='\r') || (*s=='\n') )
	        --s;
	    else
	        break;

	* ( s + 1 ) = 0;

	return str;
}



int main()
{
	printf("test\n" );
	
	char str[255];
	char cankao[255]="2131231                     1                            ";
	char cankao2[257]="                                                                                                                                                                                                                                                                ";
	char flag[3]="1";
	
	printf("ori[%s]\n",cankao2);
	
	sprintf(str,"���ײο���[%s]\n��Ȩ���[%s]\n����[%s]", 
	cankao, 
	GetFlagName(9,flag),
	RightTrim(cankao2)
	);
	
	
	printf("test[%s]\nRightTrim(ori)[%s]\n",str,cankao2);
	
	
	

	return 0;




}

