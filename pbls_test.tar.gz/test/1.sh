sed 1 1.txt
