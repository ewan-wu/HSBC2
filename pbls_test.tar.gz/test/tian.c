#include  <stdio.h> 
#include <stdlib.h>
#include <string.h>

char * RightTrim ( char *str )
{
	char	*s = str;

	while ( *s )
	    ++s;

	--s;
	while ( s >= str )
	    if ( (*s==' ') || (*s=='\t') || (*s=='\r') || (*s=='\n') )
	        --s;
	    else
	        break;

	* ( s + 1 ) = 0;

	return str;
}


int main()
{
	printf("test\n" );
	char    str[30]="test123      ";
	char	str1[30]="333333    ";
	char 	sBuf[1500];
	memset(sBuf,0,1500);
	
	static struct TIS5011_GROUP
	{
		char    id	            [16];   /*交易参考号   */    
		char    bank_id	        [3 ];   /*合作行       */    
		char    bank_name	    [60];   /*合作行行名   */    
		char    our_actno	    [34];   /*付款人账号   */    
		char    curcd	        [3 ];   /*币种         */    
		char    our_name	    [60];   /*付款人名称   */    
		char    our_addr	    [60];   /*付款人地址   */    
		char    opp_actno	    [34];   /*收款人帐号   */    
		char    opp_name	    [60];   /*收款人名称   */    
		char    opp_addr	    [60];   /*收款人地址   */    
		char    opp_bankno	    [12];   /*收款行行号   */    
		char    opp_bankname	[60];   /*收款行名称   */    
		char    hub_refno	    [20];   /*HUB参考号    */    
		char    amount	        [17];   /*金额         */    
		char    vdate	        [8 ];   /*生效日期     */    
		char    busitype	    [5 ];   /*业务类型     */    
		char    buskind	        [2 ];   /*业务种类     */    
		char    work_flag	    [1 ];   /*批量标志     */    
		char    account_flag	[1 ];   /*入账方式     */    
		char    certi_type	    [3 ];   /*凭证种类     */     
		char    certi_name	    [30];   /*凭证名称     */    
		char    certi_number	[9 ];   /*凭证号       */    
		char    org_flag	    [1 ];   /*公私标志     */     
		char    erprefno	    [20];   /*ERP参考号    */    
		char    erpbuno	        [20];   /*ERP业务编号  */    
		char    erptrnno	    [35];   /*ERP流水号    */    
		char    erpdb	        [5 ];   /*借方BAI      */      
		char    erpcb	        [5 ];   /*贷方BAI      */    
		char    businsno	    [35];   /*业务指令编号 */    
		char    businsno_1	    [16];   /*业务编号     */    
		char    businsno_2	    [20];   /*业务参考号   */    
    char    businsno_3	    [20];   /*特殊参考号   */    
    char    summary	        [20];   /*摘要         */    
    char    useage	        [20];   /*用途         */    
    char    note	        [60];   /*附言         */    
} tis5011;

double  dTmpAmount;   

memcpy(&tis5011,"sssssssssssssssssssssdddddddddddddddddd                        ddddddddddddddfffffffeeeeeeeegggggggg                                                   ggggggggggggggggggggggggggggggddddddddddddddddddd11111111111111122222222222222222222222222222ww333333333333333333ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd33333333wwwwwwwwww33",sizeof(tis5011));

printf("tis5011[%s]\n",tis5011);
	
	sprintf( sBuf, "交易参考号[%16.16s]\n合作行号[%3.3s]\n合作行行名[%.60s]\n客户账号[%35.35s]\n币种[%3.3s]\n客户名称[%60.60s]\n类型[%6.6s]\n生效日期[%8.8s]\n金额[%.2f]\n对方客户号[%35.35s]\n对方客户名称[%60.60s]\n对方分行号[%12.12s]\n对方分行名称[%60.60s]\n用途[%60.60s]", 
	tis5011.id,
	tis5011.bank_id,
	tis5011.bank_name,
	RightTrim(tis5011.our_actno),
	tis5011.curcd,
	RightTrim(tis5011.our_name),
	"收款",
	tis5011.vdate,
	dTmpAmount/100,
	RightTrim(tis5011.opp_actno),
	RightTrim(tis5011.opp_name),
	RightTrim(tis5011.opp_bankno),
	RightTrim(tis5011.opp_bankname),
	RightTrim(tis5011.note) );
	
printf("sBuf[%s]\n",sBuf);
	printf("str1[%30.30s],RightTrim(test)[%30.30s]\n",str1,RightTrim(str)); 


	return 0;




}
