#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int ParseIpString(char* pString)
{
	int i = 0;
	unsigned int x = 0;
	unsigned int ui = 0;
	char *temp;
	char* p = pString;
	while(strchr(p, '.') != NULL)
	{
		temp = p;
		p = strchr(p, '.');
		*p = 0;
		x = atoi(temp);
		printf("ui[%x]\n%u[%x]\n", ui, x, x);
		ui = ui<<8;
		ui = ui | x;
		p++;
	}
	x = atoi(p);
	printf("ui[%x]\n%u[%x]\n", ui, x, x);
	ui = ui<<8;
	ui = ui | x;
	return ui;	
}

void Ip2String(int ipVal,char* pString)
{
	unsigned int ui1, ui2, ui3, ui4;
	printf("ipVal[%x]\n", ipVal);
	ui4 = ipVal & 0xff;
	ipVal = ipVal>>8;
	ui3 = ipVal & 0xff;
	ipVal = ipVal>>8;
	ui2 = ipVal & 0xff;
	ipVal = ipVal>>8;
	ui1 = ipVal & 0xff;
	ipVal = ipVal>>8;

	printf("%u.%u.%u.%u\n",  ui1, ui2, ui3, ui4);
	sprintf(pString, "%u.%u.%u.%u", ui1, ui2, ui3, ui4);
	printf("%u-%x[%s]\n", ipVal, ipVal, pString);
}

int main()
{
	unsigned int iIp = 0;
	char sIp[20] = "128.64.8.0";
	char sTemp[20];

//	scanf("%s", sIp);
	
	int i = -1;
	iIp = i;
	printf("%d\n", 0x18 & 0xf);
	printf("%d\n", 07);

	scanf("%s",sIp);
	iIp =  ParseIpString(sIp);
	printf("%u(%x)\n", iIp, iIp);
	Ip2String(iIp, sTemp);

	return 0;
}
