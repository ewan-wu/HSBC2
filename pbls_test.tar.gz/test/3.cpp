#include <iostream>
#include <cstring>

int main()
{
	int iMin = 0, iMax = 11;
	int x = 0, flag = 0;
	char str[10] = { 0 };
	char sPtf[200] = { 0 };
	const char s[][10] = { "too high", "too low", "correct" };
	std::cin >> x;
	std::cin.get();
	flag = 1;
	while (x != 0) 
	{
		if (x >= iMax || x <= iMin)
			flag = 0;
		std::cin.getline(str, 10);
		if (flag != 0 && strcmp(str, s[0]) == 0)
		{
			iMax = x;
		}
		else if (flag != 0 && strcmp(str, s[1]) == 0)
		{
			iMin = x;
		}
		else if (flag != 0 && strcmp(str, s[2]) == 0)
		{
			strcat(sPtf, "maybe\n");
			iMin = 0;
			iMax = 11;
			flag = 1;
		}
		else if (flag == 0 && strcmp(str, s[2]) == 0)
		{
			strcat(sPtf, "yes\n");
			iMin = 0;
			iMax = 11;
			flag = 1;
		}
		
		std::cin >> x;
		std::cin.get();
	}
	std::cout << sPtf;

	return 0;
}