#include <iostream>
using namespace std;

int main()
{
	int x = 0;
	char s[20] = { 0 };
	std::cout << "s=" << s << endl;
	std::cin >> x;
	cin.get();
	std::cin.getline(s,3);
	std::cout << x << endl << s << endl;
	return 0;
}
