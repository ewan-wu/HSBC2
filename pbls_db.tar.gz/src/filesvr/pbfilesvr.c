/****************************************************
 ��Ȩ����:���Ϻ���������ϵͳ���޹�˾
 �ļ�����:	pbfilesvr
 �ļ�����:  ʹ��Socket �����ļ� ֮ �����
 ****************************************************
 Modification Log:
 	Name			Date			Note
 	------------	----------		--------------
 	Coco Chu		2010-06-02		Initial
 	Jasmine	Ding	2010-08-26		for BOA PBLS
*****************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/times.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <unistd.h>
#include <stropts.h>
#include <poll.h>
#include <arpa/inet.h>
#include "pbfilesvr.h"
#include "glb_def.h"
#include "htlog.h"
#include "wd_incl.h"
#include <sys/stat.h>

#define RETRYNUM     5
#define TCPTIMEOUT  120
#define MANUAL_FILE_MSGLEN 287 /*�ֹ��ϴ��ļ����ļ����Եı��ĳ���*/
#define MANUAL_FILE_RSP_LEN 320
#define MAX_BUF_SIZE	1024*10

static char logfile[256];

int nReadSocket(int Socket_id, char *Buf, int nLen);
int nWriteSocket(int SocketId, char *Buf, int nLen);
int iGetFileInfo(int Socket_id,char *FilePath,char *FileName);
int HandleExit();

void Quit(int t);
void TimeOut(int t);

int  Socket_id, Child_Socket, Pid;

int nFatherFlg;

int main(int argc, char *argv[])
{
	int   I, J, Num,  Flag, port;
	int i;
	//char sFileType[3];
	int iFileType;
	long lReadLen, lFileSize;

	char szInBufTmp[MAX_BUF_SIZE];
	char szOutBuf[MAX_BUF_SIZE];
	char sTempFileName[512+1];
	char sCmd[1028+1];
	char sTemp[512+1];
	char sFileSize[20+1];
	char sParaVal[DLEN_PARA_VAL+1];
	
	int nRet;
	int nTrsFlag;
	short nLen, nMsgSource;
	pid_t pid;
	long lMsgType;

	int   RetryTimeSap = 2;
	int   nRetryFlag = 0;
	int Socket_id_new;

	struct  sockaddr_in   Client;
	unsigned int Client_len= sizeof( Client);

	setbuf(stdout, NULL);
	setbuf(stderr, NULL);

	Pid = getpid();

	sigset(SIGCLD, SIG_IGN);
	sigset(SIGUSR2, Quit);
	if(sigset(SIGTERM, (void (*)())HandleExit) == SIG_ERR)
		HtLog(HTLM_ERR, "sigset SIGTERM Error!");

	if(argc < 2)
	{
		printf("argument error: %s logfile \n", argv[0]);
		return -1;
	}

	/*nRet = GetLogName(argv[1], gl_logfile);
	if (nRet != 0 )
	{
		printf("Get logfile error [%s]\n", argv[1]);
		exit(-1);
	}*/
	nRet = GetLogName(argv[1], logfile);
	if (nRet != 0 )
	{
      	printf("Can't get the log name.\n");
		exit(-1);
	}
   //strcpy(gl_logfile,logfile);

   HtLog(HTLM_COM, "logfile[%s]",logfile);

   /*�������ݿ�*/
	if (0 != DbConnect() )
    {
       	HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,
       			"DbConnect() error");
       	exit(-1);
    }
	//port = atol(argv[2]);

	//��ϵͳ���ñ�ȡ�˿ں�
	MSET(sParaVal);
    nRet = GetSysPara("7003", sParaVal);
    if( nRet != 0 )
    {
        HtLog(HTLM_ERR, "��ȡ�˿ں�ʧ��=[%d]\n", nRet);
        exit(-1);
    }
    RightTrim(sParaVal);
    port = atoi(sParaVal);

	memset(&Client,0, sizeof(Client));
	Client.sin_port = htons(port);
	Client.sin_family = AF_INET;
	Client.sin_addr.s_addr = inet_addr("0.0.0.0");

	HtLog(HTLM_COM, "��ȡ�˿ںųɹ�");
	
	while ((Socket_id = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("%d Error time %s", Pid, GetCurTime());
		perror("socket error");
		if (nRetryFlag++ == RETRYNUM)
		{
			if ( RetryTimeSap<100) RetryTimeSap += 2;
			nRetryFlag = 0;
		}
		sleep(RetryTimeSap);
	}

	RetryTimeSap = 2;
	nRetryFlag = 0;

	nFatherFlg = -1;
	while (bind(Socket_id, (struct sockaddr *)&Client, sizeof(Client)) < 0)
	{
		printf("%d Error time %s", Pid, GetCurTime());
		perror("bind error");
		HtLog(HTLM_ERR, "�󶨶˿�ʧ�ܣ�30�������...");
		if (nRetryFlag++ == RETRYNUM)
		{
			if ( RetryTimeSap<100)
				RetryTimeSap += 2;
			nRetryFlag = 0;
		}
		sleep(30);
	}

	listen(Socket_id, 5);

	HtLog(HTLM_COM, "�ȴ��������Զ˿�[%d]����Ϣ ... (pid = %d)", port, Pid);

	Client_len = sizeof(Client);


	while(1)
	{
		Socket_id_new = accept(Socket_id, (struct sockaddr *)&Client,&Client_len);
		if(Socket_id_new <= 0)
		{
			printf("%d Error Time %s", Pid, GetCurTime());
			perror("accept");
			close(Socket_id);
			return(-1);
		}

		pid = fork();

		if(pid < 0 )
		{
			PERR("fork error!");
			Quit(0);
		}

		if(pid == 0)
		{
			nFatherFlg = 0;
			pid = getpid();
			lMsgType = pid;
			Child_Socket = Socket_id_new;
			nTrsFlag = 0;

			signal(SIGALRM,TimeOut);
			
			Process(Socket_id_new);
			//while(1)
			//{
			//}
		}
		else
		{
			/* father */
			nFatherFlg = 1;
			close(Socket_id_new);
		}
	}
}

void Quit(int t)
{
	if(nFatherFlg == 0)
		close(Socket_id);
	else
		close(Child_Socket);
	exit(1);
}

void TimeOut(int t)
{
	close(Child_Socket);
	printf("filercv: filercv process (%d) TimeOut at [%s]\n", Pid, GetCurTime());
	exit(-1);
}

int nReadSocket(int Socket_id, char *Buf, int nLen)
{
	int   i,I, Num;
	unsigned char Buf_head[8];

printf("read data from socket, id[%d]\n", Socket_id);

	if (nLen <= 0)
	{
		printf(" Len error nLen = [%d]\n", nLen);
		return -2;
	}

	I = 0;
	do
	{
		Num = read(Socket_id, &(Buf[I]), nLen - I);
		if (Num < 0)
		{
			printf("[%d][%d]", nLen, Num);
			perror("read socket error...");
			return -1;
		}
		I += Num;
	} while (I < nLen);

printf("Buf[%s]\n", Buf);

	return(nLen);
}

int nWriteSocket (int SocketId, char *Buf, int nLen)
{
	int   I, Num;

	I = 0;
	do
	{
		Num = write(SocketId, Buf, nLen - I);
		if (Num < 0)
		{
			perror("write sock error");
			return(-1);
		}
		I += Num;
	} while (I < nLen);

	return(nLen);
}

int iGetFileInfo(int Socket_id, char *FilePath, char *FileName)
{
	char sFilePath[512+1];
	char sFileNameTemp[256+1];
	int iRet;
	int iLen = 0;
	char sParaVal[DLEN_PARA_VAL+1];
	char sFileNameFull[256+1];
	T_TIS_DOWNLOAD_FILE	wdTisDownloadFile;

	//����Ϣ
	MSETS(wdTisDownloadFile);
	iLen = nReadSocket(Socket_id, (char *)&wdTisDownloadFile, sizeof(wdTisDownloadFile));
	if(iLen < 0)
	{
			printf("read file base info len=[%d]\n",iLen);
			return -1;
	}

	/* ���Ϊȫ·��
	//��ϵͳ���ñ�ȡ�ļ�·��
	MSET(sParaVal);
    iRet = GetSysPara("7004", sParaVal);
    if( iRet != 0 )
    {
        HtLog(HTLM_ERR, "��ȡ�ļ�·��ʧ�� iRet[%d]\n", iRet);
        exit(-1);
    }
    RightTrim(sParaVal);
	memset(sFilePath,0,sizeof(sFilePath));
    strcpy(sFilePath, sParaVal);
	*/

	//�ļ�ȫ·��
	MSET(sFileNameTemp);
	memcpy(sFileNameTemp, wdTisDownloadFile.sFileName, sizeof(sFileNameTemp)-1);
	RightTrim(sFileNameTemp);
	MSET(sFileNameFull);
	//strcpy(sFileNameFull, sFilePath);
	strcat(sFileNameFull, sFileNameTemp);
	replace_env_var(sFileNameFull);

	HtLog(HTLM_COM, "file[%s]", sFileNameFull);
	
	//��ֵ����
   	strcpy(FilePath,sFilePath);
   	strcpy(FileName,sFileNameFull);

   	return 0;
}

int HandleExit()
{
	HtLog(HTLM_COM, "Info: pbfilesvr exits!");

	/* disconnect from DB*/
	DbDisConnect();
	
	Quit(0);

	exit(1);
}

int Process(int Socket_id_new)
{
	char szInBuf[MAX_BUF_SIZE];
	char sFilePath[512+1];
	char sFileName[512+1];
	int nRet;
	FILE *fp;
	T_TOS_DOWNLOAD_FILE	wdTosDownloadFile;
	int iLen;
	char sFileSize[8+1];
	int iSendLen;
	long lFileLen;
	int Num;
	int iFirst;

	memset(szInBuf, 0, sizeof(szInBuf));

	printf("Socket_id_new[%d]\n", Socket_id_new);

	memset(sFilePath,0,sizeof(sFilePath));
	memset(sFileName,0,sizeof(sFileName));
	nRet = iGetFileInfo(Socket_id_new,sFilePath,sFileName);
	if(nRet!=0)
	{
		printf("process fail ,iRet=[%d]\n",nRet);
		Quit(0);
	}

	HtLog( HTLM_COM, "sFilePath is [%s],sFileName=[%s]\n", sFilePath,sFileName);
	
	//��ȡ�ļ����ݷ��ظ��ͻ���
	fp = fopen(sFileName, "r");
	if(fp == NULL)
	{
		printf("��Ч�ļ�[%s]\n", sFilePath);
		MSETS(wdTosDownloadFile);
		memcpy(wdTosDownloadFile.wdHead.sRetCode, "9999", 4);
		strcpy(wdTosDownloadFile.sFileContent, "�ļ���ʧ��");
		iLen = strlen(wdTosDownloadFile.sFileContent);
		MSET(sFileSize);
		sprintf(sFileSize, "%8ld", iLen);
		memcpy(wdTosDownloadFile.wdHead.sFileSize, sFileSize, 8);
		iSendLen = sizeof(wdTosDownloadFile.wdHead)+iLen;
		alarm(TCPTIMEOUT);
		Num = nWriteSocket(Socket_id_new, (char *)&wdTosDownloadFile, iSendLen);
		alarm(0);
		Quit(0);
	}
	HtLog(HTLM_COM, "���ļ��ɹ�");

	//��ȡ�ļ�����
	lFileLen = 0;
	lFileLen = lGetFileLength(sFileName);
	if(-1 == lFileLen)
	{
		printf("get file len error! \n");
		/*add by tianchangjin on 20110801 begin*/
		fclose(fp);
		/*add by tianchangjin on 20110801 end*/
		Quit(0);
	}
				
	//��ȡ�ļ����ݲ����ظ�ǰ̨
	iFirst = 1;
	while(!feof(fp))
	{
		MSET(szInBuf);
		MSETS(wdTosDownloadFile);
		
		iLen = fread(szInBuf, 1, FILE_CONTENT_LEN, fp);
		//��ȡ�ļ�����
		if(ferror(fp) != 0)
		{
			PERR("read error");
			memcpy(wdTosDownloadFile.wdHead.sRetCode, "9999", 4);
			strcpy(wdTosDownloadFile.sFileContent, "��ȡ�ļ�����");
			iLen = strlen(wdTosDownloadFile.sFileContent);
			MSET(sFileSize);
			sprintf(sFileSize, "%8ld", lFileLen);
			memcpy(wdTosDownloadFile.wdHead.sFileSize, sFileSize, 8);
			iSendLen = sizeof(wdTosDownloadFile.wdHead)+iLen;
			fclose(fp);
			Quit(0);
		}
		else
		{
			printf("read ok, len[%d]\n", iLen);
			memcpy(wdTosDownloadFile.sFileContent, szInBuf, iLen);
		}
		//���ͱ���
		alarm(TCPTIMEOUT);
		//��һ�η��͵ı��Ĵ�����ͷ��֮��ֻ��������
		if(1 == iFirst)
		{
			printf("first send\n");
			memcpy(wdTosDownloadFile.wdHead.sRetCode, "0000", 4);
			MSET(sFileSize);
			sprintf(sFileSize, "%8ld", lFileLen);
			memcpy(wdTosDownloadFile.wdHead.sFileSize, sFileSize, 8);
			iSendLen = sizeof(wdTosDownloadFile.wdHead)+iLen;
			Num = nWriteSocket(Socket_id_new, (char *)&wdTosDownloadFile, iSendLen);
			printf("send content [%s]\n", &wdTosDownloadFile);
		}
		else
		{
			printf("not first send\n");
			iSendLen = iLen;
			Num = nWriteSocket(Socket_id_new, (char *)&wdTosDownloadFile.sFileContent, iSendLen);
			printf("send content [%s]\n", &wdTosDownloadFile.sFileContent);
		}
		alarm(0);
		iFirst = 0;
	}

	HtLog(HTLM_COM, "Send OK!");
	fclose(fp);
	Quit(0);
}
