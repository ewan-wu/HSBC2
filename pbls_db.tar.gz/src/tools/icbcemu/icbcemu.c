/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: e3emu.c                                                     */
/* DESCRIPTIONS: The bridge and convert-in process server.                   */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/signal.h>
#include "msgque.h"
#include "msglog.h"
#include "glb_def.h"
#include "wd_incl.h"
#include "ipc.h"
#include "convert.h"

#include "htlog.h"
char logfile[256];
char filename[256];

short   InitBridge();
void    vBdgProcess(void*, short); 
void    QuitTerminate(int sig);


/*****************************************************************************/
/* FUNC:   short InitBridge ();                                              */
/* INPUT:  <none>                                                            */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Initialize the BRIDGE server.                                     */
/*         1. Initial the toplink message queues which BRIDGE may use.       */
/*         2. Open the (Connect to) database.                                */
/*         3. Load the route information.                             		 */
/*         4. Close the (Disconnect from) database.                          */
/*****************************************************************************/


/*****************************************************************************/
/* FUNC:   void main ();                                                     */
/* INPUT:  <none>                                                            */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Toplink BRIDGE server main process.                               */
/*         1. InitBridge().                                                  */
/*         2. Main loop: Handle the received messages.                       */
/*****************************************************************************/
void main(int argc, char **argv)
{
	short nRet;
	long lMsgSource;
	char sTime[15];
	short nDataLen=0;
	char sDataBuf[CNS_MAX_PKT_LEN];
	T_MsgKeyData        tMsgKeyData;

	if ( argc != 4 )
	{
		fprintf(stdout, "Usage: icbcemu <logfile> <filename> <seqno>\n");
		exit(1);
	}

	setbuf(stdout, NULL);
	sigset(SIGTERM, QuitTerminate);

	nRet = GetLogName(argv[1], logfile);
	if (nRet != 0 )
	{
		ErrReport(CI_E3BDG,
				  EI_PROCESS,
				  0,
				  CI_SEVERITY_SYSERROR,
				  ES_PROCESS_EXIT);
		fprintf(stderr, "GetLogName error !\n");
	}
	nRet = GetLogName(argv[2], filename);
	if (nRet != 0 )
	{
		ErrReport(CI_ICBCBDG,
				  EI_PROCESS,
				  0,
				  CI_SEVERITY_SYSERROR,
				  ES_PROCESS_EXIT);
		fprintf(stderr, "GetLogName error !\n");
	}
	/**************/
	/* InitBridge */
	/**************/
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"InitBridge: begin\n");
	nRet = nInitMsgQue(CI_ICBCCOMM, logfile);
	if (nRet != 0)
	{
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    			"InitBridge:error\n");
		ErrReport(CI_ICBCBDG,
				  EI_PROCESS,
				  0,
				  CI_SEVERITY_SYSERROR,
				  ES_PROCESS_EXIT);
       	exit(1);
	}

	nRet = nInitMsgQue(CI_ICBCBDG, logfile);
	if (nRet != 0)
	{
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    			"InitBridge:error\n");
		ErrReport(CI_ICBCCOMM,
				  EI_PROCESS,
				  0,
				  CI_SEVERITY_SYSERROR,
				  ES_PROCESS_EXIT);
       	exit(1);
	}
    memset(&tMsgKeyData, ' ', sizeof(tMsgKeyData));
    memcpy(tMsgKeyData.msg_date, "20081021", 8);
	/*
    memcpy(tMsgKeyData.msg_seqno, "20000009", 8);
	*/
	memcpy(tMsgKeyData.msg_seqno, argv[3], 8);
    memcpy(tMsgKeyData.msg_type, PBLS_MSG_TYPE_ICBC,
            strlen(PBLS_MSG_TYPE_ICBC));
    tMsgKeyData.msg_io = PBLS_MSG_IO_IN[0];
    tMsgKeyData.msg_source = PBLS_MSG_SOURCE_ONLINE[0];
    memset(&tMsgKeyData.msg_file_name, '\0',
            sizeof(tMsgKeyData.msg_file_name));
    memcpy(tMsgKeyData.msg_file_name, filename, strlen(filename));

    memset(sDataBuf, 0, sizeof (sDataBuf));
    strcpy(sDataBuf, (char *)&tMsgKeyData);
    nDataLen = strlen(sDataBuf);

	/*
    nRet = nCommonMsqSend(nDataLen, sDataBuf, CI_E3COMM, CI_E3BDG);
	*/
	nRet = nCommonMsqSend(nDataLen, sDataBuf, CI_ICBCCOMM, CI_ICBCBDG);
    if (nRet != 0) {
          HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "e3comm: can't write into system queue %d\n", nRet);
			exit(1);
    }


	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    		"InitBridge:success return\n");

} /* end of main() */

void QuitTerminate(int sig)
{
    short nRet;
    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
            "\nCnapsBridge PROCESS(%d) Normal[%d] EXIT AT %s\n",
            getpid(), sig, GetSystemTime());
    ErrReport(CI_CCBBDG,
          EI_PROCESS,
          sig,
          CI_SEVERITY_SYSERROR,
          "CCBBDG���������˳�");
    nRet=DbDisConnect();
    if (nRet != 0)
    {
        ErrReport(CI_CCBBDG,
                  EI_DATABASE,
                  nRet,
                  CI_SEVERITY_SYSERROR,
                  ES_DB_CLOSE);
        return ;
    }
    exit(1);
}

