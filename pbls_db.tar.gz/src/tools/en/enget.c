/************
*
*************/
#include "mbfe.h"

int	 convert_env(char *str)
{
char envbuf[512],buf[512];
char *ptr=NULL,*ptr1=NULL;
int  choice=0;
/*len,*/
	
	memset(buf, 0, sizeof(buf));

   	ptr=(char *)strpbrk((char *)str,"./");
	if ( ptr != NULL )
	{
		choice = 1;
		memset(envbuf, 0, sizeof(envbuf));
		memcpy(envbuf, &str[1], ptr-str-1);
	}
	else
	{
		choice = 2;
		memset(envbuf, 0, sizeof(envbuf));
		strcpy(envbuf,&str[1]);
	}

#ifdef PRT_CONVERT
	printf("before convert, envbuf=[%s]\n", str);	
#endif

	ptr1=(char *)getenv(envbuf);
	if ( ptr1 == (char *)NULL )
	{
		fprintf(stdout, "environment variable [%s] not exist !\n", envbuf);
		return -1;
	}
	else
	{
		if ( choice == 1 )
		{
			strcat(buf, ptr1);
			strcat(buf, ptr);
		}
		else if ( choice == 2 )
			strcat(buf, ptr1);
	}

	/*len=strlen(buf);*/

	memset(str, 0, sizeof(str));
	strcpy(str, buf);

#ifdef PRT_CONVERT
	printf("after  convert, envbuf=[%s]\n", str);
#endif

	return 0;
}


int replace_env_var(char *str)
{
char *ptr=NULL;
char buf[512], field[512];
int	 len=0,nRet,flag;
int  count=1,i,j;

	/********************************************************************/
	/* 		delete 	characters ' ','(',')','\t' from string "str"		*/
	/********************************************************************/
    len=strlen(str);
    memset(buf,0,sizeof(buf));

    for(i=0,j=0;i<len;i++)
    if ( str[i] != ' ' && str[i] != '\t' && str[i] != '(' && str[i] != ')' )
        buf[j++]=str[i];

    memset(str,0, len);
    strcpy(str,buf);

	/********************************************************/
	/* 		distinguish if first character is ' ' or not	*/
	/********************************************************/
	if ( str[0] == '$' )
		flag = 1;
	else
		flag = 2;

	memset(buf, 0, sizeof(buf));
	if ( flag == 1 )
	{
	   	ptr=(char *)strtok((char *)str,"$");
   		while ( ptr != NULL )
		{
			memset(field, 0, sizeof(field));
			sprintf(field,"%c%s",'$',ptr);
			nRet = convert_env(field);
			if ( nRet != 0 )
				return -1;
	
			strcat(buf, field);

			ptr=(char *)strtok((char *)NULL,"$");
		}
	}
	else if ( flag == 2 )
	{
	   	ptr=(char *)strtok((char *)str,"$");
   		while ( ptr != NULL )
		{
			count++;
			if ( count != 2)
			{
				memset(field, 0, sizeof(field));
				sprintf(field,"%c%s",'$',ptr);
				nRet = convert_env(field);
				if ( nRet != 0 )
					return -1;
			}
			else
			{
				memset(field, 0, sizeof(field));
				sprintf(field,"%s",ptr);
			}

			strcat(buf, field);

			ptr=(char *)strtok((char *)NULL,"$");
		}
	}

	len = strlen(buf);
	memcpy(str, buf, len+1);

	return 0;
}
/*********************************************
*Usage:
*	enget <shiperFile> <plainTextTempFile> <keyFile>
*
*********************************************/
int  main(int argc, char *argv[])
{
	int  nRet;
	int  i;
	char sCmd[700];
	char sDBFile[200];
	char sDBFiletmp[200];
	char sKeyFile[200];
	char sBufRead[101];
	FILE *fp;

	if (argc<4)
	{
		printf("argument error\nenget <cipherFile> <plainTextTempFile> <keyFile>\n");
		exit(1);
	}
	
	memset(sDBFile, 0, sizeof(sDBFile));
	memset(sDBFiletmp, 0, sizeof(sDBFiletmp));
	memset(sKeyFile, 0, sizeof(sKeyFile));
	memset(sBufRead, 0, sizeof(sBufRead));

	sprintf(sDBFile, "%s", argv[1]);
	sprintf(sDBFiletmp, "%s", argv[2]);
	sprintf(sKeyFile, "%s", argv[3]);
	
	replace_env_var(sDBFile);
	replace_env_var(sDBFiletmp);
	replace_env_var(sKeyFile);
	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/bin/tb_crypto d %s %s %s", (char*)getenv("APPL"), sDBFile, sDBFiletmp, sKeyFile);
#ifdef PRT_CONVERT
	printf("sCmd=[%s]\n", sCmd);
#endif
	nRet = 0;
	nRet = system(sCmd);
	if (nRet != 0)
	{
		printf("Decrypt Password File Fail!\n");
		return -1;
	}
	
	fp = NULL;
	memset(sBufRead, 0, sizeof(sBufRead));
	fp = fopen(sDBFiletmp , "r");
	if ( fp == NULL )
	{
		printf("Open Decrypted Password File Fail!\n");
		return -1;
	}
	/*
	i=0;
	while(i<200) 
	{
		fscanf(fp, "%c", &sBufRead[i]);
		i++;
	}
	printf("wile_sBuf=[%s]\n", sBufRead);
	*/
	fgets(sBufRead, 200, fp);
	fclose(fp);
	printf("%s\n", sBufRead);
	
	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "rm -f %s", sDBFiletmp);
	
	nRet = system(sCmd);
	if (nRet != 0)
	{
		printf("Remove Decrypted Password File Fail!\n");
	}	
	return 0;

}

