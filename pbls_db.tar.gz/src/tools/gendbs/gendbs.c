/******************************************************************************/
/*  Copyright (c) 2000                                                        */
/*  ShangHai HuaTeng Co.,LTD                                                  */
/******************************************************************************/
#include <stdio.h>
#include <string.h>

FILE	*fsql;
FILE	*fwd;
FILE	*fhvar;
FILE	*fexthvar;
FILE	*fdbs;
FILE	*finit;
char	GsTable[80];
char	GsTableCap[80];
char	GsFile[80];
char	GsBuffer[200];
struct Schema 
{
char	name[80];
int		type;
double  len;
};

struct Schema	GtSchema[400];
struct Schema	GtIdx[50];
int				GiSchema;
int				GiIdx;
int 			GiStart;

#define		TYPE_CHAR		1
#define		TYPE_VARCHAR	2
#define		TYPE_INTEGER	3
#define		TYPE_DECIMAL	4
#define		TYPE_SHORT		5
#define		TYPE_LONG		6

main(argc,argv)
int	argc;
char	**argv;
{
	int	LiI;

	if ( argc != 2 )
	{
		printf("Try this :%s <table>\n",argv[0] );
		exit(1);
	}
	printf("\n\n\n\n");
	printf("          ******************************************\n");
	printf("          DataBase Service routine generation tool  \n");
	printf("          ******************************************\n");
	printf("\n");
	printf("This tools need the environmental variable \n");
	printf("to locate the home directory\n");
	printf("The input %s.sql is located in %s/db/sql/ directory.\n",argv[1],getenv("APPL"));
	printf("Be sure the .sql file is in create table/create index syntax of Oracle \n");
	printf("The result files includes 3 files :\n\n");
	printf("    [table].wd       -- the working structure for database service routine\n");
	printf("                        at $APPL/incl/dbincl \n");
	printf("                        to be append to $APPL/incl/dbincl/wd_incl.h \n");
	printf("    dbsvr_[table].pc -- the Esql/C source code of database service routine\n");
	printf("                        at $APPL/src/dbsvr \n");
	printf("\n\n");
	printf("Process O.K.\n");
	printf("\n\n");

	strcpy(GsTable,argv[1]);
	strcpy(GsTableCap,argv[1]);
	for(LiI=0;LiI<(int)strlen(GsTable);LiI++)
	{
		GsTable[LiI]=tolower(GsTable[LiI]);
		GsTableCap[LiI]=toupper(GsTable[LiI]);
	}

	strcpy(GsFile,(char *)getenv("APPL"));
	strcat(GsFile,"/db/sql/"); 
	strcat(GsFile,GsTable);
	strcat(GsFile,".sql");
	fsql=fopen(GsFile,"r");	
	if ( fsql == NULL )
	{
		printf("sql file not found:%s ",GsFile );
		exit(1);
	}

	strcpy(GsFile,(char *)getenv("APPL"));
	strcat(GsFile,"/incl/dbincl/");
	strcat(GsFile,GsTable);
	strcat(GsFile,".wd");
	fwd=fopen(GsFile,"w");	
	if ( fsql == NULL )
	{
		printf("wd file write error");
		exit(1);
	}
	
	strcpy(GsFile,(char *)getenv("APPL"));
	strcat(GsFile,"/incl/dbincl/");
	strcat(GsFile,GsTableCap);
	strcat(GsFile,"_HVAR.h");
	fhvar=fopen(GsFile,"w");	
	if ( fhvar == NULL )
	{
		printf("hvar file write error");
		exit(1);
	}

	strcpy(GsFile,(char *)getenv("APPL"));
	strcat(GsFile,"/incl/dbincl/EXTERN_");
	strcat(GsFile,GsTableCap);
	strcat(GsFile,"_HVAR.h");
	fexthvar=fopen(GsFile,"w");	
	if ( fexthvar == NULL )
	{
		printf("exthvar file write error");
		exit(1);
	}

	strcpy(GsFile,(char *)getenv("APPL"));
	strcat(GsFile,"/src/dbsvr/");
	strcat(GsFile,"dbsvr_");
	strcat(GsFile,GsTable);
	strcat(GsFile,".pc");
	fdbs=fopen(GsFile,"w");	
	if ( fdbs == NULL )
	{
		printf("dbsvr file write error");
		exit(1);
	}

	strcpy(GsFile,(char *)getenv("APPL"));
	strcat(GsFile,"/src/dbsvr/");
	strcat(GsFile,"init_");
	strcat(GsFile,GsTable);
	strcat(GsFile,"_hvar");
	strcat(GsFile,".pc");
	finit=fopen(GsFile,"w");	
	if ( finit == NULL )
	{
		printf("Init_HVAR file write error");
		exit(1);
	}

	memset(GtSchema,0x00,sizeof(GtSchema));
	memset(GtIdx,0x00,sizeof(GtIdx));
	GiSchema=GiIdx=0;

	gen_wd();
	gen_hvar();
	gen_exthvar();
	gen_dbs();
	gen_init();
	fclose(fwd);
	fclose(fhvar);
	fclose(fexthvar);
	fclose(fdbs);
	fclose(finit);
	printf("=========Gen wd,HVAR,pc,c Successfully  !!!=========\n");
	exit(0);
}


gen_wd()
{
	char	*LpKey,*LpC1,*LpC2,*LpC3;
	char	LsStr[200];
	int		LiI;
	int		First=0;


	rewind(fsql);

	First = 0;
	GiStart=0;

	while(1)
	{
		memset(GsBuffer,0x00,sizeof(GsBuffer));
		if ( fgets(GsBuffer,sizeof(GsBuffer),fsql) == NULL )
			break;
		for(LiI=0;LiI<(int)strlen(GsBuffer);LiI++) 
			GsBuffer[LiI]=tolower(GsBuffer[LiI]);

		LpKey=strtok(GsBuffer,", /*()\t\n}{;");
		if ( LpKey == NULL ) 
			continue;

		if ( strcmp(LpKey,"create") == 0 )
		{
			LpC1=strtok(NULL,", /*()\t\n;{}");
			if ( LpC1 == NULL )
				continue;
			else if ( strcmp(LpC1,"table") == 0 )
			{
				GiStart=1;
				sprintf(LsStr,"struct wd_%s_area {\n",GsTable);
				fputs(LsStr,fwd);
			}
			else
			{
				if ( GiStart )
				{
					GiStart=0;
					fputs("};\n",fwd);
				}
			}
			continue;
		}
		
		if ( ! GiStart )
		{
			continue;
		}

		LpC1=strtok(NULL,", /*()\t\n;{}");
		if ( LpC1 == NULL )
			continue;
		if ( strcmp(LpC1,"char") == 0  ||
		     strcmp(LpC1,"varchar2") == 0 ||
		     strcmp(LpC1,"number") == 0 ||
		     strcmp(LpC1,"varchar") == 0)
		{
			int	LiNum;
			int	LiDot;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
			LpC3=strtok(NULL,", /*()\t\n;{}");
			if ( LpC3 != NULL )
				LiDot=atoi(LpC3);
			else
				LiDot=0;
			if (strcmp(LpC1, "char") == 0) {
				sprintf(LsStr,"\tchar  \t\t%s\t[%3d];\n",LpKey,LiNum+1);
				GtSchema[GiSchema].type=TYPE_CHAR;
				GtSchema[GiSchema].len=LiNum;
			} else if (strcmp(LpC1, "varchar2") == 0 ||
			strcmp(LpC1, "varchar") == 0 ) {
				sprintf(LsStr,"\tchar  \t\t%s\t[%3d];\n",LpKey,LiNum+1);
				GtSchema[GiSchema].type=TYPE_VARCHAR;
				GtSchema[GiSchema].len=LiNum;
			} else if (strcmp(LpC1, "number") == 0) {
				if (LiNum > 8 || (LiDot >= 1 && LiDot <= 9)) {
					sprintf(LsStr,"\tdouble\t\t%s;\n",LpKey);
					GtSchema[GiSchema].type=TYPE_DECIMAL;
				} else if((LiNum > 4)&&(LiNum <= 9))  {
					sprintf(LsStr,"\tlong\t\t%s;\n",LpKey);
					GtSchema[GiSchema].type=TYPE_LONG;
					GtSchema[GiSchema].len=LiNum;
				} else {
					sprintf(LsStr,"\tshort\t\t%s;\n",LpKey);
					GtSchema[GiSchema].type=TYPE_SHORT;
					GtSchema[GiSchema].len=LiNum;
				}	
							
			}
			fputs(LsStr,fwd);
			strcpy(GtSchema[GiSchema].name,LpKey);
			GiSchema++;
		}
		continue;
	}
}

gen_hvar()
{
	int		GiStart;
	char	*LpKey,*LpC1,*LpC2,*LpC3;
	char	LsStr[200];
	int		LiI;


	rewind(fsql);

	GiStart=0;
	while(1)
	{
		memset(GsBuffer,0x00,sizeof(GsBuffer));
		if ( fgets(GsBuffer,sizeof(GsBuffer),fsql) == NULL )
			break;
		for(LiI=0;LiI<(int)strlen(GsBuffer);LiI++) 
			GsBuffer[LiI]=tolower(GsBuffer[LiI]);

		LpKey=strtok(GsBuffer,", /*()\t\n}{;");
		if ( LpKey == NULL ) 
			continue;
		if ( strcmp(LpKey,"create") == 0 )
		{
			LpC1=strtok(NULL,", /*()\t\n;{}");
			if ( LpC1 == NULL )
				continue;
			else if ( strcmp(LpC1,"table") == 0 )
			{
				GiStart=1;
				sprintf(LsStr,"EXEC SQL BEGIN DECLARE SECTION;\n");
				fputs(LsStr,fhvar);
			}
			else
			{
				if ( GiStart )
				{
					GiStart=0;
				sprintf(LsStr,"EXEC SQL END DECLARE SECTION;\n");
				fputs(LsStr,fhvar);
				}
			}
			continue;
		}
		
		if ( ! GiStart )
		{
			continue;
		}

		LpC1=strtok(NULL,", /*()\t\n;{}");
		if ( LpC1 == NULL )
			continue;
		toCap(LpKey);
		if ( strcmp(LpC1,"integer") == 0  ||
		     strcmp(LpC1,"int") == 0  ||
		     strcmp(LpC1,"smallint") == 0 )
		{
			sprintf(LsStr,"\tint   \t\tH_%s_%s;\n",GsTableCap,LpKey);
			fputs(LsStr,fhvar);
		}
		else if ( strcmp(LpC1,"decimal") == 0  ||
		     strcmp(LpC1,"numeric") == 0  ||
		     strcmp(LpC1,"money") == 0  )
		{
			sprintf(LsStr,"\tdouble\t\tH_%s_%s;\n",GsTableCap,LpKey);
			fputs(LsStr,fhvar);
		}
		else if ( strcmp(LpC1,"char") == 0  ||
		     strcmp(LpC1,"number") == 0 )
		{
			int	LiNum;
			int	LiDot;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
			LpC3=strtok(NULL,", /*()\t\n;{}");
			if ( LpC3 != NULL )
				LiDot=atoi(LpC3);
			else
				LiDot=0;
			if ( strcmp(LpC1, "char") == 0 ) {
				sprintf(LsStr,"\tchar  \t\tH_%s_%s\t[%3d];\n",GsTableCap,LpKey,LiNum+1);
			} 
			else if (strcmp(LpC1, "number") == 0) {
				if (LiNum > 8 || (LiDot >= 1 && LiDot <= 9)) {
					sprintf(LsStr,"\tdouble\t\tH_%s_%s;\n",GsTableCap,LpKey);
				} else {
					sprintf(LsStr,"\tint   \t\tH_%s_%s;\n",GsTableCap,LpKey);
				}
			}
			fputs(LsStr,fhvar);
		}
		else if ( strcmp(LpC1,"varchar2") == 0 )
		{
			int	LiNum;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
			LpC3=strtok(NULL,", /*()\t\n;{}");
			sprintf(LsStr,"\tvarchar2  \t\tH_%s_%s\t[%3d];\n",GsTableCap,LpKey,LiNum+1);
			fputs(LsStr,fhvar);
		}
		else if ( strcmp(LpC1,"varchar") == 0)
		{
			int	LiNum;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
			LpC3=strtok(NULL,", /*()\t\n;{}");
			sprintf(LsStr,"\tvarchar  \tH_%s_%s\t[%3d];\n",GsTableCap,LpKey,LiNum+1);
			fputs(LsStr,fhvar);
		}
		continue;
	}

}
gen_exthvar()
{
	int		GiStart;
	char	*LpKey,*LpC1,*LpC2,*LpC3;
	char	LsStr[200];
	int		LiI;


	rewind(fsql);

	GiStart=0;
	while(1)
	{
		memset(GsBuffer,0x00,sizeof(GsBuffer));
		if ( fgets(GsBuffer,sizeof(GsBuffer),fsql) == NULL )
			break;
		for(LiI=0;LiI<(int)strlen(GsBuffer);LiI++) 
			GsBuffer[LiI]=tolower(GsBuffer[LiI]);

		LpKey=strtok(GsBuffer,", /*()\t\n}{;");
		if ( LpKey == NULL ) 
			continue;
		if ( strcmp(LpKey,"create") == 0 )
		{
			LpC1=strtok(NULL,", /*()\t\n;{}");
			if ( LpC1 == NULL )
				continue;
			else if ( strcmp(LpC1,"table") == 0 )
			{
				GiStart=1;
				sprintf(LsStr,"EXEC SQL BEGIN DECLARE SECTION;\n");
				fputs(LsStr,fexthvar);
			}
			else
			{
				if ( GiStart )
				{
					GiStart=0;
				sprintf(LsStr,"EXEC SQL END DECLARE SECTION;\n");
				fputs(LsStr,fexthvar);
				}
			}
			continue;
		}
		
		if ( ! GiStart )
		{
			continue;
		}

		LpC1=strtok(NULL,", /*()\t\n;{}");
		if ( LpC1 == NULL )
			continue;
		toCap(LpKey);
		if ( strcmp(LpC1,"integer") == 0  ||
		     strcmp(LpC1,"int") == 0  ||
		     strcmp(LpC1,"smallint") == 0 )
		{
			sprintf(LsStr,"\textern int   \t\tH_%s_%s;\n",GsTableCap,LpKey);
			fputs(LsStr,fexthvar);
		}
		else if ( strcmp(LpC1,"decimal") == 0  ||
		     strcmp(LpC1,"numeric") == 0  ||
		     strcmp(LpC1,"money") == 0  )
		{
			sprintf(LsStr,"\textern double\t\tH_%s_%s;\n",GsTableCap,LpKey);
			fputs(LsStr,fexthvar);
		}
		else if ( strcmp(LpC1,"char") == 0  ||
		     strcmp(LpC1,"number") == 0 )
		{
			int	LiNum;
			int	LiDot;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
			LpC3=strtok(NULL,", /*()\t\n;{}");
			if ( LpC3 != NULL )
				LiDot=atoi(LpC3);
			else
				LiDot=0;
			if ( strcmp(LpC1, "char") == 0 ) {
				sprintf(LsStr,"\textern char  \t\tH_%s_%s\t[%3d];\n",GsTableCap,LpKey,LiNum+1);
			} 
			else if (strcmp(LpC1, "number") == 0) {
				if (LiNum > 8 || (LiDot >= 1 && LiDot <= 9)) {
					sprintf(LsStr,"\textern double\t\tH_%s_%s;\n",GsTableCap,LpKey);
				} else {
					sprintf(LsStr,"\textern int   \t\tH_%s_%s;\n",GsTableCap,LpKey);
				}
			}
			fputs(LsStr,fexthvar);
		}
		else if ( strcmp(LpC1,"varchar2") == 0 )
		{
			int	LiNum;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
			LpC3=strtok(NULL,", /*()\t\n;{}");
			sprintf(LsStr,"\textern varchar2  \t\tH_%s_%s\t[%3d];\n",GsTableCap,LpKey,LiNum+1);
			fputs(LsStr,fexthvar);
		}
		else if ( strcmp(LpC1,"varchar") == 0)
		{
			int	LiNum;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
			LpC3=strtok(NULL,", /*()\t\n;{}");
			sprintf(LsStr,"\textern varchar  \tH_%s_%s\t[%3d];\n",GsTableCap,LpKey,LiNum+1);
			fputs(LsStr,fexthvar);
		}
		continue;
	}

}

toCap(IsBuffer)
char	*IsBuffer;
{
	int	LiI;
	for(LiI=0;LiI<(int)strlen(IsBuffer);LiI++)
	{
		*(IsBuffer+LiI)=toupper(*(IsBuffer+LiI));
	}
}

gen_dbs()
{
	char	*LpKey,*LpC1;
	char	LsCap[30];
	int	LiI,LiJ;

	rewind(fsql);

	GiStart=0;
	while(1)
	{
		memset(GsBuffer,0x00,sizeof(GsBuffer));
		if ( fgets(GsBuffer,sizeof(GsBuffer),fsql) == NULL )
			break;
		for(LiI=0;LiI<(int)strlen(GsBuffer);LiI++) 
			GsBuffer[LiI]=tolower(GsBuffer[LiI]);
		
		LpKey=strtok(GsBuffer,", /*()\t\n}{;");
		if ( LpKey == NULL ) 
			continue;
		if ( strcmp(LpKey,"create") == 0 )
		{
			LpC1=strtok(NULL,", /*()\t\n;{}");
			if ( LpC1 == NULL )
				continue;
			else if ( strcmp(LpC1,"unique") == 0 )
			{
				LpC1=strtok(NULL,", /*()\t\n;{}");
				LpC1=strtok(NULL,", /*()\t\n;{}");
				LpC1=strtok(NULL,", /*()\t\n;{}");
				LpC1=strtok(NULL,", /*()\t\n;{}");
				for(GiIdx=0; LpC1 != NULL;GiIdx++ )
				{
					LpC1=strtok(NULL,", /*()\t\n;{}");
					if ( LpC1 == NULL )
						break;
					strcpy(GtIdx[GiIdx].name,LpC1);
				}
			}
		}
	}

	for (LiI=0;LiI<GiIdx;LiI++)
	{
		for(LiJ=0;LiJ<GiSchema;LiJ++)
		{
			if ( strcmp(GtIdx[LiI].name,GtSchema[LiJ].name) == 0 )
			{
				GtIdx[LiI].type=GtSchema[LiJ].type;
				GtIdx[LiI].len=GtSchema[LiJ].len;
			}
		}
	}

	/*** Begin here ***/
	fputs("/******************************************************************************/\n",fdbs);
	fputs("/*  Copyright (c) 2000                                                        */\n",fdbs);
	fputs("/*  ShangHai HuaTeng Co.,LTD                                                  */\n",fdbs);
	fputs("/******************************************************************************/\n",fdbs);
	fputs("#include \"glb_def.h\"\n",fdbs);
	fputs("#include \"wd_incl.h\"\n",fdbs);
	fputs("EXEC SQL include sqlca;\n",fdbs);
	fprintf(fdbs,"EXEC SQL include \"%s_HVAR.h\";\n",GsTableCap);
	fprintf(fdbs,"struct	wd_%s_area\tsd_%s;\n",GsTable,GsTable);
fputs("/*************************************************************************/\n",fdbs);
fputs("/*    input : DBS_FUNC   the batch dbs func                              */\n",fdbs);
fputs("/*                       DBS_INI                                        */\n",fdbs);
fputs("/*                       DBS_FIND                                        */\n",fdbs);
fputs("/*                       DBS_LOCK_NOCURSOR                                  */\n",fdbs);
fputs("/*                       DBS_LOCK                                        */\n",fdbs);
fputs("/*                       DBS_UPDATE                                      */\n",fdbs);
fputs("/*                       DBS_INSERT                                      */\n",fdbs);
fputs("/*                       DBS_DELETE                                      */\n",fdbs);
fputs("/*                       DBS_CLOSE                                       */\n",fdbs);
fputs("/*                       DBS_IUPD                                        */\n",fdbs);
fputs("/*                       DBS_IDEL                                        */\n",fdbs);
fputs("/*                 wd_bctl    the struct pointer of wd_bctl define in    */\n",fdbs);
fputs("/*                            wd_incl.h                                  */\n",fdbs);
fputs("/*         return : the sqlca.sqlcode                                    */\n",fdbs);
fputs("/*************************************************************************/\n",fdbs);

	fprintf(fdbs,"Dbs%s( ifunc , LtpWd%s )\n",GsTableCap,GsTableCap);
	fprintf(fdbs,"int\tifunc;\n");
	fprintf(fdbs,"struct wd_%s_area\t*LtpWd%s;\n",GsTable,GsTableCap);
	fputs("{\n",fdbs);
	
	for(LiI=0;LiI<GiSchema;LiI++)
	{
		strcpy(LsCap,GtSchema[LiI].name);
		toCap(LsCap);
		switch(GtSchema[LiI].type)
		{
		case TYPE_VARCHAR:
			fprintf(fdbs,"\tvarchar\t%s[4000];\n", GtSchema[LiI].name);
		}
	}

	if (GiIdx > 0) {
		fprintf(fdbs,"\tstruct save_key {\n");
		for(LiI=0;LiI<GiIdx;LiI++)	
		{
			switch(GtIdx[LiI].type)
			{
			case TYPE_INTEGER:
				fprintf(fdbs,"\tint   \t%s ;\n", GtIdx[LiI].name);
				break;
			case TYPE_SHORT:
				fprintf(fdbs,"\tshort   \t%s ;\n", GtIdx[LiI].name);
				break;				
			case TYPE_LONG:
				fprintf(fdbs,"\tlong   \t%s ;\n", GtIdx[LiI].name);
				break;									
			case TYPE_DECIMAL:
				fprintf(fdbs,"\tdouble\t%s ;\n", GtIdx[LiI].name);
				break;
			default :
				fprintf(fdbs,"\tchar  \t%s [%2d];\n", 
				GtIdx[LiI].name,(int)GtIdx[LiI].len+1 );
				break;
			}
		}
		fputs("\t};\n",fdbs);	
		fprintf(fdbs,"\tstatic struct save_key sv;\n");
	}

	fprintf(fdbs,"\tmemcpy(&sd_%s , LtpWd%s ,sizeof(sd_%s));\n",GsTable,GsTableCap,GsTable);
	fputs("\tsqlca.sqlcode = 0;\n",fdbs);
	fputs("\tswitch( ifunc ) \n\t{\n",fdbs);	
	fputs("\tcase DBS_FIND : \n",fdbs);
	fputs("\t\tEXEC SQL select * into \n",fdbs);

	for(LiI=0;LiI<GiSchema;LiI++){
		if (GtSchema[LiI].type == TYPE_VARCHAR) {
			strcpy(LsCap,GtSchema[LiI].name);
			if (LiI == GiSchema-1)
			fprintf(fdbs,"\t\t:%s \n",LsCap);
			else
			fprintf(fdbs,"\t\t:%s ,\n",LsCap);
		} else {
			strcpy(LsCap,GtSchema[LiI].name);
			if (LiI == GiSchema-1)
			fprintf(fdbs,"\t\t:sd_%s.%s \n",GsTable,LsCap);
			else
			fprintf(fdbs,"\t\t:sd_%s.%s ,\n",GsTable,LsCap);
		}
	}

	if( GiIdx > 0)	{
		fprintf(fdbs,"\t\t\tfrom %s \n",GsTable);
		fputs("\t\t\twhere \n",fdbs);
		for(LiI=0;LiI<GiIdx;LiI++) {
			strcpy(LsCap,GtIdx[LiI].name);
			if ( LiI == GiIdx -1 )
			fprintf(fdbs,"\t\t\t\t%s = :sd_%s.%s ; \n",LsCap,GsTable,LsCap);	
			else
			fprintf(fdbs,"\t\t\t\t%s = :sd_%s.%s  and \n",LsCap,GsTable,LsCap);	
			}
		}
	else{
		fprintf(fdbs,"\t\t\tfrom %s ; \n",GsTable);
		}

	fputs("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n",fdbs);

	for(LiI=0;LiI<GiSchema;LiI++)
	{
		switch(GtSchema[LiI].type)
		{
		case TYPE_VARCHAR:
			fprintf(fdbs,"\t\tmemcpy(sd_%s.%s, (char *)%s.arr, %s.len);\n", GsTable, GtSchema[LiI].name, GtSchema[LiI].name, GtSchema[LiI].name);
		}
	}

	fprintf(fdbs,"\t\tmemcpy(LtpWd%s , &sd_%s , sizeof(sd_%s));\n",
			GsTableCap,GsTable,GsTable);
	fputs("\t\treturn(0);\n",fdbs);

	fputs("\tcase DBS_INI   :\n",fdbs);
	fprintf(fdbs,"\t\tmemset(&sd_%s, 0, sizeof(sd_%s));\n", GsTable,GsTable);
	for(LiI=0;LiI<GiSchema;LiI++)
	{
        strcpy(LsCap,GtSchema[LiI].name);
		if(GtSchema[LiI].type == TYPE_CHAR) {
		}
		else if(GtSchema[LiI].type == TYPE_VARCHAR) {
		}
		else
		{
			fprintf(fdbs,"\t\tsd_%s.%s = 0;\n", GsTable,LsCap);
		}
	}
	fprintf(fdbs,"\t\tmemcpy(LtpWd%s , &sd_%s , sizeof(sd_%s));\n",
			GsTableCap,GsTable,GsTable);
	fputs("\t\treturn(0);\n",fdbs);


	fputs("\tcase DBS_LOCK_NOCURSOR   :\n",fdbs);
    fputs("\t\tEXEC SQL select * into \n",fdbs);

    for(LiI=0;LiI<GiSchema;LiI++){
        if (GtSchema[LiI].type == TYPE_VARCHAR) {
            strcpy(LsCap,GtSchema[LiI].name);
            if (LiI == GiSchema-1)
            fprintf(fdbs,"\t\t:%s \n",LsCap);
            else
            fprintf(fdbs,"\t\t:%s ,\n",LsCap);
        } else {
            strcpy(LsCap,GtSchema[LiI].name);
            if (LiI == GiSchema-1)
            fprintf(fdbs,"\t\t:sd_%s.%s \n",GsTable,LsCap);
            else
            fprintf(fdbs,"\t\t:sd_%s.%s ,\n",GsTable,LsCap);
        }
    }

    if( GiIdx > 0)  {
        fprintf(fdbs,"\t\t\tfrom %s \n",GsTable);
        fputs("\t\t\twhere \n",fdbs);
        for(LiI=0;LiI<GiIdx;LiI++) {
            strcpy(LsCap,GtIdx[LiI].name);
            if ( LiI == GiIdx -1 )
            fprintf(fdbs,"\t\t\t\t%s = :sd_%s.%s\n\t\t\tfor update; \n",
				LsCap,GsTable,LsCap);
            else
            fprintf(fdbs,"\t\t\t\t%s = :sd_%s.%s and \n",LsCap,GsTable,LsCap);
            }
        }
    else{
        fprintf(fdbs,"\t\t\tfrom %s \n\t\tfor update; \n",GsTable);
        }

    fputs("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n",fdbs);

    for(LiI=0;LiI<GiSchema;LiI++)
    {
        switch(GtSchema[LiI].type)
        {
        case TYPE_VARCHAR:
            fprintf(fdbs,"\t\tmemcpy(sd_%s.%s, (char *)%s.arr, %s.len);\n", GsTable, GtSchema[LiI].name, GtSchema[LiI].name, GtSchema[LiI].name);
        }
    }

    fprintf(fdbs,"\t\tmemcpy(LtpWd%s , &sd_%s , sizeof(sd_%s));\n",
            GsTableCap,GsTable,GsTable);
    fputs("\t\treturn(0);\n",fdbs);

	/*** LOCK UPDATE DELETE ***/
	fputs("\tcase DBS_LOCK   :\n",fdbs);
	fputs("\tcase DBS_UPDATE :\n",fdbs);
	fputs("\tcase DBS_DELETE :\n",fdbs);
	fputs("\tif ( ifunc == DBS_LOCK )\n",fdbs);
	fputs("\t\t{\n",fdbs);
	fputs("\t\tsqlca.sqlcode = 0;\n",fdbs);
	fprintf(fdbs,"\t\tEXEC SQL declare dbs_%s_cur cursor for select\n",GsTable);
	for(LiI=0;LiI<GiSchema;LiI++)
	{
		strcpy(LsCap,GtSchema[LiI].name);
		if ( LiI == GiSchema-1 )
		fprintf(fdbs,"\t\t\t%s \n",LsCap);
		else
		fprintf(fdbs,"\t\t\t%s ,\n",LsCap);
	}

	if(GiIdx > 0)	{
		fprintf(fdbs,"\t\tfrom %s \n",GsTable);
		fputs("\t\twhere \n",fdbs);
		for(LiI=0;LiI<GiIdx;LiI++) {
			strcpy(LsCap,GtIdx[LiI].name);
			if ( LiI == GiIdx -1 )
			fprintf(fdbs,"\t\t\t%s = :sd_%s.%s for update ;\n",LsCap,GsTable,LsCap);
			else
			fprintf(fdbs,"\t\t\t%s = :sd_%s.%s  and \n",LsCap,GsTable,LsCap);	
		}
	}
	else{
		fprintf(fdbs,"\t\tfrom %s for update ; \n",GsTable);
	}

	fputs("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405)) \n\t\t\treturn(sqlca.sqlcode);\n",fdbs);

	fprintf(fdbs,"\t\tEXEC SQL open dbs_%s_cur;\n",GsTable);
	fputs("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n",fdbs);

	fprintf(fdbs,"\t\tEXEC SQL fetch dbs_%s_cur into\n",GsTable,GsTableCap);

	for(LiI=0;LiI<GiSchema;LiI++){
		if (GtSchema[LiI].type == TYPE_VARCHAR) {
			strcpy(LsCap,GtSchema[LiI].name);
			if (LiI == GiSchema-1)
			fprintf(fdbs,"\t\t:%s;\n",LsCap);
			else
			fprintf(fdbs,"\t\t:%s ,\n",LsCap);
		} else {
			strcpy(LsCap,GtSchema[LiI].name);
			if (LiI == GiSchema-1)
			fprintf(fdbs,"\t\t:sd_%s.%s;\n",GsTable,LsCap);
			else
			fprintf(fdbs,"\t\t:sd_%s.%s,\n",GsTable,LsCap);
		}
	}

	fputs("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n",fdbs);

	for(LiI=0;LiI<GiSchema;LiI++)
	{
		switch(GtSchema[LiI].type)
		{
		case TYPE_VARCHAR:
			fprintf(fdbs,"\t\tmemcpy(sd_%s.%s, (char *)%s.arr, %s.len);\n", GsTable, GtSchema[LiI].name, GtSchema[LiI].name, GtSchema[LiI].name);
		}
	}

	fprintf(fdbs,"\t\tmemcpy(LtpWd%s , &sd_%s , sizeof(sd_%s));\n",
			GsTableCap,GsTable,GsTable);
	for(LiI=0;LiI<GiIdx;LiI++)	
	{
		switch(GtIdx[LiI].type)
		{
		case TYPE_INTEGER:
		case TYPE_SHORT:		
		case TYPE_LONG:
		case TYPE_DECIMAL:
			fprintf(fdbs,"\t\tsv.%s = sd_%s.%s;\n", GtIdx[LiI].name,GsTable,GtIdx[LiI].name);
			break;
		default :
			fprintf(fdbs,"\t\tstrcpy(sv.%s , sd_%s.%s);\n", GtIdx[LiI].name,GsTable,GtIdx[LiI].name);
			break;
		}
	}
	fputs("\t\treturn(0);\n",fdbs);
	fputs("\t\t}\n\t\telse\n\t\t{\n",fdbs);

	if (GiIdx > 0) {
		fputs("\t\tif (\n",fdbs);
		for(LiI=0;LiI<GiIdx;LiI++) {
			switch(GtIdx[LiI].type) {
			case TYPE_INTEGER:
			case TYPE_SHORT:		
			case TYPE_LONG:
			case TYPE_DECIMAL:
				if ( LiI == GiIdx-1 )
				fprintf(fdbs,"\t\t\tsv.%s != sd_%s.%s \n", GtIdx[LiI].name,GsTable,GtIdx[LiI].name);
				else
				fprintf(fdbs,"\t\t\tsv.%s != sd_%s.%s || \n", GtIdx[LiI].name,GsTable,GtIdx[LiI].name);
				break;
			default :
				if ( LiI == GiIdx-1 )
				fprintf(fdbs,"\t\tstrcmp(sv.%s , sd_%s.%s) != 0 \n", GtIdx[LiI].name,GsTable,GtIdx[LiI].name);
				else
				fprintf(fdbs,"\t\tstrcmp(sv.%s , sd_%s.%s) != 0 ||\n", GtIdx[LiI].name,GsTable,GtIdx[LiI].name);
				break;
			}
		}
	fputs("\t\t)\t\t\treturn(544);\n",fdbs);
	}

	fputs("\t\tif ( ifunc == DBS_UPDATE )\n\t\t{\n",fdbs);

	for(LiI=0;LiI<GiSchema;LiI++)
	{
		switch(GtSchema[LiI].type)
		{
		case TYPE_VARCHAR:
			fprintf(fdbs,"\t\t%s.len = strlen(sd_%s.%s);\n", GtSchema[LiI].name, GsTable, GtSchema[LiI].name);
			fprintf(fdbs,"\t\tmemcpy((char *)%s.arr, sd_%s.%s, %s.len);\n", GtSchema[LiI].name, GsTable, GtSchema[LiI].name, GtSchema[LiI].name);
		}
	}

	fprintf(fdbs,"\t\tEXEC SQL update %s set \n",GsTable );
	
	for(LiI=0;LiI<GiSchema;LiI++)
	{
		if (GtSchema[LiI].type == TYPE_VARCHAR) {
			strcpy(LsCap,GtSchema[LiI].name);
			if (LiI == GiSchema-1)
			fprintf(fdbs,"\t\t\t%s = :%s \n",LsCap, LsCap);
			else
			fprintf(fdbs,"\t\t\t%s = :%s ,\n",LsCap, LsCap);
		} else {
			strcpy(LsCap,GtSchema[LiI].name);
			if ( LiI == GiSchema-1 )
			fprintf(fdbs,"\t\t\t%s = :sd_%s.%s \n",LsCap,GsTable,LsCap);
			else
			fprintf(fdbs,"\t\t\t%s = :sd_%s.%s ,\n",LsCap,GsTable,LsCap);
		}
	}
	fprintf(fdbs,"\t\twhere current of dbs_%s_cur;\n",GsTable);

	fputs("\t\tif(sqlca.sqlcode == -1405) sqlca.sqlcode = 0;\n",fdbs);
	fputs("\t\treturn(sqlca.sqlcode);\n",fdbs);
	fputs("\t\t}\n\t\telse\n\t\t{\n",fdbs);
	fprintf(fdbs,"\t\tEXEC SQL delete from %s where current of dbs_%s_cur ;\n",
				GsTable,GsTable);
	fputs("\t\tif (sqlca.sqlcode == -1405) sqlca.sqlcode = 0;\n",fdbs);
	fputs("\t\treturn(sqlca.sqlcode);\n",fdbs);
	fputs("\t\t}\n",fdbs);
	fputs("\t\t}\n",fdbs);

	/*** INSERT ***/
	fputs("\tcase DBS_INSERT :\n",fdbs);
	for(LiI=0;LiI<GiSchema;LiI++)
	{
		switch(GtSchema[LiI].type)
		{
		case TYPE_VARCHAR:
			fprintf(fdbs,"\t\t%s.len = strlen(sd_%s.%s);\n", GtSchema[LiI].name, GsTable, GtSchema[LiI].name);
			fprintf(fdbs,"\t\tmemcpy((char *)%s.arr, sd_%s.%s, %s.len);\n", GtSchema[LiI].name, GsTable, GtSchema[LiI].name, GtSchema[LiI].name);
		}
	}

	fprintf(fdbs,"\t\tEXEC SQL insert into %s values ( \n",GsTable);
		
	for(LiI=0;LiI<GiSchema;LiI++){
		if (GtSchema[LiI].type == TYPE_VARCHAR) {
			strcpy(LsCap,GtSchema[LiI].name);
			if (LiI == GiSchema-1)
			fprintf(fdbs,"\t\t:%s \n",LsCap);
			else
			fprintf(fdbs,"\t\t:%s ,\n",LsCap);
		} else {
			strcpy(LsCap,GtSchema[LiI].name);
			if (LiI == GiSchema-1)
			fprintf(fdbs,"\t\t:sd_%s.%s \n",GsTable,LsCap);
			else
			fprintf(fdbs,"\t\t:sd_%s.%s ,\n",GsTable,LsCap);
		}
	}
	
	fputs("\t\t);\n",fdbs);
	fputs("\t\tif (sqlca.sqlcode == -1405) sqlca.sqlcode = 0;\n",fdbs);
	fputs("\t\treturn(sqlca.sqlcode);\n",fdbs);

	fputs("\tcase DBS_IUPD : \n",fdbs);
	for(LiI=0;LiI<GiSchema;LiI++)
	{
		switch(GtSchema[LiI].type)
		{
		case TYPE_VARCHAR:
			fprintf(fdbs,"\t\t%s.len = strlen(sd_%s.%s);\n", GtSchema[LiI].name, GsTable, GtSchema[LiI].name);
			fprintf(fdbs,"\t\tmemcpy((char *)%s.arr, sd_%s.%s, %s.len);\n", GtSchema[LiI].name, GsTable, GtSchema[LiI].name, GtSchema[LiI].name);
		}
	}

	fprintf(fdbs,"\t\tEXEC SQL update %s set \n",GsTable );
	for(LiI=0;LiI<GiSchema;LiI++)
	{
		int	LiK,LiKey;
		strcpy(LsCap,GtSchema[LiI].name);
		LiKey=0;
		for(LiK=0;LiK<GiIdx;LiK++)	
		{
			if ( strcmp(GtIdx[LiK].name,GtSchema[LiI].name) == 0 )
			{
				LiKey=1;
				break;
			}
		}
		if ( LiKey )
			continue;
		if ( LiI == GiSchema-1 )
			{
				if(GiIdx > 0)	{
					fprintf(fdbs,"\t\t\t%s = :sd_%s.%s \n",LsCap,GsTable,LsCap);
				}
				else{
					fprintf(fdbs,"\t\t\t%s = :sd_%s.%s;\n",LsCap,GsTable,LsCap);
				}

			}
		else
		fprintf(fdbs,"\t\t\t%s = :sd_%s.%s ,\n",LsCap,GsTable,LsCap);
	}

	if(GiIdx > 0)	{
		fputs("\t\twhere \n",fdbs);
		for(LiI=0;LiI<GiIdx;LiI++)
		{
			{
				strcpy(LsCap,GtIdx[LiI].name);
				if ( LiI == GiIdx -1 )
					fprintf(fdbs,"\t\t\t%s = :sd_%s.%s;\n",LsCap,GsTable,LsCap);
				else
					fprintf(fdbs,"\t\t\t%s = :sd_%s.%s  and \n",LsCap,GsTable,LsCap);	
			}
		}
	}
	fputs("\t\tif (sqlca.sqlcode == -1405) sqlca.sqlcode = 0;\n",fdbs);
	fputs("\t\treturn(sqlca.sqlcode);\n",fdbs);

	fputs("\tcase DBS_IDEL : \n",fdbs);

	if(GiIdx > 0)	{
		fprintf(fdbs,"\t\tEXEC SQL delete from %s\n", GsTable,GsTable);
		fputs("\t\twhere \n",fdbs);
		for(LiI=0;LiI<GiIdx;LiI++)
		{
			strcpy(LsCap,GtIdx[LiI].name);
			if ( LiI == GiIdx -1 )
			  fprintf(fdbs,"\t\t\t%s = :sd_%s.%s;\n",LsCap,GsTable,LsCap);
			else
			  fprintf(fdbs,"\t\t\t%s = :sd_%s.%s  and \n",LsCap,GsTable,LsCap);	
		}
	}
	else {
		fprintf(fdbs,"\t\tEXEC SQL delete from %s ;\n", GsTable,GsTable);
	}
	fputs("\t\tif (sqlca.sqlcode == -1405) sqlca.sqlcode = 0;\n",fdbs);
	fputs("\t\treturn(sqlca.sqlcode);\n",fdbs);

	/*** CLOSE ***/
	fputs("\tcase DBS_CLOSE : \n",fdbs);
	fprintf(fdbs,"\t\tEXEC SQL close dbs_%s_cur;\n",GsTable);
	fputs("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n",fdbs);
	
	fputs("\t\treturn(0);\n",fdbs);
	fputs("\tdefault :  return(543);\n",fdbs);
	fputs("\t}\n",fdbs);
	fputs("}\n",fdbs);
}

gen_init()
{
	char	*LpKey,*LpC1;
	char	LsCap[30];
	int		LiI,LiJ;

	rewind(fsql);

	GiStart=0;
	while(1)
	{
		memset(GsBuffer,0x00,sizeof(GsBuffer));
		if ( fgets(GsBuffer,sizeof(GsBuffer),fsql) == NULL )
			break;
		for(LiI=0;LiI<(int)strlen(GsBuffer);LiI++) 
			GsBuffer[LiI]=tolower(GsBuffer[LiI]);
		
		LpKey=strtok(GsBuffer,", /*()\t\n}{;");
		if ( LpKey == NULL ) 
			continue;
		if ( strcmp(LpKey,"create") == 0 )
		{
			LpC1=strtok(NULL,", /*()\t\n;{}");
			if ( LpC1 == NULL )
				continue;
			else if ( strcmp(LpC1,"unique") == 0 )
			{
				LpC1=strtok(NULL,", /*()\t\n;{}");
				LpC1=strtok(NULL,", /*()\t\n;{}");
				LpC1=strtok(NULL,", /*()\t\n;{}");
				LpC1=strtok(NULL,", /*()\t\n;{}");
				for(GiIdx=0; LpC1 != NULL;GiIdx++ )
				{
					LpC1=strtok(NULL,", /*()\t\n;{}");
					if ( LpC1 == NULL )
						break;
					strcpy(GtIdx[GiIdx].name,LpC1);
				}
			}
		}
	}

	for (LiI=0;LiI<GiIdx;LiI++)
	{
		for(LiJ=0;LiJ<GiSchema;LiJ++)
		{
			if ( strcmp(GtIdx[LiI].name,GtSchema[LiJ].name) == 0 )
			{
				GtIdx[LiI].type=GtSchema[LiJ].type;
				GtIdx[LiI].len=GtSchema[LiJ].len;
			}
		}
	}

	fputs("/******************************************************************************/\n",finit);
	fputs("/*  Copyright (c) 2002                                                        */\n",finit);
	fputs("/*  ShangHai HuaTeng Co.,LTD                                                  */\n",finit);
	fputs("/******************************************************************************/\n",finit);
	fputs("#include \"glb_def.h\"\n",finit);
	fputs("EXEC SQL include sqlca;\n",finit);
	fprintf(finit,"EXEC SQL include \"EXTERN_%s_HVAR.h\";\n",GsTableCap);

	fprintf(finit,"init_%s_hvar()\n",GsTable);
	fputs("{\n",finit);
	
	for(LiI=0;LiI<GiSchema;LiI++)
	{
		strcpy(LsCap,GtSchema[LiI].name);
		toCap(LsCap);
		if(GtSchema[LiI].type == TYPE_CHAR)
			fprintf(finit,"\t\tmemset(H_%s_%s, 0, sizeof(H_%s_%s));\n", 
				GsTableCap,LsCap,GsTableCap,LsCap);
		else if(GtSchema[LiI].type == TYPE_VARCHAR)
			fprintf(finit,"\t\tmemset(&H_%s_%s, 0, sizeof(H_%s_%s));\n", 
				GsTableCap,LsCap,GsTableCap,LsCap);
		else
			fprintf(finit,"\t\tH_%s_%s = 0;\n", GsTableCap,LsCap);
	}

	fputs("}\n",finit);
}

