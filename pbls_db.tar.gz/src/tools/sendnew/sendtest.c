#include <stdio.h>
#include <string.h>

char *a = "#";
char    logfile[356];


int main(int argc, char *argv[]){
	int num;
	char *pfile;
	char pkgbuf[2048];
	short pkgsize;
    FILE *fp;
    int i;
	int iRet;
	int iSrvid;
	int iDstId;

	if ( argc < 4 ){
		printf("send <filename> <SrcId> <DstId>\n");
		return 0;
	}

	iSrvid = atoi(argv[2]);	
	iDstId = atoi(argv[3]);
	pfile = argv[1];

    if ((fp = fopen(pfile, "r")) == NULL){
       printf("���ļ�����%s", pfile);
	   return 0;
    }

    memset(pkgbuf, '\0', 2048);
    pkgsize = makePkg(pkgbuf,fp);

	DbConnect();
	nLoadMsqDef();
	nCommonMsqInit(iSrvid);
	nCommonMsqInit(iDstId);

	nCommonMsqSend(pkgsize, pkgbuf, iSrvid, iDstId);
	printf("\n pkgsize=[%d]\n",pkgsize);
	printf("\n pkgbuf=[%s]\n",pkgbuf);
	return 0;
}

int makePkg(char* pkg,FILE* fp){
    int offset;
    int size;
    int leng;
    int i;
    char *p;
    char buf[356];

    memset(buf, '\0', 356);
    offset = 0;
    while(fgets(buf, 355, fp)){

        size = strlen(buf);
        if(buf[size - 1] == '\n'){
            buf[size - 1] = '\0';
        }

        strtok(buf, a);
        leng = atoi(strtok(NULL, a));
        p = strtok(NULL, a);
        i = strlen(p);
        sprintf(pkg + offset,"%.*s",leng,p);
        for(;i <= leng;++i){
            pkg[offset + i] = ' ';
        }
        offset += leng;
        memset(buf, '\0', 356);
    }
	
    return offset;
}
