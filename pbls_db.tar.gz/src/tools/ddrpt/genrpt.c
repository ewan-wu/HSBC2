/**********************************************************************
 *
 *  Rpt.c 
 *
 *  File Name      : %M%
 *  Version No     : %I%
 *  Date / Time    : %D% %T%
 *  Author         : Freeman
 *  Use Template   : Ver 1.00
 *
 *  Copyright      : Shanghai Systems & GDPSRB, Feb 1998.
 *
 *  Description    :
 *      Common routin for genarate report file according to format. 
 *
 *  Change History :
 *      Date        Name      Reason
 *      1998/05/10  Freeman   Initial Version
 *      1998/10/14  Miles     Modified for report process program
 *
 *********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

#include "genrpt.h"

static int GetOneLine(FILE *FmtFp, char *Line);
static int ReadLine(rpt_cntl_def *RptCntl, int Command);
void cnv_amount_tndivide(const char *si,char *so,int n);

int CmRpt( rpt_cntl_def *RptCntl,   
          int          Command, 
          ...
         )
{
   va_list  argptr;
   char  fmt_filename[100];
   char  *cp, *tp, *sp, *param_buf;
   char  pcmdbuf[100], prstbuf[100];       /* printf command and result buf */
   int    tmp_int;
   double tmp_double;
   char   tmp_char;
   char   *tmp_str;
   char   tmp_linebuf[MAX_LINES_LEN];
   int  o_flag, x_flag;
   char *tmp_cmdcp;
   int  outflag;

   va_start(argptr, Command);

   switch(Command){
      case RPT_INIT:
      case RPT_INIT_MULTI:
           tmp_str=va_arg(argptr, char *); 
           strcpy(fmt_filename, (char *)getenv("APPL")); 
           strcat(fmt_filename, "/etc/fmt/");
           strcat(fmt_filename, tmp_str);
           strcat(fmt_filename, ".fmt");
           RptCntl->FmtFp=fopen(fmt_filename, "rt");
           if(RptCntl->FmtFp==NULL)
           {
              fprintf( stderr, "Can't open the format file.[%s]\n", fmt_filename);
              return FAIL;
           }

           if(Command==RPT_INIT_MULTI) 
              tmp_str = va_arg(argptr, char *); 
           RptCntl->rpt_flag = va_arg(argptr, int);

           RptCntl->RptFp = stdout;

           if(RptCntl->RptFp==NULL)
           {
              fprintf( stderr, "Can't open the report file.\n");
              return FAIL;
           }

           RptCntl->LineBuf[0]='\0';
           RptCntl->LineBak[0]='\0';
           RptCntl->HeadBak[0]='\0';
           RptCntl->TailBak[0]='\0';
		   RptCntl->SummaryBak[0]='\0';

           RptCntl->line_no=0;
           ReadLine(RptCntl, RPT_TAIL);
           RptCntl->tail_lines=RptCntl->curr_lines;
		   ReadLine(RptCntl, RPT_SUMMARY);
		   RptCntl->summary_lines=RptCntl->curr_lines;
           RptCntl->expect_lines=0;
           RptCntl->head_lines=0;
           RptCntl->line_no=0;
           RptCntl->page_no=1;
           RptCntl->page_length = MAX_LINE_PER_PAGE;
		   RptCntl->BodyPosition = -1;
           return SUCCESS;

      case RPT_TITLE:
      case RPT_PROMPT:
      case RPT_BODY:
      case RPT_BODYNEXT:
      case RPT_BODY_N:
      case RPT_BODYNEXT_N:
      case RPT_SKIPBODY_N:
      case RPT_PRE_HEAD:
      case RPT_PRE_TAIL:
      case RPT_PRE_SUMMARY:
           if( Command==RPT_BODY_N || Command==RPT_BODYNEXT_N 
               || Command==RPT_SKIPBODY_N )
              RptCntl->expect_lines = va_arg(argptr, int);
           else
              if ( Command==RPT_BODY || Command==RPT_BODYNEXT )
                 RptCntl->expect_lines = 2;
              else
                 RptCntl->expect_lines = 0;    
           ReadLine( RptCntl, Command );
           if ( Command != RPT_PRE_HEAD && Command != RPT_PRE_TAIL
                && Command != RPT_PRE_SUMMARY  && Command != RPT_PROMPT )
              RptCntl->line_no += RptCntl -> curr_lines;
           if ( Command==RPT_BODY || Command==RPT_BODYNEXT
              || Command==RPT_BODY_N || Command==RPT_BODYNEXT_N )
              strcpy(RptCntl->LineBak, RptCntl->LineBuf);
	   if ( Command==RPT_SKIPBODY_N ) return SUCCESS;
           break;

      case RPT_HEAD:
           if(RptCntl->HeadBak[0]!='\0')    /* if prepared */
	   {
              strcpy(RptCntl->LineBuf, RptCntl->HeadBak);
			  RptCntl->curr_lines = RptCntl->head_lines;
	   }
           else
           {
              ReadLine(RptCntl, RPT_HEAD);
              RptCntl->head_lines = RptCntl->curr_lines;
           }
           RptCntl->line_no += RptCntl->curr_lines;
           break;

      case RPT_TAIL:
           if(RptCntl->TailBak[0]!='\0')    /* if prepared */
	   {
              strcpy(RptCntl->LineBuf, RptCntl->TailBak);
  			  RptCntl->curr_lines = RptCntl->tail_lines;
	   }
           else
           {
              ReadLine(RptCntl, RPT_TAIL);
			  RptCntl->tail_lines = RptCntl->curr_lines;
           }
           RptCntl->line_no += RptCntl->curr_lines;
           break;

      case RPT_SUMMARY:
           if ( RptCntl->SummaryBak[0] != '\0' )
	   {
              strcpy(RptCntl->LineBuf, RptCntl->SummaryBak);
			  RptCntl->curr_lines = RptCntl->summary_lines;
	   }
	   else
           {
              ReadLine(RptCntl, RPT_SUMMARY);
			  RptCntl->summary_lines = RptCntl->curr_lines;
           }
           RptCntl->line_no += RptCntl->curr_lines;
           break;

      case RPT_BODYLOOP:
           strcpy(RptCntl->LineBuf, RptCntl->LineBak);
           RptCntl->line_no += RptCntl->curr_lines;
           break;

      case RPT_CLOSE:
           fclose(RptCntl->FmtFp);
           return SUCCESS;

      default:
           return FAIL;
   }

   cp = RptCntl->LineBuf;

   /* Prepare print data according to format in RptCntl->LineBuf */
   param_buf = va_arg(argptr,char *);
   param_buf = strtok( param_buf, "\t|\n");

   while(1)
   {
      while(*cp!='%'&&*cp!='\0') cp++;
      if(*cp=='\0') break;

      sp=cp;
      tp=pcmdbuf;
      tmp_cmdcp=NULL;
      o_flag=x_flag=0;
      outflag=0;

      *tp++=*cp++;
      while(1)  
      {
         switch(*cp){
           case 'd':
           case 'i':
           case 'u':
           case 'X':
           case 's':
           case 'c':
           case 'f':
           case 'p':
                tmp_cmdcp=tp;
                break;
           case 'o':
                if(tmp_cmdcp==NULL)
                   tmp_cmdcp=tp;
                else
                   o_flag=1;
                break;
           case 'x':
                if(tmp_cmdcp==NULL)
                   tmp_cmdcp=tp;
                else
                   x_flag=1;
                break;
           case ' ':
           case '\n':
           case '\\':
           case '\0':
           case '%':
                outflag=1;
                break;
           default:
                if(tmp_cmdcp!=NULL)
                   outflag=1;
                break; 
         }
         if(outflag)
            break;
         *tp++=*cp++;
      }
      if(tmp_cmdcp==NULL) 
         continue;
      *(tmp_cmdcp+1)='\0';

      switch(*tmp_cmdcp){
        case 'd':
        case 'i':
        case 'o':
        case 'u':
        case 'x':
        case 'X':
             if ( param_buf != NULL )
             { 
                tmp_int = atoi( param_buf );
                param_buf = strtok( NULL, "\t|\n");
             }
             else tmp_int = 0;
             if ( x_flag && tmp_int == 0 )
             {
                memset(prstbuf, ' ', strlen(pcmdbuf));
                prstbuf[strlen(pcmdbuf)]='\0';
             }
             else
                sprintf(prstbuf, pcmdbuf, tmp_int);
#ifdef __N_SEPRATE		
			 cnv_amount_tndivide(prstbuf,prstbuf,3);
#endif
             break;
        case 's':
             if ( param_buf != NULL )
             {
                tmp_str = param_buf;
                param_buf = strtok( NULL, "\t|\n");
                sprintf( prstbuf, pcmdbuf, tmp_str );
             }
             else
			 {
                memset(prstbuf, ' ', strlen(pcmdbuf));
				prstbuf[strlen(pcmdbuf)]=0;
			 }
             break;
        case 'c':
             if ( param_buf != NULL )
             {
                tmp_char = param_buf[0];
                param_buf = strtok( NULL, "\t|\n");
                sprintf( prstbuf, pcmdbuf, tmp_char );
             }
             else
                sprintf(prstbuf, pcmdbuf, ' ');
             break;
        case 'f':
             if ( param_buf != NULL )
             { 
                tmp_double = atof( param_buf );
                if ( (tmp_str = strchr( pcmdbuf,'.' )) == NULL )
                   tmp_int = 0;
                else tmp_int = atoi( ++tmp_str );
                tmp_int = (int)pow( 10.0, (double)tmp_int );
                tmp_double /= tmp_int;
                param_buf = strtok( NULL, "\t|\n");
             }
             else tmp_double = 0.0;
             if ( x_flag && tmp_double == 0.0 )
             {
                memset(prstbuf, ' ', strlen(pcmdbuf));
                prstbuf[strlen(pcmdbuf)]='\0';
             }
             else
                sprintf(prstbuf, pcmdbuf, tmp_double);
			
#ifdef __N_SEPRATE		
			 cnv_amount_tndivide(prstbuf,prstbuf,3);
#endif
             break;
        case 'p':
             if(Command==RPT_PRE_TAIL || Command==RPT_PRE_HEAD) continue;
             sprintf(prstbuf, "%d", RptCntl->page_no);
             if(strlen(prstbuf)==1)
                strcat(prstbuf, " ");
             break;
        default:
             continue;
      }

      if(o_flag)
      {
         strcpy(tmp_linebuf, cp);
         memcpy(sp, prstbuf, strlen(prstbuf));
         strcpy(sp+strlen(prstbuf), tmp_linebuf);
         cp=sp+strlen(prstbuf);
      }
      else
      {
         tp=cp;
         while(*tp==' ') tp++;
         if ( tp-sp < (int)strlen(prstbuf) )
         {
            strcpy(tmp_linebuf, tp);
            memcpy(sp, prstbuf, strlen(prstbuf));
            strcpy(sp+strlen(prstbuf), tmp_linebuf);
         }
         else
         {
            memset(sp, ' ', tp-sp);
            memcpy(sp, prstbuf, strlen(prstbuf));
         }
      }

      if(*cp=='\0') break;
   }

   if (Command == RPT_PRE_HEAD)
   {
	  RptCntl->head_lines = RptCntl->curr_lines;
      strcpy(RptCntl->HeadBak, RptCntl->LineBuf);
      return SUCCESS;
   }
   if (Command == RPT_PRE_TAIL)
   {
	  RptCntl->tail_lines = RptCntl->curr_lines;
      strcpy(RptCntl->TailBak, RptCntl->LineBuf);
      return SUCCESS;
   }
   if (Command == RPT_PRE_SUMMARY)
   {
	  RptCntl->summary_lines = RptCntl->curr_lines;
      strcpy(RptCntl->SummaryBak, RptCntl->LineBuf);
      return SUCCESS;
   }
   if (Command == RPT_PROMPT )
   {
	char *ch;
	if ( RptCntl->LineBuf[0] )
	{
		ch = strchr( RptCntl->LineBuf, '\n' );
		if ( ch ) *ch = 0;
		fprintf( RptCntl->RptFp, "`!%s`\n", RptCntl->LineBuf );
	}
	return SUCCESS;
   }
   if ( RptCntl->LineBuf[0] )
      fprintf(RptCntl->RptFp, "%s", RptCntl->LineBuf);

   if( RptCntl -> line_no
	   + RptCntl -> tail_lines
	   + RptCntl -> summary_lines > RptCntl->page_length
      && Command!=RPT_HEAD && Command!=RPT_TAIL && Command != RPT_SUMMARY
      && (RptCntl->rpt_flag & RPT_FLAG_ONEPAGE)==0 )
   {
      int lines;
	  lines = RptCntl->curr_lines;
      CmRpt( RptCntl, RPT_TAIL, "" );
      fprintf(RptCntl->RptFp, "\f");
      RptCntl->page_no++;
      RptCntl->line_no=0;
      CmRpt( RptCntl, RPT_HEAD, "" );
	  RptCntl->curr_lines = lines;
   }    

   return SUCCESS;
}


/* Read several lines from format file according to Command */
static int ReadLine(rpt_cntl_def *RptCntl, int Command)
{
	char oneline[300];
	char keyword[20];
	int  lines=0;
	int  i;

	RptCntl->LineBuf[0]='\0';
	RptCntl->curr_lines=0;

	/* RPT_BODYNEXT and RPT_BODYNEXT_N get lines from current location */
	if(Command==RPT_BODYNEXT||Command==RPT_BODYNEXT_N
		|| Command==RPT_SKIPBODY_N && RptCntl->BodyPosition >= 0 )
	{
		if ( RptCntl->BodyPosition >= 0 )
			fseek(RptCntl->FmtFp, RptCntl->BodyPosition, SEEK_SET);
		for(i=0;i<RptCntl->expect_lines;i++)
		{
			RptCntl->BodyPosition = ftell( RptCntl->FmtFp );
			if ( GetOneLine(RptCntl->FmtFp, oneline ) == FAIL )
				break;
			if ( oneline[0]=='{' && strchr(oneline,'}' ) != NULL )
			{
				/* Rollback this line */
				fseek(RptCntl->FmtFp, RptCntl->BodyPosition, SEEK_SET);
				break;
			}
			strcat(RptCntl->LineBuf, oneline);
			strcat(RptCntl->LineBuf, "\n");
		}
		RptCntl->curr_lines = i;
		RptCntl->BodyPosition = ftell( RptCntl->FmtFp );
		return SUCCESS;
	} 

	fseek(RptCntl->FmtFp, 0, SEEK_SET);

	/* Define keyword  */
	switch ( Command )
	{
		case RPT_TITLE:
			strcpy(keyword, "TITLE"); 
			break;
		case RPT_HEAD:
		case RPT_PRE_HEAD:
			strcpy(keyword, "HEAD"); 
			break;
		case RPT_BODY:
		case RPT_BODY_N:
		case RPT_SKIPBODY_N:
			strcpy(keyword, "BODY"); 
			break;
		case RPT_TAIL:
		case RPT_PRE_TAIL:
			strcpy(keyword, "TAIL"); 
			break;
		case RPT_SUMMARY:
		case RPT_PRE_SUMMARY:
			strcpy(keyword, "SUMMARY" );
			break;
		case RPT_PROMPT:
			strcpy(keyword, "PROMPT" );
			break;
	}

	/*  Search the keyword  */
	while(1)
	{
		if(GetOneLine(RptCntl->FmtFp, oneline)==FAIL)
		{
/*         fprintf(stderr,"Warning: The section %s not found.\n", keyword);*/
			return FAIL;
		}
		Capstr(oneline);
		if(strncmp(oneline+1, keyword, strlen(keyword))==0)
			break;
	}

	/* if RPT_BODY, RPT_BODY_N, read expected lines(2 or N) */
	if ( Command==RPT_BODY||Command==RPT_BODY_N||Command==RPT_SKIPBODY_N )
	{
		for(i=0;i<RptCntl->expect_lines;i++)
		{
			RptCntl->BodyPosition = ftell( RptCntl->FmtFp );
			if ( GetOneLine(RptCntl->FmtFp, oneline ) == FAIL )
				break;
			if ( oneline[0]=='{' && strchr(oneline,'}' ) != NULL )
			{
				/* Rollback this line */
				fseek(RptCntl->FmtFp, RptCntl->BodyPosition, SEEK_SET);
				break;
			}
			strcat(RptCntl->LineBuf, oneline);
			strcat(RptCntl->LineBuf, "\n");
		}
		RptCntl->curr_lines=i;
		RptCntl->BodyPosition = ftell( RptCntl->FmtFp );
		return SUCCESS;
	} 

	/* for TITLE, HEAD and TAIL, read lines until meet '{'(next keyword) or EOF*/
	while(1)
	{
		if ( GetOneLine(RptCntl->FmtFp, oneline)==FAIL )
			break;
		if (oneline[0]=='{')
			break;
		lines++;
		strcat(RptCntl->LineBuf, oneline);
		strcat(RptCntl->LineBuf, "\n");
	}  
	RptCntl->curr_lines=lines;
	return SUCCESS;
}

static int GetOneLine(FILE *FmtFp, char *Line)
{
   char *cp;
   int  c;

   Line[0]='\0';
   cp=Line;
   while((c=getc(FmtFp))!='\n'&&c!=EOF) *(cp++) = c;
   *cp='\0';
   if(c==EOF)
      return FAIL;
   else
      return SUCCESS;
}

/* Convert the characters in string to Capital Char */
char *Capstr(char *str)
{
   unsigned char *cp=( unsigned char *)str;

   while(*cp!='\0') {
      *cp -= (*cp>='a'&&*cp<='z') ? 'a'-'A' : 0;
      cp ++;
      }
   return str;
}


/*******************************************
	�������n��λ��ʽ��ʾ(EX:ǧ��/���),���е�������������λ���
*******************************************/
void cnv_amount_tndivide(const char *si,char *so,int n)
{

	char	prstbuf_head[100],prstbuf_tail[50],prstbuf_rst[100],TmpVal[20];
	int 	HeadFlag=1,i,j=0,k=0,HaveDot=0,FstFlag;
	long	OrigLong,NewLong,TmpLong,DivideUnit;
	char	ZeroBuf[10],UnitFmt[4],LongFmt[10];

	if( atol(si) == 0)
    {
        strcpy(so,si);
        return ;
    }

	DivideUnit=pow(10,n);

	for(i=0; i< strlen(si); i++)
	{
		if(si[i]!='.')
		{
			if(HeadFlag==1)
			{
				prstbuf_head[j]=si[i];
				j++;
			}
			else
			{
				prstbuf_tail[k]=si[i];
				k++;
			}
		}
		else
		{
			HeadFlag=0;
			HaveDot=1;
		}
	}
	prstbuf_head[j]='\0';
	prstbuf_tail[k]='\0';

	prstbuf_rst[0]='\0';

	OrigLong=atol(prstbuf_head);

	if(OrigLong<0)
    {
        prstbuf_rst[0]='-';
        prstbuf_rst[1]='\0';
        OrigLong= 0 - OrigLong;
    }

	NewLong=OrigLong;

	i=1;
	while( (TmpLong=NewLong/DivideUnit) >= DivideUnit )
	{
		NewLong=TmpLong;	
		i++;
	}
	
	for(j=0;j<n;j++)	ZeroBuf[j]='0';
	ZeroBuf[j]='\0';

	if(NewLong==OrigLong)
	{
		if(TmpLong>0)
		{
			NewLong = OrigLong % DivideUnit;
			if ( TmpLong > 0 )
			{
				if(n==3)
					sprintf(TmpVal,"%d%s%03d",TmpLong,",",NewLong);
				else
					sprintf(TmpVal,"%d%s%04d",TmpLong,",",NewLong);
			}
			else
				sprintf(TmpVal,"%d%s%s",TmpLong,",",ZeroBuf);
		}
		else
			sprintf(TmpVal,"%d",NewLong);

		strcat(prstbuf_rst,TmpVal);
	}	
	else
	{
		NewLong=TmpLong;
		if((OrigLong-NewLong * pow(DivideUnit,i))==0)
        {
            sprintf(TmpVal,"%d",NewLong);
            strcat(prstbuf_rst,TmpVal);

            for(j=0;j<i;j++)
            {
                sprintf(TmpVal,"%s%s",",",ZeroBuf);
                strcat(prstbuf_rst,TmpVal);
            }
        }
		else
		{
			FstFlag=1;
			do
			{
				if(FstFlag==1)
				{
					sprintf(TmpVal,"%d%s",NewLong,",");
					FstFlag=0;
				}
				else
				{
					if(n==3)
						sprintf(TmpVal,"%03d%s",NewLong,",");
					else
						sprintf(TmpVal,"%04d%s",NewLong,",");
				}
				strcat(prstbuf_rst,TmpVal);
				TmpLong=OrigLong-NewLong * pow(DivideUnit,i);
				OrigLong=TmpLong;
				i--;
				NewLong=TmpLong/(pow(DivideUnit,i));
			}while(i>0);
			if(n==3)
				sprintf(TmpVal,"%03d",TmpLong);
			else
				sprintf(TmpVal,"%04d",TmpLong);
			strcat(prstbuf_rst,TmpVal);
		}
	}

	if(HaveDot==1)
	{
		strcat(prstbuf_rst,".");
		strcat(prstbuf_rst,prstbuf_tail);
	}

	strcpy(so,prstbuf_rst);

	return ;
}
