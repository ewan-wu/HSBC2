/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: hubemu.c                                                    */
/* DESCRIPTIONS: The hub emu application.                                    */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 20110412    yisiliang      hubemu                                         */
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/signal.h>
#include <sys/stat.h> 
#include <sys/types.h>
#include <unistd.h>
#include "msgque.h"
#include "msglog.h"
#include "glb_def.h"
#include "wd_incl.h"
#include "ipc.h"

int nGenerateMsgID(char *txdate, char *id)
{
    char ssn[8 + 1];
    char msg_id[16+1];
    
    memset(&ssn    , 0, sizeof(ssn)); 
    memset(&msg_id    , 0, sizeof(msg_id)); 
    printf("nNewTxnRefnoForSystem begin\n");
    if (nNewTxnRefnoForSystem(ssn) != 0)
    {
        return -1;
    }
    printf("nNewTxnRefnoForSystem end\n");
    sprintf(msg_id, "%8.8s%8.8s", txdate, ssn);
    
    memcpy(id, msg_id, 16);
    printf("msg_id=[%16.16s]\n", id);
    return 0;
}

/*
useage:hubemu type filename
*/
int main(int argc, char **argv)
{
    int  nRet;
    char sSendData[5120];
    if(argc != 3)
    {
        printf("useage:hubemu type filename\n");
        printf("useage:type = BALE/PAY1/H111 \n");
        return -1;
    }
    if(memcmp(argv[1], "BALE", 4) != 0 
        && memcmp(argv[1], "PAY1", 4) != 0
        && memcmp(argv[1], "LOGN", 4) != 0
        && memcmp(argv[1], "LOGF", 4) != 0
        && memcmp(argv[1], "H111", 4) != 0)
    {
        printf("useage:hubemu type filename\n");
        printf("useage:type = BALE/PAY1/H111 \n");
        return -1;
    }
    
    
    /*********************/
    /* Connect Database  */
    /*********************/
        nRet = DbConnect();
        if(nRet != 0 )
        {
                exit(1);
        }

    /*********************/
    /* nLoadMsqDef       */
    /*********************/
        nRet = nLoadMsqDef();
        if(nRet != 0 )
        {
                DbDisConnect();
                exit(1);
        }

        nRet = nCommonMsqAllInit(CI_PAIDBDG);
        if (nRet != 0) 
    {
        printf("nCommonMsqAllInit FAILED![%d]\n", nRet);
        DbDisConnect();
        return -4;
    }
    
    char filename[256];
    
    char sSize[9];
    char sDataBuf[1024];
    int  nDataLen;
    char sID[17];
    struct stat statbuf; 
    char md_time[15];
    memset(md_time, 0, sizeof(md_time));
    memset(sID, 0, sizeof(sID));
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, md_time);
    FILE *fp;
    T_HUB_MSG hub_msg;
    
    memset(sSize, 0, sizeof(sSize));
    memset(sSendData, 0, sizeof(sSendData));
    memset(&hub_msg, 0, sizeof(T_HUB_MSG));
    memset(filename, 0, sizeof(filename));
    memset(sDataBuf, 0, sizeof(sDataBuf));
    nRet = nGenerateMsgID(md_time, sID);
    printf("nGenerateMsgID msg_id=[%16.16s], return code=[%d]\n", sID, nRet);
    strcpy(filename, argv[2]);
    fp = fopen(filename, "r+");
    if(fp == NULL)
    {
        printf("useage:hubemu filename\n");
        printf("file[%s] do not exist!\n", filename);
        return -2;
    }
    stat(filename, &statbuf); 
    fwrite(sID, 1, 16, fp);
    fseek(fp, 20, SEEK_SET);
    sprintf(sSize, "%08d", statbuf.st_size - sizeof(T_HUB_HEAD));
    fwrite(sSize, 1, 8, fp);
    fseek(fp, 0, SEEK_SET);
    
    nRet = fread(&(hub_msg.tHubHead), 1, sizeof(hub_msg.tHubHead), fp);
    if(nRet != sizeof(hub_msg.tHubHead))
    {
        printf("useage:hubemu filename\n");
        printf("read hub head from file[%s] failed!\n", filename);
        return -3;
    }
    /*if pay1 replace hub refno with sID*/
    fseek(fp, 473, SEEK_SET);
    fwrite(sID, 1, 16, fp);
    fclose(fp);
    /* send to pbhubbdg */
    strcpy(hub_msg.file_name, filename);
    sprintf(sSize, "%08d", statbuf.st_size);
    memcpy(hub_msg.file_size, sSize, 8);
    hub_msg.msg_io = 'I';

        memcpy(sSendData, &hub_msg, sizeof(hub_msg));
        printf("Length:%d\n", sizeof(hub_msg));
        printf("Data:%s\n", sSendData);
        nRet = nCommonMsqSend(sizeof(hub_msg), sSendData, CI_PAIDCOMM, CI_PAIDBDG);
    if (nRet != 0) 
    {
        printf("SEND MSG TO CI_PAIDBDG FAILED![%d]\n", nRet);
        char *buffer; 
        buffer = strerror(errno); 
        printf("Error: %s\n", buffer); 
        DbDisConnect();
        return -4;
    }
    printf("SEND MSG TO CI_PAIDBDG SUCCESSFULLY!\n");
    DbDisConnect();
    return 0;
}

