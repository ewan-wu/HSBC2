#include <stdio.h>
#include "cmqc.h"

 /*********************************************************************/
 /*  MQBACK Call -- Back Out Changes                                  */
 /*********************************************************************/

 void MQENTRY MQBACK (
   MQHCONN  Hconn,      /* Connection handle */
   PMQLONG  pCompCode,  /* Completion code */
   PMQLONG  pReason)    /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQBEGIN Call -- Begin Unit of Work                               */
 /*********************************************************************/

 void MQENTRY MQBEGIN (
   MQHCONN  Hconn,          /* Connection handle */
   PMQVOID  pBeginOptions,  /* Options that control the action of
                               MQBEGIN */
   PMQLONG  pCompCode,      /* Completion code */
   PMQLONG  pReason)        /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQCLOSE Call -- Close Object                                     */
 /*********************************************************************/

 void MQENTRY MQCLOSE (
   MQHCONN  Hconn,      /* Connection handle */
   PMQHOBJ  pHobj,      /* Object handle */
   MQLONG   Options,    /* Options that control the action of MQCLOSE */
   PMQLONG  pCompCode,  /* Completion code */
   PMQLONG  pReason)    /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQCMIT Call -- Commit Changes                                    */
 /*********************************************************************/

 void MQENTRY MQCMIT (
   MQHCONN  Hconn,      /* Connection handle */
   PMQLONG  pCompCode,  /* Completion code */
   PMQLONG  pReason)    /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQCONN Call -- Connect Queue Manager                             */
 /*********************************************************************/

 void MQENTRY MQCONN (
   PMQCHAR   pQMgrName,  /* Name of queue manager */
   PMQHCONN  pHconn,     /* Connection handle */
   PMQLONG   pCompCode,  /* Completion code */
   PMQLONG   pReason)    /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQCONNX Call -- Connect Queue Manager (Extended)                 */
 /*********************************************************************/

 void MQENTRY MQCONNX (
   PMQCHAR   pQMgrName,     /* Name of queue manager */
   PMQCNO    pConnectOpts,  /* Options that control the action of
                               MQCONNX */
   PMQHCONN  pHconn,        /* Connection handle */
   PMQLONG   pCompCode,     /* Completion code */
   PMQLONG   pReason)       /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQDISC Call -- Disconnect Queue Manager                          */
 /*********************************************************************/

 void MQENTRY MQDISC (
   PMQHCONN  pHconn,     /* Connection handle */
   PMQLONG   pCompCode,  /* Completion code */
   PMQLONG   pReason)    /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQGET Call -- Get Message                                        */
 /*********************************************************************/

 void MQENTRY MQGET (
   MQHCONN  Hconn,         /* Connection handle */
   MQHOBJ   Hobj,          /* Object handle */
   PMQVOID  pMsgDesc,      /* Message descriptor */
   PMQVOID  pGetMsgOpts,   /* Options that control the action of
                              MQGET */
   MQLONG   BufferLength,  /* Length in bytes of the Buffer area */
   PMQVOID  pBuffer,       /* Area to contain the message data */
   PMQLONG  pDataLength,   /* Length of the message */
   PMQLONG  pCompCode,     /* Completion code */
   PMQLONG  pReason)       /* Reason code qualifying CompCode */
   {
		/* test */
		sleep(100);
		{
			FILE *fp;
			char sFileName[1024];

			memset(sFileName, 0, sizeof(sFileName));
			sprintf(sFileName, "%s/iodata/mqemu/%s", getenv("APPL"), 
				"mqemu.xml");
			fp = fopen(sFileName, "r");
			if (fp == NULL)
			{
				*pDataLength = 22;
				memcpy(pBuffer, "OK12345678901234567890", 22);
			}
			else
			{
				*pDataLength = fread(pBuffer, 1, 20480, fp);
				if (ferror(fp))
				{
					*pDataLength = 22;
					memcpy(pBuffer, "OK12345678901234567890", 22);
				}
				fclose(fp);
			}
		}
		*pReason = MQRC_NONE;

		return;
   }


 /*********************************************************************/
 /*  MQINQ Call -- Inquire Object Attributes                          */
 /*********************************************************************/

 void MQENTRY MQINQ (
   MQHCONN  Hconn,           /* Connection handle */
   MQHOBJ   Hobj,            /* Object handle */
   MQLONG   SelectorCount,   /* Count of selectors */
   PMQLONG  pSelectors,      /* Array of attribute selectors */
   MQLONG   IntAttrCount,    /* Count of integer attributes */
   PMQLONG  pIntAttrs,       /* Array of integer attributes */
   MQLONG   CharAttrLength,  /* Length of character attributes buffer */
   PMQCHAR  pCharAttrs,      /* Character attributes */
   PMQLONG  pCompCode,       /* Completion code */
   PMQLONG  pReason)         /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQOPEN Call -- Open Object                                       */
 /*********************************************************************/

 void MQENTRY MQOPEN (
   MQHCONN  Hconn,      /* Connection handle */
   PMQVOID  pObjDesc,   /* Object descriptor */
   MQLONG   Options,    /* Options that control the action of MQOPEN */
   PMQHOBJ  pHobj,      /* Object handle */
   PMQLONG  pCompCode,  /* Completion code */
   PMQLONG  pReason)    /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQPUT Call -- Put Message                                        */
 /*********************************************************************/

 void MQENTRY MQPUT (
   MQHCONN  Hconn,         /* Connection handle */
   MQHOBJ   Hobj,          /* Object handle */
   PMQVOID  pMsgDesc,      /* Message descriptor */
   PMQVOID  pPutMsgOpts,   /* Options that control the action of
                              MQPUT */
   MQLONG   BufferLength,  /* Length of the message in Buffer */
   PMQVOID  pBuffer,       /* Message data */
   PMQLONG  pCompCode,     /* Completion code */
   PMQLONG  pReason)       /* Reason code qualifying CompCode */
   {
		printf("MQPUT[%.*s]\n", BufferLength, pBuffer);
		*pReason = MQRC_NONE;
   }


 /*********************************************************************/
 /*  MQPUT1 Call -- Put One Message                                   */
 /*********************************************************************/

 void MQENTRY MQPUT1 (
   MQHCONN  Hconn,         /* Connection handle */
   PMQVOID  pObjDesc,      /* Object descriptor */
   PMQVOID  pMsgDesc,      /* Message descriptor */
   PMQVOID  pPutMsgOpts,   /* Options that control the action of
                              MQPUT1 */
   MQLONG   BufferLength,  /* Length of the message in Buffer */
   PMQVOID  pBuffer,       /* Message data */
   PMQLONG  pCompCode,     /* Completion code */
   PMQLONG  pReason)       /* Reason code qualifying CompCode */
   {
   }


 /*********************************************************************/
 /*  MQSET Call -- Set Object Attributes                              */
 /*********************************************************************/

 void MQENTRY MQSET (
   MQHCONN  Hconn,           /* Connection handle */
   MQHOBJ   Hobj,            /* Object handle */
   MQLONG   SelectorCount,   /* Count of selectors */
   PMQLONG  pSelectors,      /* Array of attribute selectors */
   MQLONG   IntAttrCount,    /* Count of integer attributes */
   PMQLONG  pIntAttrs,       /* Array of integer attributes */
   MQLONG   CharAttrLength,  /* Length of character attributes buffer */
   PMQCHAR  pCharAttrs,      /* Character attributes */
   PMQLONG  pCompCode,       /* Completion code */
   PMQLONG  pReason)         /* Reason code qualifying CompCode */
   {
   }

