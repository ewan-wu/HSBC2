/*****************************************************************************/
/*  Shanghai Huateng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2001. All rights reserved.                                 */
/*****************************************************************************/
/* PROGRAM NAME: tstsoft.c                                                   */
/* DESCRIPTIONS: The program is for epost secure module                      */
/*****************************************************************************/
/*                                  MODIFICATION LOG                         */
/* DATE        PROGRAMMER               DESCRIPTION                          */
/*****************************************************************************/
#include <stdio.h>
#include "scubenc.h"

#define  LOOP_TIME 1

void main (int argc,char *argv[])
{
	int iRet,i, iNum;
	char caErrMsg[SEC_MAX_ERR_MSG_LEN];
	char szInfo[100];
	T_GenHashReq tGenHashReq;
	T_GenHashRep tGenHashRep;
	T_ExcKeyReq  tExcKeyReq;
	T_FetKeyReq  tFetKeyReq;
	T_FetKeyRep  tFetKeyRep;
	T_GenPinReq  tGenPinReq;
	T_GenPinRep  tGenPinRep;
	T_GenMacReq  tGenMacReq;
	T_GenMacRep  tGenMacRep;
	T_VryMacReq  tVryMacReq;
	T_DESEncReq  tDESEncReq;
	T_DESEncRep  tDESEncRep;
	T_DESDecReq  tDESDecReq;
	T_DESDecRep  tDESDecRep;
	char caData[SEC_MAX_DATA_LEN*2];
    char szFileName[256];

	memset(&tGenHashReq,'\0',sizeof(T_GenHashReq));
	memset(&tExcKeyReq,'\0',sizeof(T_ExcKeyReq));
	memset(&tFetKeyReq,'\0',sizeof(T_FetKeyReq));
	memset(&tGenPinReq,'\0',sizeof(T_GenPinReq));
	memset(&tGenMacReq,'\0',sizeof(T_GenMacReq));
	memset(&tVryMacReq,'\0',sizeof(T_VryMacReq));
	memset(&tDESEncReq,'\0',sizeof(T_DESEncReq));
	memset(&tDESDecReq,'\0',sizeof(T_DESDecReq));
	memset(caData, '\0', sizeof(caData));
	
	iRet = Initialize();
	if(iRet != SEC_OK)
	{
		GetErrMsg(iRet,caErrMsg);
		printf("Initialize():%s\n",caErrMsg);
		exit(1);
	}

    while(1)
    {
	    printf("-------------------------------------------------------------------\n");
        printf("                   Welcome to Use This Test                        \n");
	    printf("-------------------------------------------------------------------\n");
	    printf("1.GenHash  2.GenHashOfFile  3.ExchangeKey   4.FetchKey\n");
	    printf("5.GenPin   6.GenMac         7.VerifyMac     8.DESEncrypt&DESDecrypt\n");
	    printf("9.exit \n");
	    printf("Please select one opertion number:");
	    scanf("%d",&iNum);
	    if(iNum<1 || iNum>9)
	    {
	    	printf("Wrong Number Selected. Please select once again!\n");
	        continue;
	    }       
	    if (iNum == 9)
	    {
	    	exit(0);
	    }
	    
	    switch (iNum)
	    {
	    case 1: /*GenHash*/
	        printf("Please input the source data you want to GenHash:");
	        scanf("%s", caData);
			tGenHashReq.lDataLen=strlen(caData);
	    	memcpy(tGenHashReq.caData, caData, strlen(caData));
			for (i=0; i<LOOP_TIME; i++)
			{
				iRet= GenHash(&tGenHashReq,&tGenHashRep);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("GenHash():%s\n",caErrMsg);
					break;
				}
				printf("HASH LEN : %d\n",tGenHashRep.lHashLen);
				printf("HASH : ");
				for(i=0;i<tGenHashRep.lHashLen;i++)
					printf("%02X",(unsigned char)tGenHashRep.caHash[i]);
				printf("\n");
		    }
	        break;
	    case 2: /*GenHashOfFile*/
	        
	        memset(szFileName, '\0', sizeof(szFileName));
	        printf("Please input the source file path:");
	        scanf("%s", caData);
	    	memcpy(szFileName, caData, strlen(caData));
			for (i=0; i<LOOP_TIME; i++)
			{
				iRet= GenHashOfFile(szFileName, &tGenHashRep);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("GenHashOfFile() failed:%s\n",caErrMsg);
					break;
				}
				printf("HASH LEN : %d\n",tGenHashRep.lHashLen);
				printf("HASH : ");
				for(i=0;i<tGenHashRep.lHashLen;i++)
					printf("%02X",(unsigned char)tGenHashRep.caHash[i]);
				printf("\n");
		    }
	        break;
	    case 3: /*ExchangeKey*/
			printf("Please input OrgIdx:");
			memset(caData,0,sizeof(caData));
			scanf("%s",caData);
			strcpy(tExcKeyReq.caOrgIdx,caData);
			printf("Please input MMKey index:");
			scanf("%d",&iNum);
			tExcKeyReq.nMMKIdx = iNum ;
        	printf("1. MAC     2.PIN     3.DES\n");
        	printf("Please select the key type:");
        	scanf("%d", &iNum);
        	if (iNum == 1)
        	{
        		tExcKeyReq.cKeyUsage=SEC_MAC_KEY;
			}else if (iNum == 2)
			{
        		tExcKeyReq.cKeyUsage=SEC_PIN_KEY;
			}else if (iNum == 3)
			{
        		tExcKeyReq.cKeyUsage=SEC_DES_KEY;
        	}else
			{
				printf("Wrong Number Selected.\n");
				break;			     
		    }
		    printf("Please input KEY text:");
		    scanf("%s", caData);
		    memcpy(tExcKeyReq.caKey, caData, strlen(caData));
			tExcKeyReq.lKeyLen = strlen(caData);
			printf("Please input Check Value:");
			scanf("%s", caData);
			iNum = SEC_CHK_VALUE_LEN  ;
			iRet = comASCIIToBCD(tExcKeyReq.caCheckValue,&iNum,1,
				   caData,SEC_CHK_VALUE_LEN * 2 );
            if (iRet )
			{
				printf("CHECK VALUE :BCD TO ASCII error !\n");
            }
			printf("Please input the TimeOut (Seconds):");
			scanf("%d", &iNum);
			tExcKeyReq.lTimeOut = iNum;
			for (i=0; i<LOOP_TIME; i++)
			{
				iRet=ExchangeKey(&tExcKeyReq);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("ExchangeKey() failed:%s\n",caErrMsg);
					break;
				}
				printf("ExchangeKey() success\n");
				DumpShareMem();
	        }
	        break;
	    case 4: /*FetchKey*/
			printf("Please input OrgIdx:");
			memset(caData,0,sizeof(caData));
			scanf("%s",caData);
			strcpy(tFetKeyReq.caOrgIdx,caData);
        	printf("1. MAC     2.PIN     3.DES\n");
	        printf("Please select the key type:");
        	scanf("%d", &iNum);
        	if (iNum == 1)
        	{
        		tFetKeyReq.cKeyUsage=SEC_MAC_KEY;
			}else if (iNum == 2)
			{
        		tFetKeyReq.cKeyUsage=SEC_PIN_KEY;
			}else if (iNum == 3)
			{
        		tFetKeyReq.cKeyUsage=SEC_DES_KEY;
        	}else
			{
				printf("Wrong Number Selected.\n");
				break;			     
		    }
		    printf("1.New      2.Old\n");
		    printf("Please select New key or Old key:");
		    scanf("%d", &iNum);
		    if (iNum == 1)
		    {
		    	tFetKeyReq.cFlag=SEC_KEY_NEW;
		    }else 
		    {
		    	tFetKeyReq.cFlag=SEC_KEY_OLD;
		    }
		    for (i=0; i<LOOP_TIME; i++)
		    {
				iRet=FetchKey(&tFetKeyReq,&tFetKeyRep);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("FetchKey() failed:%s\n",caErrMsg);
					break;
				}
				printf("FetchKey() success\n");
				memset(szInfo,'\0',sizeof(szInfo));
				memcpy(szInfo,tFetKeyRep.caKey,SEC_DES_KEY_LEN*2);
				printf("KEY VALUE : %s\n",szInfo);
				memset(szInfo,'\0',sizeof(szInfo));
				memcpy(szInfo,tFetKeyRep.caCheckValue,SEC_CHK_VALUE_LEN);
				printf("CHECK VALUE : ");
				for (i = 0 ; i < SEC_CHK_VALUE_LEN  ; i ++ )
				{
					printf("%02X",(unsigned char )szInfo[i]);
				}
				printf("\n");
			}
	        break;
	    case 5: /*GenPin*/
			memset(caData,0,sizeof(caData));
			printf("Please input OrgIdx:");
			scanf("%s",caData);
			strcpy(tGenPinReq.caOrgIdx,caData);
			memset(caData,0,sizeof(caData));
	    	printf("Please input the Pin block(6 bytes):");
	    	scanf("%s", caData);
	    	memcpy(tGenPinReq.caPinBlock, caData, strlen(caData));
			tGenPinReq.lPinBlockLen = strlen(caData);
			printf("Please input the Account No(19 bytes):");
			scanf("%s", caData);
			memcpy(tGenPinReq.caActNo, caData, strlen(caData));
			tGenPinReq.lActNoLen = strlen(caData);
			for (i=0; i<LOOP_TIME; i++)
			{
				iRet=GenPin(&tGenPinReq,&tGenPinRep);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("GenPin() failed:%s\n",caErrMsg);
					break;
				}
				printf("GenPin() success\n");
				if (tGenPinRep.cFlag == SEC_KEY_OLD )
				{
					printf("Use old key !\n");
				}
				else
				if (tGenPinRep.cFlag == SEC_KEY_NEW )
				{
					printf("Use new key !\n");
                }
				else
					printf("KEY FLAG : %c\n",tGenPinRep.cFlag);
				memset(szInfo,'\0',sizeof(szInfo));
				memcpy(szInfo,tGenPinRep.caEnPin,SEC_PIN_LEN*2);
				printf("ENCIHPERED PIN : %s\n",szInfo);
			}
	        break;
	    case 6: /*GenMac*/
			memset(caData,0,sizeof(caData));
			printf("Please input OrgIdx:");
			scanf("%s",caData);
			strcpy(tGenMacReq.caOrgIdx,caData);
			memset(caData,0,sizeof(caData));
	       	printf("Please input source data to GenMac:");
	       	scanf("%s", caData);
	       	memcpy(tGenMacReq.caData, caData, strlen(caData));
			tGenMacReq.lDataLen = strlen(caData);
			for (i=0; i<LOOP_TIME; i++)
			{
				iRet=GenMac(&tGenMacReq,&tGenMacRep);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("GenMac() failed:%s\n",caErrMsg);
					break;
				}
				printf("GenMac() success\n");
				if (tGenMacRep.cFlag == SEC_KEY_OLD )
				{
					printf("Use old key!\n");
				}
                else
				if (tGenMacRep.cFlag == SEC_KEY_NEW)
				{
					printf("Use new key !\n");
				}
				else
					printf("KEY FLAG : %c\n",tGenMacRep.cFlag);
				memset(szInfo,'\0',sizeof(szInfo));
				memcpy(szInfo,tGenMacRep.caMac,SEC_MAC_LEN*2);
				printf("MAC : %s\n",szInfo);
	        }
	        break;
	    case 7: /*VerifyMac*/
			printf("Please input OrgIdx:");
			memset(caData,0,sizeof(caData));
			scanf("%s",caData);
			strcpy(tVryMacReq.caOrgIdx,caData);
			memset(caData,0,sizeof(caData));
        	printf("1.New      2.Old\n");
        	printf("Please select New key or Old key:");
        	scanf("%d", &iNum);
        	if (iNum == 1)
        	{
        		tVryMacReq.cFlag=SEC_KEY_NEW;
			}
			else
			{
        		tVryMacReq.cFlag=SEC_KEY_OLD;
			}
			printf("Please input source data:");
			scanf("%s", caData);
			memcpy(tVryMacReq.caData, caData, strlen(caData));
			tVryMacReq.lDataLen = strlen(caData);
			printf("Please input MAC:");
			scanf("%s", caData);
			memcpy(tVryMacReq.caMac, caData, strlen(caData));
			tVryMacReq.lMacLen = strlen(caData);
			for (i=0; i<LOOP_TIME; i++)
			{
				iRet=VerifyMac(&tVryMacReq);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("VerifyMac() failed:%s\n",caErrMsg);
					break;
				}
				printf("VerifyMac() success\n");
			}
	        break;
	    case 8: /*DESEncrypt and DESDecrypt*/
			printf("Please input OrgIdx:");
			memset(caData,0,sizeof(caData));
			scanf("%s",caData);
			strcpy(tDESEncReq.caOrgIdx,caData);
			strcpy(tDESDecReq.caOrgIdx,caData);
			memset(caData,0,sizeof(caData));
        	printf("Please input the plaintext to be encrypt:");
        	scanf("%s", caData);
        	memcpy(tDESEncReq.caData, caData, strlen(caData));
			tDESEncReq.lDataLen = strlen(caData);
			for (i=0; i<LOOP_TIME; i++)
			{
				iRet=DESEncrypt(&tDESEncReq,&tDESEncRep);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("DESEncrypt() failed:%s\n",caErrMsg);
					break;
				}
				printf("DESEncrypt() success\n");
				memset(szInfo,'\0',sizeof(szInfo));
				memcpy(szInfo,tDESEncRep.caEnData,tDESEncRep.lEnDataLen);
				printf("ENCIPHERED DATA : %s\n",szInfo);
				
				memcpy(tDESDecReq.caEnData,tDESEncRep.caEnData,tDESEncRep.lEnDataLen);
				tDESDecReq.lEnDataLen=tDESEncRep.lEnDataLen;
				tDESDecReq.cFlag=tDESEncRep.cFlag;
				iRet=DESDecrypt(&tDESDecReq,&tDESDecRep);
				if(iRet != SEC_OK)
				{
					GetErrMsg(iRet,caErrMsg);
					printf("DESDecrypt() failed:%s\n",caErrMsg);
					exit(1);
				}
				printf("DESDecrypt() success\n");
				memset(szInfo,'\0',sizeof(szInfo));
				memcpy(szInfo,tDESDecRep.caData,tDESDecRep.lDataLen);
				printf("DECIPHERED DATA : %s\n",szInfo);
	        }
	        break;
	    } /* end of switch */
	} /* end of while(1) */
}
