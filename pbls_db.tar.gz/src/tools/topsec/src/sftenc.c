/*****************************************************************************/
/*                    TOPSecure Software Cryptography Module                 */
/* Copyright (c) 2000 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/
/* PROGRAM NAME: sftenc.c                                                    */
/* DESCRIPTIONS: This program provids security services                      */
/*****************************************************************************/
/*                            MODIFICATION LOG                               */
/* DATE       PROGRAMMER        DESCRIPTON                                   */
/* 2001-03-12 WANG,YINGZI       Initial Version Creation                     */
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "sftenc.h"

#ifndef NOPROTO
static int check_parity(des_cblock (*key));
#else
static int check_parity();
#endif

const DES_LONG des_SPtrans[8][64]={
{
/* nibble 0 */
0x02080800L, 0x00080000L, 0x02000002L, 0x02080802L,
0x02000000L, 0x00080802L, 0x00080002L, 0x02000002L,
0x00080802L, 0x02080800L, 0x02080000L, 0x00000802L,
0x02000802L, 0x02000000L, 0x00000000L, 0x00080002L,
0x00080000L, 0x00000002L, 0x02000800L, 0x00080800L,
0x02080802L, 0x02080000L, 0x00000802L, 0x02000800L,
0x00000002L, 0x00000800L, 0x00080800L, 0x02080002L,
0x00000800L, 0x02000802L, 0x02080002L, 0x00000000L,
0x00000000L, 0x02080802L, 0x02000800L, 0x00080002L,
0x02080800L, 0x00080000L, 0x00000802L, 0x02000800L,
0x02080002L, 0x00000800L, 0x00080800L, 0x02000002L,
0x00080802L, 0x00000002L, 0x02000002L, 0x02080000L,
0x02080802L, 0x00080800L, 0x02080000L, 0x02000802L,
0x02000000L, 0x00000802L, 0x00080002L, 0x00000000L,
0x00080000L, 0x02000000L, 0x02000802L, 0x02080800L,
0x00000002L, 0x02080002L, 0x00000800L, 0x00080802L,
},{
/* nibble 1 */
0x40108010L, 0x00000000L, 0x00108000L, 0x40100000L,
0x40000010L, 0x00008010L, 0x40008000L, 0x00108000L,
0x00008000L, 0x40100010L, 0x00000010L, 0x40008000L,
0x00100010L, 0x40108000L, 0x40100000L, 0x00000010L,
0x00100000L, 0x40008010L, 0x40100010L, 0x00008000L,
0x00108010L, 0x40000000L, 0x00000000L, 0x00100010L,
0x40008010L, 0x00108010L, 0x40108000L, 0x40000010L,
0x40000000L, 0x00100000L, 0x00008010L, 0x40108010L,
0x00100010L, 0x40108000L, 0x40008000L, 0x00108010L,
0x40108010L, 0x00100010L, 0x40000010L, 0x00000000L,
0x40000000L, 0x00008010L, 0x00100000L, 0x40100010L,
0x00008000L, 0x40000000L, 0x00108010L, 0x40008010L,
0x40108000L, 0x00008000L, 0x00000000L, 0x40000010L,
0x00000010L, 0x40108010L, 0x00108000L, 0x40100000L,
0x40100010L, 0x00100000L, 0x00008010L, 0x40008000L,
0x40008010L, 0x00000010L, 0x40100000L, 0x00108000L,
},{
/* nibble 2 */
0x04000001L, 0x04040100L, 0x00000100L, 0x04000101L,
0x00040001L, 0x04000000L, 0x04000101L, 0x00040100L,
0x04000100L, 0x00040000L, 0x04040000L, 0x00000001L,
0x04040101L, 0x00000101L, 0x00000001L, 0x04040001L,
0x00000000L, 0x00040001L, 0x04040100L, 0x00000100L,
0x00000101L, 0x04040101L, 0x00040000L, 0x04000001L,
0x04040001L, 0x04000100L, 0x00040101L, 0x04040000L,
0x00040100L, 0x00000000L, 0x04000000L, 0x00040101L,
0x04040100L, 0x00000100L, 0x00000001L, 0x00040000L,
0x00000101L, 0x00040001L, 0x04040000L, 0x04000101L,
0x00000000L, 0x04040100L, 0x00040100L, 0x04040001L,
0x00040001L, 0x04000000L, 0x04040101L, 0x00000001L,
0x00040101L, 0x04000001L, 0x04000000L, 0x04040101L,
0x00040000L, 0x04000100L, 0x04000101L, 0x00040100L,
0x04000100L, 0x00000000L, 0x04040001L, 0x00000101L,
0x04000001L, 0x00040101L, 0x00000100L, 0x04040000L,
},{
/* nibble 3 */
0x00401008L, 0x10001000L, 0x00000008L, 0x10401008L,
0x00000000L, 0x10400000L, 0x10001008L, 0x00400008L,
0x10401000L, 0x10000008L, 0x10000000L, 0x00001008L,
0x10000008L, 0x00401008L, 0x00400000L, 0x10000000L,
0x10400008L, 0x00401000L, 0x00001000L, 0x00000008L,
0x00401000L, 0x10001008L, 0x10400000L, 0x00001000L,
0x00001008L, 0x00000000L, 0x00400008L, 0x10401000L,
0x10001000L, 0x10400008L, 0x10401008L, 0x00400000L,
0x10400008L, 0x00001008L, 0x00400000L, 0x10000008L,
0x00401000L, 0x10001000L, 0x00000008L, 0x10400000L,
0x10001008L, 0x00000000L, 0x00001000L, 0x00400008L,
0x00000000L, 0x10400008L, 0x10401000L, 0x00001000L,
0x10000000L, 0x10401008L, 0x00401008L, 0x00400000L,
0x10401008L, 0x00000008L, 0x10001000L, 0x00401008L,
0x00400008L, 0x00401000L, 0x10400000L, 0x10001008L,
0x00001008L, 0x10000000L, 0x10000008L, 0x10401000L,
},{
/* nibble 4 */
0x08000000L, 0x00010000L, 0x00000400L, 0x08010420L,
0x08010020L, 0x08000400L, 0x00010420L, 0x08010000L,
0x00010000L, 0x00000020L, 0x08000020L, 0x00010400L,
0x08000420L, 0x08010020L, 0x08010400L, 0x00000000L,
0x00010400L, 0x08000000L, 0x00010020L, 0x00000420L,
0x08000400L, 0x00010420L, 0x00000000L, 0x08000020L,
0x00000020L, 0x08000420L, 0x08010420L, 0x00010020L,
0x08010000L, 0x00000400L, 0x00000420L, 0x08010400L,
0x08010400L, 0x08000420L, 0x00010020L, 0x08010000L,
0x00010000L, 0x00000020L, 0x08000020L, 0x08000400L,
0x08000000L, 0x00010400L, 0x08010420L, 0x00000000L,
0x00010420L, 0x08000000L, 0x00000400L, 0x00010020L,
0x08000420L, 0x00000400L, 0x00000000L, 0x08010420L,
0x08010020L, 0x08010400L, 0x00000420L, 0x00010000L,
0x00010400L, 0x08010020L, 0x08000400L, 0x00000420L,
0x00000020L, 0x00010420L, 0x08010000L, 0x08000020L,
},{
/* nibble 5 */
0x80000040L, 0x00200040L, 0x00000000L, 0x80202000L,
0x00200040L, 0x00002000L, 0x80002040L, 0x00200000L,
0x00002040L, 0x80202040L, 0x00202000L, 0x80000000L,
0x80002000L, 0x80000040L, 0x80200000L, 0x00202040L,
0x00200000L, 0x80002040L, 0x80200040L, 0x00000000L,
0x00002000L, 0x00000040L, 0x80202000L, 0x80200040L,
0x80202040L, 0x80200000L, 0x80000000L, 0x00002040L,
0x00000040L, 0x00202000L, 0x00202040L, 0x80002000L,
0x00002040L, 0x80000000L, 0x80002000L, 0x00202040L,
0x80202000L, 0x00200040L, 0x00000000L, 0x80002000L,
0x80000000L, 0x00002000L, 0x80200040L, 0x00200000L,
0x00200040L, 0x80202040L, 0x00202000L, 0x00000040L,
0x80202040L, 0x00202000L, 0x00200000L, 0x80002040L,
0x80000040L, 0x80200000L, 0x00202040L, 0x00000000L,
0x00002000L, 0x80000040L, 0x80002040L, 0x80202000L,
0x80200000L, 0x00002040L, 0x00000040L, 0x80200040L,
},{
/* nibble 6 */
0x00004000L, 0x00000200L, 0x01000200L, 0x01000004L,
0x01004204L, 0x00004004L, 0x00004200L, 0x00000000L,
0x01000000L, 0x01000204L, 0x00000204L, 0x01004000L,
0x00000004L, 0x01004200L, 0x01004000L, 0x00000204L,
0x01000204L, 0x00004000L, 0x00004004L, 0x01004204L,
0x00000000L, 0x01000200L, 0x01000004L, 0x00004200L,
0x01004004L, 0x00004204L, 0x01004200L, 0x00000004L,
0x00004204L, 0x01004004L, 0x00000200L, 0x01000000L,
0x00004204L, 0x01004000L, 0x01004004L, 0x00000204L,
0x00004000L, 0x00000200L, 0x01000000L, 0x01004004L,
0x01000204L, 0x00004204L, 0x00004200L, 0x00000000L,
0x00000200L, 0x01000004L, 0x00000004L, 0x01000200L,
0x00000000L, 0x01000204L, 0x01000200L, 0x00004200L,
0x00000204L, 0x00004000L, 0x01004204L, 0x01000000L,
0x01004200L, 0x00000004L, 0x00004004L, 0x01004204L,
0x01000004L, 0x01004200L, 0x01004000L, 0x00004004L,
},{
/* nibble 7 */
0x20800080L, 0x20820000L, 0x00020080L, 0x00000000L,
0x20020000L, 0x00800080L, 0x20800000L, 0x20820080L,
0x00000080L, 0x20000000L, 0x00820000L, 0x00020080L,
0x00820080L, 0x20020080L, 0x20000080L, 0x20800000L,
0x00020000L, 0x00820080L, 0x00800080L, 0x20020000L,
0x20820080L, 0x20000080L, 0x00000000L, 0x00820000L,
0x20000000L, 0x00800000L, 0x20020080L, 0x20800080L,
0x00800000L, 0x00020000L, 0x20820000L, 0x00000080L,
0x00800000L, 0x00020000L, 0x20000080L, 0x20820080L,
0x00020080L, 0x20000000L, 0x00000000L, 0x00820000L,
0x20800080L, 0x20020080L, 0x20020000L, 0x00800080L,
0x20820000L, 0x00000080L, 0x00800080L, 0x20020000L,
0x20820080L, 0x00800000L, 0x20800000L, 0x20000080L,
0x00820000L, 0x00020080L, 0x20020080L, 0x20800000L,
0x00000080L, 0x20820000L, 0x00820080L, 0x00000000L,
0x20000000L, 0x20800080L, 0x00020000L, 0x00820080L,
}};

int des_check_key=0;

/*****************************************************************************/
/* FUNC:   void des_set_odd_parity(des_cblock (*key))                        */
/* INPUT:  key -- DES key                                                    */
/* OUTPUT: key -- DES key                                                    */
/* RETURN: none                                                              */
/* DESC:   The function handles the DES key                                  */
/*****************************************************************************/
void des_set_odd_parity(des_cblock (*key))
{
	int i;

	for (i=0; i<DES_KEY_SZ; i++)
		(*key)[i]=odd_parity[(*key)[i]];
}
/*****************************************************************************/
/* FUNC:   static int check_parity(des_cblock (*key))                        */
/* INPUT:  key -- DES key                                                    */
/* OUTPUT: key -- DES key                                                    */
/* RETURN: 1 --  succeed                                                     */
/*         0 --  fail                                                        */
/* DESC:   The function checks the DES key                                   */
/*****************************************************************************/
static int check_parity(des_cblock (*key))
{
	int i;

	for (i=0; i<DES_KEY_SZ; i++)
	{
		if ((*key)[i] != odd_parity[(*key)[i]])
			return(0);
	}

	return(1);
}

/* Weak and semi week keys as take from
 * %A D.W. Davies
 * %A W.L. Price
 * %T Security for Computer Networks
 * %I John Wiley & Sons
 * %D 1984
 * Many thanks to smb@ulysses.att.com (Steven Bellovin) for the reference
 * (and actual cblock values).
 */
/*****************************************************************************/
/* FUNC:   int des_is_weak_key(des_cblock (*key))                            */
/* INPUT:  key -- DES key                                                    */
/* OUTPUT: key -- DES key                                                    */
/* RETURN: 0 --  succeed                                                     */
/*         1 --  fail                                                        */
/* DESC:   The function judges if the DES key is weak                        */
/*****************************************************************************/
#define NUM_WEAK_KEY	16
static des_cblock weak_keys[NUM_WEAK_KEY]={
	/* weak keys */
	{0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01},
	{0xFE,0xFE,0xFE,0xFE,0xFE,0xFE,0xFE,0xFE},
	{0x1F,0x1F,0x1F,0x1F,0x1F,0x1F,0x1F,0x1F},
	{0xE0,0xE0,0xE0,0xE0,0xE0,0xE0,0xE0,0xE0},
	/* semi-weak keys */
	{0x01,0xFE,0x01,0xFE,0x01,0xFE,0x01,0xFE},
	{0xFE,0x01,0xFE,0x01,0xFE,0x01,0xFE,0x01},
	{0x1F,0xE0,0x1F,0xE0,0x0E,0xF1,0x0E,0xF1},
	{0xE0,0x1F,0xE0,0x1F,0xF1,0x0E,0xF1,0x0E},
	{0x01,0xE0,0x01,0xE0,0x01,0xF1,0x01,0xF1},
	{0xE0,0x01,0xE0,0x01,0xF1,0x01,0xF1,0x01},
	{0x1F,0xFE,0x1F,0xFE,0x0E,0xFE,0x0E,0xFE},
	{0xFE,0x1F,0xFE,0x1F,0xFE,0x0E,0xFE,0x0E},
	{0x01,0x1F,0x01,0x1F,0x01,0x0E,0x01,0x0E},
	{0x1F,0x01,0x1F,0x01,0x0E,0x01,0x0E,0x01},
	{0xE0,0xFE,0xE0,0xFE,0xF1,0xFE,0xF1,0xFE},
	{0xFE,0xE0,0xFE,0xE0,0xFE,0xF1,0xFE,0xF1}};

int des_is_weak_key(des_cblock (*key))
{
	int i;

		/* Added == 0 to comparision, I obviously don't run
		 * this section very often :-(, thanks to
		 * engineering@MorningStar.Com for the fix
		 * eay 93/06/29
		 * Another problem, I was comparing only the first 4
		 * bytes, 97/03/18 */
	for (i=0; i<NUM_WEAK_KEY; i++)
	{
		if (memcmp(weak_keys[i],key,sizeof(des_cblock)) == 0) return(1);
	}	
	return(0);
}

/* NOW DEFINED IN des_local.h
 * See ecb_encrypt.c for a pseudo description of these macros. 
 * #define PERM_OP(a,b,t,n,m) ((t)=((((a)>>(n))^(b))&(m)),\
 * 	(b)^=(t),\
 * 	(a)=((a)^((t)<<(n))))
 */

/*****************************************************************************/
/* FUNC:   int des_set_key(des_cblock (*key), des_key_schedule schedule)     */
/* INPUT:  schedule -- used to  set  key                                     */
/* OUTPUT: key -- DES key                                                    */
/* RETURN: 0 --  succeed                                                     */
/*         <0 --  fail                                                       */
/* DESC:   The function sets key                                             */
/*****************************************************************************/
#define HPERM_OP(a,t,n,m) ((t)=((((a)<<(16-(n)))^(a))&(m)),\
	(a)=(a)^(t)^(t>>(16-(n))))

/* return 0 if key parity is odd (correct),
 * return -1 if key parity error,
 * return -2 if illegal weak key.
 */
int des_set_key(des_cblock (*key), des_key_schedule schedule)
{
	static int shifts2[16]={0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,0};
	register DES_LONG c,d,t,s,t2;
	register unsigned char *in;
	register DES_LONG *k;
	register int i;

	if (des_check_key)
	{
		if (!check_parity(key))
			return(-1);

		if (des_is_weak_key(key))
			return(-2);
	}

	k=(DES_LONG *)schedule;
	in=(unsigned char *)key;

	c2l(in,c);
	c2l(in,d);

	/* do PC1 in 60 simple operations */ 
/*	PERM_OP(d,c,t,4,0x0f0f0f0fL);
	HPERM_OP(c,t,-2, 0xcccc0000L);
	HPERM_OP(c,t,-1, 0xaaaa0000L);
	HPERM_OP(c,t, 8, 0x00ff0000L);
	HPERM_OP(c,t,-1, 0xaaaa0000L);
	HPERM_OP(d,t,-8, 0xff000000L);
	HPERM_OP(d,t, 8, 0x00ff0000L);
	HPERM_OP(d,t, 2, 0x33330000L);
	d=((d&0x00aa00aaL)<<7L)|((d&0x55005500L)>>7L)|(d&0xaa55aa55L);
	d=(d>>8)|((c&0xf0000000L)>>4);
	c&=0x0fffffffL; */

	/* I now do it in 47 simple operations :-)
	 * Thanks to John Fletcher (john_fletcher@lccmail.ocf.llnl.gov)
	 * for the inspiration. :-) */
	PERM_OP (d,c,t,4,0x0f0f0f0fL);
	HPERM_OP(c,t,-2,0xcccc0000L);
	HPERM_OP(d,t,-2,0xcccc0000L);
	PERM_OP (d,c,t,1,0x55555555L);
	PERM_OP (c,d,t,8,0x00ff00ffL);
	PERM_OP (d,c,t,1,0x55555555L);
	d=	(((d&0x000000ffL)<<16L)| (d&0x0000ff00L)     |
		 ((d&0x00ff0000L)>>16L)|((c&0xf0000000L)>>4L));
	c&=0x0fffffffL;

	for (i=0; i<ITERATIONS; i++)
	{
		if (shifts2[i])
		{ 
			c=((c>>2L)|(c<<26L)); d=((d>>2L)|(d<<26L)); 
		}
		else
		{
			c=((c>>1L)|(c<<27L)); d=((d>>1L)|(d<<27L)); 
		}
		c&=0x0fffffffL;
		d&=0x0fffffffL;
		/* could be a few less shifts but I am to lazy at this
		 * point in time to investigate */
		s=	des_skb[0][ (c    )&0x3f                ]|
			des_skb[1][((c>> 6)&0x03)|((c>> 7L)&0x3c)]|
			des_skb[2][((c>>13)&0x0f)|((c>>14L)&0x30)]|
			des_skb[3][((c>>20)&0x01)|((c>>21L)&0x06) |
						  ((c>>22L)&0x38)];
		t=	des_skb[4][ (d    )&0x3f                ]|
			des_skb[5][((d>> 7L)&0x03)|((d>> 8L)&0x3c)]|
			des_skb[6][ (d>>15L)&0x3f                ]|
			des_skb[7][((d>>21L)&0x0f)|((d>>22L)&0x30)];

		/* table contained 0213 4657 */
		t2=((t<<16L)|(s&0x0000ffffL))&0xffffffffL;
		*(k++)=ROTATE(t2,30)&0xffffffffL;

		t2=((s>>16L)|(t&0xffff0000L));
		*(k++)=ROTATE(t2,26)&0xffffffffL;
	}
	return(0);
}
/*****************************************************************************/
/* FUNC:   int des_key_sched(des_cblock (*key), des_key_schedule schedule)   */
/* INPUT:  schedule -- used to  set  key                                     */
/* OUTPUT: key -- DES key                                                    */
/* RETURN: 0 --  succeed                                                     */
/*         <0 --  fail                                                       */
/* DESC:   The function handles key                                          */
/*****************************************************************************/
int des_key_sched(des_cblock (*key), des_key_schedule schedule)
{
	return(des_set_key(key,schedule));
}
/*****************************************************************************/
/* FUNC:   char *des_options()                                               */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: buffer                                                            */
/* DESC:   The function handles DES options                                  */
/*****************************************************************************/
char *des_options()
{
	static int init=1;
	static char buf[32];

	if (init)
	{
		char *ptr,*unroll,*risc,*size;

		init=0;
#ifdef DES_PTR
		ptr="ptr";
#else
		ptr="idx";
#endif
#if defined(DES_RISC1) || defined(DES_RISC2)
#ifdef DES_RISC1
		risc="risc1";
#endif
#ifdef DES_RISC2
		risc="risc2";
#endif
#else
		risc="cisc";
#endif
#ifdef DES_UNROLL
		unroll="16";
#else
		unroll="4";
#endif
		if (sizeof(DES_LONG) != sizeof(long))
			size="int";
		else
			size="long";
		sprintf(buf,"des(%s,%s,%s,%s)",ptr,risc,unroll,size);
	}
	return(buf);
}	
/*****************************************************************************/
/* FUNC:   void des_cbc_encrypt(des_cblock (*input), des_cblock (*output),   */
/*       long length, des_key_schedule schedule, des_cblock (*ivec), int enc)*/
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         length   -- length of plaintext                                   */
/*         schedule -- key use to encrypt data                               */
/*         ivec     -- encrypt IV                                            */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output -- encrypted text                                          */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DESCBC mechanism              */
/*****************************************************************************/
void des_cbc_encrypt(des_cblock (*input), des_cblock (*output), 
     long length, des_key_schedule schedule, des_cblock (*ivec), int enc)
{
	register DES_LONG tin0,tin1;
	register DES_LONG tout0,tout1,xor0,xor1;
	register unsigned char *in,*out;
	register long l=length;
	DES_LONG tin[2];
	unsigned char *iv;

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	iv=(unsigned char *)ivec;

	if (enc)
	{
		c2l(iv,tout0);
		c2l(iv,tout1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0);
			c2l(in,tin1);
			tin0^=tout0; tin[0]=tin0;
			tin1^=tout1; tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_ENCRYPT);
			tout0=tin[0]; l2c(tout0,out);
			tout1=tin[1]; l2c(tout1,out);
		}
		if (l != -8)
		{
			c2ln(in,tin0,tin1,l+8);
			tin0^=tout0; tin[0]=tin0;
			tin1^=tout1; tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_ENCRYPT);
			tout0=tin[0]; l2c(tout0,out);
			tout1=tin[1]; l2c(tout1,out);
		}
	}
	else
	{
		c2l(iv,xor0);
		c2l(iv,xor1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0); tin[0]=tin0;
			c2l(in,tin1); tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_DECRYPT);
			tout0=tin[0]^xor0;
			tout1=tin[1]^xor1;
			l2c(tout0,out);
			l2c(tout1,out);
			xor0=tin0;
			xor1=tin1;
		}
		if (l != -8)
		{
			c2l(in,tin0); tin[0]=tin0;
			c2l(in,tin1); tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_DECRYPT);
			tout0=tin[0]^xor0;
			tout1=tin[1]^xor1;
			l2cn(tout0,tout1,out,l+8);
		/*	xor0=tin0;
			xor1=tin1; */
		}
	}
	tin0=tin1=tout0=tout1=xor0=xor1=0;
	tin[0]=tin[1]=0;
}
/*****************************************************************************/
/* FUNC:   void des_ecb_encrypt(des_cblock (*input), des_cblock (*output),   */
/*                             des_key_schedule ks, int enc)                 */
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         ks       -- key use to encrypt data                               */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output -- encrypted text                                          */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DESECB mechanism              */
/*****************************************************************************/
void des_ecb_encrypt(des_cblock (*input), des_cblock (*output), 
                     des_key_schedule ks, int enc)
{
	register DES_LONG l;
	register unsigned char *in,*out;
	DES_LONG ll[2];

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	c2l(in,l); ll[0]=l;
	c2l(in,l); ll[1]=l;
	des_encrypt(ll,ks,enc);
	l=ll[0]; l2c(l,out);
	l=ll[1]; l2c(l,out);
	l=ll[0]=ll[1]=0;
}
/*****************************************************************************/
/* FUNC:   short DES_CBC_Encryption(unsigned char *clearTxt,                 */
/*              unsigned char *cipherTxt, unsigned char keyDES[8],           */
/*              long len, unsigned char IV[8])                               */
/* INPUT:  clearTxt -- plaintext to be encrypted                             */
/*         len      -- length of plaintext                                   */
/*         keyDES   -- key use to encrypt data                               */
/*         IV       -- encrypt IV                                            */
/* OUTPUT: cipherTxt-- encrypted text                                        */
/* RETURN: 0 --  succeed                                                     */
/*         <0 --  fail                                                       */
/* DESC:   The function encrypts the data with DESCBC mechanism              */
/*****************************************************************************/
short DES_CBC_Encryption(unsigned char *clearTxt, unsigned char *cipherTxt, 
                        unsigned char keyDES[8], long len, unsigned char IV[8])
{
	des_key_schedule ks;
	
	if(des_key_sched((C_Block *)keyDES, ks) != 0)
		return -1;
	
	des_cbc_encrypt((des_cblock *)clearTxt, (des_cblock *)cipherTxt, 
	    len , ks, (des_cblock *)IV, DES_ENCRYPT);

	return 0;
}
/*****************************************************************************/
/* FUNC:   short DES_CBC_Encryption(unsigned char *clearTxt,                 */
/*              unsigned char *cipherTxt, unsigned char keyDES[8],           */
/*              long len, unsigned char IV[8])                               */
/* INPUT:  cipherTxt-- encrypted text                                        */
/*         len      -- length of plaintext                                   */
/*         keyDES   -- key use to encrypt data                               */
/*         IV       -- encrypt IV                                            */
/* OUTPUT: clearTxt -- plaintext to be encrypted                             */
/* RETURN: 0 --  succeed                                                     */
/*         <0 --  fail                                                       */
/* DESC:   The function decrypts the data with DESCBC mechanism              */
/*****************************************************************************/
short DES_CBC_Decryption(unsigned char *cipherTxt, unsigned char *clearTxt,
          unsigned char keyDES[8], long len, unsigned char IV[8])
{
	des_key_schedule ks;
	
	if(des_key_sched((C_Block *)keyDES, ks) != 0)
		return -1;
	
	des_cbc_encrypt((des_cblock *)cipherTxt, (des_cblock *)clearTxt, 
	len, ks, (des_cblock *)IV, DES_DECRYPT);

	return 0;
}
/*****************************************************************************/
/* FUNC:   void des_encrypt(DES_LONG *data, des_key_schedule ks, int enc)    */
/* INPUT:  data     -- plaintext to be encrypted                             */
/*         ks       -- key use to encrypt data                               */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: data     -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES mechanism                 */
/*****************************************************************************/
void des_encrypt(DES_LONG *data, des_key_schedule ks, int enc)
{
	register DES_LONG l,r,t,u;
#ifdef DES_PTR
	register unsigned char *des_SP=(unsigned char *)des_SPtrans;
#endif
#ifndef DES_UNROLL
	register int i;
#endif
	register DES_LONG *s;

	r=data[0];
	l=data[1];

	IP(r,l);
	/* Things have been modified so that the initial rotate is
	 * done outside the loop.  This required the
	 * des_SPtrans values in sp.h to be rotated 1 bit to the right.
	 * One perl script later and things have a 5% speed up on a sparc2.
	 * Thanks to Richard Outerbridge <71755.204@CompuServe.COM>
	 * for pointing this out. */
	/* clear the top bits on machines with 8byte longs */
	/* shift left by 2 */
	r=ROTATE(r,29)&0xffffffffL;
	l=ROTATE(l,29)&0xffffffffL;

	s=(DES_LONG *)ks;
	/* I don't know if it is worth the effort of loop unrolling the
	 * inner loop */
	if (enc)
	{
#ifdef DES_UNROLL
		D_ENCRYPT(l,r, 0); /*  1 */
		D_ENCRYPT(r,l, 2); /*  2 */
		D_ENCRYPT(l,r, 4); /*  3 */
		D_ENCRYPT(r,l, 6); /*  4 */
		D_ENCRYPT(l,r, 8); /*  5 */
		D_ENCRYPT(r,l,10); /*  6 */
		D_ENCRYPT(l,r,12); /*  7 */
		D_ENCRYPT(r,l,14); /*  8 */
		D_ENCRYPT(l,r,16); /*  9 */
		D_ENCRYPT(r,l,18); /*  10 */
		D_ENCRYPT(l,r,20); /*  11 */
		D_ENCRYPT(r,l,22); /*  12 */
		D_ENCRYPT(l,r,24); /*  13 */
		D_ENCRYPT(r,l,26); /*  14 */
		D_ENCRYPT(l,r,28); /*  15 */
		D_ENCRYPT(r,l,30); /*  16 */
#else
		for (i=0; i<32; i+=8)
		{
			D_ENCRYPT(l,r,i+0); /*  1 */
			D_ENCRYPT(r,l,i+2); /*  2 */
			D_ENCRYPT(l,r,i+4); /*  3 */
			D_ENCRYPT(r,l,i+6); /*  4 */
		}
#endif
		}
	else
	{
#ifdef DES_UNROLL
		D_ENCRYPT(l,r,30); /* 16 */
		D_ENCRYPT(r,l,28); /* 15 */
		D_ENCRYPT(l,r,26); /* 14 */
		D_ENCRYPT(r,l,24); /* 13 */
		D_ENCRYPT(l,r,22); /* 12 */
		D_ENCRYPT(r,l,20); /* 11 */
		D_ENCRYPT(l,r,18); /* 10 */
		D_ENCRYPT(r,l,16); /*  9 */
		D_ENCRYPT(l,r,14); /*  8 */
		D_ENCRYPT(r,l,12); /*  7 */
		D_ENCRYPT(l,r,10); /*  6 */
		D_ENCRYPT(r,l, 8); /*  5 */
		D_ENCRYPT(l,r, 6); /*  4 */
		D_ENCRYPT(r,l, 4); /*  3 */
		D_ENCRYPT(l,r, 2); /*  2 */
		D_ENCRYPT(r,l, 0); /*  1 */
#else
		for (i=30; i>0; i-=8)
		{
			D_ENCRYPT(l,r,i-0); /* 16 */
			D_ENCRYPT(r,l,i-2); /* 15 */
			D_ENCRYPT(l,r,i-4); /* 14 */
			D_ENCRYPT(r,l,i-6); /* 13 */
		}
#endif
	}

	/* rotate and clear the top bits on machines with 8byte longs */
	l=ROTATE(l,3)&0xffffffffL;
	r=ROTATE(r,3)&0xffffffffL;

	FP(r,l);
	data[0]=l;
	data[1]=r;
	l=r=t=u=0;
}
/*****************************************************************************/
/* FUNC:   void des_encrypt2(DES_LONG *data, des_key_schedule ks, int enc)   */
/* INPUT:  data     -- plaintext to be encrypted                             */
/*         ks       -- key use to encrypt data                               */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: data     -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES mechanism once again      */
/*****************************************************************************/
void des_encrypt2(DES_LONG *data, des_key_schedule ks, int enc)
{
	register DES_LONG l,r,t,u;
#ifdef DES_PTR
	register unsigned char *des_SP=(unsigned char *)des_SPtrans;
#endif
#ifndef DES_UNROLL
	register int i;
#endif
	register DES_LONG *s;

	r=data[0];
	l=data[1];

	/* Things have been modified so that the initial rotate is
	 * done outside the loop.  This required the
	 * des_SPtrans values in sp.h to be rotated 1 bit to the right.
	 * One perl script later and things have a 5% speed up on a sparc2.
	 * Thanks to Richard Outerbridge <71755.204@CompuServe.COM>
	 * for pointing this out. */
	/* clear the top bits on machines with 8byte longs */
	r=ROTATE(r,29)&0xffffffffL;
	l=ROTATE(l,29)&0xffffffffL;

	s=(DES_LONG *)ks;
	/* I don't know if it is worth the effort of loop unrolling the
	 * inner loop */
	if (enc)
	{
#ifdef DES_UNROLL
		D_ENCRYPT(l,r, 0); /*  1 */
		D_ENCRYPT(r,l, 2); /*  2 */
		D_ENCRYPT(l,r, 4); /*  3 */
		D_ENCRYPT(r,l, 6); /*  4 */
		D_ENCRYPT(l,r, 8); /*  5 */
		D_ENCRYPT(r,l,10); /*  6 */
		D_ENCRYPT(l,r,12); /*  7 */
		D_ENCRYPT(r,l,14); /*  8 */
		D_ENCRYPT(l,r,16); /*  9 */
		D_ENCRYPT(r,l,18); /*  10 */
		D_ENCRYPT(l,r,20); /*  11 */
		D_ENCRYPT(r,l,22); /*  12 */
		D_ENCRYPT(l,r,24); /*  13 */
		D_ENCRYPT(r,l,26); /*  14 */
		D_ENCRYPT(l,r,28); /*  15 */
		D_ENCRYPT(r,l,30); /*  16 */
#else
		for (i=0; i<32; i+=8)
		{
			D_ENCRYPT(l,r,i+0); /*  1 */
			D_ENCRYPT(r,l,i+2); /*  2 */
			D_ENCRYPT(l,r,i+4); /*  3 */
			D_ENCRYPT(r,l,i+6); /*  4 */
		}
#endif
	}
	else
	{
#ifdef DES_UNROLL
		D_ENCRYPT(l,r,30); /* 16 */
		D_ENCRYPT(r,l,28); /* 15 */
		D_ENCRYPT(l,r,26); /* 14 */
		D_ENCRYPT(r,l,24); /* 13 */
		D_ENCRYPT(l,r,22); /* 12 */
		D_ENCRYPT(r,l,20); /* 11 */
		D_ENCRYPT(l,r,18); /* 10 */
		D_ENCRYPT(r,l,16); /*  9 */
		D_ENCRYPT(l,r,14); /*  8 */
		D_ENCRYPT(r,l,12); /*  7 */
		D_ENCRYPT(l,r,10); /*  6 */
		D_ENCRYPT(r,l, 8); /*  5 */
		D_ENCRYPT(l,r, 6); /*  4 */
		D_ENCRYPT(r,l, 4); /*  3 */
		D_ENCRYPT(l,r, 2); /*  2 */
		D_ENCRYPT(r,l, 0); /*  1 */
#else
		for (i=30; i>0; i-=8)
		{
			D_ENCRYPT(l,r,i-0); /* 16 */
			D_ENCRYPT(r,l,i-2); /* 15 */
			D_ENCRYPT(l,r,i-4); /* 14 */
			D_ENCRYPT(r,l,i-6); /* 13 */
		}
#endif
	}
	/* rotate and clear the top bits on machines with 8byte longs */
	data[0]=ROTATE(l,3)&0xffffffffL;
	data[1]=ROTATE(r,3)&0xffffffffL;
	l=r=t=u=0;
}
/*****************************************************************************/
/* FUNC:   void des_encrypt3(DES_LONG *data, des_key_schedule ks1,           */
/*                  des_key_schedule ks2, des_key_schedule ks3)              */
/* INPUT:  data     -- plaintext to be encrypted                             */
/*         ks1      -- key1 use to encrypt data                              */
/*         ks2      -- key2 use to encrypt data                              */
/*         ks3      -- key3 use to encrypt data                              */
/* OUTPUT: data     -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with 3DES mechanism                */
/*****************************************************************************/
void des_encrypt3(DES_LONG *data, des_key_schedule ks1, 
                  des_key_schedule ks2, des_key_schedule ks3)
{
	register DES_LONG l,r;

	l=data[0];
	r=data[1];
	IP(l,r);
	data[0]=l;
	data[1]=r;
	des_encrypt2((DES_LONG *)data,ks1,DES_ENCRYPT);
	des_encrypt2((DES_LONG *)data,ks2,DES_DECRYPT);
	des_encrypt2((DES_LONG *)data,ks3,DES_ENCRYPT);
	l=data[0];
	r=data[1];
	FP(r,l);
	data[0]=l;
	data[1]=r;
}
/*****************************************************************************/
/* FUNC:   void des_decrypt3(DES_LONG *data, des_key_schedule ks1,           */
/*                  des_key_schedule ks2, des_key_schedule ks3)              */
/* INPUT:  data     -- ciphertext to be decrypted                            */
/*         ks1      -- key1 use to encrypt data                              */
/*         ks2      -- key2 use to encrypt data                              */
/*         ks3      -- key3 use to encrypt data                              */
/* OUTPUT: data     -- plain text                                            */
/* RETURN: none                                                              */
/* DESC:   The function decrypts the data with 3DES mechanism                */
/*****************************************************************************/
void des_decrypt3(DES_LONG *data, des_key_schedule ks1,
                  des_key_schedule ks2, des_key_schedule ks3)
{
	register DES_LONG l,r;

	l=data[0];
	r=data[1];
	IP(l,r);
	data[0]=l;
	data[1]=r;
	des_encrypt2((DES_LONG *)data,ks3,DES_DECRYPT);
	des_encrypt2((DES_LONG *)data,ks2,DES_ENCRYPT);
	des_encrypt2((DES_LONG *)data,ks1,DES_DECRYPT);
	l=data[0];
	r=data[1];
	FP(r,l);
	data[0]=l;
	data[1]=r;
}

/*****************************************************************************/
/* FUNC:   void des_ncbc_encrypt(des_cblock (*input), des_cblock (*output),  */
/*       long length, des_key_schedule schedule, des_cblock (*ivec), int enc)*/
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         length   -- length of plaintext                                   */
/*         schedule -- key use to encrypt data                               */
/*         ivec     -- encrypt IV                                            */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output   -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_NCBC mechanism            */
/*****************************************************************************/
#ifndef DES_DEFAULT_OPTIONS

void des_ncbc_encrypt(des_cblock (*input), des_cblock (*output), 
     long length, des_key_schedule schedule, des_cblock (*ivec), int enc)
{
	register DES_LONG tin0,tin1;
	register DES_LONG tout0,tout1,xor0,xor1;
	register unsigned char *in,*out;
	register long l=length;
	DES_LONG tin[2];
	unsigned char *iv;

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	iv=(unsigned char *)ivec;

	if (enc)
	{
		c2l(iv,tout0);
		c2l(iv,tout1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0);
			c2l(in,tin1);
			tin0^=tout0; tin[0]=tin0;
			tin1^=tout1; tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_ENCRYPT);
			tout0=tin[0]; l2c(tout0,out);
			tout1=tin[1]; l2c(tout1,out);
		}
		if (l != -8)
		{
			c2ln(in,tin0,tin1,l+8);
			tin0^=tout0; tin[0]=tin0;
			tin1^=tout1; tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_ENCRYPT);
			tout0=tin[0]; l2c(tout0,out);
			tout1=tin[1]; l2c(tout1,out);
		}
		iv=(unsigned char *)ivec;
		l2c(tout0,iv);
		l2c(tout1,iv);
	}
	else
	{
		c2l(iv,xor0);
		c2l(iv,xor1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0); tin[0]=tin0;
			c2l(in,tin1); tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_DECRYPT);
			tout0=tin[0]^xor0;
			tout1=tin[1]^xor1;
			l2c(tout0,out);
			l2c(tout1,out);
			xor0=tin0;
			xor1=tin1;
		}
		if (l != -8)
		{
			c2l(in,tin0); tin[0]=tin0;
			c2l(in,tin1); tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_DECRYPT);
			tout0=tin[0]^xor0;
			tout1=tin[1]^xor1;
			l2cn(tout0,tout1,out,l+8);
			xor0=tin0;
			xor1=tin1;
		}

		iv=(unsigned char *)ivec;
		l2c(xor0,iv);
		l2c(xor1,iv);
	}
	
	tin0=tin1=tout0=tout1=xor0=xor1=0;
	tin[0]=tin[1]=0;
}
/*****************************************************************************/
/* FUNC:   void des_ede3_cbc_encrypt(des_cblock (*input),des_cblock(*output),*/
/*                  long length, des_key_schedule ks1, des_key_schedule ks2, */
/*                  des_key_schedule ks3,  des_cblock (*ivec), int enc)      */
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         length   -- length of plaintext                                   */
/*         ks1      -- key1 use to encrypt data                              */
/*         ks2      -- key2 use to encrypt data                              */
/*         ks3      -- key3 use to encrypt data                              */
/*         ivec     -- encrypt IV                                            */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output   -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_EDE3CBC mechanism         */
/*****************************************************************************/
void des_ede3_cbc_encrypt(des_cblock (*input), des_cblock (*output), 
     long length, des_key_schedule ks1, des_key_schedule ks2,
     des_key_schedule ks3,  des_cblock (*ivec), int enc)
{
	register DES_LONG tin0,tin1;
	register DES_LONG tout0,tout1,xor0,xor1;
	register unsigned char *in,*out;
	register long l=length;
	DES_LONG tin[2];
	unsigned char *iv;

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	iv=(unsigned char *)ivec;

	if (enc)
	{
		c2l(iv,tout0);
		c2l(iv,tout1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0);
			c2l(in,tin1);
			tin0^=tout0;
			tin1^=tout1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_encrypt3((DES_LONG *)tin,ks1,ks2,ks3);
			tout0=tin[0];
			tout1=tin[1];

			l2c(tout0,out);
			l2c(tout1,out);
		}
		if (l != -8)
		{
			c2ln(in,tin0,tin1,l+8);
			tin0^=tout0;
			tin1^=tout1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_encrypt3((DES_LONG *)tin,ks1,ks2,ks3);
			tout0=tin[0];
			tout1=tin[1];

			l2c(tout0,out);
			l2c(tout1,out);
		}
		iv=(unsigned char *)ivec;
		l2c(tout0,iv);
		l2c(tout1,iv);
	}
	else
	{
		register DES_LONG t0,t1;

		c2l(iv,xor0);
		c2l(iv,xor1);
		for (l-=8; l>=0; l-=8)
			{
			c2l(in,tin0);
			c2l(in,tin1);

			t0=tin0;
			t1=tin1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_decrypt3((DES_LONG *)tin,ks1,ks2,ks3);
			tout0=tin[0];
			tout1=tin[1];

			tout0^=xor0;
			tout1^=xor1;
			l2c(tout0,out);
			l2c(tout1,out);
			xor0=t0;
			xor1=t1;
		}
		if (l != -8)
		{
			c2l(in,tin0);
			c2l(in,tin1);
			
			t0=tin0;
			t1=tin1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_decrypt3((DES_LONG *)tin,ks1,ks2,ks3);
			tout0=tin[0];
			tout1=tin[1];
		
			tout0^=xor0;
			tout1^=xor1;
			l2cn(tout0,tout1,out,l+8);
			xor0=t0;
			xor1=t1;
		}

		iv=(unsigned char *)ivec;
		l2c(xor0,iv);
		l2c(xor1,iv);
	}
	tin0=tin1=tout0=tout1=xor0=xor1=0;
	tin[0]=tin[1]=0;
}
/*****************************************************************************/
/* FUNC:   void des_3cbc_encrypt(des_cblock (*input),des_cblock(*output),    */
/*           long length, unsigned char desKey1[8], unsigned char desKey2[8],*/
/*                    unsigned char ivec[8], int enc)                        */
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         length   -- length of plaintext                                   */
/*         desKey1  -- key1 use to encrypt data                              */
/*         desKey2  -- key2 use to encrypt data                              */
/*         ivec     -- encrypt IV                                            */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output   -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_3CBC mechanism            */
/*****************************************************************************/
int des_3cbc_encrypt(unsigned char *input, unsigned char *output, 
       long length, unsigned char desKey1[8], unsigned char desKey2[8],
       unsigned char ivec[8], int enc)
{
	register DES_LONG tin0,tin1;
	register DES_LONG tout0,tout1,xor0,xor1;
	register unsigned char *in,*out;
	register long l=length;
	unsigned char lastBlock[8];
	DES_LONG tin[2];
	unsigned char *iv;
	des_key_schedule ks1;
	des_key_schedule ks2;
	

	if(des_key_sched((C_Block *)desKey1, ks1) != 0)
		return -1;

	if(des_key_sched((C_Block *)desKey2, ks2) != 0)
		return -1;

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	iv=(unsigned char *)ivec;

	if (enc)
	{
		c2l(iv,tout0);
		c2l(iv,tout1);
		for (l-=8; l>=-8; l-=8)
		{
			if (l < 0)			
			{
				memcpy(lastBlock, in, 8 + l);
				memset(lastBlock + 8 + l, -l, -l);
				in = (unsigned char *)lastBlock;
			}
			c2l(in,tin0);
			c2l(in,tin1);
			tin0^=tout0;
			tin1^=tout1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_encrypt3((DES_LONG *)tin,ks1,ks2,ks1);
			tout0=tin[0];
			tout1=tin[1];

			l2c(tout0,out);
			l2c(tout1,out);
		}
		iv=(unsigned char *)ivec;
		l2c(tout0,iv);
		l2c(tout1,iv);
	}
	else
	{
		register DES_LONG t0,t1;

		c2l(iv,xor0);
		c2l(iv,xor1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0);
			c2l(in,tin1);

			t0=tin0;
			t1=tin1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_decrypt3((DES_LONG *)tin,ks1,ks2,ks1);
			tout0=tin[0];
			tout1=tin[1];

			tout0^=xor0;
			tout1^=xor1;
			l2c(tout0,out);
			l2c(tout1,out);
			xor0=t0;
			xor1=t1;
		}
		if (l != -8)
		{
			c2l(in,tin0);
			c2l(in,tin1);
			
			t0=tin0;
			t1=tin1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_decrypt3((DES_LONG *)tin,ks1,ks2,ks1);
			tout0=tin[0];
			tout1=tin[1];
		
			tout0^=xor0;
			tout1^=xor1;
			l2cn(tout0,tout1,out,l+8);
			xor0=t0;
			xor1=t1;
		}

		iv=(unsigned char *)ivec;
		l2c(xor0,iv);
		l2c(xor1,iv);
	}
	tin0=tin1=tout0=tout1=xor0=xor1=0;
	tin[0]=tin[1]=0;
	return 0;

}

/*****************************************************************************/
/* FUNC:   void des_3cbc_encrypt_24(des_cblock (*input),des_cblock(*output), */
/*           long length, unsigned char desKey1[8], unsigned char desKey2[8],*/
/*                        unsigned char desKey3[8],                          */
/*                    unsigned char ivec[8], int enc)                        */
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         length   -- length of plaintext                                   */
/*         desKey1  -- key1 use to encrypt data                              */
/*         desKey2  -- key2 use to encrypt data                              */
/*         desKey3  -- key3 use to encrypt data                              */
/*         ivec     -- encrypt IV                                            */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output   -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_3CBC mechanism            */
/*****************************************************************************/
int des_3cbc_encrypt_24(unsigned char *input, unsigned char *output, 
       long length, unsigned char desKey1[8], unsigned char desKey2[8],
       unsigned char desKey3[8],
       unsigned char ivec[8], int enc)
{
	register DES_LONG tin0,tin1;
	register DES_LONG tout0,tout1,xor0,xor1;
	register unsigned char *in,*out;
	register long l=length;
	unsigned char lastBlock[8];
	DES_LONG tin[2];
	unsigned char *iv;
	des_key_schedule ks1;
	des_key_schedule ks2;
	des_key_schedule ks3;
	

	if(des_key_sched((C_Block *)desKey1, ks1) != 0)
		return -1;

	if(des_key_sched((C_Block *)desKey2, ks2) != 0)
		return -1;

	if(des_key_sched((C_Block *)desKey3, ks3) != 0)
		return -1;

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	iv=(unsigned char *)ivec;

	if (enc)
	{
		c2l(iv,tout0);
		c2l(iv,tout1);
		for (l-=8; l>=-8; l-=8)
		{
			if (l < 0)			
			{
				memcpy(lastBlock, in, 8 + l);
				memset(lastBlock + 8 + l, -l, -l);
				in = (unsigned char *)lastBlock;
			}
			c2l(in,tin0);
			c2l(in,tin1);
			tin0^=tout0;
			tin1^=tout1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_encrypt3((DES_LONG *)tin,ks1,ks2,ks3);
			tout0=tin[0];
			tout1=tin[1];

			l2c(tout0,out);
			l2c(tout1,out);
		}
		iv=(unsigned char *)ivec;
		l2c(tout0,iv);
		l2c(tout1,iv);
	}
	else
	{
		register DES_LONG t0,t1;

		c2l(iv,xor0);
		c2l(iv,xor1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0);
			c2l(in,tin1);

			t0=tin0;
			t1=tin1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_decrypt3((DES_LONG *)tin,ks1,ks2,ks3);
			tout0=tin[0];
			tout1=tin[1];

			tout0^=xor0;
			tout1^=xor1;
			l2c(tout0,out);
			l2c(tout1,out);
			xor0=t0;
			xor1=t1;
		}
		if (l != -8)
		{
			c2l(in,tin0);
			c2l(in,tin1);
			
			t0=tin0;
			t1=tin1;

			tin[0]=tin0;
			tin[1]=tin1;
			des_decrypt3((DES_LONG *)tin,ks1,ks2,ks3);
			tout0=tin[0];
			tout1=tin[1];
		
			tout0^=xor0;
			tout1^=xor1;
			l2cn(tout0,tout1,out,l+8);
			xor0=t0;
			xor1=t1;
		}

		iv=(unsigned char *)ivec;
		l2c(xor0,iv);
		l2c(xor1,iv);
	}
	tin0=tin1=tout0=tout1=xor0=xor1=0;
	tin[0]=tin[1]=0;
	return 0;

}

#endif /* DES_DEFAULT_OPTIONS */
/*****************************************************************************/
/* FUNC:   short DES_3CBC_Encryption(unsigned char *clearTxt,                */
/*                   unsigned char *cipherTxt,unsigned char keyDES[16],      */
/*                    long len, unsigned char IV[8])                         */
/* INPUT:  clearTxt -- plaintext to be encrypted                             */
/*         len      -- length of plaintext                                   */
/*         keyDES   -- key  use to encrypt data                              */
/*         IV       -- encrypt IV                                            */
/* OUTPUT: cipherTxt-- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_3CBC mechanism            */
/*****************************************************************************/
short DES_3CBC_Encryption(unsigned char *clearTxt, unsigned char *cipherTxt, 
                     unsigned char keyDES[16], long len, unsigned char IV[8])
{
	
	unsigned   char desKey1[8];
	unsigned   char desKey2[8];
	
	memcpy(desKey1,keyDES,8);
	memcpy(desKey2,&keyDES[8],8);
	
	des_3cbc_encrypt(clearTxt, cipherTxt, len, desKey1,desKey2,
	         IV, DES_ENCRYPT);

	return 0;
}
/*****************************************************************************/
/* FUNC:   short DES_3CBC_Decryption(unsigned char *cipherTxt,               */
/*                  unsigned char *clearTxt,  unsigned char keyDES[16],      */
/*                    long len, unsigned char IV[8])                         */
/* INPUT:  cipherTxt-- encrypted text                                        */
/*         len      -- length of encrypted text                              */
/*         keyDES   -- key  use to decrypt data                              */
/*         IV       -- decrypt IV                                            */
/* OUTPUT: clearTxt -- plaintext                                             */
/* RETURN: none                                                              */
/* DESC:   The function decrypts the data with DES_3CBC mechanism            */
/*****************************************************************************/
short DES_3CBC_Decryption(unsigned char *cipherTxt, unsigned char *clearTxt,
          unsigned char keyDES[16], long len, unsigned char IV[8])
{
	unsigned   char desKey1[8];
	unsigned   char desKey2[8];
	
	memcpy(desKey1,keyDES,8);
	memcpy(desKey2,&keyDES[8],8);
	
	des_3cbc_encrypt(cipherTxt,clearTxt, len, desKey1,desKey2,
	         IV, DES_DECRYPT);

	return 0;
}
/*****************************************************************************/
/* FUNC:   void des_ecb3_encrypt(des_cblock (*input),des_cblock(*output),    */
/*                  long length, des_key_schedule ks1, des_key_schedule ks2, */
/*                  des_key_schedule ks3,  des_cblock (*ivec), int enc)      */
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         length   -- length of plaintext                                   */
/*         ks1      -- key1 use to encrypt data                              */
/*         ks2      -- key2 use to encrypt data                              */
/*         ks3      -- key3 use to encrypt data                              */
/*         ivec     -- encrypt IV                                            */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output   -- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_ECB3 mechanism            */
/*****************************************************************************/
void des_ecb3_encrypt(des_cblock (*input), des_cblock (*output),
     des_key_schedule ks1, des_key_schedule ks2, des_key_schedule ks3, int enc)
{
	register DES_LONG l0,l1;
	register unsigned char *in,*out;
	DES_LONG ll[2];

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	c2l(in,l0);
	c2l(in,l1);
	ll[0]=l0;
	ll[1]=l1;
	if (enc)
		des_encrypt3(ll,ks1,ks2,ks3);
	else
		des_decrypt3(ll,ks1,ks2,ks3);
	l0=ll[0];
	l1=ll[1];
	l2c(l0,out);
	l2c(l1,out);
}
/*****************************************************************************/
/* FUNC:   void des_xwhite_in2out(des_cblock (*des_key),                     */
/*                  des_cblock (*in_white),des_cblock (*out_white))          */
/* INPUT:  des_key -- DES key                                                */
/*         in_white-- input                                                  */
/* OUTPUT: out_white -- output                                               */
/* RETURN: none                                                              */
/* DESC:   The function handles DES key                                      */
/*****************************************************************************/
static unsigned char desx_white_in2out[256]={
0xBD,0x56,0xEA,0xF2,0xA2,0xF1,0xAC,0x2A,0xB0,0x93,0xD1,0x9C,0x1B,0x33,0xFD,
0xD0,0x30,0x04,0xB6,0xDC,0x7D,0xDF,0x32,0x4B,0xF7,0xCB,0x45,0x9B,0x31,0xBB,
0x21,0x5A,0x41,0x9F,0xE1,0xD9,0x4A,0x4D,0x9E,0xDA,0xA0,0x68,0x2C,0xC3,0x27,
0x5F,0x80,0x36,0x3E,0xEE,0xFB,0x95,0x1A,0xFE,0xCE,0xA8,0x34,0xA9,0x13,0xF0,
0xA6,0x3F,0xD8,0x0C,0x78,0x24,0xAF,0x23,0x52,0xC1,0x67,0x17,0xF5,0x66,0x90,
0xE7,0xE8,0x07,0xB8,0x60,0x48,0xE6,0x1E,0x53,0xF3,0x92,0xA4,0x72,0x8C,0x08,
0x15,0x6E,0x86,0x00,0x84,0xFA,0xF4,0x7F,0x8A,0x42,0x19,0xF6,0xDB,0xCD,0x14,
0x8D,0x50,0x12,0xBA,0x3C,0x06,0x4E,0xEC,0xB3,0x35,0x11,0xA1,0x88,0x8E,0x2B,
0x94,0x99,0xB7,0x71,0x74,0xD3,0xE4,0xBF,0x3A,0xDE,0x96,0x0E,0xBC,0x0A,0xED,
0x77,0xFC,0x37,0x6B,0x03,0x79,0x89,0x62,0xC6,0xD7,0xC0,0xD2,0x7C,0x6A,0x8B,
0x22,0xA3,0x5B,0x05,0x5D,0x02,0x75,0xD5,0x61,0xE3,0x18,0x8F,0x55,0x51,0xAD,
0x1F,0x0B,0x5E,0x85,0xE5,0xC2,0x57,0x63,0xCA,0x3D,0x6C,0xB4,0xC5,0xCC,0x70,
0xB2,0x91,0x59,0x0D,0x47,0x20,0xC8,0x4F,0x58,0xE0,0x01,0xE2,0x16,0x38,0xC4,
0x6F,0x3B,0x0F,0x65,0x46,0xBE,0x7E,0x2D,0x7B,0x82,0xF9,0x40,0xB5,0x1D,0x73,
0xF8,0xEB,0x26,0xC7,0x87,0x97,0x25,0x54,0xB1,0x28,0xAA,0x98,0x9D,0xA5,0x64,
0x6D,0x7A,0xD4,0x10,0x81,0x44,0xEF,0x49,0xD6,0xAE,0x2E,0xDD,0x76,0x5C,0x2F,
0xA7,0x1C,0xC9,0x09,0x69,0x9A,0x83,0xCF,0x29,0x39,0xB9,0xE9,0x4C,0xFF,0x43,
0xAB,};

void des_xwhite_in2out(des_cblock (*des_key), des_cblock (*in_white),
     des_cblock (*out_white))
{
	unsigned char *key,*in,*out;
	int out0,out1;
	int i;

	key=(unsigned char *)des_key;
	in=(unsigned char *)in_white;
	out=(unsigned char *)out_white;

	out[0]=out[1]=out[2]=out[3]=out[4]=out[5]=out[6]=out[7]=0;
	out0=out1=0;
	for (i=0; i<8; i++)
	{
		out[i]=key[i]^desx_white_in2out[out0^out1];
		out0=out1;
		out1=(int)out[i&0x07];
	}

	out0=out[0];
	out1=out[i];
	for (i=0; i<8; i++)
	{
		out[i]=in[i]^desx_white_in2out[out0^out1];
		out0=out1;
		out1=(int)out[i&0x07];
	}
}
/*****************************************************************************/
/* FUNC:   void des_xcbc_encrypt(des_cblock (*input), des_cblock (*output,   */
/*                  long length, des_key_schedule ks1, des_key_schedule ks2, */
/*                  des_key_schedule ks3,  des_cblock (*ivec), int enc)      */
/* INPUT:  input    -- plaintext to be encrypted                             */
/*         length   -- length of plaintext                                   */
/*         schedule -- key use to encrypt data                               */
/*         inw      -- input data                                            */
/*         ivec     -- encrypt IV                                            */
/*         enc      -- ID of encrypt                                         */
/* OUTPUT: output   -- encrypted text                                        */
/*         outw     -- output data                                           */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_XCBC mechanism            */
/*****************************************************************************/
void des_xcbc_encrypt(des_cblock (*input), des_cblock (*output), 
     long length, des_key_schedule schedule, des_cblock (*ivec), 
     des_cblock (*inw), des_cblock (*outw), int enc)
{
	register DES_LONG tin0,tin1;
	register DES_LONG tout0,tout1,xor0,xor1;
	register DES_LONG inW0,inW1,outW0,outW1;
	register unsigned char *in,*out;
	register long l=length;
	DES_LONG tin[2];
	unsigned char *iv;

	in=(unsigned char *)inw;
	c2l(in,inW0);
	c2l(in,inW1);
	in=(unsigned char *)outw;
	c2l(in,outW0);
	c2l(in,outW1);

	in=(unsigned char *)input;
	out=(unsigned char *)output;
	iv=(unsigned char *)ivec;

	if (enc)
	{
		c2l(iv,tout0);
		c2l(iv,tout1);
		for (l-=8; l>=0; l-=8)
		{
			c2l(in,tin0);
			c2l(in,tin1);
			tin0^=tout0^inW0; tin[0]=tin0;
			tin1^=tout1^inW1; tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_ENCRYPT);
			tout0=tin[0]^outW0; l2c(tout0,out);
			tout1=tin[1]^outW1; l2c(tout1,out);
		}
		if (l != -8)
		{
			c2ln(in,tin0,tin1,l+8);
			tin0^=tout0^inW0; tin[0]=tin0;
			tin1^=tout1^inW1; tin[1]=tin1;
			des_encrypt((DES_LONG *)tin,schedule,DES_ENCRYPT);
			tout0=tin[0]^outW0; l2c(tout0,out);
			tout1=tin[1]^outW1; l2c(tout1,out);
		}
		iv=(unsigned char *)ivec;
		l2c(tout0,iv);
		l2c(tout1,iv);
	}
	else
	{
		c2l(iv,xor0);
		c2l(iv,xor1);
		for (l-=8; l>0; l-=8)
		{
			c2l(in,tin0); tin[0]=tin0^outW0;
			c2l(in,tin1); tin[1]=tin1^outW1;
			des_encrypt((DES_LONG *)tin,schedule,DES_DECRYPT);
			tout0=tin[0]^xor0^inW0;
			tout1=tin[1]^xor1^inW1;
			l2c(tout0,out);
			l2c(tout1,out);
			xor0=tin0;
			xor1=tin1;
		}
		if (l != -8)
		{
			c2l(in,tin0); tin[0]=tin0^outW0;
			c2l(in,tin1); tin[1]=tin1^outW1;
			des_encrypt((DES_LONG *)tin,schedule,DES_DECRYPT);
			tout0=tin[0]^xor0^inW0;
			tout1=tin[1]^xor1^inW1;
			l2cn(tout0,tout1,out,l+8);
			xor0=tin0;
			xor1=tin1;
		}

		iv=(unsigned char *)ivec;
		l2c(xor0,iv);
		l2c(xor1,iv);
	}
	tin0=tin1=tout0=tout1=xor0=xor1=0;
	inW0=inW1=outW0=outW1=0;
	tin[0]=tin[1]=0;
}


/*****************************************************************************/
/* FUNC:   short DES_3CBC_Encryption_24(unsigned char *clearTxt,             */
/*                   unsigned char *cipherTxt,unsigned char keyDES[24],      */
/*                    long len, unsigned char IV[8])                         */
/* INPUT:  clearTxt -- plaintext to be encrypted                             */
/*         len      -- length of plaintext                                   */
/*         keyDES   -- key  use to encrypt data                              */
/*         IV       -- encrypt IV                                            */
/* OUTPUT: cipherTxt-- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_3CBC mechanism            */
/*****************************************************************************/
short DES_3CBC_Encryption_24(unsigned char *clearTxt, unsigned char *cipherTxt, 
                     unsigned char *keyDES, long len, unsigned char IV[8])
{
	unsigned   char desKey1[8];
	unsigned   char desKey2[8];
	unsigned   char desKey3[8];
	
	memcpy(desKey1,keyDES,8);
	memcpy(desKey2,&keyDES[8],8);
	memcpy(desKey3,&keyDES[16],8);
	
	des_3cbc_encrypt_24(clearTxt, cipherTxt, len, desKey1,desKey2,desKey3,
	         IV, DES_ENCRYPT);

	return 0;
}

/*****************************************************************************/
/* FUNC:   short DES_3CBC_Decryption_24(unsigned char *cipherTxt,            */
/*                  unsigned char *clearTxt,  unsigned char keyDES[24],      */
/*                    long len, unsigned char IV[8])                         */
/* INPUT:  cipherTxt-- encrypted text                                        */
/*         len      -- length of encrypted text                              */
/*         keyDES   -- key  use to decrypt data                              */
/*         IV       -- decrypt IV                                            */
/* OUTPUT: clearTxt -- plaintext                                             */
/* RETURN: none                                                              */
/* DESC:   The function decrypts the data with DES_3CBC mechanism            */
/*****************************************************************************/
short DES_3CBC_Decryption_24(unsigned char *cipherTxt, unsigned char *clearTxt,
          unsigned char *keyDES, long len, unsigned char IV[8])
{
	unsigned   char desKey1[8];
	unsigned   char desKey2[8];
	unsigned   char desKey3[8];
	
	memcpy(desKey1,keyDES,8);
	memcpy(desKey2,&keyDES[8],8);
	memcpy(desKey3,&keyDES[16],8);
	
	des_3cbc_encrypt_24(cipherTxt,clearTxt, len, desKey1,desKey2,desKey3,
	         IV, DES_DECRYPT);

	return 0;
}

/*****************************************************************************/
/* FUNC:   short DES_3ECB_Encryption(unsigned char *clearTxt,                */
/*                   unsigned char *cipherTxt,unsigned char keyDES[24],      */
/*                    long len, unsigned char IV[8])                         */
/* INPUT:  clearTxt -- plaintext to be encrypted                             */
/*         len      -- length of plaintext                                   */
/*         keyDES   -- key  use to encrypt data                              */
/*         IV       -- encrypt IV                                            */
/* OUTPUT: cipherTxt-- encrypted text                                        */
/* RETURN: none                                                              */
/* DESC:   The function encrypts the data with DES_3ECB mechanism            */
/*****************************************************************************/
short DES_3ECB_Encryption(unsigned char *clearTxt, unsigned char *cipherTxt, 
                     unsigned char *keyDES, long len, unsigned char IV[8])
{
	register   long l=len;
	unsigned   char desKey1[8];
	unsigned   char desKey2[8];
	unsigned   char desKey3[8];
	unsigned   char cblock1[8]; 
	unsigned   char eblock1[8]; 
	des_key_schedule ks1;
	des_key_schedule ks2;
	des_key_schedule ks3;
	
	memcpy(desKey1,keyDES,8);
	memcpy(desKey2,&keyDES[8],8);
	memcpy(desKey3,&keyDES[16],8);
	
	if(des_key_sched((C_Block *)desKey1, ks1) != 0)
		return -1;
	if(des_key_sched((C_Block *)desKey2, ks2) != 0)
		return -1;
	if(des_key_sched((C_Block *)desKey3, ks3) != 0)
		return -1;

	for (l-=8; l>=0; l-=8)
	{
		memset(cblock1, 0, sizeof(cblock1));
		memset(eblock1, 0, sizeof(eblock1));
		memcpy(cblock1, clearTxt+l, 8);
		des_ecb3_encrypt((des_cblock *)cblock1, (des_cblock *)eblock1, 
			ks1, ks2, ks3, DES_ENCRYPT);
		memcpy(cipherTxt+l, eblock1, 8);
	}

	return 0;
}

/*****************************************************************************/
/* FUNC:   short DES_3ECB_Decryption(unsigned char *cipherTxt,               */
/*                  unsigned char *clearTxt,  unsigned char keyDES[24],      */
/*                    long len, unsigned char IV[8])                         */
/* INPUT:  cipherTxt-- encrypted text                                        */
/*         len      -- length of encrypted text                              */
/*         keyDES   -- key  use to decrypt data                              */
/*         IV       -- decrypt IV                                            */
/* OUTPUT: clearTxt -- plaintext                                             */
/* RETURN: none                                                              */
/* DESC:   The function decrypts the data with DES_3ECB mechanism            */
/*****************************************************************************/
short DES_3ECB_Decryption(unsigned char *cipherTxt, unsigned char *clearTxt,
          unsigned char *keyDES, long len, unsigned char IV[8])
{
	register   long l=len;
	unsigned   char desKey1[8];
	unsigned   char desKey2[8];
	unsigned   char desKey3[8];
	unsigned   char cblock1[8]; 
	unsigned   char eblock1[8]; 
	des_key_schedule ks1;
	des_key_schedule ks2;
	des_key_schedule ks3;
	
	memcpy(desKey1,keyDES,8);
	memcpy(desKey2,&keyDES[8],8);
	memcpy(desKey3,&keyDES[16],8);
	
	if(des_key_sched((C_Block *)desKey1, ks1) != 0)
		return -1;
	if(des_key_sched((C_Block *)desKey2, ks2) != 0)
		return -1;
	if(des_key_sched((C_Block *)desKey3, ks3) != 0)
		return -1;

	for (l-=8; l>=0; l-=8)
	{
		memset(cblock1, 0, sizeof(cblock1));
		memset(eblock1, 0, sizeof(eblock1));
		memcpy(eblock1, cipherTxt+l, 8);
		des_ecb3_encrypt((des_cblock *)eblock1, (des_cblock *)cblock1, 
			ks1, ks2, ks3, DES_DECRYPT);
		memcpy(clearTxt+l, cblock1, 8);
	}

	return 0;
}

