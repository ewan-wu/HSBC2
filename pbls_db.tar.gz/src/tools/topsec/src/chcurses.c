/*|--------------------------------------------------------------------------|*/
/*| Product: SmartTeller Version 2.0                                         |*/
/*| Copyright (c) 1998 Shanghai Systems.                                     |*/
/*|    All Rights Reserved                                                   |*/
/*|--------------------------------------------------------------------------|*/
/*| Module: Athena Curses Library                                            |*/
/*|         Chinese Curses Lib                                               |*/
/*|--------------------------------------------------------------------------|*/
/*| File: chcurses.c                                                         |*/
/*| Discription:                                                             |*/
/*| Original written by: Fu Sean (1998.09)                                   |*/
/*| Update Log:                                                              |*/
/*|--------------------------------------------------------------------------|*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "chcurses.h"

/***********************************************\
 *             Global Variables
\***********************************************/

int     ch_global_width;
int		ch_global_height;

int     g_ch_cursor_x;
int		g_ch_cursor_y;

static  unsigned char*  ch_attr = NULL;
static  unsigned char ch_curr_attr = CCHAR_NORMAL;

#define  CH_ATTR(X, Y)   ch_attr[(Y) * COLS + (X)]

void ch_initscr();
void ch_endwin();
void ch_refresh();
void ch_mvprintw(int, int, char*);
int ch_ischinese(const char*);
void ch_xy_attroff(int, int, unsigned char);
void ch_xy_attron(int, int, unsigned char);
int ch_xy_isattron(int, int, unsigned char);
void ch_xy_set_dispattr(int, int);
void ch_xy_clearattr(int x, int y);
void ch_attroff(unsigned char);
void ch_attron(unsigned char);
int ch_isattron( unsigned char);
void ch_set_dispattr();
void ch_clearattr();
int ch_getch();
void ch_beep();
void ch_move(int, int);
void ch_nodelay(int);
void ch_setcursor();

void ch_initscr()
{
	int i, j;

	if( NULL == initscr())
	{
		printf("FATAL: Can't open screen!\n");
		exit(1);
	}

	cbreak();
	noecho();
	nonl();
	intrflush(stdscr,FALSE);
	keypad(stdscr,TRUE);
	clear();
	nodelay(stdscr, FALSE);

	if( NULL == ( ch_attr = 
				  (unsigned char*)malloc(COLS * LINES * sizeof(char)) ) )
	{
		endwin();
		printf("FATAL: Can't initialize Chinese screen!\n");
		exit(1);
	}

	for( i = 0; i < COLS; i++)
	{
		for( j = 0; j < LINES; j++)
		{
			ch_xy_clearattr(i, j);
		}
	}
	ch_clearattr();

	g_ch_cursor_x = -1;
	g_ch_cursor_y = -1;

	ch_refresh();
}

void ch_endwin()
{
	if( ch_attr != NULL )
	{
		free(ch_attr);
	}
	ch_attr = NULL;

	clear();
	refresh();

	endwin();
}

void ch_mvprintw(int y, int x, char* szStr)
{
	int i;

	if( ! ( x >= 0 && x < COLS  ) )
		return;
	if( ! ( y >= 0 && y < LINES ) )
		return;
	if( ! ( szStr != NULL ) )
		return;
	if(  ch_attr == NULL )
		return;

	for( i = 0; i < strlen(szStr); i++ )
	{
		if( ch_ischinese(&szStr[i]) )
		{
			ch_xy_clearattr(x + i, y);
			ch_xy_attron( x + i, y, CCHAR_CHLOW | ch_curr_attr );
			ch_xy_clearattr( x + i + 1, y);
			ch_xy_attron( x + i + 1, y, CCHAR_CHHIGH | ch_curr_attr );
			i ++;
		}
		else
		{
			ch_xy_clearattr(x + i, y);
			ch_xy_attroff(x + i, y, ch_curr_attr );
		}
	}

	ch_set_dispattr();
	mvprintw(y, x, szStr);

	if( x != 0 && ch_xy_isattron( x - 1, y, CCHAR_CHLOW ) )
	{
		ch_xy_attroff(x - 1, y, CCHAR_CHLOW);
		ch_xy_set_dispattr( x - 1, y);
		mvprintw(y, x - 1, " ");
	}

	if( x + strlen(szStr) != COLS  && 
		ch_xy_isattron(x + strlen(szStr), y, CCHAR_CHHIGH ) )
	{
		ch_xy_attroff(x + strlen(szStr), y, CCHAR_CHHIGH);
		ch_xy_set_dispattr( x + strlen(szStr), y);
		mvprintw(y, x + strlen(szStr), " ");
	}
}

void ch_setcursor()
{
	if( g_ch_cursor_x == -1 || g_ch_cursor_y == -1 )
	{
		move(LINES - 1, COLS - 1 );  /* bottom-right corner */
	}
	else
	{
		move(g_ch_cursor_y, g_ch_cursor_x);
	}
}

void ch_refresh()
{
	ch_setcursor();
	refresh();
}

int ch_ischinese(const char* szStr)
{
	if( NULL == szStr || strlen(szStr) < 2 )
		return 0;

	if( (unsigned char)szStr[0] >= 0xa1 && (unsigned char)szStr[1] >= 0xa1 )
		return 1;

	return 0;
}

int ch_xy_isattron(int x, int y, unsigned char cAttr)
{
	if( ! ( x >= 0 && x < COLS  ) )
		return 0;
	if( ! ( y >= 0 && y < LINES ) )
		return 0;
	if( !  ( ch_attr != NULL ) )
		return 0;

	if( CH_ATTR(x, y) & cAttr )
		return 1;

	return 0;
}

int ch_isattron(unsigned char cAttr)
{
	if( ch_curr_attr & cAttr )
		return 1;
	return 0;
}

void ch_xy_attron(int x, int y, unsigned char cAttr)
{
	if( ! ( x >= 0 && x < COLS  ) )
		return;
	if( ! ( y >= 0 && y < LINES ) )
		return;
	if( !  ( ch_attr != NULL ) )
		return;

	CH_ATTR(x, y) |= cAttr;
}

void ch_attron(unsigned char cAttr)
{
	ch_curr_attr |= cAttr;
}

void ch_xy_attroff(int x, int y, unsigned char cAttr)
{
	if( ! ( x >= 0 && x < COLS  ) )
		return;
	if( ! ( y >= 0 && y < LINES ) )
		return;
	if( !  ( ch_attr != NULL ) )
		return;

	CH_ATTR(x, y) &= ( cAttr ^ 0xff);
}

void ch_attroff(unsigned char cAttr)
{
	ch_curr_attr &= ( cAttr ^ 0xff);
}

int ch_getch()
{
	return getch();
}

void ch_xy_clearattr(int x, int y) 
{
	if( ! ( x >= 0 && x < COLS  ) )
		return;
	if( ! ( y >= 0 && y < LINES ) )
		return;
	if( !  ( ch_attr != NULL ) )
		return;

	CH_ATTR(x, y) = CCHAR_NORMAL;
}

void ch_clearattr()
{
	ch_curr_attr = CCHAR_NORMAL;
}

void ch_set_dispattr()
{
	attroff(A_STANDOUT);
	attroff(A_DIM);
	attroff(A_BLINK);
	attroff(A_REVERSE);
	attroff(A_BOLD);
	attroff(A_UNDERLINE);

	if( ch_curr_attr & CCHAR_DIM)
		attron(A_DIM);
	if( ch_curr_attr & CCHAR_BLINK)
		attron(A_BLINK);
	if( ch_curr_attr & CCHAR_REVERSE)
		attron(A_REVERSE);
	if( ch_curr_attr & CCHAR_BOLD)
		attron(A_BOLD);
	if( ch_curr_attr & CCHAR_UNDERLINE)
		attron(A_UNDERLINE);
}

void ch_xy_set_dispattr(int x, int y)
{
	attroff(A_STANDOUT);
	attroff(A_DIM);
	attroff(A_BLINK);
	attroff(A_REVERSE);
	attroff(A_BOLD);
	attroff(A_UNDERLINE);

	if( CH_ATTR(x, y) & CCHAR_DIM)
		attron(A_DIM);
	if( CH_ATTR(x, y) & CCHAR_BLINK)
		attron(A_BLINK);
	if( CH_ATTR(x, y) & CCHAR_REVERSE)
		attron(A_REVERSE);
	if( CH_ATTR(x, y) & CCHAR_BOLD)
		attron(A_BOLD);
	if( CH_ATTR(x, y) & CCHAR_UNDERLINE)
		attron(A_UNDERLINE);
}

void ch_beep()
{
	beep();
}

void ch_move(int y, int x)
{
	move(y, x);
}

void ch_nodelay(int bf)
{
	nodelay(stdscr, bf);
}
