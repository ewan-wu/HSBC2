/*****************************************************************************/
/*                    TOPSecure Software Cryptography Module                 */
/* Copyright (c) 2000 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/
/* PROGRAM NAME: sftcrmskey.c                                                */
/* DESCRIPTIONS: The program is common header file for software encryption   */
/*****************************************************************************/
/*                                  MODIFICATION LOG                         */
/* DATE        PROGRAMMER               DESCRIPTION                          */
/* 2001-03-20  Wang YingZi             Initial Version Creation              */
/*****************************************************************************/
#include "scubenc.h"
#include <sys/types.h>
#ifdef HP_UNIX
#include <time.h>
#endif
#ifdef SCO_UNIX
#include <sys/time.h>
#endif
#ifdef SCOUW_UNIX
#include <sys/time.h>
#endif
#ifdef DEC_UNIX
#include <sys/time.h>
#endif

void main(int argc,char **argv)
{
    FILE     *ptFp;
    int		 i,iRandom,iCount;
    char     caFlag[32];
    char     caFilePath[256];
    
    if (argc < 4 )
    {
        exit(1);        
    }
    
    strcpy(caFilePath,getenv("SCUBENC_PATH"));
    strcat(caFilePath,"/bin/getmskey.c");
    if ((ptFp = fopen(caFilePath,"w")) == NULL )
    {
        exit(2);
    }       
    
    fprintf(ptFp,
      "\nvoid sftEncByMsKey( char *caKey,char *caEncKey)\n{\n");
    srand( (unsigned)time(NULL));
    for(i=1;i<=3;i++)
    {
        memset(caFlag,'\0',sizeof(caFlag));
        iCount=0;
        while(1)
        {
            iRandom=rand()%16;
            if(caFlag[iRandom] == 0)
            {
                caFlag[iRandom]=1;
                fprintf(ptFp,"    unsigned char ucaMsKey%1d_%02d=0x%c%c;\n",
                    i,iRandom,argv[i][iRandom*2],
                    argv[i][iRandom*2+1]);
                iCount++;
            }
            if(iCount == 16)
                break;
        }
    }
    fprintf(ptFp,"    char  caIv[8];\n"); 
    fprintf(ptFp,"    unsigned char  ucaMsKey[16];\n\n"); 
    
    fprintf(ptFp,
        "    ucaMsKey[0] =  ucaMsKey1_00 ^ ucaMsKey2_00 ^ ucaMsKey3_00;\n");
    fprintf(ptFp,
        "    ucaMsKey[1] =  ucaMsKey1_01 ^ ucaMsKey2_01 ^ ucaMsKey3_01;\n");
    fprintf(ptFp,
        "    ucaMsKey[2] =  ucaMsKey1_02 ^ ucaMsKey2_02 ^ ucaMsKey3_02;\n");
    fprintf(ptFp,
        "    ucaMsKey[3] =  ucaMsKey1_03 ^ ucaMsKey2_03 ^ ucaMsKey3_03;\n");
    fprintf(ptFp,
        "    ucaMsKey[4] =  ucaMsKey1_04 ^ ucaMsKey2_04 ^ ucaMsKey3_04;\n");
    fprintf(ptFp,
        "    ucaMsKey[5] =  ucaMsKey1_05 ^ ucaMsKey2_05 ^ ucaMsKey3_05;\n");
    fprintf(ptFp,
        "    ucaMsKey[6] =  ucaMsKey1_06 ^ ucaMsKey2_06 ^ ucaMsKey3_06;\n");
    fprintf(ptFp,
        "    ucaMsKey[7] =  ucaMsKey1_07 ^ ucaMsKey2_07 ^ ucaMsKey3_07;\n");
    fprintf(ptFp,
    	"    ucaMsKey[8] =  ucaMsKey1_08 ^ ucaMsKey2_08 ^ ucaMsKey3_08;\n");
    fprintf(ptFp,
    	"    ucaMsKey[9] =  ucaMsKey1_09 ^ ucaMsKey2_09 ^ ucaMsKey3_09;\n");
    fprintf(ptFp,
    	"    ucaMsKey[10] =  ucaMsKey1_10 ^ ucaMsKey2_10 ^ ucaMsKey3_10;\n");
    fprintf(ptFp,
    	"    ucaMsKey[11] =  ucaMsKey1_11 ^ ucaMsKey2_11 ^ ucaMsKey3_11;\n");
    fprintf(ptFp,
    	"    ucaMsKey[12] =  ucaMsKey1_12 ^ ucaMsKey2_12 ^ ucaMsKey3_12;\n");
    fprintf(ptFp,
    	"    ucaMsKey[13] =  ucaMsKey1_13 ^ ucaMsKey2_13 ^ ucaMsKey3_13;\n");
    fprintf(ptFp,
    	"    ucaMsKey[14] =  ucaMsKey1_14 ^ ucaMsKey2_14 ^ ucaMsKey3_14;\n");
    fprintf(ptFp,
    	"    ucaMsKey[15] =  ucaMsKey1_15 ^ ucaMsKey2_15 ^ ucaMsKey3_15;\n\n");
    
    fprintf(ptFp,"    memset(caIv,0,sizeof(caIv));\n");
    
    fprintf(ptFp,
      "    DES_3CBC_Encryption(caKey,caEncKey,ucaMsKey, 16,caIv);\n}\n");

    fprintf(ptFp,
      "\nvoid sftDecByMsKey(char *caEncKey, char *caKey)\n{\n");
    srand( (unsigned)time(NULL));
    for(i=1;i<=3;i++)
    {
        memset(caFlag,'\0',sizeof(caFlag));
        iCount=0;
        while(1)
        {
            iRandom=rand()%16;
            if(caFlag[iRandom] == 0)
            {
                caFlag[iRandom]=1;
                fprintf(ptFp,"    unsigned char ucaMsKey%1d_%02d=0x%c%c;\n",
                    i,iRandom,argv[i][iRandom*2],
                    argv[i][iRandom*2+1]);
                iCount++;
            }
            if(iCount == 16)
                break;
        }
    }
    fprintf(ptFp,"    unsigned char  caIv[8];\n");  
    fprintf(ptFp,"    unsigned char  ucaMsKey[16];\n\n");

    fprintf(ptFp,
    	"    ucaMsKey[0] =  ucaMsKey1_00 ^ ucaMsKey2_00 ^ ucaMsKey3_00;\n");
    fprintf(ptFp,
    	"    ucaMsKey[1] =  ucaMsKey1_01 ^ ucaMsKey2_01 ^ ucaMsKey3_01;\n");
    fprintf(ptFp,
    	"    ucaMsKey[2] =  ucaMsKey1_02 ^ ucaMsKey2_02 ^ ucaMsKey3_02;\n");
    fprintf(ptFp,
    	"    ucaMsKey[3] =  ucaMsKey1_03 ^ ucaMsKey2_03 ^ ucaMsKey3_03;\n");
    fprintf(ptFp,
    	"    ucaMsKey[4] =  ucaMsKey1_04 ^ ucaMsKey2_04 ^ ucaMsKey3_04;\n");
    fprintf(ptFp,
    	"    ucaMsKey[5] =  ucaMsKey1_05 ^ ucaMsKey2_05 ^ ucaMsKey3_05;\n");
    fprintf(ptFp,
    	"    ucaMsKey[6] =  ucaMsKey1_06 ^ ucaMsKey2_06 ^ ucaMsKey3_06;\n");
    fprintf(ptFp,
    	"    ucaMsKey[7] =  ucaMsKey1_07 ^ ucaMsKey2_07 ^ ucaMsKey3_07;\n");
    fprintf(ptFp,
    	"    ucaMsKey[8] =  ucaMsKey1_08 ^ ucaMsKey2_08 ^ ucaMsKey3_08;\n");
    fprintf(ptFp,
    	"    ucaMsKey[9] =  ucaMsKey1_09 ^ ucaMsKey2_09 ^ ucaMsKey3_09;\n");
    fprintf(ptFp,
    	"    ucaMsKey[10] =  ucaMsKey1_10 ^ ucaMsKey2_10 ^ ucaMsKey3_10;\n");
    fprintf(ptFp,
    	"    ucaMsKey[11] =  ucaMsKey1_11 ^ ucaMsKey2_11 ^ ucaMsKey3_11;\n");
    fprintf(ptFp,
    	"    ucaMsKey[12] =  ucaMsKey1_12 ^ ucaMsKey2_12 ^ ucaMsKey3_12;\n");
    fprintf(ptFp,
    	"    ucaMsKey[13] =  ucaMsKey1_13 ^ ucaMsKey2_13 ^ ucaMsKey3_13;\n");
    fprintf(ptFp,
    	"    ucaMsKey[14] =  ucaMsKey1_14 ^ ucaMsKey2_14 ^ ucaMsKey3_14;\n");
    fprintf(ptFp,
    	"    ucaMsKey[15] =  ucaMsKey1_15 ^ ucaMsKey2_15 ^ ucaMsKey3_15;\n\n");
    
    fprintf(ptFp,"    memset(caIv,0,sizeof(caIv));\n");
    fprintf(ptFp,
      "    DES_3CBC_Decryption(caEncKey,caKey,ucaMsKey, 16,caIv);\n}\n");

    fprintf(ptFp,
      "    static void TOPSecure_ver2_0_1_a(void){}\n");
      
    fclose (ptFp); 
    exit(0);   
}   
/*****************************************************************************/
/* FUNC:   static void TOPSecure_ver2_0_1_a(void)                            */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: none                                                              */
/* DESC:   maintain version                                                  */
/*****************************************************************************/
static void Scubenc_1_0_1(void)
{
    /*Version:Scubenc_1_0_1 */
}   
    
