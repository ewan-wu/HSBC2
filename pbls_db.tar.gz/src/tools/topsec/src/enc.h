/*****************************************************************************/
/*                       cryptographic model of the Smart Agent              */
/*****************************************************************************/
/* PROGRAM NAME: enc.h                                                       */
/* DESCRIPTIONS: The program is head file for encrypting and decrypting      */
/*****************************************************************************/
/*                                  MODIFICATION LOG                         */
/* DATE        PROGRAMMER               DESCRIPTION                          */
/* 2000-03-25  Wang Faith             Initial Version Creation               */
/*****************************************************************************/
#ifndef __ENC_H
#define __ENC_H

#define ENC_MAX_BUFF_LEN 1024 
#define ENC_MAX_FILENAME 100
#define ENC_BLOCK_SIZE   8
#define ENC_FILE_END     1
#define ENC_FILE_BUF_END 2
#define ENC_LINE_BREAK   3
#define ENC_ZERO		 0x00
#define ENC_BLANK		 0xff

#endif
