/*****************************************************************************/
/*  Shanghai Huateng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2001. All rights reserved.                                 */
/*                                                                           */
/*  File:        scubenc.h                                                   */
/*  Description: constants and functions definition of libscubenc.so         */
/*                                                                           */
/*  Author        Date        Description                                    */
/*  ~~~~~~        ~~~~        ~~~~~~~~~~~                                    */
/*  Yang Wubin    7/5/2001    Initial Version Creation                       */
/*****************************************************************************/

#ifndef _SCUBENC_H
#define _SCUBENC_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <time.h>

/* command constants definition */
#define TRUE                    1
#define FALSE                   0
#define SEC_MAX_ERR_MSG_LEN     200
#define SEC_DEF_MEMKEY          27778
#define SEC_DEF_SEMKEY          27779
#define SEC_DEF_FLAG            432

#define SEC_MAX_PATH_LEN        256
#define SEC_MAX_DATA_LEN        4096
#define SEC_DATA_BLOCK_LEN      1024
#define SEC_HASH_LEN            20
#define SEC_PIN_LEN             8
#define SEC_MAC_LEN             4
#define SEC_PINBLK_LEN          16
#define SEC_ACTNO_LEN           19
#define SEC_ACTNO_DEFLEN        12
#define SEC_MAC_DATA_LEN        512
#define SEC_ORGIDX_LEN          8  
#define SEC_KEYIDX_LEN          4
#define SEC_DATETIME_LEN        14
#define SEC_BITDEF_LEN          8
#define SEC_MAXKEYLIST_SIZE     256
#define SEC_LOGFILE_DEF_SIZE    100000
#define SEC_PASSWD_LEN          6
#define SEC_TLRNO_LEN           4
#define SEC_MAX_DATETIME        "99999999999999"

/* Key related constants */
#define SEC_3DES_KEY_LEN        16
#define SEC_DES_KEY_LEN         8

#define SEC_MAC_KEY             '1' 
#define SEC_PIN_KEY             '2'
#define SEC_DES_KEY             '3'

#define SEC_KEY_OLD             '0'
#define SEC_KEY_NEW             '1'
#define SEC_KEY_NULL            'N'

#define SEC_CHK_VALUE           "\0\0\0\0\0\0\0\0"
#define SEC_CHK_VALUE_LEN       8

/* error code definitions */
#define SEC_OK                  0x0000
#define SEC_ERR_BASE            0x0000
#define SEC_ARGUMENTS_ERR       SEC_ERR_BASE + 1
#define SEC_KEY_EXIST_ERR       SEC_ERR_BASE + 2
#define SEC_VERIFY_ERR          SEC_ERR_BASE + 3
#define SEC_NOKEY_ERR           SEC_ERR_BASE + 4
#define SEC_ASCIITOBCD_ERR      SEC_ERR_BASE + 5
#define SEC_BCDTOASCII_ERR      SEC_ERR_BASE + 6
#define SEC_BUFFER_ERR          SEC_ERR_BASE + 7
#define SEC_UPD_KEY_ERR         SEC_ERR_BASE + 8
#define SEC_MEM_ERR             SEC_ERR_BASE + 9
#define SEC_OPEN_FILE_ERR       SEC_ERR_BASE + 10
#define SEC_READ_FILE_ERR       SEC_ERR_BASE + 11
#define SEC_WRITE_FILE_ERR      SEC_ERR_BASE + 12
#define SEC_MK_SEM_ERR          SEC_ERR_BASE + 13
#define SEC_SEM_OP_ERR          SEC_ERR_BASE + 14
#define SEC_ENV_DEF_ERR         SEC_ERR_BASE + 15
#define SEC_MK_SHM_ERR          SEC_ERR_BASE + 16
#define SEC_SHM_OP_ERR          SEC_ERR_BASE + 17
#define SEC_NOT_INIT_ERR        SEC_ERR_BASE + 18
#define SEC_KEYFILE_DEF_ERR     SEC_ERR_BASE + 19
#define SEC_LOGFILE_DEF_ERR     SEC_ERR_BASE + 20
#define SEC_BIT_DEF_ERR         SEC_ERR_BASE + 21
#define SEC_OS_ERR              SEC_ERR_BASE + 22
#define SEC_NOMMKEY_ERR         SEC_ERR_BASE + 23
#define SEC_ENCRYPT_ERR         SEC_ERR_BASE + 24
#define SEC_DECRYPT_ERR         SEC_ERR_BASE + 25

typedef struct {
    unsigned long   ulKeyIdx;
    unsigned char   cbKey[SEC_3DES_KEY_LEN];
}T_MMKey;

typedef struct {
    unsigned long   ulCount;
    T_MMKey         tMMKey[SEC_MAXKEYLIST_SIZE];
}T_MMKeyList ;

typedef struct
{
    char cKeyFlag;                                               /* ��Կ��־ */
    char filler1;
    char caStartTime[SEC_DATETIME_LEN];                  /* ����Կ��Ч��ʱ�� */
    char filler2;
    char caEndTime[SEC_DATETIME_LEN];                    /* ����Կ���ϵ�ʱ�� */
    char filler3;
    char caOldKey[SEC_DES_KEY_LEN * 2];            /* ����Կ������(�ɼ��ַ�) */
    char filler4;
    char caNewKey[SEC_DES_KEY_LEN * 2];            /* ����Կ������(�ɼ��ַ�) */
}T_KEY_RECORD;
#define T_KEY_RECORD_LEN        sizeof(T_KEY_RECORD_LEN)

typedef struct{  
    char caMMKIdx[SEC_KEYIDX_LEN];
    char filler1;
    char caOrgIdx[SEC_ORGIDX_LEN];                                 /* ������ */
    char filler2;
    T_KEY_RECORD tMacKey;
    char filler3;
    T_KEY_RECORD tPinKey;
    char filler4;
    T_KEY_RECORD tDesKey;          
    char filler5;
}T_ORG_RECORD;

typedef struct{
    char  caOrgKeyCnt[SEC_KEYIDX_LEN];
    char  filler1;
    T_ORG_RECORD tOrgKey[SEC_MAXKEYLIST_SIZE];
}T_ORG_RECLIST ;
    
typedef struct{
    char  caOrgIdx[SEC_ORGIDX_LEN];                                /* ������ */
    long  lDataLen ;                                       /* �������ݵĳ��� */
    char  caData[SEC_MAX_DATA_LEN];                              /* �������� */
} T_DESEncReq;

typedef struct{
    char  cFlag;                                                 /* ��Կ��־ */
    long  lEnDataLen;                                          /* ���ĵĳ��� */
    char  caEnData[SEC_MAX_DATA_LEN*2] ;               /*����������(�ɼ��ַ�)*/
} T_DESEncRep;

typedef struct{
    char  caOrgIdx[SEC_ORGIDX_LEN];                                /* ������ */
    char  cFlag;                                                 /* ��Կ��־ */
    long  lEnDataLen;                                          /* ���ĵĳ��� */
    char  caEnData[SEC_MAX_DATA_LEN*2];                    /* ����(�ɼ��ַ�) */
} T_DESDecReq;

typedef struct{
    long  lDataLen;                                          /*�������ݵĳ���*/
    char  caData[SEC_MAX_DATA_LEN];                               /*�������� */
} T_DESDecRep;

typedef struct{
    long  lDataLen;                                            /* ���ݵĳ��� */
    char  caData[SEC_MAX_DATA_LEN];                        /* Ҫ��ժҪ������ */
} T_GenHashReq;

typedef struct{
    long lHashLen;                                             /* ժҪ�ĳ��� */
    char caHash[SEC_HASH_LEN];                                  /* ������ժҪ*/
}T_GenHashRep;

typedef struct{
    char  caOrgIdx[SEC_ORGIDX_LEN];                                /* ������ */
    long  lDataLen;                                            /* ���ݵĳ��� */
    char  caData[SEC_MAX_DATA_LEN];                       /* Ҫ����MAC������ */
} T_GenMacReq;

typedef struct{
    char  cFlag;                                                 /* ��Կ��־ */
    long  lMacLen;                                              /* MAC�ĳ��� */
    char  caMac[SEC_MAC_LEN*2];                             /* MAC(�ɼ��ַ�) */
}T_GenMacRep;

typedef struct{
    char  caOrgIdx[SEC_ORGIDX_LEN];                                /* ������ */
    char  cFlag;                                                 /* ��Կ��־ */
    long  lMacLen;                                              /* MAC�ĳ��� */
    char  caMac[SEC_MAC_LEN*2];                             /* MAC(�ɼ��ַ�) */
    long  lDataLen;                                         /* MAC���ݵĳ��� */
    char  caData[SEC_MAX_DATA_LEN];                               /* MAC���� */
} T_VryMacReq;

typedef struct{
    char  caOrgIdx[SEC_ORGIDX_LEN];                                /* ������ */
    long  lPinBlockLen;                                /* PIN BLOCK���ݵĳ���*/
    char  caPinBlock[SEC_PINBLK_LEN];                       /* PIN BLOCK���� */
    long  lActNoLen;                                           /*���ʺŵĳ���*/
    char  caActNo[SEC_ACTNO_LEN];                                /*���ʺ���Ϣ*/
} T_GenPinReq;

typedef struct{
    char  cFlag;                                                 /* ��Կ��־ */
    long  lEnPinLen;                                        /* PIN���ĵĳ��� */
    char  caEnPin[SEC_PIN_LEN*2];                   /*������PIN����(�ɼ��ַ�)*/
}T_GenPinRep;

typedef struct{
    char  caOrgIdx[SEC_ORGIDX_LEN];                                /* ������ */
    short nMMKIdx;                                       /* ������Կ�������� */
    char  cKeyUsage;                                           /* ��Կ������ */
    long  lKeyLen;                                             /* ��Կ�ĳ��� */
    char  caKey[SEC_DES_KEY_LEN*2];                 /* ����Կ������(�ɼ��ַ�)*/
    char  caCheckValue[SEC_CHK_VALUE_LEN];            /*��Կ��֤��(�����ַ�) */
    long  lTimeOut;                                /* ����Կ��ʱ��ʱ�䣨�룩 */
}T_ExcKeyReq;

typedef struct{
    char caOrgIdx[SEC_ORGIDX_LEN];                                 /* ������ */
    char cKeyUsage;                                            /* ��Կ����; */
    char cFlag;                                                    /*��Կ��־*/
}T_FetKeyReq;

typedef struct{
    long lKeyLen;                                              /* ��Կ�ĳ��� */
    char caKey[SEC_DES_KEY_LEN*2];                   /* ��Կ������(�ɼ��ַ�) */
    char caCheckValue[SEC_CHK_VALUE_LEN];            /*��Կ����֤��(�ɼ��ַ�)*/
}T_FetKeyRep;

extern int comASCIIToBCD(char* ,int *,int , const char* ,int );
extern int comBCDToASCII(unsigned char* ,int *,
                    const char* ,int ,int ,int );
void DumpShareMem(void);
int Initialize(void);
int DESEncrypt(T_DESEncReq *, T_DESEncRep *);
int DESDecrypt(T_DESDecReq *, T_DESDecRep *);
int GenHash(T_GenHashReq *, T_GenHashRep * );
int GenHashOfFile(char *szFileName, T_GenHashRep * );
int GenMac( T_GenMacReq *, T_GenMacRep *);
int VerifyMac( T_VryMacReq *);
int GenPin( T_GenPinReq *, T_GenPinRep *);
int ExchangeKey( T_ExcKeyReq *);
int FetchKey( T_FetKeyReq *, T_FetKeyRep *);
void GetErrMsg( int iErrCode, char *caErrMsg );
int VerifyMacOfFile( T_VryMacReq *);
int GenMacOfFile( T_GenMacReq *, T_GenMacRep *);
int DBEnc(char *,char *,char *,char *);

#endif
