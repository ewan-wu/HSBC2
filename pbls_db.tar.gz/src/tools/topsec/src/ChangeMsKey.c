/*****************************************************************************/
/*  Shanghai Huateng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2001. All rights reserved.                                 */
/*                                                                           */
/*  File:        ChangeMsKey.c                                               */
/*  Description: change master key of libscubenc.so                          */
/*                                                                           */
/*  Author        Date        Description                                    */
/*  ~~~~~~        ~~~~        ~~~~~~~~~~~                                    */
/*****************************************************************************/
#include "scubenc.h"

int main(void)
{
	int i;
	FILE *fp;
	char caMsKey1[SEC_3DES_KEY_LEN*2+1];
	char caMsKey2[SEC_3DES_KEY_LEN*2+1];
	
	memset(caMsKey1,'\0',sizeof(caMsKey1));
	memset(caMsKey2,'\0',sizeof(caMsKey2));
/*	printf("����������Կ��������������ΧΪ1-9��A-F������Ϊ32���ֽ�\n");
	printf("����һ��");
*/
	printf("Please enter the two sections of master key, 1-9 or A-F, 32bytes\n");
	printf("Section one: ");
	scanf("%s",caMsKey1);
	if(strlen(caMsKey1) != SEC_3DES_KEY_LEN*2 )
	{
		printf("The length of Section error! \n");
/*		printf("�������Ȳ�����Ҫ��\n"); */
		exit(1);
	}
	printf("Section two: ");
/*	printf("��������"); */
	scanf("%s",caMsKey2);
	if(strlen(caMsKey2) != SEC_3DES_KEY_LEN*2 )
	{
		printf("The length of Section error! \n");
/*		printf("�������Ȳ�����Ҫ��\n");*/
		exit(1);
	}
	fp=fopen("mskey.c","w");
	if(fp == NULL)
	{
		printf("Open File Error! \n");
/*		printf("���ļ�����\n");	 */
		exit(1);
	}
	fprintf(fp,"char MASTERKEY1[]=\"%s\";\n",caMsKey1);
	fprintf(fp,"char MASTERKEY2[]=\"%s\";\n",caMsKey2);
	fclose(fp);
	printf("Generating libscubenc.so ...\n");
	system("make");
	unlink("mskey.c");
	exit(0);
}

