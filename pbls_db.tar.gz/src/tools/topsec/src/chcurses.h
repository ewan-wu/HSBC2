#ifndef __ATHENA_CHCURSES_H
#define __ATHENA_CHCURSES_H

#include "curses.h"

/******************************************************************************\
 * One Chinese character consists of [LOW, HIGH]
 *
\******************************************************************************/
#define CCHAR_NORMAL		0x00
#define CCHAR_UNDERLINE     0x01
#define CCHAR_REVERSE		0x02
#define CCHAR_BLINK			0x04
#define CCHAR_DIM			0x08
#define CCHAR_BOLD			0x10
#define CCHAR_HIGHTLIGHT	0x20
#define CCHAR_CHLOW			0x40
#define CCHAR_CHHIGH		0x80

extern void ch_initscr();
extern void ch_endwin();
extern void ch_refresh();
extern void ch_mvprintw(int, int, char*);
extern int ch_ischinese(const char*);
extern void ch_xy_attroff(int, int, unsigned char);
extern void ch_xy_attron(int, int, unsigned char);
extern int ch_xy_isattron(int, int, unsigned char);
extern void ch_xy_set_dispattr(int, int);
extern void ch_xy_clearattr(int x, int y);
extern void ch_attroff(unsigned char);
extern void ch_attron(unsigned char);
extern int ch_isattron( unsigned char);
extern void ch_set_dispattr();
extern void ch_clearattr();
extern int ch_getch();
extern void ch_beep();
extern void ch_move(int, int);
extern void ch_nodelay(int);
extern void ch_setcursor();

extern int g_ch_cursor_x;
extern int g_ch_cursor_y;

#endif

