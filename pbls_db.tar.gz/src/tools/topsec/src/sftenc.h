/*****************************************************************************/
/*                    TOPSecure Software Cryptography Module                 */
/* Copyright (c) 2000 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/
/* FILENAME:     sftenc.h                                                    */
/* DESCRIPTIONS: Header file for communication programs sftenc.c             */
/*****************************************************************************/
/*                            MODIFICATION LOG                               */
/* DATE       PROGRAMMER        DESCRIPTON                                   */
/* 2001-03-12 WANG,YINGZI       Initial Version Creation                     */
/*****************************************************************************/
#ifndef __SEC_ENC_H
#define __SEC_ENC_H

#include "des.h"
#include "des_locl.h"
#include "podd.h"
#include "sk.h"

void des_set_odd_parity(des_cblock (*));
static int check_parity(des_cblock (*));
int des_is_weak_key(des_cblock (*));
int des_set_key(des_cblock (*), des_key_schedule );
int des_key_sched(des_cblock (*), des_key_schedule );
char *des_options();
void des_cbc_encrypt(des_cblock (*), des_cblock (*), 
     long , des_key_schedule , des_cblock (*), int );
void des_ecb_encrypt(des_cblock (*), des_cblock (*),des_key_schedule , int );
short DES_CBC_Encryption(unsigned char *, unsigned char *, 
                        unsigned char keyDES[8], long , unsigned char IV[8]);
short DES_CBC_Decryption(unsigned char *, unsigned char *,
          unsigned char keyDES[8], long , unsigned char IV[8]);
void des_encrypt(DES_LONG *, des_key_schedule , int );
void des_encrypt2(DES_LONG *, des_key_schedule , int );
void des_encrypt3(DES_LONG *,des_key_schedule,
                  des_key_schedule,des_key_schedule);
void des_decrypt3(DES_LONG *, des_key_schedule ,
                  des_key_schedule , des_key_schedule );
void des_ncbc_encrypt(des_cblock (*), des_cblock (*), 
     long , des_key_schedule , des_cblock (*), int );
void des_ede3_cbc_encrypt(des_cblock (*), des_cblock (*), 
     long , des_key_schedule , des_key_schedule ,
     des_key_schedule ,  des_cblock (*), int );
int des_3cbc_encrypt(unsigned char *, unsigned char *, 
       long , unsigned char desKey1[8], unsigned char desKey2[8],
       unsigned char ivec[8], int );
short DES_3CBC_Encryption(unsigned char *, unsigned char *, 
                     unsigned char keyDES[16], long , unsigned char IV[8]);
short DES_3CBC_Decryption(unsigned char *, unsigned char *,
          unsigned char keyDES[16], long , unsigned char IV[8]);
void des_ecb3_encrypt(des_cblock (*), des_cblock (*),
     des_key_schedule , des_key_schedule, des_key_schedule , int );
void des_xwhite_in2out(des_cblock (*), des_cblock (*),  des_cblock (*));
void des_xcbc_encrypt(des_cblock (*), des_cblock (*), 
     long , des_key_schedule , des_cblock (*), 
     des_cblock (*), des_cblock (*), int );
     
#endif
