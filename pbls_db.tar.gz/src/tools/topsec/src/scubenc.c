/*****************************************************************************/
/*  Shanghai Huateng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2001. All rights reserved.                                 */
/*                                                                           */
/*  File:        scubenc.c                                                   */
/*  Description: main source code of libscubenc.so                           */
/*                                                                           */
/*  Author        Date        Description                                    */
/*  ~~~~~~        ~~~~        ~~~~~~~~~~~                                    */
/*  Yang Wubin    7/5/2001    Initial Version Creation                       */
/*  Xu YiFang                                                                */
/*  Wang YingZi   07/19/2001  Modified for integrate with EPR                */
/*****************************************************************************/
#include <sys/stat.h>
#include "scubenc.h"
#include "sha_1.h"
#include "sftenc.h"

static char gInitializeFlag=FALSE;
static int giFlag;
static int gSemKey,gShareMemKey;
static char gszKeyFileName[SEC_MAX_PATH_LEN + 1];
static char gszLogFileName[SEC_MAX_PATH_LEN + 1];           
static char gszMMKeyFileName[SEC_MAX_PATH_LEN + 1];
static char gszBit[SEC_BITDEF_LEN+1];
static FILE *gfpLogFile;
static int gSemID,gShareMemID;
static T_ORG_RECLIST *gpOrgRecList;
static long glLogFileSize ;
static long glSecKeyLstSize ;
static T_MMKeyList gtMMKeyLst ;
static char gbLog = 0 ;
static char gbDebugString = 0;

static int ReadCfgFile(void);
static int LoadOrgFromFile(void);
static int SaveOrgToFile(void);
static int MakeSem(void);
static int SemLock(void);
static int SemUnLock(void);
static int PrepareShareMem(void);
static int GetChkValue(char *caKeyASC, long lKeyLen, 
               unsigned long ulMMKIdx,char *caCheckValue);
static int ChkKeyTimeOut(char cKeyUsage,T_ORG_RECORD *ptOrgRecord);
extern void sftDecByMsKey(char *, char *);
extern void sftEncByMsKey(char *, char *);
static void Log(int iErrCode,int iLineNo);
static int GetKey(char *,T_ORG_RECORD *);
static int UpdateKey(T_ORG_RECORD *);
static  int LoadMMKey(void);
static void DebugString(unsigned char *,long ,char *);
static int UpdateEndTime(time_t *, char *);

/*****************************************************************************/
/* FUNC:   static void Scubenc_1_0_0(void)                                   */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: none                                                              */
/* DESC:   for query version                                                 */
/*****************************************************************************/
static void Scubenc_1_0_1(void)
{
    /* Version 1.0.1 :  */
    return;
}
/*****************************************************************************/
/* FUNC:   int Initialize(void)                                              */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   initialize for secure operation                                   */
/*****************************************************************************/
int Initialize(void)
{
    int iRet;
    
    if(gInitializeFlag == TRUE)      
    {
        return SEC_OK;
    }
        
    iRet = ReadCfgFile();
    if (iRet != SEC_OK)
    {
        Log(iRet,__LINE__);
        return iRet;
    }
    iRet = MakeSem();
    if( iRet != SEC_OK)
    {
        Log(iRet,__LINE__);
        return iRet;
    }
    SemLock();
    iRet = PrepareShareMem();
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet,__LINE__);
        return iRet;
    }
    SemUnLock();       
    
    iRet = LoadMMKey() ;
    if (iRet != SEC_OK )
    {
        Log(iRet,__LINE__);
        return iRet;
    }
    
    gInitializeFlag = TRUE;            
    
    return SEC_OK ;
}
/****************************************************************************/
/* FUNC:   int GenHash(T_GenHashReq *ptGenHashReq,                          */
/*                       T_GenHashRep *ptGenHashRep)                        */
/* INPUT:  ptGenHashReq -- request structrue                                */
/* OUTPUT: ptGenHashRep -- reply structure                                  */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                   */
/* DESC:   Request to generate SHA1 Hash.                                   */
/****************************************************************************/
int GenHash(T_GenHashReq *ptGenHashReq, T_GenHashRep *ptGenHashRep)
{
    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if((ptGenHashReq->lDataLen > SEC_MAX_DATA_LEN) || 
        (ptGenHashRep == NULL) || (ptGenHashReq == NULL))
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptGenHashReq,
            ptGenHashReq->lDataLen+sizeof(long),"GenHash()");
    }
    memset(ptGenHashRep,'\0',sizeof(T_GenHashRep));
    
    SHA_Hash((UCHAR*)ptGenHashReq->caData,(UCHAR*)ptGenHashRep->caHash,
        ptGenHashReq->lDataLen);
    ptGenHashRep->lHashLen=SEC_HASH_LEN;
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int GenHashOfFile(char *szFileName, T_GenHashRep *ptGenHashRep)  */
/* INPUT:  caFileName[] -- point to file path and name                      */
/* OUTPUT: ptGenHashRep -- reply structure                                  */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                   */
/* DESC:   Request to generate SHA1 Hash of file.                           */
/****************************************************************************/
int GenHashOfFile(char *szFileName, T_GenHashRep *ptGenHashRep)
{
    FILE *fp;
    struct stat tFileStat;
    char caBuf[SEC_DATA_BLOCK_LEN];
    size_t nread;
    SHA_CTX  tShaCtx;
    
    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if(ptGenHashRep == NULL)
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if((fp=fopen(szFileName,"rb")) == NULL)
    {
        Log(SEC_OPEN_FILE_ERR,__LINE__);
        return SEC_OPEN_FILE_ERR;
    }
    if(stat(szFileName,&tFileStat) == -1)
    {
        fclose(fp);
        Log(SEC_OPEN_FILE_ERR,__LINE__);
        return SEC_OPEN_FILE_ERR;
    }
    if(tFileStat.st_size == 0)
    {
        memset(ptGenHashRep->caHash,'\0',SEC_HASH_LEN);
        ptGenHashRep->lHashLen=0;
        fclose(fp);
        return SEC_OK;
    }
    SHA1_Init(&tShaCtx);
    while (!feof(fp))
    {
        nread=fread(caBuf,1,SEC_DATA_BLOCK_LEN,fp);
        if(ferror(fp))
        {
            fclose(fp);
            Log(SEC_READ_FILE_ERR,__LINE__);
            return SEC_READ_FILE_ERR;
        }
        SHA1_Update(&tShaCtx,(unsigned char *)caBuf,nread);
    }
    SHA1_Final((UCHAR*)ptGenHashRep->caHash,&tShaCtx);
    ptGenHashRep->lHashLen=SEC_HASH_LEN;
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int ExchangeKey( T_ExcKeyReq *ptExchKeyReq)                      */
/* INPUT:  ptFetchKeyReq -- request structrue                               */
/* OUTPUT: none                                                             */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to exchange a data key value.                            */
/****************************************************************************/
int ExchangeKey( T_ExcKeyReq *ptExchKeyReq)
{
    char caCheckValue[SEC_CHK_VALUE_LEN];
    int iChkValueLen = SEC_CHK_VALUE_LEN;
    unsigned char caIV[8];
    int iRet;
    T_ORG_RECORD    tOrgRecord;        
    char            caTmp[20]; 
    char            caFmt[10];
    time_t tNowTime,tTmpTime ;

    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if (ptExchKeyReq == NULL || 
              ptExchKeyReq->lKeyLen != SEC_DES_KEY_LEN*2)
    {
        Log(SEC_ARGUMENTS_ERR, __LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptExchKeyReq,
            sizeof(T_ExcKeyReq),"ExchangeKey()");
    } 
    memset(caIV,'\0',sizeof(caIV));
    memset(&tOrgRecord,'0',sizeof(tOrgRecord));

    tOrgRecord.tMacKey.filler1 = ',';
    tOrgRecord.tMacKey.filler2 = ',';
    tOrgRecord.tMacKey.filler3 = ',';
    tOrgRecord.tMacKey.filler4 = ',';
    
    tOrgRecord.tPinKey.filler1 = ',';
    tOrgRecord.tPinKey.filler2 = ',';
    tOrgRecord.tPinKey.filler3 = ',';
    tOrgRecord.tPinKey.filler4 = ',';
    
    tOrgRecord.tDesKey.filler1 = ',';
    tOrgRecord.tDesKey.filler2 = ',';
    tOrgRecord.tDesKey.filler3 = ',';
    tOrgRecord.tDesKey.filler4 = ',';
    
    tOrgRecord.filler1 = ',' ;
    tOrgRecord.filler2 = ',' ;
    tOrgRecord.filler3 = ',' ;
    tOrgRecord.filler4 = ',' ;
    tOrgRecord.filler5 = '|' ;

    tOrgRecord.tMacKey.cKeyFlag=SEC_KEY_NULL;
    tOrgRecord.tPinKey.cKeyFlag=SEC_KEY_NULL;
    tOrgRecord.tDesKey.cKeyFlag=SEC_KEY_NULL;
    
    /* Get the new KEY plaintext */
    iRet = GetChkValue (ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen,
                        ptExchKeyReq->nMMKIdx, caCheckValue);
    if (iRet )
    {
        Log(iRet,__LINE__);
        return iRet ;
    }                       
 
    if (memcmp(ptExchKeyReq->caCheckValue, caCheckValue, iChkValueLen) != 0)
    {
        Log(SEC_VERIFY_ERR, __LINE__);
        return SEC_VERIFY_ERR;
    }
        
    /* update the key in share memory */     
    memset(caFmt,0,sizeof(caFmt));
    memset(caTmp,0,sizeof(caTmp));
    sprintf(caFmt,"%%0%dd",SEC_KEYIDX_LEN);
    sprintf(caTmp,caFmt,ptExchKeyReq->nMMKIdx);
    memcpy(tOrgRecord.caOrgIdx ,ptExchKeyReq->caOrgIdx,SEC_ORGIDX_LEN);  
        
    SemLock();
    iRet = GetKey(ptExchKeyReq->caOrgIdx,&tOrgRecord);
    SemUnLock();
    if (iRet && iRet != SEC_NOKEY_ERR )
    {
        Log(iRet,__LINE__);
        return iRet ;   
    }   

    memcpy(tOrgRecord.caMMKIdx,caTmp,SEC_KEYIDX_LEN);

    switch (ptExchKeyReq->cKeyUsage)
    {
        case SEC_MAC_KEY:
            /* update the key value */  
            if (iRet == SEC_NOKEY_ERR || 
                tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NULL ) 
            {
                memcpy(tOrgRecord.tMacKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen); 
                memcpy(tOrgRecord.tMacKey.caOldKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                if ( ptExchKeyReq->lTimeOut == 0 )
                {
                    memcpy(tOrgRecord.tMacKey.caStartTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    memcpy(tOrgRecord.tMacKey.caEndTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    tOrgRecord.tMacKey.cKeyFlag=SEC_KEY_OLD;
                
                }     
                else
                {
                    tNowTime = time(NULL);
                    tTmpTime = tNowTime ;
                    UpdateEndTime(&tTmpTime,tOrgRecord.tMacKey.caStartTime);    
                    tTmpTime = tNowTime + ptExchKeyReq->lTimeOut ;
                    UpdateEndTime(&tTmpTime,
                           tOrgRecord.tMacKey.caEndTime);
                        tOrgRecord.tMacKey.cKeyFlag=SEC_KEY_NEW;  
                }   
                   
            }    
            else
            {
                
                if ( ptExchKeyReq->lTimeOut == 0 )
                {
                    memcpy(tOrgRecord.tMacKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen); 
                    memcpy(tOrgRecord.tMacKey.caOldKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                    memcpy(tOrgRecord.tMacKey.caStartTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    memcpy(tOrgRecord.tMacKey.caEndTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    tOrgRecord.tMacKey.cKeyFlag=SEC_KEY_OLD;
                }     
                else
                {
                    memcpy(tOrgRecord.tMacKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                    tNowTime = time(NULL);
                    tTmpTime = tNowTime ;
                    UpdateEndTime(&tTmpTime,tOrgRecord.tMacKey.caStartTime);    
                    tTmpTime = tNowTime + ptExchKeyReq->lTimeOut ;
                    UpdateEndTime(&tTmpTime,
                       tOrgRecord.tMacKey.caEndTime);
                    tOrgRecord.tMacKey.cKeyFlag=SEC_KEY_NEW;  
                }   
            }   
              
            break;         
        case SEC_PIN_KEY:
            /* update the key value */
            if (iRet == SEC_NOKEY_ERR || 
                tOrgRecord.tPinKey.cKeyFlag == SEC_KEY_NULL ) 
            {
                memcpy(tOrgRecord.tPinKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen); 
                memcpy(tOrgRecord.tPinKey.caOldKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                if ( ptExchKeyReq->lTimeOut == 0 )
                {
                    memcpy(tOrgRecord.tPinKey.caStartTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    memcpy(tOrgRecord.tPinKey.caEndTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    tOrgRecord.tPinKey.cKeyFlag=SEC_KEY_OLD;
                
                }     
                else
                {
                    tNowTime = time(NULL);
                    tTmpTime = tNowTime ;
                    UpdateEndTime(&tTmpTime,tOrgRecord.tPinKey.caStartTime);    
                    tTmpTime = tNowTime + ptExchKeyReq->lTimeOut ;
                    UpdateEndTime(&tTmpTime,
                       tOrgRecord.tPinKey.caEndTime);
                    tOrgRecord.tPinKey.cKeyFlag=SEC_KEY_NEW;  
                }   
                   
            }    
            else
            {
                
                if ( ptExchKeyReq->lTimeOut == 0 )
                {
                    memcpy(tOrgRecord.tPinKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen); 
                    memcpy(tOrgRecord.tPinKey.caOldKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                    memcpy(tOrgRecord.tPinKey.caStartTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    memcpy(tOrgRecord.tPinKey.caEndTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    tOrgRecord.tPinKey.cKeyFlag=SEC_KEY_OLD;
                }     
                else
                {
                    memcpy(tOrgRecord.tPinKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                    tNowTime = time(NULL);
                    tTmpTime = tNowTime ;
                    UpdateEndTime(&tTmpTime,tOrgRecord.tPinKey.caStartTime);    
                    tTmpTime = tNowTime + ptExchKeyReq->lTimeOut ;
                    UpdateEndTime(&tTmpTime,
                       tOrgRecord.tPinKey.caEndTime);
                    tOrgRecord.tPinKey.cKeyFlag=SEC_KEY_NEW;  
                }   
            }   

            break;         
        case SEC_DES_KEY:
            /* update the key value */
            if (iRet == SEC_NOKEY_ERR ||
                 tOrgRecord.tDesKey.cKeyFlag == SEC_KEY_NULL ) 
            {
                memcpy(tOrgRecord.tDesKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen); 
                memcpy(tOrgRecord.tDesKey.caOldKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                if ( ptExchKeyReq->lTimeOut == 0 )
                {
                    memcpy(tOrgRecord.tDesKey.caStartTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    memcpy(tOrgRecord.tDesKey.caEndTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    tOrgRecord.tDesKey.cKeyFlag=SEC_KEY_OLD;
                
                }     
                else
                {
                    tNowTime = time(NULL);
                    tTmpTime = tNowTime ;
                    UpdateEndTime(&tTmpTime,tOrgRecord.tDesKey.caStartTime);    
                    tTmpTime = tNowTime + ptExchKeyReq->lTimeOut ;
                    UpdateEndTime(&tTmpTime,
                       tOrgRecord.tDesKey.caEndTime);
                    tOrgRecord.tDesKey.cKeyFlag=SEC_KEY_NEW;  
                }   
                   
            }    
            else
            {
                
                if ( ptExchKeyReq->lTimeOut == 0 )
                {
                    memcpy(tOrgRecord.tDesKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen); 
                    memcpy(tOrgRecord.tDesKey.caOldKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                    memcpy(tOrgRecord.tDesKey.caStartTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    memcpy(tOrgRecord.tDesKey.caEndTime,SEC_MAX_DATETIME ,
                       SEC_DATETIME_LEN);
                    tOrgRecord.tDesKey.cKeyFlag=SEC_KEY_OLD;
                }     
                else
                {
                    memcpy(tOrgRecord.tDesKey.caNewKey, 
                       ptExchKeyReq->caKey, ptExchKeyReq->lKeyLen);
                    tNowTime = time(NULL);
                    tTmpTime = tNowTime ;
                    UpdateEndTime(&tTmpTime,tOrgRecord.tDesKey.caStartTime);    
                    tTmpTime = tNowTime + ptExchKeyReq->lTimeOut;
                    UpdateEndTime(&tTmpTime,
                       tOrgRecord.tDesKey.caEndTime);
                    tOrgRecord.tDesKey.cKeyFlag=SEC_KEY_NEW;  
                }   
            }   

            break;         
        
        default:
            Log(SEC_ARGUMENTS_ERR, __LINE__);
            return SEC_ARGUMENTS_ERR;
    }
    
    /* Save the change to file */
    SemLock();
    iRet = UpdateKey(&tOrgRecord);
    SemUnLock();
    if (iRet != SEC_OK)
    {
        Log(iRet, __LINE__);
        return iRet;
    }
    
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int FetchKey(T_FetchKeyReq *ptFetchKeyReq,                       */
/*                        T_FetchKeyRep *ptFetchKeyRep)                     */
/* INPUT:  ptFetchKeyReq -- request structrue                               */
/* OUTPUT: ptFetchKeyRep -- reply structure                                 */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                   */
/* DESC:   Request to fetch a data key value.                               */
/****************************************************************************/
int FetchKey(T_FetKeyReq *ptFetKeyReq, T_FetKeyRep *ptFetKeyRep)
{
     int           iRet;
    T_ORG_RECORD  tOrgRecord;     
    char          sMMKIdx[SEC_KEYIDX_LEN+1];
    unsigned long ulMMKIdx ;
    
    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
        
    if (ptFetKeyReq == NULL || ptFetKeyRep == NULL)
    {
        Log(SEC_ARGUMENTS_ERR, __LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptFetKeyReq,
            sizeof(T_FetKeyReq),"FetchKey()");
    }
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    SemLock();
    iRet = GetKey(ptFetKeyReq->caOrgIdx,&tOrgRecord);
    SemUnLock();
    if (iRet )
    {
        Log(iRet, __LINE__);
        return iRet;
    }
        
    ptFetKeyRep->lKeyLen = SEC_DES_KEY_LEN*2;
    switch(ptFetKeyReq->cKeyUsage)
    {
        case SEC_MAC_KEY:
            if (tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NULL )
            {
                Log(SEC_NOKEY_ERR,__LINE__);
                return SEC_NOKEY_ERR;
            }                        
                
            if (ptFetKeyReq->cFlag == SEC_KEY_NEW)
            {
                memcpy(ptFetKeyRep->caKey,
                    tOrgRecord.tMacKey.caNewKey, SEC_DES_KEY_LEN*2);
            }
            else
            {
                memcpy(ptFetKeyRep->caKey,
                    tOrgRecord.tMacKey.caOldKey, SEC_DES_KEY_LEN*2);
            }
            break;   
        case SEC_PIN_KEY:
            if (tOrgRecord.tPinKey.cKeyFlag == SEC_KEY_NULL )
            {
                Log(SEC_NOKEY_ERR,__LINE__);
                return SEC_NOKEY_ERR;
            }                        
            if (ptFetKeyReq->cFlag == SEC_KEY_NEW)
            {
                memcpy(ptFetKeyRep->caKey,
                    tOrgRecord.tPinKey.caNewKey, SEC_DES_KEY_LEN*2);
            }
            else
            {
                memcpy(ptFetKeyRep->caKey,
                    tOrgRecord.tPinKey.caOldKey, SEC_DES_KEY_LEN*2);
            }
            break;    
        case SEC_DES_KEY:
            if (tOrgRecord.tDesKey.cKeyFlag == SEC_KEY_NULL )
            {
                Log(SEC_NOKEY_ERR,__LINE__);
                return SEC_NOKEY_ERR;
            }                        
            if (ptFetKeyReq->cFlag == SEC_KEY_NEW)
            {
                memcpy(ptFetKeyRep->caKey,
                    tOrgRecord.tDesKey.caNewKey, SEC_DES_KEY_LEN*2);
            }
            else
            {
                memcpy(ptFetKeyRep->caKey,
                    tOrgRecord.tDesKey.caOldKey, SEC_DES_KEY_LEN*2);
            }
            break;        
        default: 
            Log(SEC_ARGUMENTS_ERR, __LINE__);
            return SEC_ARGUMENTS_ERR;
    }                
   
    memset(sMMKIdx,0,sizeof(sMMKIdx));
    memcpy(sMMKIdx,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN); 
    ulMMKIdx = atol(sMMKIdx);
    iRet = GetChkValue(ptFetKeyRep->caKey,
                SEC_DES_KEY_LEN*2, ulMMKIdx,ptFetKeyRep->caCheckValue);
    if (iRet != SEC_OK)
    {
        Log(iRet, __LINE__);
        return iRet;
    }      
        
    return SEC_OK;  
}
/****************************************************************************/
/* FUNC:  int GenPin( T_GenPinReq *ptGenPinReq,                             */
/*                       T_GenPinRep *ptGenPinRep)                          */
/* INPUT:  ptGenPinReq -- request structrue                                 */
/* OUTPUT: ptGenPinRep -- reply structure                                   */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to generate pin.                                         */
/****************************************************************************/
int GenPin( T_GenPinReq *ptGenPinReq, T_GenPinRep *ptGenPinRep)
{
    int iRet,i;
    char caPinBlock[SEC_PINBLK_LEN];
    char caActNo[SEC_ACTNO_LEN];
    char caPin[SEC_PIN_LEN];
    char caTmp[SEC_PIN_LEN*2];
    int  iTmpLen ;
    char caKeyASC[SEC_DES_KEY_LEN*2];
    char caKeyBCD[SEC_DES_KEY_LEN];
    char caKeyPlain[SEC_DES_KEY_LEN];
    char caEncPin[SEC_PIN_LEN];
    char caIV[8];
    int iKeyLen, iPinLen;                   
    T_ORG_RECORD  tOrgRecord;     
    unsigned long   ulMMKIdx;

    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if (ptGenPinReq == NULL || ptGenPinRep == NULL ||
        ptGenPinReq->lActNoLen < SEC_ACTNO_DEFLEN ||
        ptGenPinReq->lActNoLen > SEC_ACTNO_LEN)
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptGenPinReq,
            sizeof(T_GenPinReq),"GenPin()");
    }
    memset(ptGenPinRep,'\0',sizeof(T_GenPinRep));
    memset(caPinBlock,'\xff',sizeof(caPinBlock));
    if(ptGenPinReq->lPinBlockLen+2 > SEC_PINBLK_LEN)
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    
    caPinBlock[0] = ptGenPinReq->lPinBlockLen * 2 ;
    memcpy(caPinBlock + 1,ptGenPinReq->caPinBlock,ptGenPinReq->lPinBlockLen);
    
    memcpy(caActNo,
      ptGenPinReq->caActNo + ptGenPinReq->lActNoLen - SEC_ACTNO_DEFLEN - 1,
      SEC_ACTNO_DEFLEN);
    
    iTmpLen = SEC_ACTNO_DEFLEN;
    iRet = comASCIIToBCD (caTmp,&iTmpLen,0,
                          caActNo ,
                          SEC_ACTNO_DEFLEN);
    if (iRet != SEC_OK)
    {
        Log(iRet,__LINE__);
        return iRet;
    }                      
    
    if (iTmpLen > SEC_PIN_LEN )
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR ;
    }
    
    memset(caActNo, '\0', sizeof(caActNo));
    memcpy(caActNo + 2, caTmp, iTmpLen);
    
    for ( i= 0 ;i < SEC_PIN_LEN ; i++)
    {
        caPin[i] = caActNo[i] ^ caPinBlock [i];
    }
    
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    SemLock();
    iRet = GetKey(ptGenPinReq->caOrgIdx,&tOrgRecord);
    if (iRet )
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
        
    if (tOrgRecord.tPinKey.cKeyFlag == SEC_KEY_NULL )
    {
        SemUnLock();
        Log(SEC_NOKEY_ERR, __LINE__);
        return SEC_NOKEY_ERR ;  
    }   
    
    iRet = ChkKeyTimeOut(SEC_PIN_KEY,&tOrgRecord);
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    SemUnLock();
    
    ptGenPinRep->cFlag = tOrgRecord.tPinKey.cKeyFlag;
    if (tOrgRecord.tPinKey.cKeyFlag == SEC_KEY_NEW)
    {
        memcpy(caKeyASC, tOrgRecord.tPinKey.caNewKey, 
            SEC_DES_KEY_LEN*2);
    }else
    {
        memcpy(caKeyASC, tOrgRecord.tPinKey.caOldKey, 
            SEC_DES_KEY_LEN*2);
    }
 
    iKeyLen = SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
                   caKeyASC, SEC_DES_KEY_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memset(caTmp,0,sizeof(caTmp));
    memcpy(caTmp,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN);
    ulMMKIdx = atol(caTmp);    
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caKeyPlain,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV, '\0', sizeof(caIV));    
    /* encrypt the caPin */
    iRet = DES_CBC_Encryption((UCHAR*)caPin,(UCHAR*)caEncPin, 
                       (UCHAR*)caKeyPlain, SEC_PIN_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }
                               
    iPinLen = SEC_PIN_LEN*2;
    iRet = comBCDToASCII((UCHAR*)ptGenPinRep->caEnPin, &iPinLen,
                         caEncPin, SEC_PIN_LEN,
                         SEC_PIN_LEN*2, 1);
    if (iRet != SEC_OK)
    {
        Log(SEC_BCDTOASCII_ERR, __LINE__);
        return SEC_BCDTOASCII_ERR;
    }
    ptGenPinRep->lEnPinLen = (long)iPinLen;
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int GenMac( T_GenMacReq *ptGenMacReq,                            */
/*                       T_GenMacRep *ptGenMacRep)                          */
/* INPUT:  ptGenMacReq -- request structrue                                 */
/* OUTPUT: ptGenMacRep -- reply structure                                   */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to generate MAC.                                         */
/****************************************************************************/
int GenMac( T_GenMacReq *ptGenMacReq, T_GenMacRep *ptGenMacRep)
{
    int  iRet, iKeyLen, iMacLen,i;
    char caKeyASC[SEC_DES_KEY_LEN*2];
    char caKeyBCD[SEC_DES_KEY_LEN];
    char caMacKey[SEC_DES_KEY_LEN];
    char caIV[8];
    char caData[SEC_MAX_DATA_LEN];
    long lDataLen;
    char caEncData[SEC_MAX_DATA_LEN];
    char caMac[SEC_MAC_LEN];
    T_ORG_RECORD  tOrgRecord;     
    unsigned long   ulMMKIdx;
    char            caTmp[16]; 
    T_GenHashReq    tGenHashReq;
    T_GenHashRep    tGenHashRep;
        
    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if (ptGenMacReq == NULL || ptGenMacRep == NULL  )
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(ptGenMacReq->lDataLen > SEC_MAX_DATA_LEN)
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptGenMacReq,
            ptGenMacReq->lDataLen+12,"GenMac()");
    }

    memset(&tGenHashReq,0,sizeof(tGenHashReq));
    memset(&tGenHashRep,0,sizeof(tGenHashRep));
    
    memcpy(tGenHashReq.caData,ptGenMacReq->caData,ptGenMacReq->lDataLen);
    tGenHashReq.lDataLen = ptGenMacReq->lDataLen;    
    iRet = GenHash(&tGenHashReq,&tGenHashRep);
    if (iRet)
    {
        Log(iRet,__LINE__);
        return iRet;
    }   
    memset(ptGenMacRep,'\0',sizeof(T_GenMacRep));
    
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    /* Get the Mac Key from share memory */
    SemLock();
    iRet = GetKey(ptGenMacReq->caOrgIdx,&tOrgRecord);
    if (iRet )
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    if (tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NULL )
    {
        SemUnLock();
        Log(SEC_NOKEY_ERR, __LINE__);
        return SEC_NOKEY_ERR ;  
    }           
    iRet = ChkKeyTimeOut(SEC_MAC_KEY,&tOrgRecord);
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    SemUnLock();
    
    ptGenMacRep->cFlag = tOrgRecord.tMacKey.cKeyFlag;
    /* get the MAC Key's plaintext */
    if (tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NEW)
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caNewKey, 
            SEC_DES_KEY_LEN*2);
    }else
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caOldKey, 
            SEC_DES_KEY_LEN*2);
    }
    
    iKeyLen = SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
                   caKeyASC, SEC_DES_KEY_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memset(caTmp,0,sizeof(caTmp));
    memcpy(caTmp,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN);
    ulMMKIdx = atol(caTmp);    
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caMacKey,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV, '\0', sizeof(caIV));    
    memset(caData, '\0', sizeof(caData));
    /* encrypt the Data */
    memcpy(caData, tGenHashRep.caHash, tGenHashRep.lHashLen);
    lDataLen = tGenHashRep.lHashLen;
    if (lDataLen % 8)
    {
        lDataLen += 8 - lDataLen % 8;
    }

    iRet = DES_CBC_Encryption((UCHAR*)caData,(UCHAR*)caEncData,
        (UCHAR*)caMacKey,lDataLen,(UCHAR*)caIV);               
    if (iRet )
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }       

    memcpy(caMac,caEncData + lDataLen - 8 ,SEC_MAC_LEN);
    iMacLen = SEC_MAC_LEN*2;
    iRet = comBCDToASCII((UCHAR*)ptGenMacRep->caMac, &iMacLen,
                         caMac, SEC_MAC_LEN,
                         SEC_MAC_LEN*2, 1);
    if (iRet != SEC_OK)
    {
        Log(SEC_BCDTOASCII_ERR, __LINE__);
        return SEC_BCDTOASCII_ERR;
    }
    ptGenMacRep->lMacLen = (long)iMacLen;
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:    int VerifyMac( T_VryMacReq *ptVryMacReq)                        */
/* INPUT:  ptVryMacReq -- request structrue                                 */
/* OUTPUT: none                                                             */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to verify MAC.                                           */
/****************************************************************************/
int VerifyMac( T_VryMacReq *ptVryMacReq)
{
    char caKeyASC[SEC_DES_KEY_LEN*2];
    char caKeyBCD[SEC_DES_KEY_LEN];
    char caMacKey[SEC_DES_KEY_LEN];
    char caData[SEC_MAX_DATA_LEN];
    char caEncData[SEC_MAX_DATA_LEN];
    char caMacBCD[SEC_MAC_LEN],caMacBCDTmp[SEC_MAC_LEN];
    char caIV[8];
    long lDataLen;
    int iRet, iKeyLen, iMacLen,i;
    T_ORG_RECORD    tOrgRecord;     
    unsigned long   ulMMKIdx;
    char            caTmp[16]; 
    T_GenHashReq    tGenHashReq;
    T_GenHashRep    tGenHashRep;

    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if (ptVryMacReq == NULL || 
        ptVryMacReq->lDataLen > SEC_MAX_DATA_LEN ||
        ptVryMacReq->lMacLen != SEC_MAC_LEN*2)
    {
        Log(SEC_ARGUMENTS_ERR, __LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptVryMacReq,
            ptVryMacReq->lDataLen+30,"VerifyMac()");
    }
    
    memset(&tGenHashReq,0,sizeof(tGenHashReq));
    memset(&tGenHashRep,0,sizeof(tGenHashRep));
    
    memcpy(tGenHashReq.caData,ptVryMacReq->caData,ptVryMacReq->lDataLen);
    tGenHashReq.lDataLen = ptVryMacReq->lDataLen;    
    iRet = GenHash(&tGenHashReq,&tGenHashRep);
    if (iRet)
    {
        Log(iRet,__LINE__);
        return iRet;
    }   
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    /* Get the Mac Key from share memory */
    SemLock();
    iRet = GetKey(ptVryMacReq->caOrgIdx,&tOrgRecord);
    if (iRet )
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
        
    if (tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NULL )
    {
        SemUnLock();
        Log(SEC_NOKEY_ERR, __LINE__);
        return SEC_NOKEY_ERR ;  
    }   

    iRet = ChkKeyTimeOut(SEC_MAC_KEY,&tOrgRecord);
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    SemUnLock();
    
    /* get the MAC Key's plaintext */
    if (ptVryMacReq->cFlag == SEC_KEY_NEW)
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caNewKey, 
            SEC_DES_KEY_LEN*2);
    }else
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caOldKey, 
            SEC_DES_KEY_LEN*2);
    }

    iKeyLen = SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
                   caKeyASC, SEC_DES_KEY_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memset(caTmp,0,sizeof(caTmp));
    memcpy(caTmp,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN);
    ulMMKIdx = atol(caTmp);    
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caMacKey,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV, '\0', sizeof(caIV));  
    memset(caData, '\0', sizeof(caData));  
    /* encrypt the Data */
    memcpy(caData, tGenHashRep.caHash, tGenHashRep.lHashLen);
    lDataLen = tGenHashRep.lHashLen;
    if (lDataLen % 8)
    {
        lDataLen += 8 - lDataLen % 8;
    }

    iRet = DES_CBC_Encryption((UCHAR*)caData,(UCHAR*)caEncData,
        (UCHAR*)caMacKey,lDataLen,(UCHAR*)caIV);
    if (iRet )
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }       

    iMacLen = SEC_MAC_LEN;
    iRet = comASCIIToBCD(caMacBCD, &iMacLen, 1,
                   ptVryMacReq->caMac, SEC_MAC_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memcpy(caMacBCDTmp,caEncData + lDataLen - 8,SEC_MAC_LEN);
    if (memcmp(caMacBCDTmp, caMacBCD, SEC_MAC_LEN))
    {
        Log(SEC_VERIFY_ERR, __LINE__);
        return SEC_VERIFY_ERR;
    }
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int GenMacOfFile( T_GenMacReq *ptGenMacReq,                      */
/*                       T_GenMacRep *ptGenMacRep)                          */
/* INPUT:  ptGenMacReq -- request structrue                                 */
/* OUTPUT: ptGenMacRep -- reply structure                                   */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to generate MAC of a file.                               */
/****************************************************************************/
int GenMacOfFile( T_GenMacReq *ptGenMacReq, T_GenMacRep *ptGenMacRep)
{
    int  iRet, iKeyLen, iMacLen,i;
    char caKeyASC[SEC_DES_KEY_LEN*2];
    char caKeyBCD[SEC_DES_KEY_LEN];
    char caMacKey[SEC_DES_KEY_LEN];
    char caIV[8];
    char caData[SEC_MAX_DATA_LEN];
    long lDataLen;
    char caEncData[SEC_MAX_DATA_LEN];        
    char szFileName[500];
    char caMac[SEC_MAC_LEN];
    T_ORG_RECORD    tOrgRecord;     
    unsigned long   ulMMKIdx;
    char            caTmp[16]; 
    T_GenHashReq    tGenHashReq;
    T_GenHashRep    tGenHashRep;
        
    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if (ptGenMacReq == NULL || ptGenMacRep == NULL  )
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(ptGenMacReq->lDataLen > SEC_MAX_PATH_LEN)
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptGenMacReq,
            ptGenMacReq->lDataLen+12,"GenMacOfFile()");
    }

    memset(&tGenHashRep,0,sizeof(tGenHashRep));
    
    memset(szFileName,0,sizeof(szFileName));
    memcpy(szFileName,ptGenMacReq->caData,ptGenMacReq->lDataLen);
    memcpy(tGenHashReq.caData,ptGenMacReq->caData,ptGenMacReq->lDataLen);
    iRet = GenHashOfFile(szFileName,&tGenHashRep);
    if (iRet)
    {
        Log(iRet,__LINE__);
        return iRet;
    }   
    memset(ptGenMacRep,'\0',sizeof(T_GenMacRep));
    
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    /* Get the Mac Key from share memory */
    SemLock();
    iRet = GetKey(ptGenMacReq->caOrgIdx,&tOrgRecord);
    if (iRet )
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }  
    
    if (tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NULL )
    {
        SemUnLock();
        Log(SEC_NOKEY_ERR, __LINE__);
        return SEC_NOKEY_ERR ;  
    }   

    iRet = ChkKeyTimeOut(SEC_MAC_KEY,&tOrgRecord);
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    SemUnLock();
    
    ptGenMacRep->cFlag = tOrgRecord.tMacKey.cKeyFlag;
    /* get the MAC Key's plaintext */
    if (tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NEW)
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caNewKey, 
            SEC_DES_KEY_LEN*2);
    }else
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caOldKey, 
            SEC_DES_KEY_LEN*2);
    }
    
    iKeyLen = SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
                   caKeyASC, SEC_DES_KEY_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memset(caTmp,0,sizeof(caTmp));
    memcpy(caTmp,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN);
    ulMMKIdx = atol(caTmp);    
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caMacKey,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV, '\0', sizeof(caIV));    
    memset(caData, '\0', sizeof(caData));
    /* encrypt the Data */
    memcpy(caData, tGenHashRep.caHash, tGenHashRep.lHashLen);
    lDataLen = tGenHashRep.lHashLen;
    if (lDataLen % 8)
    {
        lDataLen += 8 - lDataLen % 8;
    }

    iRet = DES_CBC_Encryption((UCHAR*)caData,(UCHAR*)caEncData,
        (UCHAR*)caMacKey,lDataLen,(UCHAR*)caIV);               
    if (iRet )
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }       

    memcpy(caMac,caEncData + lDataLen - 8 ,SEC_MAC_LEN);
    iMacLen = SEC_MAC_LEN*2;
    iRet = comBCDToASCII((UCHAR*)ptGenMacRep->caMac, &iMacLen,
                         caMac, SEC_MAC_LEN,
                         SEC_MAC_LEN*2, 1);
    if (iRet != SEC_OK)
    {
        Log(SEC_BCDTOASCII_ERR, __LINE__);
        return SEC_BCDTOASCII_ERR;
    }
    ptGenMacRep->lMacLen = (long)iMacLen;
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int VerifyMacOfFile( T_VryMacReq *ptVryMacReq)                   */
/* INPUT:  ptVryMacReq -- request structrue                                 */
/* OUTPUT: none                                                             */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to verify MAC of a file .                                */
/****************************************************************************/
int VerifyMacOfFile( T_VryMacReq *ptVryMacReq)
{
    char caKeyASC[SEC_DES_KEY_LEN*2];
    char caKeyBCD[SEC_DES_KEY_LEN];
    char caMacKey[SEC_DES_KEY_LEN];
    char caData[SEC_MAX_DATA_LEN];
    char caEncData[SEC_MAX_DATA_LEN];
    char caMacBCD[SEC_MAC_LEN],caMacBCDTmp[SEC_MAC_LEN];
    char caIV[8];
    long lDataLen;
    int iRet, iKeyLen, iMacLen,i;
    T_ORG_RECORD    tOrgRecord;     
    unsigned long   ulMMKIdx;
    char            caTmp[16]; 
    char            szFileName[500];
    T_GenHashRep    tGenHashRep;

    if(gInitializeFlag == FALSE)
        return SEC_NOT_INIT_ERR;
    if (ptVryMacReq == NULL || 
        ptVryMacReq->lDataLen > SEC_MAX_DATA_LEN ||
        ptVryMacReq->lMacLen != SEC_MAC_LEN*2)
    {
        Log(SEC_ARGUMENTS_ERR, __LINE__);
        return SEC_ARGUMENTS_ERR;
    }
        
    memset(&tGenHashRep,0,sizeof(tGenHashRep));
    
    memset(szFileName,0,sizeof(szFileName));
    memcpy(szFileName,ptVryMacReq->caData,ptVryMacReq->lDataLen);
    iRet = GenHashOfFile(szFileName,&tGenHashRep);
    if (iRet)
    {
        Log(iRet,__LINE__);
        return iRet;
    }   
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    /* Get the Mac Key from share memory */
    SemLock();
    iRet = GetKey(ptVryMacReq->caOrgIdx,&tOrgRecord);
    if (iRet )
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
        
    if (tOrgRecord.tMacKey.cKeyFlag == SEC_KEY_NULL )
    {
        SemUnLock();
        Log(SEC_NOKEY_ERR, __LINE__);
        return SEC_NOKEY_ERR ;  
    }   

    iRet = ChkKeyTimeOut(SEC_MAC_KEY,&tOrgRecord);
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    SemUnLock();
    
    /* get the MAC Key's plaintext */

    if (ptVryMacReq->cFlag == SEC_KEY_NEW)
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caNewKey, 
            SEC_DES_KEY_LEN*2);
    }else
    {
        memcpy(caKeyASC, tOrgRecord.tMacKey.caOldKey, 
            SEC_DES_KEY_LEN*2);
    }

    iKeyLen = SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
                   caKeyASC, SEC_DES_KEY_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memset(caTmp,0,sizeof(caTmp));
    memcpy(caTmp,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN);
    ulMMKIdx = atol(caTmp);    
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caMacKey,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV, '\0', sizeof(caIV));  
    memset(caData, '\0', sizeof(caData));  
    /* encrypt the Data */
    memcpy(caData, tGenHashRep.caHash, tGenHashRep.lHashLen);
    lDataLen = tGenHashRep.lHashLen;
    if (lDataLen % 8)
    {
        lDataLen += 8 - lDataLen % 8;
    }

    iRet = DES_CBC_Encryption((UCHAR*)caData,(UCHAR*)caEncData,
        (UCHAR*)caMacKey,lDataLen,(UCHAR*)caIV);
    if (iRet )
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }       

    iMacLen = SEC_MAC_LEN;
    iRet = comASCIIToBCD(caMacBCD, &iMacLen, 1,
                   ptVryMacReq->caMac, SEC_MAC_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memcpy(caMacBCDTmp,caEncData + lDataLen - 8,SEC_MAC_LEN);
    if (memcmp(caMacBCDTmp, caMacBCD, SEC_MAC_LEN))
    {
        Log(SEC_VERIFY_ERR, __LINE__);
        return SEC_VERIFY_ERR;
    }
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int DESEncrypt(T_DESEncReq *ptDESEncReq,                         */
/*                       T_DESEncRep *ptDESEncRep)                          */
/* INPUT:  ptDESEncReq -- request structrue                                 */
/* OUTPUT: ptDESEncRep -- reply structure                                   */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to encrypt data.                                         */
/****************************************************************************/
int DESEncrypt(T_DESEncReq *ptDESEncReq, T_DESEncRep *ptDESEncRep)
{
    int iRet,i;
    char caKeyASC[SEC_DES_KEY_LEN*2];
    char caKeyBCD[SEC_DES_KEY_LEN*2];
    char caDesKey[SEC_DES_KEY_LEN];
    char caData[SEC_MAX_DATA_LEN];
    char caEncData[SEC_MAX_DATA_LEN*2];
    char caIV[8];
    int  iKeyLen, iEnDataLen, iVerCodeLen;
    long lDataLen;
    T_ORG_RECORD    tOrgRecord;     
    unsigned long   ulMMKIdx;
    char            caTmp[16]; 
    
    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if (ptDESEncReq == NULL || ptDESEncRep == NULL ||
        ptDESEncReq->lDataLen > SEC_MAX_DATA_LEN)
    {
        Log(SEC_ARGUMENTS_ERR, __LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptDESEncReq,
            ptDESEncReq->lDataLen+12,"DESEncrypt()");
    }
    memset(ptDESEncRep, '\0', sizeof(T_DESEncRep));
    /* Get the DES key from Share Memory*/
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    /* Get the Mac Key from share memory */
    SemLock();
    iRet = GetKey(ptDESEncReq->caOrgIdx,&tOrgRecord);
    if (iRet )
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
        
     if (tOrgRecord.tDesKey.cKeyFlag == SEC_KEY_NULL )
    {
        SemUnLock();
        Log(SEC_NOKEY_ERR, __LINE__);
        return SEC_NOKEY_ERR ;  
    }   

   iRet = ChkKeyTimeOut(SEC_MAC_KEY,&tOrgRecord);
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    SemUnLock();
    
    if (tOrgRecord.tDesKey.cKeyFlag == SEC_KEY_NEW)
    {
        memcpy(caKeyASC, tOrgRecord.tDesKey.caNewKey, 
            SEC_DES_KEY_LEN*2);
    }else
    {
        memcpy(caKeyASC, tOrgRecord.tDesKey.caOldKey, 
            SEC_DES_KEY_LEN*2);
    }
    ptDESEncRep->cFlag = tOrgRecord.tDesKey.cKeyFlag;

    iKeyLen = SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
                   caKeyASC, SEC_DES_KEY_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memset(caTmp,0,sizeof(caTmp));
    memcpy(caTmp,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN);
    ulMMKIdx = atol(caTmp);    
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caDesKey,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV, '\0', sizeof(caIV));  
    memset(caData, '\0', sizeof(caData));  
    /* Fill the source data */
    memcpy(caData,ptDESEncReq->caData,ptDESEncReq->lDataLen);
    iVerCodeLen=ptDESEncReq->lDataLen%8;
    iVerCodeLen=8-iVerCodeLen;
    for(i=0;i<iVerCodeLen;i++)
    {
        caData[ptDESEncReq->lDataLen+i]=iVerCodeLen;
    }
    lDataLen = ptDESEncReq->lDataLen + iVerCodeLen;

    /* encrypt the Data */
    iRet = DES_CBC_Encryption((UCHAR*)caData,(UCHAR*)caEncData,
        (UCHAR*)caDesKey,lDataLen,(UCHAR*)caIV);
    if (iRet )
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }
        
    iEnDataLen = lDataLen*2;
    iRet = comBCDToASCII((UCHAR*)ptDESEncRep->caEnData, &iEnDataLen,
                         caEncData, lDataLen,
                         lDataLen*2, 1);
    if (iRet != SEC_OK)
    {
        Log(SEC_BCDTOASCII_ERR, __LINE__);
        return SEC_BCDTOASCII_ERR;
    }
    ptDESEncRep->lEnDataLen = (long)iEnDataLen;
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   int DESDecrypt(T_DESDecReq *ptDESDecReq,                         */
/*                       T_DESDecRep *ptDESDecRep)                          */
/* INPUT:  ptDESDecReq -- request structrue                                 */
/* OUTPUT: ptDESDecRep -- reply structure                                   */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Request to decrypt data.                                         */
/****************************************************************************/
int DESDecrypt(T_DESDecReq *ptDESDecReq, T_DESDecRep *ptDESDecRep)
{
    char caKeyASC[SEC_DES_KEY_LEN*2];
    char caKeyBCD[SEC_DES_KEY_LEN];
    char caDesKey[SEC_DES_KEY_LEN];
    char caEnDataBCD[SEC_MAX_DATA_LEN];
    char caOutData[SEC_MAX_DATA_LEN];
    int  iKeyLen, iRet,i; 
    int  iEnDataLen,iVerCodeLen;
    char caIV[8];
    T_ORG_RECORD    tOrgRecord;     
    unsigned long   ulMMKIdx;
    char            caTmp[16]; 
    
        
    if(gInitializeFlag == FALSE)
    {
        Log(SEC_NOT_INIT_ERR,__LINE__);
        return SEC_NOT_INIT_ERR;
    }
    if (ptDESDecReq == NULL || ptDESDecRep == NULL ||
        ptDESDecReq->lEnDataLen > SEC_MAX_DATA_LEN*2)
    {
        Log(SEC_ARGUMENTS_ERR, __LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    if(gbDebugString)
    {
        DebugString((unsigned char*)ptDESDecReq,
            ptDESDecReq->lEnDataLen+14,"DESDecrypt()");
    }
    memset(ptDESDecRep, '\0', sizeof(T_DESDecRep));
    /* Get the DES Key from share memory*/
    memset(&tOrgRecord,0,sizeof(tOrgRecord));
    /* Get the Mac Key from share memory */
    SemLock();
    iRet = GetKey(ptDESDecReq->caOrgIdx,&tOrgRecord);
    if (iRet )
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
        
    if (tOrgRecord.tDesKey.cKeyFlag == SEC_KEY_NULL )
    {
        SemUnLock();
        Log(SEC_NOKEY_ERR, __LINE__);
        return SEC_NOKEY_ERR ;  
    }   

   iRet = ChkKeyTimeOut(SEC_MAC_KEY,&tOrgRecord);
    if (iRet != SEC_OK)
    {
        SemUnLock();
        Log(iRet, __LINE__);
        return iRet;
    }
    SemUnLock();

    if (ptDESDecReq->cFlag == SEC_KEY_NEW)
    {
        memcpy(caKeyASC, tOrgRecord.tDesKey.caNewKey, 
            SEC_DES_KEY_LEN*2);
    }else
    {
        memcpy(caKeyASC, tOrgRecord.tDesKey.caOldKey, 
            SEC_DES_KEY_LEN*2);
    }

    iKeyLen = SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
        caKeyASC, SEC_DES_KEY_LEN*2);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    memset(caTmp,0,sizeof(caTmp));
    memcpy(caTmp,tOrgRecord.caMMKIdx,SEC_KEYIDX_LEN);
    ulMMKIdx = atol(caTmp);    
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caDesKey,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV, '\0', sizeof(caIV));
    memset(caEnDataBCD, '\0', sizeof(caEnDataBCD));
    iEnDataLen = (ptDESDecReq->lEnDataLen) / 2;
    iRet = comASCIIToBCD(caEnDataBCD,&iEnDataLen, 1,
        ptDESDecReq->caEnData, ptDESDecReq->lEnDataLen);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR, __LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    
    iRet = DES_CBC_Decryption((UCHAR*)caEnDataBCD,(UCHAR*)caOutData,
        (UCHAR*)caDesKey,(long)iEnDataLen,(UCHAR*)caIV);
    if (iRet )
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR ;
    }
                
    iVerCodeLen=caOutData[iEnDataLen-1];
    if((iVerCodeLen < 1) || (iVerCodeLen > 8))
    {
        Log(SEC_VERIFY_ERR,__LINE__);
        return SEC_VERIFY_ERR;
    }
    for(i=1;i<=iVerCodeLen;i++)
    {
        if(caOutData[iEnDataLen-i] != iVerCodeLen)
        {
            Log(SEC_VERIFY_ERR, __LINE__);
            return SEC_VERIFY_ERR;
        }
    }
    ptDESDecRep->lDataLen = iEnDataLen-iVerCodeLen;
    memcpy(ptDESDecRep->caData,caOutData,ptDESDecRep->lDataLen);
    return SEC_OK;
}
/****************************************************************************/
/* FUNC:   static void Log(int iErrCode,int iLineNo)                        */
/* INPUT:  iErrCode -- error code                                           */
/*         iLineNo  -- line number                                          */
/* OUTPUT: none                                                             */
/* RETURN: none                                                             */
/* DESC:   error log.                                                       */
/****************************************************************************/
static void Log(int iErrCode,int iLineNo)
{
    char caErrMsg[SEC_MAX_ERR_MSG_LEN];
    char caTime[100];
    time_t       tNowTime;
    struct tm    *ptm;
    size_t       len;
    struct stat  tFileStat ;
    FILE         *fpLogFile;
    int          iFileId ;
    
    if (!gbLog)
    {
        return ;
    }
    
    if((iFileId=open(gszLogFileName ,O_RDONLY)) == -1)
    {
        tFileStat.st_size = 0;
    }
    else
    {
        if(fstat(iFileId,&tFileStat) == -1)
        {
            close(iFileId);
            return ;
        }
        close(iFileId);
    }   

    if ((tFileStat.st_size >= 0) && (tFileStat.st_size <= glLogFileSize) )
    {
        if( NULL == ( fpLogFile = fopen(gszLogFileName, "a") ) )
        {
            return;
        }
    }
    else
    {
        if( NULL == ( fpLogFile = fopen(gszLogFileName, "w+") ) )
        {
            return;
        }
    }

    tNowTime=time(NULL);
    ptm=localtime(&tNowTime);
    len=strftime(caTime,100,"%c",ptm);
    
    GetErrMsg(iErrCode,caErrMsg);
    if (errno)
    {
           fprintf(fpLogFile,
                  "%s || LINE = %d || ErrCode = %d || ErrMsg : %s[syserr:%s]\n",
                   caTime,iLineNo,iErrCode,caErrMsg,strerror(errno));
           errno=0;
    }
    else
    {
           fprintf(fpLogFile,
                   "%s || LINE = %d || ErrCode = %d || ErrMsg : %s\n",
                    caTime,iLineNo,iErrCode,caErrMsg);
   }        
   fclose(fpLogFile);       
}
/*****************************************************************************/
/* FUNC:   static void DebugString(unsigned char *caBuf,long lBufLen)        */
/* INPUT:  caBuf -- buffer which is printed to log file                      */
/*         lBufLen -- buffer length                                          */
/*         szDesc -- descript which function call DebugString()              */
/* OUTPUT: none                                                              */
/* RETURN: none                                                              */
/* DESC:   print buffer contents to log file using HEX code                  */
/*****************************************************************************/
static void DebugString(unsigned char *caBuf,long lBufLen,char *szDesc)
{
    FILE *fpLogFile;
    int i, j=0;
    char s[100], temp[10];
    char buf1[8000] ;
    char szTime[20];
    time_t       tNowTime;
    struct tm    *ptm;

    if( NULL == ( fpLogFile = fopen(gszLogFileName, "a") ) )
    {
        return;
    }
    if(lBufLen > 8000)
    {
        fclose(fpLogFile);
        return;
    }
    memset(szTime,'\0', sizeof(szTime));
    memcpy( buf1, caBuf, lBufLen);
    
    tNowTime=time(NULL);
    ptm=localtime(&tNowTime);
    strftime(szTime,100,"%c",ptm);

    fprintf(fpLogFile, "<<***** [%s]Debug Info(len=%d) From %s: *****>>\n", 
        szTime, lBufLen,szDesc);

    for( i=0; i<lBufLen; i++)
    {
        if ( j==0)
        {
            memset( s, ' ', 84);
            sprintf(temp,"%04X ",i );
            memcpy( s, temp, 5);
        }
        sprintf( temp, "%02X ", (unsigned char)buf1[i]);
        memcpy( &s[j*3+5+(j>7)], temp, 3);
        if ( isprint( buf1[i]))
        {
            s[j+55+(j>7)]=buf1[i];
        }
        else
        {
            if (buf1[i] == 0)
                s[j+55+(j>7)]=' ';
            else
                s[j+55+(j>7)]='.';
        }
        j++;
        if ( j==16)
        {
            s[76]=0;
            fprintf( fpLogFile, "%s\n", s);
            j=0;
        }
    }
    if ( j)
    {
        s[76]=0;
        fprintf( fpLogFile, "%s\n", s);
    }

    fflush(fpLogFile);
    fclose(fpLogFile);
}    
/****************************************************************************/
/* FUNC:   void GetErrMsg( int iErrCode, char *caErrMsg )                   */
/* INPUT:  iErrCode -- error code                                           */
/* OUTPUT: caErrMsg -- error message                                        */
/* RETURN: none                                                             */
/* DESC:   get error message.                                               */
/****************************************************************************/
void GetErrMsg( int iErrCode, char *caErrMsg )
{
    if(caErrMsg == NULL)
        return;
    switch(iErrCode)
    {
        case SEC_OK:
            strcpy(caErrMsg,"Operation successful!");
            break;
        case SEC_ARGUMENTS_ERR:
            strcpy(caErrMsg,"Invalid arguments!");
            break;
        case SEC_KEY_EXIST_ERR:
            strcpy(caErrMsg,"Key already exits!");
            break;
        case SEC_VERIFY_ERR:
            strcpy(caErrMsg,"Verify fail!");
            break;
        case SEC_NOKEY_ERR:
            strcpy(caErrMsg,"No key!");
            break;
        case SEC_ASCIITOBCD_ERR:
            strcpy(caErrMsg,"Transfer ASCII to BCD code fail!");
            break;
        case SEC_BCDTOASCII_ERR:
            strcpy(caErrMsg,"Transfer BCD to ASCII code fail!");
            break;
        case SEC_BUFFER_ERR:
            strcpy(caErrMsg,"Buffer overflow!");
            break;
        case SEC_UPD_KEY_ERR:
            strcpy(caErrMsg,"Update key fail!");
            break;
        case SEC_MEM_ERR:
            strcpy(caErrMsg,"Memory allocation fail!");
            break;
        case SEC_OPEN_FILE_ERR:
            strcpy(caErrMsg,"Open file fail!");
            break;
        case SEC_READ_FILE_ERR:
            strcpy(caErrMsg,"Read file fail!");
            break;
        case SEC_WRITE_FILE_ERR:
            strcpy(caErrMsg,"Write file fail!");
            break;
        case SEC_MK_SEM_ERR:
            strcpy(caErrMsg,"Create semaphore fail!");
            break;
        case SEC_SEM_OP_ERR:
            strcpy(caErrMsg,"Operate semaphore fail!");
            break;
        case SEC_ENV_DEF_ERR:
            strcpy(caErrMsg,"Environment variable not defined!");
            break;
        case SEC_MK_SHM_ERR:
            strcpy(caErrMsg,"Create share memory fail!");
            break;
        case SEC_SHM_OP_ERR:
            strcpy(caErrMsg,"Operate share memory fail!");
            break;
        case SEC_NOT_INIT_ERR:
            strcpy(caErrMsg,"Not initialized!");
            break;
        default:
            strcpy(caErrMsg,"Unknown error!");
            break;
    }
}
/*****************************************************************************/
/* FUNC:   static int ReadCfgFile(void)                                      */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   get configure information                                         */
/*****************************************************************************/
static int ReadCfgFile(void)
{
    char env_cfg_path[SEC_MAX_PATH_LEN+1];     
    char tmp_file[SEC_MAX_PATH_LEN+1];    
    int  i,iTmp;
	char *ptr;
                          
    memset(env_cfg_path,0,sizeof(env_cfg_path));                          
    memset(tmp_file,0,sizeof(tmp_file));
    
    ptr = (char *)getenv("SCUBENC_PATH");
    if( ptr == NULL )
    {
        Log(SEC_ENV_DEF_ERR,__LINE__);
        return SEC_ENV_DEF_ERR;
    }
    strcpy(env_cfg_path, ptr);
    strcpy(gszKeyFileName,env_cfg_path);
    strcpy(gszMMKeyFileName,env_cfg_path);
    strcpy(gszLogFileName,env_cfg_path);
    strcat(env_cfg_path,"/etc/topsec/scubenc.cfg");
        
    gShareMemKey=GetProfileInt("KEY", "SHARE_MEM_KEY",
        env_cfg_path);
    if ( gShareMemKey < 0 )
    {
        gShareMemKey =  SEC_DEF_MEMKEY ;
    }                          
    
    gSemKey=GetProfileInt("KEY","SEMAPHORE_KEY",
        env_cfg_path);
    if (gSemKey < 0 )
    {
        gSemKey = SEC_DEF_SEMKEY ;
    }                  
    
    giFlag=GetProfileInt("KEY","FLAG",env_cfg_path);
    if (giFlag < 0 )
    {
        giFlag = SEC_DEF_FLAG ;
    }                 
    
    if ( GetProfileString("FILE", "KEYFILE", tmp_file,SEC_MAX_PATH_LEN,
        env_cfg_path) < 0 )
    {
        return SEC_KEYFILE_DEF_ERR ;
    }                               
    strcat(gszKeyFileName,tmp_file);
    
    memset(tmp_file,0,sizeof(tmp_file));

    if ( GetProfileString("FILE", "MMKEYFILE", tmp_file,SEC_MAX_PATH_LEN,
        env_cfg_path) < 0 )
    {
        return SEC_KEYFILE_DEF_ERR ;
    }                               
    strcat(gszMMKeyFileName,tmp_file);
    
    memset(tmp_file,0,sizeof(tmp_file));
    if (GetProfileString("FILE","LOGFILE",tmp_file,SEC_MAX_PATH_LEN,
        env_cfg_path) < 0 )
    {
        return SEC_LOGFILE_DEF_ERR ;
    }
    strcat(gszLogFileName,tmp_file);
     
    memset(gszBit,0,sizeof(gszBit)); 
    if (GetProfileString("OTHER","BIT",gszBit,SEC_BITDEF_LEN,env_cfg_path) < 0 )
    {
        return SEC_BIT_DEF_ERR ;
    }           
     
    iTmp =  strlen(gszBit) ;
    if ( iTmp > SEC_BITDEF_LEN )
    { 
        return SEC_BIT_DEF_ERR;
    } 

        
    for (i = 0 ; i < iTmp ; i ++ )
    {
        if ( gszBit[i] >= '9'  || gszBit[i] <= '0' )
        {
             return SEC_BIT_DEF_ERR;
        }                           
    
    }                            
    
    glLogFileSize = GetProfileInt("FILE","LOGFILE_SIZE",env_cfg_path);
    if (glLogFileSize < 0 )
    {
        glLogFileSize = SEC_LOGFILE_DEF_SIZE ;
    }                                         
    
    glSecKeyLstSize = GetProfileInt("KEY","SECKEYLIST_SIZE",env_cfg_path);
    if (glSecKeyLstSize < 0 )
    {
        glLogFileSize = SEC_MAXKEYLIST_SIZE ;
    }                                         
    
    memset(tmp_file,0,sizeof(tmp_file));    
    if (GetProfileString("FILE","LOGERROR",tmp_file,SEC_MAX_PATH_LEN,
        env_cfg_path) < 0 )
    {
        return SEC_LOGFILE_DEF_ERR ;
    }
    if (!memcmp(tmp_file,"YES",3))
    {
        gbLog = 1 ;
    }   
    
    memset(tmp_file,0,sizeof(tmp_file));    
    if (GetProfileString("FILE","DEBUG_STRING",tmp_file,SEC_MAX_PATH_LEN,
        env_cfg_path) < 0 )
    {
        return SEC_LOGFILE_DEF_ERR ;
    }
    if (!memcmp(tmp_file,"YES",3))
    {
        gbDebugString = 1 ;
    }
    
    return SEC_OK;
}
/*****************************************************************************/
/* FUNC:   static int MakeSem(void)                                          */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   create semphore                                                   */
/*****************************************************************************/
static int MakeSem(void)
{
    union semun
    {
        int val;
        struct semid_ds * buf;
        ushort array[1];
    }arg;

    arg.val = 1;
    gSemID = semget(gSemKey, 1, giFlag);
    if (gSemID == -1)
    {
        gSemID = semget(gSemKey, 1, giFlag | IPC_CREAT);
        if (gSemID == -1) 
            return SEC_MK_SEM_ERR;
            
        if (semctl(gSemID, 0, SETVAL, arg) == -1)
            return SEC_SEM_OP_ERR;
    }
    return SEC_OK;
}
/*****************************************************************************/
/* FUNC:   static int SemLock(void)                                          */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   lock share memory                                                 */
/*****************************************************************************/
static int SemLock(void)
{
    struct sembuf sbuf;

    sbuf.sem_num = 0;
    sbuf.sem_op = -1;
    sbuf.sem_flg = SEM_UNDO;
    if(semop(gSemID, &sbuf, 1) == -1)
        return SEC_SEM_OP_ERR;
    
    return SEC_OK;
}
/*****************************************************************************/
/* FUNC:   static int SemUnLock(void)                                        */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   unlock share memory                                               */
/*****************************************************************************/
static int SemUnLock(void)
{
    struct sembuf sbuf;

    sbuf.sem_num = 0;
    sbuf.sem_op =  1;
    sbuf.sem_flg = SEM_UNDO;
    if(semop(gSemID, &sbuf, 1) == -1)
        return SEC_SEM_OP_ERR;
    
    return SEC_OK;
}    
/*****************************************************************************/
/* FUNC:   static int PrepareShareMem(void)                                  */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   prepare share memory                                              */
/*****************************************************************************/
static int PrepareShareMem(void)
{                           
    long   lShmSize ;
    
    lShmSize = SEC_KEYIDX_LEN + 1 + sizeof(T_ORG_RECORD) * glSecKeyLstSize ;
    
    gShareMemID = shmget(gShareMemKey,lShmSize,giFlag);
    /* the first time to run this function, then create share memory*/
    if (gShareMemID == -1)
    {
        gShareMemID = shmget(gShareMemKey,lShmSize,giFlag | IPC_CREAT);
        if (gShareMemID == -1)      
        {
            return SEC_MK_SHM_ERR;
        }    
        /*  attach to the share memory  */
        errno=0;
        gpOrgRecList = (T_ORG_RECLIST *)shmat(gShareMemID,(void*)0,0);
        if (errno != 0)
        {
            return SEC_SHM_OP_ERR;
        }              
        
        memset(gpOrgRecList,0,lShmSize);
        if (LoadOrgFromFile() != SEC_OK)
        {                      
            return SEC_READ_FILE_ERR;
        }
        return SEC_OK;  
    }
    /*  attach to the share memory  */
    errno=0;
    gpOrgRecList = (T_ORG_RECLIST *)shmat(gShareMemID,(void*)0,0);
    if (errno != 0)
    {
        return SEC_SHM_OP_ERR;
    }
    return SEC_OK;
}

/*****************************************************************************/
/* FUNC:   static int LoadOrgFromFile(void)                                  */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   load orgkey from file                                             */
/*****************************************************************************/
static int LoadOrgFromFile(void)
{
    int    iFd, iNum,i;           
    char   sCount[SEC_KEYIDX_LEN+1];
    long   lCount;
    struct stat  tFileStat ;
                                        
    memset(sCount,0,sizeof(sCount));
                                        
    if ((iFd = open(gszKeyFileName, O_RDONLY)) == -1)
    {                     
        if ((iFd = open(gszKeyFileName,O_RDWR|O_CREAT, S_IRUSR|S_IWUSR)) == -1)
        {       
            return SEC_OPEN_FILE_ERR;
        }
        else
        {        
            close(iFd);
            return SEC_OK ;
        }       
    }                  
    
    if(fstat(iFd,&tFileStat) == -1)
    {
        close(iFd);
        return SEC_OS_ERR;
    }     
    
    if (tFileStat.st_size == 0 )
    {
        return SEC_OK ;
    }                  
    
    iNum = read(iFd,gpOrgRecList->caOrgKeyCnt,SEC_KEYIDX_LEN + 1);
    if (iNum != SEC_KEYIDX_LEN + 1 )
    {                    
        close(iFd);
        return SEC_READ_FILE_ERR ;
    }    
    memcpy(sCount,gpOrgRecList->caOrgKeyCnt,SEC_KEYIDX_LEN);                         
    lCount = atol(sCount);  
    
    if (lCount >= glSecKeyLstSize  || lCount < 0 )
    {
        close(iFd);
        return SEC_READ_FILE_ERR ;
    }                             
    
    for  ( i = 0 ; i < lCount ; i++ )
    {
        iNum = read(iFd, &(gpOrgRecList->tOrgKey[i]), sizeof(T_ORG_RECORD));
        if (iNum != sizeof(T_ORG_RECORD))
        {
            close(iFd);
            return SEC_READ_FILE_ERR;
        }
    }   

    close(iFd);
    return SEC_OK;
}
/*****************************************************************************/
/* FUNC:   static int SaveOrgToFile(void)                                    */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   save orgkey to file                                               */
/*****************************************************************************/
static int SaveOrgToFile(void)
{
    int iFd, iNum,lCount,lWrite;
    char   sCount[SEC_KEYIDX_LEN+1];

    memset(sCount,0,sizeof(sCount));    
    if ((iFd = open(gszKeyFileName, O_WRONLY|O_CREAT, S_IRUSR|S_IWUSR)) == -1)
    {
        return SEC_OPEN_FILE_ERR;
    }
    
    memcpy(sCount,gpOrgRecList->caOrgKeyCnt,SEC_KEYIDX_LEN);
    lCount = atol(sCount );
    gpOrgRecList->filler1 = ':' ;
    lWrite = SEC_KEYIDX_LEN + 1 + lCount * sizeof(T_ORG_RECORD);    
    iNum = write(iFd, gpOrgRecList, lWrite);
    if (iNum != lWrite)
    {        
        close(iFd);
        return SEC_WRITE_FILE_ERR;
    }              
    
    close(iFd);
    return SEC_OK;
}
static int UpdateEndTime(time_t *ptTime, char *caEndTime)
{
    struct tm *ptm;
    int year = 1900;
    char caEndTimeTmp[SEC_DATETIME_LEN + 1];
    
    ptm = localtime(ptTime);
    
    year += ptm->tm_year;
    sprintf(caEndTimeTmp, "%04d%02d%02d%02d%02d%02d",
              year,
              ptm->tm_mon+1,
              ptm->tm_mday,
              ptm->tm_hour,
              ptm->tm_min,
              ptm->tm_sec);
    memcpy(caEndTime, caEndTimeTmp, SEC_DATETIME_LEN);
              
    return SEC_OK;
}
/*****************************************************************************/
/* FUNC:   static int GetChkValue(char *caKeyASC, long lKeyLen,              */
/*                                char *caCheckValue)                        */
/* INPUT:  caKeyASC -- key value in ASCII mode                               */
/*         lKeyLen  -- length of key                                         */
/* OUTPUT: caCheckValue -- check value                                       */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   get check value of key                                            */
/*****************************************************************************/
static int GetChkValue(char *caKeyASC, long lKeyLen,
                       unsigned long ulMMKIdx, char *caCheckValue)
{
    char caIV[8];
    int iChkValueLen = SEC_CHK_VALUE_LEN*2;
    int iRet, iKeyLen,i;
    char caKeyBCD[SEC_DES_KEY_LEN];
    char caKeyPlain[SEC_DES_KEY_LEN];        
    char caTmp[16];
    
    if (caKeyASC == NULL || caCheckValue == NULL)
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    memset(caIV, '\0', sizeof(caIV));
    
    /* Get the KEY plaintext */
    iKeyLen=SEC_DES_KEY_LEN;
    iRet = comASCIIToBCD(caKeyBCD, &iKeyLen, 1,
                   caKeyASC, lKeyLen);
    if (iRet != SEC_OK)
    {
        Log(SEC_ASCIITOBCD_ERR,__LINE__);
        return SEC_ASCIITOBCD_ERR;
    }
    for (i = 0 ;i < gtMMKeyLst.ulCount; i ++ )
    {
        if (gtMMKeyLst.tMMKey[i].ulKeyIdx == ulMMKIdx )
        {
            break;
        }   
    }             
    
    if  (gtMMKeyLst.tMMKey[i].ulKeyIdx != ulMMKIdx )
    {
        Log(SEC_NOMMKEY_ERR,__LINE__);
        return SEC_NOMMKEY_ERR ;
    }                                               
    memset(caTmp,0,sizeof(caTmp));
    sftDecByMsKey((char *)gtMMKeyLst.tMMKey[i].cbKey,(char *)caTmp);
    memset(caIV, '\0', sizeof(caIV));    
    iRet = DES_3CBC_Decryption((UCHAR*)caKeyBCD,(UCHAR*)caKeyPlain,
                               (UCHAR*)caTmp,SEC_DES_KEY_LEN,(UCHAR*)caIV);
    if (iRet)
    {
        Log(SEC_DECRYPT_ERR,__LINE__);
        return SEC_DECRYPT_ERR;
    }   
    
    memset(caIV,0,sizeof(caIV));
    /* encrypt the SEC_CHECK_VALUE */
    iRet = DES_CBC_Encryption((UCHAR*)SEC_CHK_VALUE,(UCHAR*)caCheckValue, 
                       (UCHAR*)caKeyPlain, SEC_CHK_VALUE_LEN,(UCHAR*)caIV);
    if (iRet )
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }                           
    
    return SEC_OK;
}

/*****************************************************************************/
/* FUNC:   static int ChkKeyTimeOut(char cKeyUsage)                          */
/* INPUT:  cKeyUsage -- usage of key                                         */
/*         lKeyLen  -- length of key                                         */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   check key if it is timeout                                        */
/*****************************************************************************/
/* Before call ChkKeyTimeOut, must lock semaphore first*/
static int ChkKeyTimeOut(char cKeyUsage,T_ORG_RECORD *ptOrgRecord)
{
    int iRet;
    char cReplace;
    char caNowTime[SEC_DATETIME_LEN];
    time_t  tNowTime ,tTmpTime;
    
    cReplace=FALSE;

    tNowTime = time(NULL);
    tTmpTime = tNowTime ;
    UpdateEndTime(&tTmpTime, caNowTime);

    switch (cKeyUsage)
    {
    case SEC_MAC_KEY:
        if (ptOrgRecord->tMacKey.cKeyFlag == SEC_KEY_OLD)
            break;
        if(strncmp(caNowTime, ptOrgRecord->tMacKey.caEndTime,
            SEC_DATETIME_LEN) > 0)
        {
            cReplace = TRUE;
            memcpy(ptOrgRecord->tMacKey.caOldKey, 
                ptOrgRecord->tMacKey.caNewKey, SEC_DES_KEY_LEN*2);
            memcpy(ptOrgRecord->tMacKey.caEndTime, SEC_MAX_DATETIME,
                SEC_DATETIME_LEN);
            tNowTime = time(NULL);
            tTmpTime = tNowTime ;
            UpdateEndTime(&tTmpTime, ptOrgRecord->tMacKey.caStartTime);
            ptOrgRecord->tMacKey.cKeyFlag = SEC_KEY_OLD;
        }
        break;       
    case SEC_PIN_KEY:
        if (ptOrgRecord->tPinKey.cKeyFlag == SEC_KEY_OLD)
            break;
        if(strncmp(caNowTime, ptOrgRecord->tPinKey.caEndTime,
            SEC_DATETIME_LEN) > 0)
        {
            cReplace = TRUE;
            memcpy(ptOrgRecord->tPinKey.caOldKey, 
                ptOrgRecord->tPinKey.caNewKey, SEC_DES_KEY_LEN*2);
            memcpy(ptOrgRecord->tPinKey.caEndTime, SEC_MAX_DATETIME,
                SEC_DATETIME_LEN);
            tNowTime = time(NULL);
            tTmpTime = tNowTime ;
            UpdateEndTime(&tTmpTime, ptOrgRecord->tPinKey.caStartTime);
            ptOrgRecord->tPinKey.cKeyFlag = SEC_KEY_OLD;
        }
        break;       
    case SEC_DES_KEY:
        if (ptOrgRecord->tDesKey.cKeyFlag == SEC_KEY_OLD)
            break;
        if(strncmp(caNowTime, ptOrgRecord->tDesKey.caEndTime,
            SEC_DATETIME_LEN) > 0)
        {
            cReplace = TRUE;
            memcpy(ptOrgRecord->tDesKey.caOldKey, 
                ptOrgRecord->tDesKey.caNewKey, SEC_DES_KEY_LEN*2);
            memcpy(ptOrgRecord->tDesKey.caEndTime, SEC_MAX_DATETIME,
                SEC_DATETIME_LEN);
            tNowTime = time(NULL);
            tTmpTime = tNowTime ;
            UpdateEndTime(&tTmpTime, ptOrgRecord->tDesKey.caStartTime);
            ptOrgRecord->tDesKey.cKeyFlag = SEC_KEY_OLD;
        }
        break;       
    default:
        return SEC_ARGUMENTS_ERR;
    }     
    
    iRet = UpdateKey(ptOrgRecord);
    if (iRet )
    {
        Log(iRet,__LINE__);
        return iRet ;
    }                
    
    if (cReplace == TRUE)
    {
        iRet = SaveOrgToFile();
        if (iRet != SEC_OK)
        {
            Log(iRet,__LINE__);
            return iRet;
        }
    }
    return SEC_OK;
}
void DumpShareMem(void)
{
    char szInfo[100];   
    T_ORG_RECORD  *ptOrgRecord;
    long    lCount,l; 
    
    
    memset(szInfo,'\0',sizeof(szInfo));    
    memcpy(szInfo,gpOrgRecList->caOrgKeyCnt,SEC_KEYIDX_LEN);
    lCount = atol(szInfo);
    SemLock();               
    for (l = 0 ; l < lCount ; l ++ )
    {
    ptOrgRecord = &gpOrgRecList->tOrgKey[l] ;           
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->caOrgIdx,8);
    printf("DUMP FROM SHM: orgIdx = %s\n", szInfo);
    
    printf("          tMacKey: KeyFlag = %c\n", ptOrgRecord->tMacKey.cKeyFlag);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tMacKey.caStartTime,SEC_DATETIME_LEN);
    printf("          tMacKey: StartTime = %s\n",szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tMacKey.caEndTime,SEC_DATETIME_LEN);
    printf("          tMacKey: EndTime = %s\n",szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tMacKey.caOldKey,SEC_DES_KEY_LEN*2);
    printf("          tMacKey: OldKey = %s\n", szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tMacKey.caNewKey,SEC_DES_KEY_LEN*2);
    printf("          tMacKey: NewKey = %s\n", szInfo);
    
    printf("          tPinKey: KeyFlag = %c\n", ptOrgRecord->tPinKey.cKeyFlag);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tPinKey.caStartTime,SEC_DATETIME_LEN);
    printf("          tPinKey: StartTime = %s\n",szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tPinKey.caEndTime,SEC_DATETIME_LEN);
    printf("          tPinKey: EndTime = %s\n",szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tPinKey.caOldKey,SEC_DES_KEY_LEN*2);
    printf("          tPinKey: OldKey = %s\n", szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tPinKey.caNewKey,SEC_DES_KEY_LEN*2);
    printf("          tPinKey: NewKey = %s\n", szInfo);
    
    printf("          tDesKey: KeyFlag = %c\n", ptOrgRecord->tDesKey.cKeyFlag);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tDesKey.caStartTime,SEC_DATETIME_LEN);
    printf("          tDesKey: StartTime = %s\n",szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tDesKey.caEndTime,SEC_DATETIME_LEN);
    printf("          tDesKey: EndTime = %s\n",szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tDesKey.caOldKey,SEC_DES_KEY_LEN*2);
    printf("          tDesKey: OldKey = %s\n", szInfo);
    memset(szInfo,'\0',sizeof(szInfo));
    memcpy(szInfo,ptOrgRecord->tDesKey.caNewKey,SEC_DES_KEY_LEN*2);
    printf("          tDesKey: NewKey = %s\n", szInfo);              
    }
    SemUnLock();
}
/****************************************************************************/
/* FUNC:   int comASCIIToBCD(char* caDBuf,int *piDBufLen,int iAlign,        */
/*                const char* caSBuf,int iSBufLen)                          */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   Translate ASCII string to BCD string                             */
/****************************************************************************/
/** if iAlign == 0, left align; if iAlign == 1,  right align **/
int comASCIIToBCD(char*       caDBuf,
                  int         *piDBufLen,
                  int         iAlign,
                  const char* caSBuf,
                  int iSBufLen)
{
    int i, j;

    if( caSBuf == NULL || iSBufLen <= 0 || caDBuf == NULL || 
        piDBufLen == NULL  || *piDBufLen <= 0 )
    {
        return SEC_ASCIITOBCD_ERR;
    }

    memset(caDBuf, 0, *piDBufLen);

    for( i = 0, j = iSBufLen % 2 * iAlign; 
         i < iSBufLen && j < *piDBufLen * 2  ;
         i++, j++ )
    {
        if (caSBuf[i] >= '0' && caSBuf[i] <= '9')
        {
            caDBuf[j/2] |= ( caSBuf[i] - '0' ) << ( (j + 1 )% 2 * 4 );
        }
        else
        if ( caSBuf[i] >='a' && caSBuf[i] <= 'f')
        {
            caDBuf[j/2] |= ( caSBuf[i] - 'a'+0x0a ) << ( (j + 1 )% 2 * 4 );
        }
        else
        if ( caSBuf[i] >='A' && caSBuf[i] <= 'F')
        {
            caDBuf[j/2] |= ( caSBuf[i] - 'A'+0x0a ) << ( (j + 1 )% 2 * 4 );
        }
        else
        {
            return SEC_ASCIITOBCD_ERR ;
        }             
                
    }

    if( i < iSBufLen )
    {
        return SEC_ASCIITOBCD_ERR;
    }

    *piDBufLen = (j + 1) / 2;

    return SEC_OK;
}

int comBCDToASCII(unsigned char* caDBuf,
                         int*           piDBufLen,
                         const char*    caSBuf,
                         int            iSBufLen,
                         int            iBCDLen,
                         int            iAlign)
{
    int i, j;

    if( caSBuf == NULL || iSBufLen <= 0 || caDBuf == NULL || 
        piDBufLen == NULL  || *piDBufLen <= 0 )
    {
        return SEC_BCDTOASCII_ERR;
    }

    memset(caDBuf, 0, *piDBufLen);
    
    for( i = iBCDLen % 2 * iAlign, j = 0; 
         i < iSBufLen * 2 && j < *piDBufLen && j < iBCDLen ;
         i++  )
    {
        caDBuf[j] = ( (((unsigned char)caSBuf[i/2]) >> ( (i + 1) % 2 * 4 ))
                      & 0xf ) ;
        if ( caDBuf[j] >= 0 && caDBuf[j] <= 9 )
            caDBuf[j]  += '0';
        else 
            caDBuf[j]  += 'A'-10 ;
        
        j ++;
    }
    
    if( i < iSBufLen * 2 && i < iBCDLen )
    {
        return SEC_BCDTOASCII_ERR;
    }

    *piDBufLen = j;

    return SEC_OK;
}
/*****************************************************************************/
/* FUNC:   static int LoadMMKey(void)                                        */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                    */
/* DESC:   load mmkey from file.                                             */
/*****************************************************************************/
static  int LoadMMKey(void)
{           
    unsigned long  ulCount = 0 ;
    unsigned long  ulKeyIdx;
    int            iFileId;
    int            iRead,i ,j,k;
    unsigned long  l;           
    unsigned char  ucaBuff[10]; 
    struct stat  tFileStat ;
                               
    memset(ucaBuff,0,sizeof(ucaBuff));                         
    memset (&gtMMKeyLst,0,sizeof(gtMMKeyLst));
    if( ( iFileId = open(gszMMKeyFileName,O_RDWR|O_CREAT,0600)) == -1)
    {
        
        Log(SEC_OPEN_FILE_ERR, __LINE__);
        return SEC_OPEN_FILE_ERR;
    }
    
    if(fstat(iFileId,&tFileStat) == -1)
    {
        Log(SEC_READ_FILE_ERR, __LINE__);
        close(iFileId);
        return SEC_READ_FILE_ERR;
    }
    
    iRead = strlen(gszBit);
    if  ( tFileStat.st_size == 0 )
    {
		if(write(iFileId,ucaBuff,iRead) != iRead)
		{
			Log(SEC_WRITE_FILE_ERR,__LINE__);
			close(iFileId);
			return SEC_WRITE_FILE_ERR;
		}
		close(iFileId);
		return SEC_OK;
    }	
    
    iRead = strlen(gszBit);
    if (read (iFileId ,ucaBuff, iRead ) != iRead )
    {
        Log(SEC_READ_FILE_ERR, __LINE__);
        close(iFileId);
        return SEC_READ_FILE_ERR ;
    }   
    
    for ( i = 0 ; i < iRead ; i ++ )
    {
        k = gszBit[i] - '0' - 1 ;
        l = 1 ;
        
        for ( j = 0 ; j < k ; j ++ )
        {
            l *= 256;
        }
        
        ulCount = l*ucaBuff[i] + ulCount ;  
    }
    
    if (ulCount >   SEC_MAXKEYLIST_SIZE )
    {
        Log(SEC_READ_FILE_ERR, __LINE__);
        close(iFileId);
        return SEC_READ_FILE_ERR ;

    }       
    
    gtMMKeyLst.ulCount = ulCount ;
    
    for ( ulCount = 0 ; ulCount < gtMMKeyLst.ulCount ; ulCount ++ ) 
    {
        iRead = strlen(gszBit);
        if (read (iFileId ,ucaBuff, iRead ) != iRead )
        {
            Log(SEC_READ_FILE_ERR, __LINE__);
            close(iFileId);
            return SEC_READ_FILE_ERR ;
        }   
        
        ulKeyIdx = 0 ;
        for ( i = 0 ; i < iRead ; i ++ )
        {
            k = gszBit[i] - '0' - 1 ;
            l = 1 ;
        
            for ( j = 0 ; j < k ; j ++ )
            {
                l *= 256;
            }
        
            ulKeyIdx = l*ucaBuff[i] + ulKeyIdx ;    
        }
        gtMMKeyLst.tMMKey[ulCount].ulKeyIdx = ulKeyIdx ;
 
        iRead = SEC_3DES_KEY_LEN; 
        if (read(iFileId,gtMMKeyLst.tMMKey[ulCount].cbKey,iRead ) != iRead )
        {
            Log(SEC_READ_FILE_ERR, __LINE__);
            close(iFileId);
            return SEC_READ_FILE_ERR ;
        }   
   
    }   
    
    close(iFileId);
    return SEC_OK ;
}   
/****************************************************************************/
/* FUNC:   int SaveMMKey(void)                                              */
/* INPUT:  none                                                             */
/* OUTPUT: none                                                             */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   save mmkey to file.                                              */
/****************************************************************************/
 int  SaveMMKey(void)
{           
    unsigned long  ulCount = 0 ;
    unsigned long  ulKeyIdx;
    int            iFileId;
    int            iWrite,i ,j,k;
    unsigned char  ucaBuff[10],ucaBuffTmp[10]; 
                               
    memset(ucaBuff,0,sizeof(ucaBuff));
    memset(ucaBuffTmp,0,sizeof(ucaBuffTmp));
    if( ( iFileId = open(gszMMKeyFileName,O_RDWR|O_CREAT,
        0600)) == -1)
    {
        Log(SEC_OPEN_FILE_ERR, __LINE__);
        return SEC_OPEN_FILE_ERR;
    }
    ulCount = gtMMKeyLst.ulCount;
    iWrite = strlen(gszBit);
    for ( i = 0 ; i < iWrite ; i ++ )
    {
        ucaBuffTmp[i]=ulCount%256;
        ulCount/=256;
    }   
    for ( i = 0 ; i < iWrite ; i ++ )
    {
        k = gszBit[i] - '0' - 1 ;
        ucaBuff[i]=ucaBuffTmp[k];
    }   
        
    if (write (iFileId ,ucaBuff, iWrite ) != iWrite )
    {
        Log(SEC_WRITE_FILE_ERR, __LINE__);
        close(iFileId);
        return SEC_WRITE_FILE_ERR ;
    }   
    
    for ( ulCount = 0 ; ulCount < gtMMKeyLst.ulCount ; ulCount ++ ) 
    {
        iWrite = strlen(gszBit);
        ulKeyIdx = gtMMKeyLst.tMMKey[ulCount].ulKeyIdx;
        for ( i = 0 ; i < iWrite ; i ++ )
        {
            ucaBuffTmp[i]=ulKeyIdx%256;
            ulKeyIdx/=256;
        }   
        for ( i = 0 ; i < iWrite ; i ++ )
        {
            k = gszBit[i] - '0' - 1 ;
            ucaBuff[i]=ucaBuffTmp[k];
        }   
        if (write (iFileId ,ucaBuff, iWrite ) != iWrite )
        {
            Log(SEC_WRITE_FILE_ERR, __LINE__);
            close(iFileId);
            return SEC_WRITE_FILE_ERR ;
        }   
        iWrite = SEC_3DES_KEY_LEN; 
        if (write(iFileId,gtMMKeyLst.tMMKey[ulCount].cbKey,iWrite ) != iWrite )
        {
            Log(SEC_WRITE_FILE_ERR, __LINE__);
            close(iFileId);
            return SEC_WRITE_FILE_ERR ;
        }   
    }   
    close(iFileId);
    return SEC_OK ;
}   

/****************************************************************************/
/* FUNC:    int InsertMMKey(unsigned long ulMMKIdx,unsigned char *caKey)    */
/* INPUT:  ulMMKIdx -- MMK Index                                            */
/*         caKey -- key value ( 128 bit )                                   */
/* OUTPUT: none                                                             */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   insert a new MMK to list.                                        */
/****************************************************************************/
int  InsertMMKey(unsigned long ulMMKIdx,unsigned char *caKey)
{
    unsigned long ulIdx;
    unsigned char caEncKey[SEC_3DES_KEY_LEN*2];

    if(gtMMKeyLst.ulCount == SEC_MAXKEYLIST_SIZE)
    {
        Log(SEC_BUFFER_ERR,__LINE__);
        return SEC_BUFFER_ERR;
    }
    for(ulIdx=0;ulIdx<gtMMKeyLst.ulCount;ulIdx++)
    {
        if(gtMMKeyLst.tMMKey[ulIdx].ulKeyIdx == ulMMKIdx)
        {
        	sftEncByMsKey((char *)caKey,(char *)caEncKey);
            memcpy(gtMMKeyLst.tMMKey[ulIdx].cbKey,caEncKey,SEC_3DES_KEY_LEN);
            return SEC_OK;
        }
    }
    sftEncByMsKey((char *)caKey,(char *)caEncKey);
    memcpy(gtMMKeyLst.tMMKey[ulIdx].cbKey,caEncKey,SEC_3DES_KEY_LEN);
    gtMMKeyLst.tMMKey[ulIdx].ulKeyIdx=ulMMKIdx;
    gtMMKeyLst.ulCount++;
    return SEC_OK;
}

/****************************************************************************/
/* FUNC:    int GetMMKeyChkValue(unsigned long ulMMKIdx,                    */
/*                                      unsigned char *caChkValue)          */
/* INPUT:  ulMMKIdx -- MMK Index                                            */
/*         caChkValue -- key check value                                    */
/* OUTPUT: none                                                             */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   insert a new MMK to list.                                        */
/****************************************************************************/
int  GetMMKeyChkValue(unsigned long ulMMKIdx,unsigned char *caChkValue)
{
    unsigned long ulIdx;
    unsigned char caEncMMKey[SEC_3DES_KEY_LEN],caMMKey[SEC_3DES_KEY_LEN];
    char     caIV[8];
    unsigned char     caTmp[8],caChk[8];
    int iRet;

    if(caChkValue == NULL)
        return SEC_ARGUMENTS_ERR;

    for(ulIdx=0;ulIdx<gtMMKeyLst.ulCount;ulIdx++)
    {
        if(gtMMKeyLst.tMMKey[ulIdx].ulKeyIdx == ulMMKIdx)
        {
            memcpy(caEncMMKey,gtMMKeyLst.tMMKey[ulIdx].cbKey,SEC_3DES_KEY_LEN);
            sftDecByMsKey((char *)caEncMMKey,(char *)caMMKey);
            memset(caIV,'\0',sizeof(caIV));
            memset(caTmp,'\0',sizeof(caTmp));
            memset(caChk,'\0',sizeof(caChk));
            iRet=DES_3CBC_Encryption(caTmp,caChk,
                (UCHAR*)caMMKey,8,(UCHAR*)caIV);
            if (iRet )
            {
                return SEC_ENCRYPT_ERR;
            }
            memcpy(caChkValue,caChk,8);
            return SEC_OK;
        }
    }
    return SEC_NOKEY_ERR;
}
/****************************************************************************/
/* FUNC:   static  int GetKey(char *pcaOrgIdx,T_ORG_RECORD *ptOrgRec)       */
/* INPUT:  pcaOrgIdx -- orgidx                                              */
/* OUTPUT: ptOrgRec -- org record                                           */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   get org record.                                                  */
/****************************************************************************/
static  int GetKey(char *pcaOrgIdx,T_ORG_RECORD *ptOrgRec)
{
    int           i;
    unsigned long ulCount;
    char          sCount[10];
    
    if (ptOrgRec == NULL || pcaOrgIdx == NULL )
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    
    memset(sCount,0,sizeof(sCount));      
    memcpy(sCount,gpOrgRecList->caOrgKeyCnt,SEC_KEYIDX_LEN);
    ulCount = atol(sCount);
    
    for ( i = 0 ; i < ulCount ; i ++ )
    {
        if (!memcmp(gpOrgRecList->tOrgKey[i].caOrgIdx,
                    pcaOrgIdx,SEC_ORGIDX_LEN))   
        {
            memcpy(ptOrgRec,&(gpOrgRecList->tOrgKey[i]),
                   sizeof(T_ORG_RECORD));
            return SEC_OK;
        }
    }/*end of for */
                        
    return  SEC_NOKEY_ERR;      
}
/****************************************************************************/
/* FUNC:   static  int UpdateKey(T_ORG_RECORD *ptOrgRec)                    */
/* INPUT:  none                                                             */
/* OUTPUT: ptOrgRec -- org record                                           */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   update org record.                                               */
/****************************************************************************/
static int UpdateKey(T_ORG_RECORD *ptOrgRecord)
{
    int           i, iRet;
    unsigned long ulCount;
    char          sCount[10];       
    char          caFmt[10];
    
    if (ptOrgRecord == NULL)
    {
        Log(SEC_ARGUMENTS_ERR, __LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    
    memset(sCount,0,sizeof(sCount));      
    memcpy(sCount,gpOrgRecList->caOrgKeyCnt,SEC_KEYIDX_LEN);
    ulCount = atol(sCount);
    
    for ( i = 0 ; i < ulCount ; i ++ )
    {
    
        if (!memcmp(gpOrgRecList->tOrgKey[i].caOrgIdx,
                    ptOrgRecord->caOrgIdx,SEC_ORGIDX_LEN))   
        {
            memcpy(&(gpOrgRecList->tOrgKey[i]),ptOrgRecord,
                   sizeof(T_ORG_RECORD));
            iRet = SaveOrgToFile();
            if (iRet != SEC_OK)
            {                  
                Log(iRet,__LINE__);
                return iRet;
            }

            return SEC_OK;
        }
    }/*end of for */
    
    if (ulCount >= glSecKeyLstSize )   
    {   
        Log(SEC_BUFFER_ERR,__LINE__);
        return SEC_BUFFER_ERR ;
    }                    
   
    memcpy(&(gpOrgRecList->tOrgKey[i]),ptOrgRecord, sizeof(T_ORG_RECORD)); 
    ulCount ++ ;            
    memset(caFmt,0,sizeof(caFmt));
    memset(sCount,0,sizeof(sCount));
    sprintf(caFmt,"%%0%dd",SEC_KEYIDX_LEN);
    sprintf(sCount,caFmt,ulCount);
    memcpy(gpOrgRecList->caOrgKeyCnt,sCount,SEC_KEYIDX_LEN);
    
    iRet = SaveOrgToFile();
    if (iRet != SEC_OK)
    {
        Log(iRet,__LINE__);
        return iRet;
    }
    return  SEC_OK;         
}
/****************************************************************************/
/* FUNC:   int  GetPartChk(int  iArgc,char* pcaKey1,char* pcaKey2,          */
/*                           char *pcaKey3,char *pcaChk )                   */
/* INPUT:  iArgc -- number of arguments                                     */
/*         pcaKey1 -- first part of key                                     */
/*         pcaKey2 -- second part of key                                    */
/*         pcaKey3 -- third part of key                                     */
/* OUTPUT: pcaChk -- check value                                            */
/* RETURN: SEC_OK   -- success                                              */
/*         else  -- error                                                   */
/* DESC:   get check value                                                  */
/****************************************************************************/
int  GetPartChk(int  iArgc,char* pcaKey1,char* pcaKey2,
                char *pcaKey3,char *pcaChk )
{
    int      i,iRet;
    char     caBnkKey1[SEC_3DES_KEY_LEN],caTBnkKey1[SEC_3DES_KEY_LEN*2];
    char     caBnkKey2[SEC_3DES_KEY_LEN],caTBnkKey2[SEC_3DES_KEY_LEN*2];
    char     caBnkKey3[SEC_3DES_KEY_LEN],caTBnkKey3[SEC_3DES_KEY_LEN*2];
    int      iKeyLen = 16;
    char     caIV[8];
    char     caTmp[8],caChk[8];
    FILE     *ptFp;
    
    if (iArgc != 2 && iArgc != 4 && iArgc != 3 )
    {
        Log(SEC_ARGUMENTS_ERR,__LINE__);
        return SEC_ARGUMENTS_ERR;
    }
    
    memset(caIV,'\0',sizeof(caIV));
    memset(caTmp,0,sizeof(caTmp));
    
    memcpy(caTBnkKey1,pcaKey1,SEC_3DES_KEY_LEN*2);
    if ( iArgc == 3 )
    {
        memcpy(caTBnkKey2,pcaKey2,SEC_3DES_KEY_LEN*2);
    }   
    else
    if ( iArgc == 4 )
    {
        memcpy(caTBnkKey2,pcaKey2,SEC_3DES_KEY_LEN*2);
        memcpy(caTBnkKey3,pcaKey3,SEC_3DES_KEY_LEN*2);
    }   
    
    iKeyLen = 16;
    if ((iRet = comASCIIToBCD(caBnkKey1,&iKeyLen,1,
        caTBnkKey1,SEC_3DES_KEY_LEN*2) ) != SEC_OK)
    {
        Log(iRet,__LINE__);
        return iRet;
    }   
    
    if ( iArgc == 3 )
    {
        iKeyLen = 16;
        if ((iRet = comASCIIToBCD(caBnkKey2,&iKeyLen,1,caTBnkKey2,
             SEC_3DES_KEY_LEN*2))   != SEC_OK)
        {
            Log(iRet,__LINE__);
            return iRet;
        }   

        for ( i = 0 ; i < SEC_3DES_KEY_LEN ; i ++)
        {
            caBnkKey1[i] = caBnkKey1[i] ^ caBnkKey2[i] ;
        }   
    }
    else	
    if ( iArgc == 4 )    
    {
        iKeyLen = 16;
        if ((iRet = comASCIIToBCD(caBnkKey2,&iKeyLen,1,caTBnkKey2,
             SEC_3DES_KEY_LEN*2))   != SEC_OK)
        {
            Log(iRet,__LINE__);
            return iRet;
        }   
    
        iKeyLen = 16;
        if ((iRet = comASCIIToBCD(caBnkKey3,&iKeyLen,1,caTBnkKey3,
             SEC_3DES_KEY_LEN*2) )  != SEC_OK)
        {
            Log(iRet,__LINE__);
            return iRet;
        }       
    
        for ( i = 0 ; i < SEC_3DES_KEY_LEN ; i ++)
        {
            caBnkKey1[i] = caBnkKey1[i] ^ caBnkKey2[i] ^ caBnkKey3[i];
        }   
    }   
    
    iRet = DES_3CBC_Encryption((unsigned char*)caTmp,(unsigned char*)caChk,
                               (unsigned char*)caBnkKey1,8,
                               (unsigned char *)caIV);
    if (iRet )
    {
        Log(SEC_ENCRYPT_ERR,__LINE__);
        return SEC_ENCRYPT_ERR ;
    }   

    iKeyLen = SEC_CHK_VALUE_LEN * 2;
	iRet = comBCDToASCII ((unsigned char *)pcaChk,&iKeyLen, caChk,8,16,1 ) ;
    if (iRet )
    {
        Log(iRet,__LINE__);
        return iRet ;
    }   
	
    return SEC_OK;  
}   
/****************************************************************************/
/* FUNC:   int   DBEnc(char *pcaOrgId,char *pcaTlrNo,                       */
/*                      char *pcaPwd,char *pcaEncData)                      */
/* INPUT:  pcaOrgId -- orgid                                                */
/*         pcaTlrNo -- teller number                                        */
/*         pcaPwd   -- password                                             */
/* OUTPUT: pcaEncData -- encrypted data                                     */
/* RETURN: SEC_OK   -- success                                               */
/*         else  -- error                                                   */
/* DESC:   encrypt password of teller                                       */
/****************************************************************************/
int DBEnc(char *pcaOrgId,char *pcaTlrNo,char *pcaPwd,char *pcaEncData)
{
	int          iRet ,iBufLen;
	char         caIn[SEC_ORGIDX_LEN + SEC_TLRNO_LEN + SEC_PASSWD_LEN ];
	char         caTmpBuff[SEC_PASSWD_LEN];
	char         caOut[3];
	T_GenHashReq tGenHashReq;
	T_GenHashRep tGenHashRep;
	
	memset(&tGenHashReq,0,sizeof(tGenHashReq));
	memset(&tGenHashRep,0,sizeof(tGenHashRep));
	
	memcpy(caIn,pcaOrgId,SEC_ORGIDX_LEN);
	memcpy(caIn + SEC_ORGIDX_LEN,pcaTlrNo,SEC_TLRNO_LEN);
	memcpy(caIn + SEC_ORGIDX_LEN + SEC_TLRNO_LEN ,pcaPwd,SEC_PASSWD_LEN);
	
	tGenHashReq.lDataLen = SEC_ORGIDX_LEN + SEC_TLRNO_LEN + SEC_PASSWD_LEN ;
	memcpy(tGenHashReq.caData,caIn,tGenHashReq.lDataLen );
	
	iRet = GenHash(&tGenHashReq,&tGenHashRep);
	if (iRet != SEC_OK )
	{
        Log(iRet,__LINE__);
        return iRet ;
    }
    
    caOut[0] = tGenHashRep.caHash[19] ;
    caOut[1] = tGenHashRep.caHash[0];    
    caOut[2] = tGenHashRep.caHash[9];
    
    iBufLen = SEC_PASSWD_LEN ;
    iRet = comBCDToASCII((unsigned char*)caTmpBuff,&iBufLen, caOut,3,6,1);
	if (iRet != SEC_OK )
	{
        Log(iRet,__LINE__);
        return iRet ;
    }
    
    memcpy(pcaEncData , caTmpBuff ,SEC_PASSWD_LEN );

	return SEC_OK;
	
}
