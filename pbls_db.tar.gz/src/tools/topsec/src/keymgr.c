/*****************************************************************************/
/*  Shanghai Huateng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2001. All rights reserved.                                 */
/*****************************************************************************/
/* PROGRAM NAME: keymgr.c                                                    */
/* DESCRIPTIONS: The program is for epost secure module                      */
/*****************************************************************************/
/*                                  MODIFICATION LOG                         */
/* DATE        PROGRAMMER               DESCRIPTION                          */
/*  Author        Date        Description                                    */
/*  ~~~~~~        ~~~~        ~~~~~~~~~~~                                    */
/*  Wang YingZi  08/11/2001   Initial Version Creation                       */
/*****************************************************************************/
#include <stdio.h>
#include <curses.h>
#include <sys/types.h>
#ifdef HP_UNIX
#include <time.h>
#endif
#ifdef SCO_UNIX
#include <sys/time.h>
#endif
#ifdef SCOUW_UNIX
#include <sys/time.h>
#endif
#ifdef DEC_UNIX
#include <sys/time.h>
#endif
#include "scubenc.h"
#include "chcurses.h"

/*****************************************************************************/
/* FUNC:   static void Scubenc_1_0_0(void)                                   */
/* INPUT:  none                                                              */
/* OUTPUT: none                                                              */
/* RETURN: none                                                              */
/* DESC:   for query version                                                 */
/*****************************************************************************/
static void Scubenc_1_0_1(void)
{
    /* Version 1.0.1 :  */
    return;
}

void  clScreen()
{
    ch_mvprintw(3,35,"                                                      ");
    ch_mvprintw(6,15,"                                                      ");
    ch_mvprintw(9,15,"                                                      ");
    ch_mvprintw(12,15,"                                                     ");
    ch_mvprintw(15,15,"                                                     ");
    ch_mvprintw(18,15,"                                                     ");
    
}   

void main (int argc,char **argv)
{
    int   i , iTmp,iRet;
    int   iSelect ;
    char  caKey1[SEC_3DES_KEY_LEN *2 + 1];
    char  caKey2[SEC_3DES_KEY_LEN *2 + 1];
    char  caKey3[SEC_3DES_KEY_LEN *2 + 1];
    char  caKeyTmp[SEC_3DES_KEY_LEN *2];
    char  caTmp[2];
    char  caMMkIdx[6];
    char  caOrgIdx[SEC_ORGIDX_LEN];
    char  caChkValue[SEC_CHK_VALUE_LEN * 2 + 1];
    char  caErrMsg[SEC_MAX_ERR_MSG_LEN];
    char  caCmd[200];
    unsigned long ulMMKIdx ;
    char     caBnkKey1[SEC_3DES_KEY_LEN];
    char     caBnkKey2[SEC_3DES_KEY_LEN];
    int      iKeyLen = 16;
	T_ExcKeyReq  tExcKeyReq;
	int      iChkValueLen; 
	     
    iRet = Initialize();
    if(iRet != SEC_OK )
    {
        GetErrMsg(iRet,caErrMsg);
        printf("Initialize Error!:%s\n",caErrMsg);
        exit(1);
    }
    ch_initscr();
    while (1)
    {   
        clScreen(); 
        ch_mvprintw(3,35,"KEY MANAGEMENT");
        ch_mvprintw(6,15,"1.Input Master Key");
        ch_mvprintw(9,15,"2.Input MMKey");
        ch_mvprintw(12,15,"3.Initialize Data Key");
        ch_mvprintw(15,15,"4.exit");
        ch_mvprintw(18,15,"Please Input Your Choice��");
        
        memset(caTmp,0,sizeof(caTmp));
        ch_move(18,42);
        iSelect = ch_getch();
        caTmp[0] = iSelect ;
        ch_mvprintw(18,42,caTmp);
        ch_getch();
        switch (iSelect)
        {
            case '1':
                memset(caKey1,0,sizeof(caKey1));
                memset(caKey2,0,sizeof(caKey2));
                memset(caKey3,0,sizeof(caKey3));
                
                clScreen();
                ch_mvprintw(3,35,"INPUT MASTER KEY");
                ch_mvprintw(6,15,"First part");
                ch_mvprintw(9,15,"Retype ");
                ch_move(6,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKey1[i] = iTmp ;
                    ch_mvprintw(6 ,30 + i,"*");
                    
                }   
               
                ch_move(9,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKeyTmp[i] = iTmp ;
                    ch_mvprintw(9 ,30 + i,"*");
                    
                }
                if (memcmp(  caKey1,caKeyTmp, SEC_3DES_KEY_LEN * 2))
                {
                    clScreen();
                    ch_mvprintw(6,15,"Input inconsistent!");
                    ch_getch(); 
                    break;
                    
                }
                ch_getch(); 

                clScreen();
                memset(caChkValue,0,sizeof(caChkValue));
                iRet = GetPartChk(2,caKey1,caKey2,caKey3,caChkValue);
                if (iRet != SEC_OK )
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                ch_mvprintw(6,15,"Check Value:");
                ch_mvprintw(6,35,caChkValue);
                ch_getch(); 
                
                clScreen();
                ch_mvprintw(3,35,"INPUT MASTER KEY");
                ch_mvprintw(6,15,"Second part");
                ch_mvprintw(9,15,"Retype ");
                ch_move(6,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKey2[i] = iTmp ;
                    ch_mvprintw(6 ,30 + i,"*");
                    
                }   
                ch_move(9,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKeyTmp[i] = iTmp ;
                    ch_mvprintw(9 ,30 + i,"*");
                    
                }
                if (memcmp(  caKey2,caKeyTmp, SEC_3DES_KEY_LEN * 2))
                {
                    clScreen();
                    ch_mvprintw(6,15,"Input inconsistent!");
                    ch_getch(); 
                    break;
                    
                }
                ch_getch(); 

                clScreen();
                memset(caChkValue,0,sizeof(caChkValue));
                iRet = GetPartChk(2,caKey2,caKey2,caKey3,caChkValue);
                if (iRet != SEC_OK )
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                ch_mvprintw(6,15,"Check Value:");
                ch_mvprintw(6,35,caChkValue);
                ch_getch(); 
                
                clScreen();
                ch_mvprintw(3,35,"INPUT MASTER KEY");
                ch_mvprintw(6,15,"Third part");
                ch_mvprintw(9,15,"Retype ");
                ch_move(6,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKey3[i] = iTmp ;
                    ch_mvprintw(6 ,30 + i,"*");
                    
                }   
                ch_move(9,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKeyTmp[i] = iTmp ;
                    ch_mvprintw(9 ,30 + i,"*");
                    
                }
                if (memcmp(  caKey3,caKeyTmp, SEC_3DES_KEY_LEN * 2))
                {
                    clScreen();
                    ch_mvprintw(6,15,"Input inconsistent!");
                    ch_getch(); 
                    break;
                    
                }
                ch_getch(); 

                clScreen();
                memset(caChkValue,0,sizeof(caChkValue));
                iRet = GetPartChk(2,caKey3,caKey2,caKey3,caChkValue);
                if (iRet != SEC_OK )
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                ch_mvprintw(6,15,"Check Value:");
                ch_mvprintw(6,35,caChkValue);
                ch_getch(); 
                
                clScreen();
                memset(caChkValue,0,sizeof(caChkValue));
                iRet = GetPartChk(4,caKey1,caKey2,caKey3,caChkValue);
                if (iRet != SEC_OK )
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                ch_mvprintw(6,15,"Input Master Key OK!");
                ch_mvprintw(9,15,"ToTal Check Value:");
                ch_mvprintw(9,35,caChkValue);
                ch_getch(); 
                
                memset(caCmd,0,sizeof(caCmd));
                strcpy(caCmd,"./scubcrmskey ");
                strcat(caCmd,caKey1);
                strcat(caCmd," ");
                strcat(caCmd,caKey2);
                strcat(caCmd," ");
                strcat(caCmd,caKey3);
                strcat(caCmd,";");

                strcat(caCmd, "make -f ");
				strcat(caCmd, getenv("MKHOME"));
				strcat(caCmd, "/src/tools/topsec/src/sspcrmskey.mak;");

                strcat(caCmd, "/usr/bin/mv -f ");
				strcat(caCmd, getenv("MKHOME"));
				strcat(caCmd, "/src/tools/topsec/src/getmskey.c ");
				strcat(caCmd, getenv("MKHOME"));
				strcat(caCmd, "/src/tools/topsec/src/getmskey.tmp;");

                strcat(caCmd, "/usr/bin/rm -f ");
				strcat(caCmd, getenv("MKHOME"));
				strcat(caCmd, "/src/tools/topsec/src/getmskey.o ");

                if (system(caCmd))
                {
                    ch_mvprintw(6,15,"Generate Master Key Error!");
                }   
                clScreen();
                ch_mvprintw(6,15,"Generate Master Key OK!");
                ch_getch(); 
                break;
            case '2':
                memset(caKey1,0,sizeof(caKey1));
                memset(caKey2,0,sizeof(caKey2));
                memset(caKey3,0,sizeof(caKey3));
                memset(caMMkIdx,0,sizeof(caMMkIdx));

                clScreen();
                ch_mvprintw(9,15,"Input MMKey Index ");
                ch_move(9,35);
                for ( i = 0 ; i < 5 ; i ++ )
                {
                    iTmp = ch_getch();
                    caMMkIdx[i] = iTmp ;
                    caTmp[0] = iTmp ;
                    ch_mvprintw(9 ,35 + i,caTmp);
                    
                }
                ch_getch();
                ulMMKIdx = atol(caMMkIdx);
                
                clScreen();
                ch_mvprintw(3,35,"INPUT MMKEY");
                ch_mvprintw(6,15,"First part");
                ch_mvprintw(9,15,"Retype ");
                ch_move(6,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKey1[i] = iTmp ;
                    ch_mvprintw(6 ,30 + i,"*");
                    
                }   
                ch_move(9,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKeyTmp[i] = iTmp ;
                    ch_mvprintw(9 ,30 + i,"*");
                    
                }
                if (memcmp(  caKey1,caKeyTmp, SEC_3DES_KEY_LEN * 2))
                {
                    clScreen();
                    ch_mvprintw(6,15,"Input inconsistent!");
                    ch_getch(); 
                    break;
                    
                }
                ch_getch(); 

                clScreen();
                memset(caChkValue,0,sizeof(caChkValue));
                iRet = GetPartChk(2,caKey1,caKey2,caKey3,caChkValue);
                if (iRet != SEC_OK )
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                ch_mvprintw(6,15,"Check Value:");
                ch_mvprintw(6,35,caChkValue);
                ch_getch(); 

                clScreen();
                ch_mvprintw(3,35,"INPUT MMKEY");
                ch_mvprintw(6,15,"Second part");
                ch_mvprintw(9,15,"Retype ");
                ch_move(6,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKey2[i] = iTmp ;
                    ch_mvprintw(6 ,30 + i,"*");
                    
                }   
                ch_move(9,30);
                for ( i = 0 ; i < SEC_3DES_KEY_LEN * 2 ; i ++ )
                {
                    iTmp = ch_getch();
                    caKeyTmp[i] = iTmp ;
                    ch_mvprintw(9 ,30 + i,"*");
                    
                }
                if (memcmp(  caKey2,caKeyTmp, SEC_3DES_KEY_LEN * 2))
                {
                    clScreen();
                    ch_mvprintw(6,15,"Input inconsistent!");
                    ch_getch(); 
                    break;
                    
                }
                ch_getch(); 

                clScreen();
                memset(caChkValue,0,sizeof(caChkValue));
                iRet = GetPartChk(2,caKey2,caKey2,caKey3,caChkValue);
                if (iRet != SEC_OK )
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                ch_mvprintw(6,15,"Check Value:");
                ch_mvprintw(6,35,caChkValue);
                ch_getch(); 
                
                clScreen();
                memset(caChkValue,0,sizeof(caChkValue));
                iRet = GetPartChk(3,caKey1,caKey2,caKey3,caChkValue);
                if (iRet != SEC_OK )
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                ch_mvprintw(6,15,"Input MMKey OK!");
                ch_mvprintw(9,15,"ToTal Check Value:");
                ch_mvprintw(9,35,caChkValue);
                ch_getch(); 

                iKeyLen = 16;
                if ((iRet = comASCIIToBCD(caBnkKey1,&iKeyLen,1,
                    caKey1,SEC_3DES_KEY_LEN*2) ) != SEC_OK)
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
    
                iKeyLen = 16;
                if ((iRet = comASCIIToBCD(caBnkKey2,&iKeyLen,1,caKey2,
                        SEC_3DES_KEY_LEN*2))   != SEC_OK)
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   

                for ( i = 0 ; i < SEC_3DES_KEY_LEN ; i ++)
                {
                    caBnkKey1[i] = caBnkKey1[i] ^ caBnkKey2[i] ;
                }   
                
                
                iRet  = InsertMMKey(ulMMKIdx,caBnkKey1);
                if (iRet != SEC_OK)
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   

                iRet = SaveMMKey();
                if (iRet != SEC_OK)
                {
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
                }   
                
                clScreen();
                ch_mvprintw(6,15,"Generate MMKey OK!");
                ch_getch(); 

                break;
            case '3':
                clScreen();
                memset(caKey1,0,sizeof(caKey1));
                memset(caKey2,0,sizeof(caKey2));
                memset(caKey3,0,sizeof(caKey3));
                memset(caMMkIdx,0,sizeof(caMMkIdx));
                ch_mvprintw(3,35,"INITIALIZE DATA KEY");
                ch_mvprintw(6,15,"Input OrgId");
                ch_mvprintw(9,15,"Input MMKey Index ");
                ch_move(6,35);
                for ( i = 0 ; i < SEC_ORGIDX_LEN  ; i ++ )
                {
                    iTmp = ch_getch();
                    caOrgIdx[i] = iTmp ;
                    memset(caTmp,0,sizeof(caTmp));
                    caTmp[0] = iTmp ;
                    ch_mvprintw(6 ,35 + i,caTmp);
                    
                }   
                ch_move(9,35);
                for ( i = 0 ; i < 5 ; i ++ )
                {
                    iTmp = ch_getch();
                    caMMkIdx[i] = iTmp ;
                    caTmp[0] = iTmp ;
                    ch_mvprintw(9 ,35 + i,caTmp);
                    
                }
                ch_getch();
                ulMMKIdx = atol(caMMkIdx);
				memset(&tExcKeyReq,'\0',sizeof(T_ExcKeyReq));
				memcpy(tExcKeyReq.caOrgIdx,caOrgIdx,SEC_ORGIDX_LEN);
                tExcKeyReq.nMMKIdx = ulMMKIdx;
				iRet = GetMMKeyChkValue(tExcKeyReq.nMMKIdx,caChkValue);
				if(iRet != SEC_OK)
				{
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
				}
				iChkValueLen = 8*2;
				iRet = comBCDToASCII((unsigned char*)tExcKeyReq.caKey,
				                  &iChkValueLen,(char*)caChkValue,8,16,1);
				if(iRet != SEC_OK)
				{
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
				}
									
				tExcKeyReq.lKeyLen=SEC_DES_KEY_LEN*2;
				tExcKeyReq.caCheckValue[0]=(char)0x8C;
				tExcKeyReq.caCheckValue[1]=(char)0xA6;
				tExcKeyReq.caCheckValue[2]=(char)0x4D;
				tExcKeyReq.caCheckValue[3]=(char)0xE9;
				tExcKeyReq.caCheckValue[4]=(char)0xC1;
				tExcKeyReq.caCheckValue[5]=(char)0xB1;
				tExcKeyReq.caCheckValue[6]=(char)0x23;
				tExcKeyReq.caCheckValue[7]=(char)0xA7;
				tExcKeyReq.lTimeOut=0;
				tExcKeyReq.cKeyUsage=SEC_MAC_KEY;
				iRet = ExchangeKey(&tExcKeyReq);
				if(iRet != SEC_OK)
				{
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
				}
									
				tExcKeyReq.cKeyUsage=SEC_PIN_KEY;
				iRet=ExchangeKey(&tExcKeyReq);
				if(iRet != SEC_OK)
				{
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
				}
									
				tExcKeyReq.cKeyUsage=SEC_DES_KEY;
				iRet=ExchangeKey(&tExcKeyReq);
				if(iRet != SEC_OK)
				{
                    GetErrMsg(iRet,caErrMsg);
                    clScreen();
                    ch_mvprintw(6,15,caErrMsg);
                    ch_getch(); 
                    break;
				}
				
				memset(caKeyTmp,0,sizeof(caKeyTmp));
				memcpy(caKeyTmp,tExcKeyReq.caKey,SEC_DES_KEY_LEN*2);					
                clScreen();
                ch_mvprintw(6,15,"Data Key    :");
                ch_mvprintw(6,30,caKeyTmp);
                ch_mvprintw(9,15,"Check Value :  8CA64DE9C1B123A7");
                ch_mvprintw(12,15,"Initialize Data Key OK!");
                ch_getch(); 

                break;      
            case '4':
                ch_endwin();
                exit(0);
                break;      
        }  
    }   
}
