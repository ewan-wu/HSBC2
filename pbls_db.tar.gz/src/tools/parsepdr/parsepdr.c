#include <stdio.h>
#include <stdlib.h>
#include <iconv.h>
#include <errno.h>

/* �ַ���ʽת��
   ���� outlen: ���ص��ַ������� */
int code_convert(char *from_charset, char *to_charset,
				char *inbuf, int inlen,
				char *outbuf, int* outlen)
{
	iconv_t cd;
	int rc;
	char **pout = &outbuf;
	char **pin = &inbuf;
	size_t iLen = (size_t)inlen;
	size_t oLen = BUFSIZ;
	
	cd = iconv_open(to_charset, from_charset);
	if(cd == 0)
		return -1;
	
	if(iconv(cd, pin, &iLen, pout, &oLen) == -1)
	{
		printf("iconv error[%d]\n", errno);
		return -1;
	}
	
	iconv_close(cd);
	
	//*outlen = (int)oLen;
	*outlen = BUFSIZ - (int)oLen;

	return 0;
}

/*utf-16 to gbk*/
int u2g(char *inbuf, int inlen, char *outbuf, int* outlen)
{
	return code_convert("UTF-16", "GBK", inbuf, inlen, outbuf, outlen);
}

/*gbk to utf-16*/
int g2u(char *inbuf, int inlen, unsigned char* outbuf, int* outlen)
{
	return code_convert("GBK", "UTF-16", inbuf, inlen, outbuf, outlen);
}

/*gbk to EBCDIC(IBM-1047)*/
int g2e(char *inbuf, int inlen, unsigned char* outbuf, int* outlen)
{
	return code_convert("GBK", "IBM-1047", inbuf, inlen, outbuf, outlen);
}

/*EBCDIC(IBM-1047) to gbk*/
int e2g(char *inbuf, int inlen, unsigned char* outbuf, int* outlen)
{
	return code_convert("IBM-1047", "GBK", inbuf, inlen, outbuf, outlen);
}

int main(int argc, char *argv[])
{
	char sFile[256];
	char sIn[586+1];
	char sType[6*2+1];
	unsigned char sOut[586*2+1];
	FILE *fp;
	int iIn, iOut;

	memset(sFile,0,sizeof(sFile));
	strcpy(sFile, argv[1]);

	fp = fopen(sFile, "r");
	if(NULL == fp)
	{
		printf("file open error\n");
		return -1;
	}

	while(0 == feof(fp))
	{
		memset(sIn, 0, sizeof(sIn));
		fread(sIn, 586, 1, fp);

		//record type
		memset(sType, 0, sizeof(sType));
		memcpy(sType, sIn, 6);

		memset(sOut, 0, sizeof(sOut));
		iIn = sizeof(sType);
		iOut = 0;
		e2g(sType, iIn, sOut, &iOut);

		if(memcmp(sOut, "FSLD41", 6) != 0)
		{
			memset(sOut, 0, sizeof(sOut));
			iIn = sizeof(sIn);
			iOut = 0;
			e2g(sIn, iIn, sOut, &iOut);
			printf("[%s]\n", sOut);
		}
		else
		{
			memset(sOut, 0, sizeof(sOut));
			iOut = 0;
			e2g(sIn, 105, sOut, &iOut);
			printf("[%s]\n", sOut);

			memset(sOut, 0, sizeof(sOut));
			iOut = 0;

/*
	{
		int i;
		unsigned char s[500];
		memset(s,0,sizeof(s));
		memcpy(s,sIn+105,472);
		for(i=0; i<472; i++)
		{
			printf("%02X ", s[i]);
			if((i+1)%40 == 0)
				printf("\n");
		}
		printf("\n\n");
	}
*/

			u2g(sIn+105, 472, sOut, &iOut);
			printf("[%s]\n", sOut);

/*
	{
		int i;
		printf("iOut[%d]\n", iOut);
		for(i=0; i<iOut; i++)
		{
			printf("%02X ", sOut[i]);
			if((i+1)%40 == 0)
				printf("\n");
		}
		printf("\n\n");
	}
*/
			memset(sOut, 0, sizeof(sOut));
			iOut = 0;
			e2g(sIn+105+472, 9, sOut, &iOut);
			printf("[%s]\n", sOut);
		}
	}

	fclose(fp);
}

