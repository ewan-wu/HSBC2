/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: DebugMemory.c                                               */
/* DESCRIPTIONS: The common routines for debug, including                    */
/*               DebugMemory -- Get the memory informaition                  */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

#include <malloc.h>

/*****************************************************************************/
/* FUNC:   void DebugMemory (char *psDesc);                                  */
/* INPUT:  psDesc      -- a description for the memory information           */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Get the memory information.                                       */
/*****************************************************************************/
void DebugMemory( char *psDesc)
{
	struct mallinfo info;
	info = mallinfo();
	printf("%s ----> %d\n", psDesc, info.uordblks);
}

