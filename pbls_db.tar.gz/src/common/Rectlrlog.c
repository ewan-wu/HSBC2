/******************************************************************************/
/*                                                                            */
/* Product: Top Kernel Banking System                                         */
/*          transaction atom module                                           */
/*   RecTlrLog		                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Description: ��¼����Ա������־                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Modification log:                                                          */
/*                                                                            */
/*     Date            Author              Description                        */
/*   --------       -----------          -----------------                    */
/*   20091014       jiawei shen          Initial                              */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ipc.h"
#include "glb_ext.h"
#include "wd_incl.h"
#include "remittype.h"
#include "glb_def.h"

int RecTlrLog(char *buf)
{
    int nRet = 0;
    char ssn[8 + 1];
    char systime[14 + 1];
    struct wd_pbtlrlog_area tTlrLog;
       
    memset(&ssn    ,0    ,sizeof(ssn)   ); 
    memset(&systime,0    ,sizeof(systime));
    memset(&tTlrLog,0    ,sizeof(struct wd_pbtlrlog_area));

    if (nNewTxnRefnoForSystem(ssn) != 0)
    {
        return -1;
    }

    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, systime);
 	
    sprintf(tTlrLog.tlr_ssn, "%s%s", systime, ssn);
	
    //printf("ssn=[%s]\n", tTlrLog.sTlrSsn);
    memcpy(tTlrLog.brno, it_tita.label.kinbr, sizeof(it_tita.label.kinbr));
    memcpy(tTlrLog.tlr_id, it_tita.label.tlrno, sizeof(it_tita.label.tlrno));
    memcpy(tTlrLog.act_time, systime, sizeof(systime) - 1);
    memcpy(tTlrLog.act_txn, it_tita.label.txno, sizeof(tTlrLog.act_txn) - 1);
    memcpy(tTlrLog.act_data1, buf, sizeof(tTlrLog.act_data1) - 1);
    memcpy(tTlrLog.ip_addr, it_tita.label.ip_addr, sizeof(tTlrLog.ip_addr) - 1);
    strcpy(tTlrLog.time_zone, "+8");
	
    nRet = DbsPBTLRLOG(DBS_INSERT, &tTlrLog);
    if(nRet != DB_OK)
    {
        return nRet;
    }
	
    return 0;
}

