/*************************************************************************/
/*  Kernel Banking System                                                */
/*  Copyright (c) 2002                                                   */
/*  Shanghai Huateng Software System Co., Ltd.                           */
/*  All Rights Reserved                                                  */
/*************************************************************************/

/**************************************************************/
/*  Name     : commDayCalc()                                  */
/*  Function : DATE CALCULATE ROUTINE                         */
/**************************************************************/

/****************************************************************************/
/*  INPUT/OUTPUT  Description                                               */
/*           typedef struct                                                 */
/*           {                                                              */
/*              short   nFunCd;         ->function code                     */
/*              char    sStartDay[9];   ->start day                         */
/*              char    sEndDay[9];     ->end day                           */
/*              int     nMonthCnt;      ->month count                       */
/*              int     nDayCntPer;     ->day count by 30 days per month    */
/*              int     nDayCntAct;     ->day count by actual               */
/*           } T_COMM_GDATE;                                                */
/****************************************************************************/
/****************************************************************************/
/* +-------+------------------------+-----------------------------------+   */
/* | FUNCD |          INPUT         |               OUTPUT              |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   1   |  sStartDay sEndDay     |  nDayCntAct                       |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   2   |  sStartDay sEndDay     |  nDayCntPer nMonthCnt             |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   3   |  sStartDay sEndDay     |  nDayCntPer nMonthCnt nDayCntAct  |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   4   |  sStartDay nMonthCnt   |  sEndDay                          |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   5   |  sStartDay nDayCntAct  |  sEndDay                          |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   6   |  sEndDay nDayCntAct    |  sStartDay                        |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   7   |  sEndDay nMonthCnt     |  sStartDay                        |   */
/* +-------+------------------------+-----------------------------------+   */
/* |   8   |  sStartDay             |  sEndDay                          |   */
/* |       +------------------------+-----------------------------------+   */
/* |       |  Check date valid.                                         |   */
/* |       |  return : 0   OK.                                          |   */
/* |       |         : 1   not valid.                                   |   */
/* |       |           The monthend day in sEndDay.                     |   */
/* |       |           Especialy for loan.                              |   */
/* +-------+------------------------+-----------------------------------+   */
/* |   9   |  sStartDay sEndDay     |  nMonthCnt (nature month)         |   */
/* |-------+------------------------+-----------------------------------|   */
/****************************************************************************/
#include <string.h>
#include <stdlib.h>
#include "cmdate.h"

static  int  rtncdy, rtncdl;
static  int  nDayCntAct, ddsavs, ddsave, mmsav, yysav;
static  char temp[9];
static  int  m[12]={31,28,31,30,31,30,31,31,30,31,30,31};
static  int  syyyy, smm, sdd;
static  int  eyyyy, emm, edd;
static  int  yyyy, mm, dd;
static  int  COMM_DAYCALC_RTNCD;

T_COMM_GDATE   wc_gdate;

void  commDayCalc01();
void  commDayCalc02();
void  commDayCalc03();
void  commDayCalc04();
void  commDayCalc05();
void  commDayCalc06();
void  commDayCalc07();
void  commDayCalc08();
void  commDayCalc09();
void  commDayCalc10();
void  commDayCalc11();
int commItoa(int, char *, int);
int commApatoi(char *s);
int commValidNumber(char *, int);

int  commDayCalc( T_COMM_GDATE *t_comm_gdate)         /* main function */
{
	memcpy(&wc_gdate,t_comm_gdate,(sizeof wc_gdate));

	wc_gdate.sStartDay[8]=0x00;
	wc_gdate.sEndDay[8]=0x00;

	COMM_DAYCALC_RTNCD = 0;

	switch(wc_gdate.nFunCd)
	{
	case  1 :
	     wc_gdate.sStartDay[8] = wc_gdate.sEndDay[8] = '\0';
	     commDayCalc01();
	     break;
	case  2 :
	     commDayCalc02();
	     break;
	case  3 :
	     commDayCalc03();
	     break;
	case  4 :
	     commDayCalc04();
	     break;
	case  5 :
	     commDayCalc05();
	     break;
	case  6 :
	     commDayCalc08();
	     break;
	case  7 :
	     commDayCalc09();
	     break;
	case  8 :
	     commDayCalc10();
	     break;
	case  9 :
	     commDayCalc11();
	     break;
	default :
	     COMM_DAYCALC_RTNCD = 1;
	}

	memcpy(t_comm_gdate,&wc_gdate,(sizeof wc_gdate));
	return(COMM_DAYCALC_RTNCD);
}     /* end main program */

void commDayCalc01()
{
	strncpy(temp, &wc_gdate.sStartDay[0], 4);
	temp[4] = '\0';
	syyyy = atoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[4], 2);
	temp[2] = '\0';
	smm = atoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[6], 2);
	temp[2] = '\0';
	sdd = atoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[0], 4);
	temp[4] = '\0';
	eyyyy = atoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[4], 2);
	temp[2] = '\0';
	emm = atoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[6], 2);
	temp[2] = '\0';
	edd = atoi(temp);
	if  ((syyyy == 0 && smm == 0 && sdd == 0) ||
		(commValidNumber(wc_gdate.sStartDay, 8) != 0))
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	if  ((eyyyy == 0 && emm == 0 && edd == 0) ||
		(commValidNumber(wc_gdate.sEndDay, 8) != 0))
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	if  (strcmp(wc_gdate.sStartDay, wc_gdate.sEndDay) > 0)
	{
		COMM_DAYCALC_RTNCD = 4;
		return;
	}
	yyyy = eyyyy;
	mm = emm;
	dd = edd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	yyyy = syyyy;
	mm = smm;
	dd = sdd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	if  (syyyy == eyyyy && smm == emm)
	{
		wc_gdate.nDayCntAct = edd - sdd;
		COMM_DAYCALC_RTNCD = 0;
		return;
	}
	wc_gdate.nDayCntAct = m[smm - 1] - sdd;
	mm++;
	while (yyyy != eyyyy || mm != emm)
	{
		if  (mm > 12)
		{
			yyyy++;
	    	mm = 1;
	    	commDayCalc07();
	    	continue;
		}
		wc_gdate.nDayCntAct += m[mm - 1];
		mm++;
	}
	wc_gdate.nDayCntAct += edd;
	COMM_DAYCALC_RTNCD = 0;
}

void commDayCalc02()
{
	strncpy(temp, &wc_gdate.sStartDay[0], 4);
	temp[4] = '\0';
	syyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[4], 2);
	temp[2] = '\0';
	smm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[6], 2);
	temp[2] = '\0';
	sdd = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[0], 4);
	temp[4] = '\0';
	eyyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[4], 2);
	temp[2] = '\0';
	emm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[6], 2);
	temp[2] = '\0';
	edd = commApatoi(temp);
	if  ((syyyy == 0 && smm == 0 && sdd == 0) ||
		(commValidNumber(wc_gdate.sStartDay, 8) != 0))
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	if  ((eyyyy == 0 && emm == 0 && edd == 0) ||
		(commValidNumber(wc_gdate.sEndDay, 8) != 0))
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	if  (strcmp(wc_gdate.sStartDay, wc_gdate.sEndDay) > 0)
	{
		COMM_DAYCALC_RTNCD = 4;
		return;
	}
	yyyy = syyyy;
	mm = smm;
	dd = sdd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	ddsavs = m[mm - 1];
	yyyy = eyyyy;
	mm = emm;
	dd = edd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	ddsave = m[mm - 1];
	if  (sdd <= edd)
	{
		wc_gdate.nDayCntPer = edd - sdd;
		wc_gdate.nMonthCnt = ((eyyyy - syyyy) * 12) + emm - smm;
		COMM_DAYCALC_RTNCD = 0;
		return;
	}
	if  (edd == ddsave)
	{
		wc_gdate.nDayCntPer = 0;
		wc_gdate.nMonthCnt = ((eyyyy - syyyy) * 12) + emm - smm;
		COMM_DAYCALC_RTNCD = 0;
		return;
	}
	wc_gdate.nDayCntPer = ddsavs - sdd + edd;
	wc_gdate.nMonthCnt = ((eyyyy - syyyy) * 12) + emm - smm - 1;
	COMM_DAYCALC_RTNCD = 0;
	return;
}

void commDayCalc03()
{
	commDayCalc02();
	if  (COMM_DAYCALC_RTNCD == 0)
	{
		wc_gdate.nDayCntAct = wc_gdate.nDayCntPer + (wc_gdate.nMonthCnt * 30);
		COMM_DAYCALC_RTNCD = 0;
	}
	return;
}

void commDayCalc04()
{
	strncpy(temp, &wc_gdate.sStartDay[0], 4);
	temp[4] = '\0';
	syyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[4], 2);
	temp[2] = '\0';
	smm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[6], 2);
	temp[2] = '\0';
	sdd = commApatoi(temp);
	if  ((syyyy == 0 && smm == 0 && sdd == 0) ||
		(commValidNumber(wc_gdate.sStartDay, 8) != 0))
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	yyyy = syyyy;
	mm = smm;
	dd = sdd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	mmsav = smm + wc_gdate.nMonthCnt;
	yysav = syyyy;
	while (mmsav > 12)
	{
		mmsav -= 12;
		yysav++;
	}
	if  (mmsav == 2)
	{
		yyyy = yysav;
		commDayCalc07();
		if  (sdd > m[1])
			commItoa(m[1], &wc_gdate.sEndDay[6], 2);
		else commItoa(sdd, &wc_gdate.sEndDay[6], 2);
	}
	else 
	{
		commItoa(sdd, &wc_gdate.sEndDay[6], 2);
		if  (sdd > m[mmsav - 1])
			commItoa(m[mmsav - 1], &wc_gdate.sEndDay[6], 2);
	}
	commItoa(mmsav, &wc_gdate.sEndDay[4], 2);
	commItoa(yysav, &wc_gdate.sEndDay[0], 4);
	wc_gdate.sEndDay[8] = '\0';
	COMM_DAYCALC_RTNCD = 0;
	return;
}

void commDayCalc05()
{
	strncpy(temp, &wc_gdate.sStartDay[0], 4);
	temp[4] = '\0';
	syyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[4], 2);
	temp[2] = '\0';
	smm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[6], 2);
	temp[2] = '\0';
	sdd = commApatoi(temp);
	if  ((syyyy == 0 && smm == 0 && sdd == 0) ||
	(commValidNumber(wc_gdate.sStartDay, 8) != 0))
	{
	COMM_DAYCALC_RTNCD = 2;
	return;
	}
	if  (wc_gdate.nDayCntAct == 0)
	{
		COMM_DAYCALC_RTNCD = 6;
		return;
	}
	yyyy = syyyy;
	mm = smm;
	dd = sdd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	nDayCntAct = sdd + wc_gdate.nDayCntAct;
	if  (nDayCntAct <= m[mm - 1])
	{
		dd = nDayCntAct;
		commItoa(yyyy, &wc_gdate.sEndDay[0], 4);
		commItoa(mm, &wc_gdate.sEndDay[4], 2);
		commItoa(dd, &wc_gdate.sEndDay[6], 2);
		wc_gdate.sEndDay[8] = '\0';
		COMM_DAYCALC_RTNCD = 0;
		return;
	}
	else {
		do  {
			nDayCntAct -= m[mm++ - 1];
	        if  (mm > 12)
	            {
	             yyyy++;
	             mm = 1;
	             commDayCalc07();
	            }
			} while (nDayCntAct > m[mm -1]);
		dd = nDayCntAct;
		commItoa(yyyy, &wc_gdate.sEndDay[0], 4);
		commItoa(mm, &wc_gdate.sEndDay[4], 2);
		commItoa(dd, &wc_gdate.sEndDay[6], 2);
		wc_gdate.sEndDay[8] = '\0';
		return;
	}
}

void commDayCalc06()
{
	rtncdl = 0;
	if  (mm < 1 || mm > 12)
	{
		rtncdl = 1;
		return;
	}
	if  (dd < 1)
	{
		rtncdl = 1;
		return;
	}
	commDayCalc07();
	if  (dd > m[mm - 1])
		rtncdl = 1;
	return;
}

void commDayCalc07()
{
	if( !(yyyy % 4) && (yyyy % 100) || !(yyyy % 400) )
	{
		m[1] = 29;
		rtncdy = 1;
	}
	else {
		m[1] = 28;
		rtncdy = 0;
	}
	return;
}

void commDayCalc08()
{
	strncpy(temp, &wc_gdate.sEndDay[0], 4);
	temp[4] = '\0';
	eyyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[4], 2);
	temp[2] = '\0';
	emm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[6], 2);
	temp[2] = '\0';
	edd = commApatoi(temp);
	if  ((eyyyy == 0 && emm == 0 && edd == 0) ||
	(commValidNumber(wc_gdate.sEndDay, 8) != 0))
	{
	COMM_DAYCALC_RTNCD = 3;
	return;
	}
	if  (wc_gdate.nDayCntAct == 0)
	{
		COMM_DAYCALC_RTNCD = 6;
		return;
	}
	yyyy = eyyyy;
	mm = emm;
	dd = edd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	nDayCntAct = wc_gdate.nDayCntAct;
	if  (dd > wc_gdate.nDayCntAct)
	{
		dd -= nDayCntAct;
		commItoa(yyyy, &wc_gdate.sStartDay[0], 4);
		commItoa(mm, &wc_gdate.sStartDay[4], 2);
		commItoa(dd, &wc_gdate.sStartDay[6], 2);
		wc_gdate.sStartDay[8] = '\0';
		COMM_DAYCALC_RTNCD = 0;
		return;
	}
	else {
		do  {
	        nDayCntAct -= dd;
	        if  (--mm == 0)
	            {
	             yyyy--;
	             mm = 12;
	             commDayCalc07();
	            }
	        dd = m[mm - 1];
	       } while (nDayCntAct > dd);
		dd -= nDayCntAct;
		commItoa(yyyy, &wc_gdate.sStartDay[0], 4);
		commItoa(mm, &wc_gdate.sStartDay[4], 2);
		commItoa(dd, &wc_gdate.sStartDay[6], 2);
		wc_gdate.sStartDay[8] = '\0';
		return;
	}
}

void commDayCalc09()
{
	strncpy(temp, &wc_gdate.sEndDay[0], 4);
	temp[4] = '\0';
	eyyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[4], 2);
	temp[2] = '\0';
	emm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[6], 2);
	temp[2] = '\0';
	edd = commApatoi(temp);
	if  ((eyyyy == 0 && emm == 0 && edd == 0) ||
	(commValidNumber(wc_gdate.sEndDay, 8) != 0))
	{
	COMM_DAYCALC_RTNCD = 3;
	return;
	}
	if  (wc_gdate.nMonthCnt == 0)
	{
		COMM_DAYCALC_RTNCD = 6;
		return;
	}
	yyyy = eyyyy;
	mm = emm;
	dd = edd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	wc_gdate.nDayCntAct = (12 * (eyyyy - 1911)) + emm;
	if  (wc_gdate.nMonthCnt > wc_gdate.nDayCntAct)
	{
		COMM_DAYCALC_RTNCD = 7;
		return;
	}
	mmsav = emm;
	yysav = eyyyy;
	if  (mmsav <= wc_gdate.nMonthCnt)
	{
		do  {
	       mmsav += 12;
	       yysav--;
	      } while (mmsav <= wc_gdate.nMonthCnt);
	}
	mmsav -= wc_gdate.nMonthCnt;
	if  (mmsav == 2)
	{
		commDayCalc07();
		if  (edd > m[1])
	      commItoa(m[1], &wc_gdate.sStartDay[6], 2);
		else
	      commItoa(edd, &wc_gdate.sStartDay[6], 2);
	}
	else
	{
		commItoa(edd, &wc_gdate.sStartDay[6], 2);
		if  (edd > m[mmsav - 1])
	       commItoa(m[mmsav - 1], &wc_gdate.sStartDay[6], 2);
	}
	commItoa(yysav, &wc_gdate.sStartDay[0], 4);
	commItoa(mmsav, &wc_gdate.sStartDay[4], 2);
	wc_gdate.sStartDay[8] = '\0';
	COMM_DAYCALC_RTNCD = 0;
	return;
}

int commItoa(int val, char *cp, int min)
{
	unsigned char tempc[34], *tcp;
	int n = 0;
	unsigned int uval;
	static unsigned char dig[] = {"0123456789"};

	*(tcp = tempc + 33) = 0;
	uval = val;
	do { *--tcp = dig[uval % 10]; }
		while (uval /= 10);
	n = tempc + 33 - tcp;
	while (n < min)
	{
		*--tcp = '0';
		n++;
	}
	memcpy(cp, tcp, n);
	return n;
}

int commApatoi(char *s)
{
	register	int j;
	int sign;

	while (*s == ' ' || *s == '\t') ++s;
	sign = 0;
	if  (*s == '-') sign=1;
	else if  (*s != '+') --s;
	++s;
	for (j = 0; *s >= '0' && *s <= '9';)
		j = (j * 10) + (*s++ - '0');
	return(sign ? -j : j);
}

void commDayCalc10()
{
	strncpy(temp, &wc_gdate.sStartDay[0], 4);
	temp[4] = '\0';
	syyyy = atoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[4], 2);
	temp[2] = '\0';
	smm = atoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[6], 2);
	temp[2] = '\0';
	sdd = atoi(temp);
	if  ((syyyy == 0 && smm == 0 && sdd == 0) ||
		(commValidNumber(wc_gdate.sStartDay, 8) != 0))
	{
		memcpy(wc_gdate.sEndDay,"00000000",8);
		COMM_DAYCALC_RTNCD = 1;
		return;
	}
	yyyy = syyyy;
	mm = smm;
	dd = sdd;
	commDayCalc06();
	memcpy(wc_gdate.sEndDay,wc_gdate.sStartDay,8);
	commItoa(m[mm-1],&wc_gdate.sEndDay[6],2);
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 1;
		return;
	}
	COMM_DAYCALC_RTNCD = 0;
}

void commDayCalc11()
{
	strncpy(temp, &wc_gdate.sStartDay[0], 4);
	temp[4] = '\0';
	syyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[4], 2);
	temp[2] = '\0';
	smm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sStartDay[6], 2);
	temp[2] = '\0';
	sdd = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[0], 4);
	temp[4] = '\0';
	eyyyy = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[4], 2);
	temp[2] = '\0';
	emm = commApatoi(temp);
	strncpy(temp, &wc_gdate.sEndDay[6], 2);
	temp[2] = '\0';
	edd = commApatoi(temp);
	if  ((syyyy == 0 && smm == 0 && sdd == 0) ||
		(commValidNumber(wc_gdate.sStartDay, 8) != 0))
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	if  ((eyyyy == 0 && emm == 0 && edd == 0) ||
		(commValidNumber(wc_gdate.sEndDay, 8) != 0))
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	if  (strcmp(wc_gdate.sStartDay, wc_gdate.sEndDay) > 0)
	{
		COMM_DAYCALC_RTNCD = 4;
		return;
	}
	yyyy = syyyy;
	mm = smm;
	dd = sdd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 2;
		return;
	}
	ddsavs = m[mm - 1];
	yyyy = eyyyy;
	mm = emm;
	dd = edd;
	commDayCalc06();
	if  (rtncdl != 0)
	{
		COMM_DAYCALC_RTNCD = 3;
		return;
	}
	ddsave = m[mm - 1];

	wc_gdate.nMonthCnt = ((eyyyy - syyyy) * 12) + emm - smm;
	COMM_DAYCALC_RTNCD = 0;
	return;
}

int commValidNumber(char *sInputStr, int nLength)
{
  int  idx, ii;
  static unsigned char dig1[] = {"0123456789+-."};

  for (ii = 0; ii < nLength; ii++)
      {
       for (idx = 0; idx < 14; idx++)
           {
            if  (dig1[idx] != *(sInputStr + ii))
                continue;
            else break;
           }
       if  (idx > 13)
           return -1;
      }
  return 0;
}

