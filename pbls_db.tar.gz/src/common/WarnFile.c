/* [TRACE] */
/* TIVOLI_FILE=/tmp/PBLSWARN.dat */

#include <stdio.h>
#include <stdlib.h>
#include "glb_def.h"
#include "htlog.h"

void vWarnFileWrite(int type, char *str, char *logfile)
{
	int nRet, len;
	FILE *fp;
	char sCfgFileName[512+1];
	char sTraceFileName[512+1];
	char sWriteString[80+1];

	memset(sCfgFileName, 0, sizeof(sCfgFileName));
	sprintf(sCfgFileName, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);

	memset(sTraceFileName, 0, sizeof(sTraceFileName));
	nRet = pflGetProfileString("TRACE", "TIVOLI_FILE",
		sTraceFileName, 512, sCfgFileName);
	if (nRet != 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
			"vWarnFileWrite(): Trace File Not Define!\n");
		return;
	}

	fp = fopen(sTraceFileName, "a+");
	if (fp == NULL)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
			"vWarnFileWrite(): Open file error! [%s]\n", sTraceFileName);
		fclose(fp);
		return;
	}

	memset(sWriteString, 0, sizeof(sWriteString));
	memset(sWriteString, ' ', sizeof(sWriteString)-1);
	if (type == 0)
		memcpy(sWriteString, "PBLSSERR: ", 10);
	else
		memcpy(sWriteString, "PBLSWARN: ", 10);

	if (strlen(str) > 69)
	{
		memcpy(sWriteString+10, str, 69);
		sWriteString[10+69] = '\n';
	}
	else
	{
		memcpy(sWriteString+10, str, strlen(str));
		sWriteString[10+69] = '\n';
	}

	len = fwrite(sWriteString, 1, 80, fp);
	if (ferror(fp))
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
			"vWarnFileWrite(): Write file error! [%s]\n", sTraceFileName);
		fclose(fp);
		return;
	}

	fclose(fp);
	return;
}



