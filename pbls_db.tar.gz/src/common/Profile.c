#include "stdio.h"

#define PFL_PF_FALSE     0

typedef char * PFL_PSTR;

void pflClearBlank(char * line)
{
	int i = 0, j, k;
	char buf[256];

	while (line[i] != 0)
	{
		if (line[i] == ';' || line[i] == '\n')
		{
			line[i] = 0;
			/*
			for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); line[j--] = 0);
			*/
			if ( i != 0 )
         	{
            	for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); )
            	{
               		line[j] = 0;
               		if ( j == 0 ) break;
               		j--;
            	}
         	}
			break;
		}	
		i++;
	}
 
	i = 0;
	memset(buf, 0, 256);

	while ((line[i] != '=') && (i < strlen(line))) i++;
	if (i == strlen(line)) return;

	for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); j--);
	for (k = i + 1; (line[k] == ' ') || (line[k] == '\t'); k++);

	memcpy(buf, line, j + 1);
	buf[j + 1] = '=';
 	strcat(buf + j + 2, line + k);
 
	strcpy(line, buf);
}

int pflIsSection(char * line)
{
	return line[0] == '[';
}

int pflIsThisSection(char * line, char * pszSection)
{
	return !memcmp(line + 1, pszSection, strlen(pszSection));
}

int pflIsThisEntry(char * line, char * pszEntry)
{
	return (!memcmp(line, pszEntry, strlen(pszEntry)) &&
           line[strlen(pszEntry)] == '=') ;
} 

int pflCutContent(char * line, char * pszDestination, int cbReturnBuf)
{
	int i = 0;

	while (line[i++] != '=');

	strncpy(pszDestination, line + i, cbReturnBuf);

	return 0;
} 

int pflGetProfileString(PFL_PSTR pszSection, PFL_PSTR pszEntry, 
    PFL_PSTR pszDestination, int cbReturnBuf, PFL_PSTR pszFileName)
{
	FILE * fp;
	char line[256];
	int cbNum = -1;
	int InThisSection = PFL_PF_FALSE;
	
	fp = fopen(pszFileName, "r");
	if (fp == NULL) 
	{
		printf("Read INI fail!\n");
		return -1;
	}

	while (NULL !=	fgets(line, 256, fp))
	{
		pflClearBlank(line);

		if (pflIsSection(line))
		{
			InThisSection = pflIsThisSection(line, pszSection);
			continue;
		}

		if (InThisSection == PFL_PF_FALSE) continue;

		if (pflIsThisEntry(line, pszEntry))
		{
			cbNum = pflCutContent(line, pszDestination, cbReturnBuf);
			break;
		}
	}

	fclose(fp);

	if (cbNum == -1)
	{
		printf ("Read INI fail (1) !\n");
		return -1;
	}

	return cbNum;

}

int pflGetProfileInt(PFL_PSTR pszSection, PFL_PSTR pszEntry, 
	PFL_PSTR pszFileName)
{
	char buf[256];

	if (pflGetProfileString(pszSection, pszEntry, buf, 256, pszFileName) < 0)
		return -1;
	else
		return (int)atol(buf);
}

long pflGetProfileLong(PFL_PSTR pszSection, PFL_PSTR pszEntry, 
	 PFL_PSTR pszFileName)
{
	char buf[256];

	if (pflGetProfileString(pszSection, pszEntry, buf, 256, pszFileName) < 0)
		return -1;
	else
		return atol(buf);
}

