/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Send2To.c                                                   */
/* DESCRIPTIONS: The common routines for time out check, including           */
/*               Send2To    -- Send time out check message and get reply     */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/
#include "swttoc.h"
#include "msglog.h"
#include "msgque.h"


/*****************************************************************************/
/* FUNC:   short SwtSnd2To (SwtToReqDef *ptSwtToReq);                        */
/* INPUT:  ptSwtToReq     -- send to TOCTL request                           */
/* OUTPUT: ptSwtToReq     -- receive from TOCTL response                     */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Send time out check message to TOCTL and get reply.               */
/*****************************************************************************/

short SwtSnd2ToSSN (SwtToSSNReqDef *ptSwtToSSNReq)
{
    short nRet;
    short nDataLen;

    /* Send Request Message Into Toctl In Queue */
	nRet = nCommonMsqSend(sizeof(SwtToSSNReqDef)-sizeof(long), 
					(char *)ptSwtToSSNReq, ptSwtToSSNReq->nMsgCode, 
					CI_TOCTL_SSN);

    if (nRet != 0)
    {
        printf("\n Send To Toctl SSN Fail!\n");
        return -1;
    }
    
    /* Receive Reply Message From Toctl Out Queue */
	nRet = nCommonMsqOutRecv (&nDataLen, 
						(char *)ptSwtToSSNReq, 
						&ptSwtToSSNReq->nSwitchPID, 
						CI_TOCTL_SSN);
    if (nRet != 0)
    {
        printf("\n Receive From Toctl SSN Fail!\n");
        return -1;
    }

    return 0;
}

short SwtSnd2ToSEQ (SwtToSEQReqDef *ptSwtToSEQReq)
{
    short nRet;
    short nDataLen;

    /* Send Request Message Into Toctl In Queue */
	nRet = nCommonMsqSend(sizeof(SwtToSEQReqDef)-sizeof(long), 
					(char *)ptSwtToSEQReq, ptSwtToSEQReq->nMsgCode, 
					CI_TOCTL_SEQ);

    if (nRet != 0)
    {
        printf("\n Send To Toctl SEQ Fail!\n");
        return -1;
    }
    
    /* Receive Reply Message From Toctl Out Queue */
	nRet = nCommonMsqOutRecv (&nDataLen, 
						(char *)ptSwtToSEQReq, 
						&ptSwtToSEQReq->nSwitchPID, 
						CI_TOCTL_SEQ);
    if (nRet != 0)
    {
        printf("\n Receive From Toctl SEQ Fail!\n");
        return -1;
    }

    return 0;
}


