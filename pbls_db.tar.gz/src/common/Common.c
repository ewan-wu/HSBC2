/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Common.c                                                    */
/* DESCRIPTIONS: The common routines, including                              */
/*               CommonGetCurrentTime -- Get the system time by format       */
/*                                       (YYYYMMDDHHMMSS)                    */
/*               CommonGetCurrentDate -- Get the system date by format       */
/*                                       (YYYYMMDD)                          */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <sys/timeb.h>

#include "glb_def.h"
#include "ipc.h"
#include "wd_incl.h"

#define MAX_BUF     36

static struct timeb inittime, starttime, endtime;

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentDate (char *sCurrentDate);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentDate   -- the string of current date                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system date with the format (YYYYMMDD).                   */
/*****************************************************************************/
void  CommonGetCurrentDate(char *sCurrentDate)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
/*
   _tzset();
*/
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentDate, "%4d%02d%02d", tmCurrentTime->tm_year + 1900, 
           tmCurrentTime->tm_mon + 1, tmCurrentTime->tm_mday);
}

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentTime (char *sCurrentTime);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentTime   -- the string of current time                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system time with the format (YYYYMMDDhhmmss).             */
/*****************************************************************************/
void CommonGetCurrentTime(char *sCurrentTime)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
   tzset();
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d", 
           tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1, 
           tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec);
}

void CommonGetCurrentTimeDB(char *sCurrentTime)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
   tzset();
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentTime, "%4d/%02d/%02d %02d:%02d:%02d", 
           tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1, 
           tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec);
}

/* ȡ��ȷ�������ʱ�������ʽ:YYYYMMDDHHMMSSNNNNNN������:20 */
void CommonGetCurrentTimeMilli(char *sCurrentTime)
{  
   struct timeb tmb;
   struct tm *tmCurrentTime;
   
   tzset();
   ftime(&tmb);
   tmCurrentTime = localtime(&tmb.time);
   sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d%06d", 
           tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1, 
           tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec,
           tmb.millitm);
}

/* from Comm1.c */
char *GetSystemTime(void)
{
   time_t current;
   struct tm *tmCurrentTime;
   static char stime[30];

   memset(stime, 0, sizeof(stime));

   time(&current);
   tmCurrentTime = localtime(&current);

   sprintf(stime, "%04d-%02d-%02d %02d:%02d:%02d",
                1900 + tmCurrentTime->tm_year,
                tmCurrentTime->tm_mon+1,
                tmCurrentTime->tm_mday,
                tmCurrentTime->tm_hour,
                tmCurrentTime->tm_min ,
                tmCurrentTime->tm_sec );

   return stime;


}

char *GetCurTime(void)
{
	long tt;
	time(&tt);
	return((char *)ctime(&tt));
}

/* ���ز������з���ʱ�� */
char *GetCurTime1(void)
{
	static char str[25];
	long tt;

	time(&tt);
	memset(str, 0, sizeof(str));
	memcpy(str, ctime(&tt), 24);
	return str;
}

/* ���ز������з���ʱ�� ��ʽ YYYY/mm/dd HH:MM:SS*/
char *GetCurTime2(void)
{
	time_t current;
	struct tm *tmCurrentTime;
	static char str[25];

	memset(str, 0, sizeof(str));

	tzset();
	time(&current);
	tmCurrentTime = localtime(&current);
	sprintf(str, "%4d/%02d/%02d %02d:%02d:%02d", 
		tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1, 
		tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
		tmCurrentTime->tm_min, tmCurrentTime->tm_sec);

	return str;
}

int CommonInterval(const char *date1, const char *date2)
{
    char year[5], month[3], day[3];
    struct tm   time1, time2;
    time_t	time_1, time_2;

    memset(year, 0, sizeof(year));
    memset(month, 0, sizeof(month));
    memset(day, 0, sizeof(day));

    /* make up date 1 */
    memcpy(year, date1, 4);
    memcpy(month, date1 + 4, 2);
    memcpy(day, date1 + 6, 2);
    time1.tm_year  = atoi(year) - 1900;
    time1.tm_mon   = atoi(month) - 1;
    time1.tm_mday  = atoi(day);
    time1.tm_hour  = 0;
    time1.tm_min   = 0;
    time1.tm_sec   = 1;
    time1.tm_isdst = -1;

    if ((time_1 = mktime(&time1)) == -1)
    {
		/* date format error */
		return -1;
    }

    /* make up date 2 */
    memcpy(year, date2, 4);
    memcpy(month, date2 + 4, 2);
    memcpy(day, date2 + 6, 2);

    time2.tm_year  = atoi(year) - 1900;
    time2.tm_mon   = atoi(month) - 1;
    time2.tm_mday  = atoi(day);
    time2.tm_hour  = 0;
    time2.tm_min   = 0;
    time2.tm_sec   = 1;
    time2.tm_isdst = -1;

    if ((time_2 = mktime(&time2)) == -1)
    {
		/* date format error */
		return -1;
    }

    /* calculate interval */
    return abs((int)(difftime(time_1, time_2) / 24 / 60 / 60));
}

void SetTimeStart(char *sDesc)
{
	ftime(&inittime);
	memcpy(&starttime, &inittime, sizeof(inittime));
	printf("Time Begin [%s]\n",sDesc );
}

void GetTimeDiff(char *sDesc)
{
	ftime(&endtime);
	printf("Time Middle [%s], Diff in sec[%d] misec[%d]\n",sDesc,
		endtime.time - starttime.time, endtime.millitm - starttime.millitm);
	memcpy(&starttime, &endtime, sizeof(endtime));
}

void GetTimeTotal(char *sDesc)
{
	ftime(&endtime);
	printf("Time End [%s], Diff in sec[%d] misec[%d]\n",
		sDesc, endtime.time - inittime.time,
		endtime.millitm - inittime.millitm );
}

/******************************************************************************/
/*  Function     : apitoa()                                                   */
/*  Description  : convert integer data into string without '\0' terminated   */
/*  Arguments    : inum - input integer data                                  */
/*                 len - required length to convert                           */
/*                 obuf - string without 0x00 terminated                      */
/*  Return Value : void                                                       */
/******************************************************************************/
void apitoa(int inum, int len, char *obuf)
{
    char    temp[50];
    char    fmt[10];

    sprintf(fmt, "%%0%dld", len);
    sprintf(temp, fmt, inum);
    memcpy(obuf, temp, len);
}

/******************************************************************************/
/*  Function     : apatoi()                                                   */
/*  Description  : convert ascii buffer into integer value with input length  */
/*  Arguments    : ibuf - input ascii buffer                                  */
/*                 len - required length to convert                           */
/*  Return Value : integer value                                              */
/******************************************************************************/
int apatoi(char *ibuf, int len)
{
    char    temp[16];

    memset(temp, '\0', sizeof(temp));
    memcpy(temp, ibuf, len);
    return(atoi(temp));
}

/******************************************************************************/
/*  Function     : str2dbl()                                                  */
/*  Description  : convert ascii buffer into double value with input length   */
/*                 and precision                                              */
/*  Arguments    : ibuf - input ascii buffer                                  */
/*                 ibuflen - require length to convert                        */
/*                 idot - dot position                                        */
/*                 obuf - pointer to double value                             */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int str2dbl(char *ibuf, short ibuflen, short idot, double *obuf)
{
    char    lstrbuf[MAX_BUF];
    short   i;

    if(strlen(ibuf) < ibuflen)
        return SYS_FAIL;

    if(strlen(ibuf) < idot)
        return SYS_FAIL;

    if(ibuflen < idot)
        return SYS_FAIL;

    for(i = 0; i < ibuflen+1; i ++)
    {
        if(i == (ibuflen - idot))
            lstrbuf[i] = '.';
        else
            lstrbuf[i] = *ibuf++;
    }

    lstrbuf[i] = '\0';

    *obuf = atof(lstrbuf);

    return SYS_OK;
}

/******************************************************************************/
/*  Function     : dbl2str()                                                  */
/*  Description  : convert double data to string without '\0' terminated      */
/*  Arguments    : idbl - pointer to double data                              */
/*                 idot - dot position                                        */
/*                 ilen - required length to convert                          */
/*                 isign - set to 1 if '+/-' sign needed                      */
/*                 obuf - output buffer                                       */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int dbl2str(double *idbl, short idot, short ilen, short isign, char *obuf)
{
    char    lstrbuf[ MAX_BUF ];
    char    lstrtmp[ MAX_BUF ];
    char    Lstr[ MAX_BUF ];
    char    fmt[10];
    char    *p1;
    double  ldbl;

    /*********** check input data ****************/
    if( idot > ilen )
        return SYS_FAIL;
    /*********** truncate ************************/
    ldbl=*idbl;
    dbltrunc( &ldbl,idot );

    sprintf(fmt,"%%+#0%d.%df",ilen+2,idot);
    sprintf(lstrbuf,fmt,ldbl);
    strcpy(lstrtmp,&lstrbuf[1]);

    if ( isign != 0 )
    {
        strcpy(Lstr,lstrtmp);
        p1=strtok(Lstr,".");
        if ( strlen(p1) > ( ilen - idot - 1 ) )
            memcpy(&lstrbuf[1],&lstrtmp[strlen(p1)-ilen+idot+1],
                ilen-idot);
        else
            strcpy(&lstrbuf[1],p1);
        p1=strtok(NULL,".");
        memcpy(&lstrbuf[ilen-idot],p1,idot);
        if ( *idbl >= 0 )
        {
            /*
            lstrbuf[0]='+';
            */
            lstrbuf[0]=lstrtmp[0];
        }
        else
            lstrbuf[0]='-';
    }
    else
    {
        strcpy(Lstr,lstrtmp);
        p1=strtok(Lstr,".");
        if ( strlen(p1) > ( ilen - idot ) )
            memcpy(lstrbuf,&lstrtmp[strlen(p1)-ilen+idot],
                ilen-idot);
        else
            strcpy(lstrbuf,p1);

        p1=strtok(NULL,".");
        memcpy(&lstrbuf[ilen-idot],p1,idot);
    }
    memcpy(obuf,lstrbuf,ilen);
    return SYS_OK;
}

int dbltrunc(double *ival, int itnclen)
{
    char lstrbuf[ MAX_BUF ];
    char lfmt[ MAX_BUF ];
    int lofset,len;
    double  temp;

    sprintf(lfmt,"%%.%df",itnclen+1);
    sprintf(lstrbuf,lfmt,*ival);
    len=strlen(lstrbuf);
    for(lofset=0; ( lofset < len) && ( lstrbuf[lofset] != '.') ; lofset++);
    if ( itnclen >= 0 )
        memset(&lstrbuf[lofset+itnclen+1],0x00,
            MAX_BUF - (lofset+itnclen+2 ));
    else
    {
        memset(&lstrbuf[lofset+itnclen],'0', itnclen * -1 );
        memset(&lstrbuf[lofset],0x00, MAX_BUF -lofset+1 );
    }
    temp=atof(lstrbuf);
    *ival=temp;
    return SYS_OK;
}


int nStringDelete(char *sBuf, int len, char c1, char c2)
{
	int i, j;
	/*
	char sStr[60*10240];
	*/
	char sStr[1200*1024];

	if (len <= 0) return 0;

	j = 0;
	memset(sStr, 0, sizeof(sStr));

	for (i=0; i<len; i++)
	{
		if (c1 != '\0')
		{
			if (sBuf[i] == c1)
				continue;
		}
		if (c2 != '\0')
		{
			if (sBuf[i] == c2)
				continue;
		}
		sStr[j] = sBuf[i];
		j++;
	}
	
	memset(sBuf, 0, len);
	if (j == 0)
	{
		return 0;
	}
	else
	{
		memcpy(sBuf, sStr, j);
		return j;
	}
}

int nCHExpatPatch(unsigned char *sBuf, int len)
{
	int i, j;
	unsigned char sStr[10240];

	if (len <= 0) return 0;

	j = 0;
	memset(sStr, 0, sizeof(sStr));

	for (i=0; i<len; i++)
	{
		if ((sBuf[i] != 0xC2) && (sBuf[i] != 0xC3))
		{
			sStr[j] = sBuf[i];
		}
		else
		{
			if (sBuf[i] == 0xC2)
			{
				sStr[j] = sBuf[i+1];
			}
			else /* 0xC3 */
			{
				sStr[j] = sBuf[i+1] + 0x40;
			}
			i++;
		}
		j++;
	}

	memset(sBuf, 0, len);
	if (j == 0)
	{
		return 0;
	}
	else
	{
		memcpy(sBuf, sStr, j);
		return j;
	}
}

/* replace all "c1" with "c2" */
void vStringReplace(char *sBuf, int len, char c1, char c2)
{
	int i;

	if (len <= 0) return;

	for (i=0; i<len; i++)
	{
		if (sBuf[i] == c1)
			sBuf[i] = c2;
	}
	return;
}

/*****************************************************************************/
/* FUNC:   Process_MoveTotaCommon (T_TITA_LABTEX *, T_TOTW_LABTEX* )         */
/* INPUT:  nInBufLen       sInBuf                                            */
/* OUTPUT: nOutBufLen      sOutBuf                                           */
/* RETURN: ��                                                                */
/*                                                                           */
/* DESC:   ��TITAͷ�����ݸ�ֵ��TOTAͷ                                        */
/*****************************************************************************/
void TitaMoveTotaCommon(T_TITA_LABTEX *ptMngInBuf, T_TOTW_LABTEX *ptMngOutBuf)
{
    memcpy(ptMngOutBuf->label.header, ptMngInBuf->label.header,
        sizeof(ptMngOutBuf->label.header));
    memcpy(ptMngOutBuf->label.clsno, ptMngInBuf->label.clsno,
        sizeof(ptMngOutBuf->label.clsno));
    memcpy(ptMngOutBuf->label.termid, ptMngInBuf->label.termid, 
        sizeof(ptMngOutBuf->label.termid));
    memcpy(ptMngOutBuf->label.kinbr, ptMngInBuf->label.kinbr, 
        sizeof(ptMngOutBuf->label.kinbr));
    memcpy(ptMngOutBuf->label.trmseq, ptMngInBuf->label.trmseq, 
        sizeof(ptMngOutBuf->label.trmseq));
    ptMngOutBuf->label.tmtype = ptMngInBuf->label.tmtype ;
    memcpy(ptMngOutBuf->label.taskid, ptMngInBuf->label.taskid,
        sizeof(ptMngOutBuf->label.taskid));
    memcpy(ptMngOutBuf->label.txno, ptMngInBuf->label.txno,
        sizeof(ptMngOutBuf->label.txno));
    memcpy(ptMngOutBuf->label.tlrno, ptMngInBuf->label.tlrno,
        sizeof(ptMngOutBuf->label.tlrno));
    memcpy(ptMngOutBuf->label.ejfno, ptMngInBuf->label.ejfno,  
        sizeof(ptMngOutBuf->label.ejfno));

    memcpy(ptMngOutBuf->label.txdate, gsDBTxdate,
        sizeof(ptMngOutBuf->label.txdate));
    
    memcpy(ptMngOutBuf->label.txtime, gsDBTxtime,
        sizeof(ptMngOutBuf->label.txtime));

    ptMngOutBuf->label.msgend = '0';
    ptMngOutBuf->label.msgtype = 'H';
    memcpy(ptMngOutBuf->label.msgno, ptMngInBuf->label.txno,
        sizeof(ptMngOutBuf->label.msgno));
    memcpy(ptMngOutBuf->label.msglng, "0000", 4);
    memcpy(ptMngOutBuf->label.inq_id, ptMngInBuf->label.inq_id,
        sizeof(ptMngOutBuf->label.inq_id));
}
/*****************************************************************************/
/* FUNC:   RecMonitor(char *pId	,char *pActNo , char *pMsgType )             */
/* INPUT:  pId,pActNo,pMsgType                                               */
/* OUTPUT: int                                                               */
/* RETURN: ��                                                                */
/*                                                                           */
/* DESC:   ��¼��Ϣ��ر�                                                    */
/*****************************************************************************/
int RecMonitor(char *pId ,char *pActNo , char *pMsgType )
{
/*
	struct wd_pbmsgmonitor_area	wd_pbmsgmonitor;
	char sId[16+1];
	char sActNo[34+1];
	char sMsgType[5+1];
	int  nRet = 0 ;

	memset(&sId		,0	,sizeof(sId		));
	memset(&sActNo	,0	,sizeof(sActNo	));
	memset(&sMsgType,0	,sizeof(sMsgType));
	memset(&wd_pbmsgmonitor	,0	,sizeof(wd_pbmsgmonitor));

	strcpy(sId	 ,pId);
	strcpy(sActNo,pActNo);
	strcpy(sMsgType,pMsgType);

	memcpy(wd_pbmsgmonitor.id		,sId		,sizeof(sId) - 1 );
	nRet = DbsPBMSGMONITOR(DBS_FIND,&wd_pbmsgmonitor);
	printf("DbsPBMSGMONITOR DBS_FIND return [%d]", nRet);
	if(nRet == DB_OK)
	{
		memcpy(wd_pbmsgmonitor.id       ,sId        ,sizeof(sId     ) - 1 );
		memcpy(wd_pbmsgmonitor.actno    ,sActNo     ,sizeof(sActNo  ) - 1 );
		memcpy(wd_pbmsgmonitor.msg_type ,sMsgType   ,sizeof(sMsgType) - 1 );
		wd_pbmsgmonitor.status[0] = '1';      
		wd_pbmsgmonitor.notice_flag[0] = '1'; 
		CommonGetCurrentDate(wd_pbmsgmonitor.txdate); 
		CommonGetCurrentTime(wd_pbmsgmonitor.txtime); 
		
		nRet = DbsPBMSGMONITOR(DBS_IUPD,&wd_pbmsgmonitor);
		if( nRet != DB_OK )
		{
		    printf("DbsPBMSGMONITOR DBS_IUPD return [%d]", nRet);
		    return -1 ;
		}

	}
	else
	{ 
		memcpy(wd_pbmsgmonitor.id		,sId		,sizeof(sId		) - 1 );
		memcpy(wd_pbmsgmonitor.actno	,sActNo		,sizeof(sActNo	) - 1 );
		memcpy(wd_pbmsgmonitor.msg_type	,sMsgType	,sizeof(sMsgType) - 1 );
		wd_pbmsgmonitor.status[0] = '1';     
		wd_pbmsgmonitor.notice_flag[0] = '1'; 
		CommonGetCurrentDate(wd_pbmsgmonitor.txdate);
		CommonGetCurrentTime(wd_pbmsgmonitor.txtime); 
		nRet = DbsPBMSGMONITOR(DBS_INSERT,&wd_pbmsgmonitor);
		if( nRet != DB_OK )
		{
		    printf("DbsPBMSGMONITOR DBS_INSERT return [%d]", nRet);
			return -1 ;
		}
	}
*/
	return 0;
}

/* �յ�Ӧ���ĺ������Ϣ��ر�״̬ 
   ���� 0-�ɹ� other-ʧ��*/
int UpdMonitor(char *sId, char *sStatus)
{
/*
	struct wd_pbmsgmonitor_area	wd_pbmsgmonitor;
	int nRet;
	
	memset(&wd_pbmsgmonitor, 0, sizeof(wd_pbmsgmonitor));
	nRet = 0;
	
	memcpy(wd_pbmsgmonitor.id, sId, sizeof(wd_pbmsgmonitor.id)-1);
	nRet = DbsPBMSGMONITOR(DBS_LOCK,&wd_pbmsgmonitor);
	if( nRet != DB_OK )
	{
		printf("lock pbmsgmonitor error, sqlcode[%d] id[%s]\n", nRet, wd_pbmsgmonitor.id);
		return nRet ;
	}
	
	memcpy(wd_pbmsgmonitor.status, sStatus, sizeof(wd_pbmsgmonitor.status)-1);
	nRet = DbsPBMSGMONITOR(DBS_UPDATE,&wd_pbmsgmonitor);
	if( nRet != DB_OK )
	{
		printf("update pbmsgmonitor error, sqlcode[%d]\n", nRet);
		return nRet ;
	}
	
	DbsPBMSGMONITOR(DBS_CLOSE,&wd_pbmsgmonitor);
	*/
	return 0;
}

/*****************************************************************************/
/* FUNC:   GetSysPara(char *pParaNo	,char *pParaValue)                       */
/* INPUT:  pParaNo                                                           */
/* OUTPUT: pParaValue                                                        */
/* RETURN: int                                                               */
/*                                                                           */
/* DESC:   ��ȡϵͳ����                                                      */
/*****************************************************************************/
int  GetSysPara(char *pParaNo ,char *pParaValue)
{
	int nRet = 0;
	
	struct wd_pbsyspara_area	wd_pbsyspara;

	memset(&wd_pbsyspara	,0	,sizeof(wd_pbsyspara));
	memcpy(wd_pbsyspara.para_no	,pParaNo	,sizeof(wd_pbsyspara.para_no)-1);
	memcpy(wd_pbsyspara.brno	,"000"		,strlen("000"));
	nRet = DbsPBSYSPARA(DBS_FIND	,&wd_pbsyspara);
	if( nRet != DB_OK )
	{
		
		return nRet;
	}

	strcpy(pParaValue	,wd_pbsyspara.para_val);

	return 0;
}

/* �յ�Ӧ���ĺ����ICBC��ѯ���ı�״̬��Ӧ����ϸ���� 
   ���� 0-�ɹ� other-ʧ��*/
int UpdICBCInq(char *sId, char *sStatus, int iRspCnt)
{
	struct wd_pbicbcinq_area	wd_pbicbcinq;
	int nRet;
	
	memset(&wd_pbicbcinq, 0, sizeof(wd_pbicbcinq));
	nRet = 0;
	
	memcpy(wd_pbicbcinq.id, sId, sizeof(wd_pbicbcinq.id)-1);
	nRet = DbsPBICBCINQ(DBS_LOCK,&wd_pbicbcinq);
	if( nRet != DB_OK )
	{
		printf("lock pbicbcinq error, sqlcode[%d] id[%s]\n", nRet, wd_pbicbcinq.id);
		return nRet ;
	}
	
	memcpy(wd_pbicbcinq.status, sStatus, sizeof(wd_pbicbcinq.status)-1);
	wd_pbicbcinq.rsp_cnt = iRspCnt;
	nRet = DbsPBICBCINQ(DBS_UPDATE,&wd_pbicbcinq);
	if( nRet != DB_OK )
	{
		printf("update pbicbcinq error, sqlcode[%d]\n", nRet);
		return nRet ;
	}
	
	DbsPBICBCINQ(DBS_CLOSE,&wd_pbicbcinq);
	return 0;
}

/* �յ�ICBCFEӦ����0000 ����Pbicbctxn ״̬
   ���� 0-�ɹ� other-ʧ��*/
int UpdPbicbctxnInq(char *sId, char *sStatus, int iRspCnt)
{
	struct	wd_pbicbctxn_area wdPbicbctxn;
	int nRet;
	
	memset(&wdPbicbctxn, 0, sizeof(wdPbicbctxn));
	nRet = 0;
	
	memcpy(wdPbicbctxn.id, sId, sizeof(wdPbicbctxn.id)-1);
	nRet = DbsPBICBCTXN(DBS_LOCK,&wdPbicbctxn);
	if( nRet != DB_OK )
	{
		printf("lock wdPbicbctxn error, sqlcode[%d] id[%s]\n", nRet, wdPbicbctxn.id);
		return nRet ;
	}
	
	memcpy(wdPbicbctxn.status, sStatus, sizeof(wdPbicbctxn.status)-1);
	nRet = DbsPBICBCTXN(DBS_UPDATE,&wdPbicbctxn);
	if( nRet != DB_OK )
	{
		printf("update DbsPBICBCTXN error, sqlcode[%d]\n", nRet);
		return nRet ;
	}
	
	DbsPBICBCTXN(DBS_CLOSE,&wdPbicbctxn);
	return 0;
}
