/*****************************************************************************/
/*																			 */
/* Product:BTMSYS															 */
/*																			 */
/*---------------------------------------------------------------------------*/
/*																			 */
/* PROGRAM NAME: bhtxt.c    												 */
/* DESCRIPTIONS: �������������ļ���������									 */
/*																			 */
/*---------------------------------------------------------------------------*/
/*																			 */
/* MODIFICATION LOG															 */
/* DATE			PROGRAMMER			DESCRIPTION								 */
/* 2003-07-28   Duan Annie			initial Version Creation				 */
/*****************************************************************************/
#include <sys/stat.h>
#include <stdio.h>
#include "glb_def.h"

#define MAX_BUF_LEN         512
#define RPT_LITTER  "|"
#define	TXT_FILEP	"/iodata/TXT/"
#define TXT_EXT		".txt"

static char sBuf[MAX_BUF_LEN + 1];

/******************************************************************************/
/*  Function     : cmOpenTxtFile()                                            */
/*  Description  : Open Txt File                                              */
/*  Arguments    : sBrno - input                                              */
/*                 sTxtFileName - input                                       */
/*                 iFlag - input                                              */
/*                 fTxtFile - output                                          */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int cmOpenTxtFile(char *sBrno, char *sDay, char *sTxtFileName,int iFlag, FILE **fTxtFile)
{
	char	sFilePath[DLEN_BH_FNAME];
	char	sFilePath1[DLEN_BH_FNAME];
	char	sFileName[DLEN_BH_FNAME];
	char	sFile[DLEN_BH_FNAME];
	char	sDate[DLEN_DATE + 1];
	int 	iRetCode;

	memset(sFilePath, 0, sizeof(sFilePath));
	memset(sFileName, 0, sizeof(sFileName));

	strcpy(sFilePath,getenv("APPL"));

	if(strlen(sFilePath) == 0)
	{
		cmBhPrintf("The envirment APPL is not set!!!\n");
		return SYS_FAIL;
	}

	memset(sDate, 0, sizeof(sDate));
	memcpy(sDate, sDay, DLEN_DATE);

	strcat(sFilePath, TXT_FILEP);
	/*
	strcat(sFilePath, sDate);
	*/

	strcpy(sFilePath1, sFilePath);
	strcat(sFilePath1, "/");
	strcat(sFilePath1, sBrno);

	strcpy(sFileName, sFilePath1);
	strcat(sFileName, "/");
	strcat(sFileName, sTxtFileName);
	strcat(sFileName, TXT_EXT);
	strcpy(sFile, sTxtFileName);

	switch(iFlag)
	{
	case TXT_CREAT:
		if((*fTxtFile = fopen(sFileName,"wb")) == NULL)
		{
			/* mkdir of brno */
			mkdir(sFilePath1,S_IRWXU|S_IRWXG|S_IRWXO);
			if((*fTxtFile = fopen(sFileName,"wb")) == NULL)
			{
				/* mkdir of batchdate */
				mkdir(sFilePath,S_IRWXU|S_IRWXG|S_IRWXO);
				/* mkdir of brno */
				mkdir(sFilePath1,S_IRWXU|S_IRWXG|S_IRWXO);
				if((*fTxtFile = fopen(sFileName,"wb")) == NULL)
				{
					cmBhPrintf("Open File %s error\n", sFileName); 
					return SYS_FAIL;
				}
			}
		}
		break;
	case TXT_APPEND:
		if((*fTxtFile = fopen(sFileName,"a+")) == NULL)
		{
			cmBhPrintf("Open File %s error\n",sFileName);  
			return SYS_FAIL;
		}
		break;
	default:
		cmBhPrintf("The Open File Mode %d is error\n",iFlag);
		return SYS_FAIL;
	}

	/*
	iRetCode = cmWrtHdToTxt(sFile, *fTxtFile);
	if(iRetCode != SYS_OK)
	{
		cmBhPrintf("write head to txt error\n");
		return SYS_FAIL;
	}
	*/
	return SYS_OK;
}

/******************************************************************************/
/*  Function     : cmCloseFile()                                              */
/*  Description  : Close File                                                 */
/*  Arguments    : fFile - input                                              */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int cmCloseFile(FILE **fFile)
{
	int iStatus;
	
	if((iStatus = fclose(*fFile)) != SYS_OK)
	{
		cmBhPrintf("Close file Error\n");
		return SYS_FAIL;
	}
	return SYS_OK;
}

/******************************************************************************/
/*  Function     : cmWrtToFile()                                              */
/*  Description  : Write Buffer to file                                       */
/*                 BULD_BUF_NOT_WRT - buildtx buffer, later write to file     */
/*                 NOT_BULD_WRT_BUF - write buffer to file                    */
/*                 BULD_BUF_WRT_BUF - buildtx buffer, write to file           */
/*  Arguments    : fFile - input                                              */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int cmWrtToFile(char *sTxtBuf, FILE *fTxtFile, const int iFlag)
{
	int iTxtBufLen;
	int iTmpTxtBufLen;
	int iBufLen;

	iBufLen = strlen(sBuf);
	if(sTxtBuf[0] != NULL)
	{
		strcat(sTxtBuf, "\n");
		iTxtBufLen = strlen(sTxtBuf);
		iTmpTxtBufLen = iTxtBufLen;
	}

	switch(iFlag)
	{
		case BULD_BUF_NOT_WRT:
			while((iBufLen + iTmpTxtBufLen) >= MAX_BUF_LEN)
			{
				fwrite(sBuf, iBufLen, 1, fTxtFile);
				if(ferror(fTxtFile))
				{
					return SYS_FAIL;
				}

				if(iTmpTxtBufLen >= MAX_BUF_LEN)
				{
					memcpy(sBuf, &sTxtBuf[iTxtBufLen - iTmpTxtBufLen], MAX_BUF_LEN);
					sBuf[MAX_BUF_LEN] = 0;
					iBufLen = strlen(sBuf);

					iTmpTxtBufLen -= MAX_BUF_LEN;
				}
				else
				{
					memset(sBuf, 0, sizeof(sBuf));
					iBufLen = 0;
				}
			}

			memcpy(&sBuf[iBufLen], &sTxtBuf[iTxtBufLen - iTmpTxtBufLen], iTmpTxtBufLen);
			sBuf[iBufLen + iTmpTxtBufLen] = 0;
			break;
		case NOT_BULD_WRT_BUF:
			fwrite(sBuf, iBufLen, 1, fTxtFile);
			if(ferror(fTxtFile))
			{
				return SYS_FAIL;
			}

			memset(sBuf, 0, sizeof(sBuf));
			iBufLen = 0;
			break;
		case BULD_BUF_WRT_BUF:
			while((iBufLen + iTmpTxtBufLen) >= MAX_BUF_LEN)
			{
				fwrite(sBuf, iBufLen, 1, fTxtFile);
				if(ferror(fTxtFile))
				{
					return SYS_FAIL;
				}

				if(iTmpTxtBufLen >= MAX_BUF_LEN)
				{
					memcpy(sBuf, &sTxtBuf[iTxtBufLen - iTmpTxtBufLen], MAX_BUF_LEN);
					sBuf[MAX_BUF_LEN] = 0;
					iBufLen = strlen(sBuf);

					iTmpTxtBufLen -= MAX_BUF_LEN;
				}
				else
				{
					memset(sBuf, 0, sizeof(sBuf));
					iBufLen = 0;
				}
			}

			memcpy(&sBuf[iBufLen], &sTxtBuf[iTxtBufLen - iTmpTxtBufLen], iTmpTxtBufLen);
			sBuf[iBufLen + iTmpTxtBufLen] = 0;
			
			iBufLen = strlen(sBuf);
			fwrite(sBuf, iBufLen, 1, fTxtFile);
			if(ferror(fTxtFile))
			{
				return SYS_FAIL;
			}

			memset(sBuf, 0, sizeof(sBuf));
			iBufLen = 0;
			break;
		default:
			return SYS_FAIL;
	}
	
	return SYS_OK;
}


/******************************************************************************/
/*  Function     : cmWrtHdToTxt()                                             */
/*  Description  : Write Head for txt file                                    */
/*  Arguments    : sFileName - input                                          */
/*                 fTxtFile - input                                           */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int cmWrtHdToTxt(char *sFileName, FILE *fTxtFile)
{
	char sVer[20];
	char sTmpType[100];

	memset(sVer, 0, sizeof(sVer));
	memset(sTmpType, 0, sizeof(sTmpType));

	strcat(sVer, "VERSION=");
	strcat(sVer, getenv("DG_RPT_VERSION"));
	strcat(sVer, "\n");

	fwrite(sVer, strlen(sVer), 1, fTxtFile);
	if(ferror(fTxtFile))
	{
		return SYS_FAIL;
	}

	strcat(sTmpType, "TYPE=");
	strcat(sTmpType, sFileName);
	strcat(sTmpType, "\n");

	fwrite(sTmpType, strlen(sTmpType), 1, fTxtFile);
	if(ferror(fTxtFile))
	{
		return SYS_FAIL;
	}

	return SYS_OK;
}

