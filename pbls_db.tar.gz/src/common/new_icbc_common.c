#include <stdio.h>
#include <stdlib.h>
#include "glb_def.h"
#include "htlog.h"
#include "ipc.h"
#include "wd_incl.h"

extern char	logfile[256];

int nGetICBCGroupHeader(T_ICBC_GROUPHEADER *icbc_groupheader)
{
	int nRet;
	char sCfgFileName[512+1];

	memset(sCfgFileName, 0, sizeof(sCfgFileName));
	sprintf(sCfgFileName, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);

    /* read from etc file */
	nRet = pflGetProfileString("ICBC_GROUPHEADER", "VERSION",
		icbc_groupheader->version, 30, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(icbc_groupheader->version, "V0.1");
	}
    
	nRet = pflGetProfileString("ICBC_GROUPHEADER", "TRADE_SOURCE",
		icbc_groupheader->trade_source, 1, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(icbc_groupheader->trade_source, "C");
	}
	
	nRet = pflGetProfileString("ICBC_GROUPHEADER", "S_INSTITUTION_IDENTIFIER",
		icbc_groupheader->s_institution_identifier, 30, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(icbc_groupheader->s_institution_identifier, "HSBC");
	}

	pflGetProfileString("ICBC_GROUPHEADER", "S_INSTITUTION_NAME",
		icbc_groupheader->s_institution_name, 60, sCfgFileName);
	
	pflGetProfileString("ICBC_GROUPHEADER", "S_BRANCH_IDENTIFIER",
		icbc_groupheader->s_branch_identifier, 30, sCfgFileName);

	pflGetProfileString("ICBC_GROUPHEADER", "S_BRANCH_NAME",
		icbc_groupheader->s_branch_name, 60, sCfgFileName);
	
	pflGetProfileString("ICBC_GROUPHEADER", "S_SUB_BRANCH_IDENTIFIER",
		icbc_groupheader->s_sub_branch_identifier, 30, sCfgFileName);


	pflGetProfileString("ICBC_GROUPHEADER", "S_SUB_BRANCH_NAME",
		icbc_groupheader->s_sub_branch_name, 60, sCfgFileName);

	nRet = pflGetProfileString("ICBC_GROUPHEADER", "R_INSTITUTION_IDENTIFIER",
		icbc_groupheader->r_institution_identifier, 30, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(icbc_groupheader->r_institution_identifier, "ICBC");
	}

	pflGetProfileString("ICBC_GROUPHEADER", "R_INSTITUTION_NAME",
		icbc_groupheader->r_institution_name, 60, sCfgFileName);

	pflGetProfileString("ICBC_GROUPHEADER", "R_BRANCH_IDENTIFIER",
		icbc_groupheader->r_branch_identifier, 30, sCfgFileName);


	pflGetProfileString("ICBC_GROUPHEADER", "R_BRANCH_NAME",
		icbc_groupheader->r_branch_name, 60, sCfgFileName);

	pflGetProfileString("ICBC_GROUPHEADER", "R_SUB_BRANCH_IDENTIFIER",
		icbc_groupheader->r_sub_branch_identifier, 30, sCfgFileName);

	pflGetProfileString("ICBC_GROUPHEADER", "R_SUB_BRANCH_NAME",
		icbc_groupheader->r_sub_branch_name, 60, sCfgFileName);

    pflGetProfileString("ICBC_GROUPHEADER", "R_SUB_BRANCH_NAME",
		icbc_groupheader->r_sub_branch_name, 60, sCfgFileName);
		
    pflGetProfileString("ICBC_GROUPHEADER", "R_SUB_BRANCH_NAME",
		icbc_groupheader->r_sub_branch_name, 60, sCfgFileName);

	nRet = pflGetProfileString("ICBC_GROUPHEADER", "CODE",
		icbc_groupheader->code, 4, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(icbc_groupheader->code, "0000");
	}

	pflGetProfileString("ICBC_GROUPHEADER", "INFO",
		icbc_groupheader->info, 128, sCfgFileName);

	return 0;
}

/* 
���������
icbc_groupheader: icbc����ͨѶͷ
time��ʱ�䣬14λ YYYYMMDDHHMMSS
business_code: ���ܺ� 
�ʻ���ϸ��ѯ	40004
�ʻ�����ѯ	40005
��Ҹ���ָ��	10020
��һ���ѯ/��ִ	10004
����Ҹ���ָ����Ϣ/��ִ	10017
����Ҹ�����Ϣ��ѯ	10015
*/
int nSetICBCGroupHeader(T_ICBC_GROUPHEADER *icbc_groupheader, char *time, char *business_code)
{
    ICBC_API_SET_VALUE("api.VERSION", 
                        icbc_groupheader->version, 
                        strlen(icbc_groupheader->version));
    /*                    
    ICBC_API_SET_VALUE("api.REFERNCE", 
                        icbc_groupheader->refernce, 
                        strlen(icbc_groupheader->refernce));
    */                  
    ICBC_API_SET_VALUE("api.BUSINESS_CODE", 
                        business_code, 
                        strlen(business_code));
                        
    ICBC_API_SET_VALUE("api.TRADE_SOURCE", 
                        icbc_groupheader->trade_source, 
                        strlen(icbc_groupheader->trade_source));
                        
    ICBC_API_SET_VALUE("api.S_INSTITUTION_ID", 
                        icbc_groupheader->s_institution_identifier, 
                        strlen(icbc_groupheader->s_institution_identifier));
                        
    ICBC_API_SET_VALUE("api.S_INSTITUTION_NAME", 
                        icbc_groupheader->s_institution_name, 
                        strlen(icbc_groupheader->s_institution_name));
                        
    ICBC_API_SET_VALUE("api.S_BRANCH_ID", 
                        icbc_groupheader->s_branch_identifier, 
                        strlen(icbc_groupheader->s_branch_identifier));
                        
    ICBC_API_SET_VALUE("api.S_BRANCH_NAME", 
                        icbc_groupheader->s_branch_name, 
                        strlen(icbc_groupheader->s_branch_name));
                        
    ICBC_API_SET_VALUE("api.S_SUB_BRANCH_ID", 
                        icbc_groupheader->s_sub_branch_identifier, 
                        strlen(icbc_groupheader->s_sub_branch_identifier));
                        
    ICBC_API_SET_VALUE("api.S_SUB_BRANCH_NAME", 
                        icbc_groupheader->s_sub_branch_name, 
                        strlen(icbc_groupheader->s_sub_branch_name));
                        
    ICBC_API_SET_VALUE("api.R_INSTITUTION_ID", 
                        icbc_groupheader->r_institution_identifier, 
                        strlen(icbc_groupheader->r_institution_identifier));
                        
    ICBC_API_SET_VALUE("api.R_INSTITUTION_NAME", 
                        icbc_groupheader->r_institution_name, 
                        strlen(icbc_groupheader->r_institution_name));
                        
    ICBC_API_SET_VALUE("api.R_BRANCH_ID", 
                        icbc_groupheader->r_branch_identifier, 
                        strlen(icbc_groupheader->r_branch_identifier));
                        
    ICBC_API_SET_VALUE("api.R_BRANCH_NAME", 
                        icbc_groupheader->r_branch_name, 
                        strlen(icbc_groupheader->r_branch_name));
                        
    ICBC_API_SET_VALUE("api.R_SUB_BRANCH_ID", 
                        icbc_groupheader->r_sub_branch_identifier, 
                        strlen(icbc_groupheader->r_sub_branch_identifier));
                        
    ICBC_API_SET_VALUE("api.R_SUB_BRANCH_NAME", 
                        icbc_groupheader->r_sub_branch_name, 
                        strlen(icbc_groupheader->r_sub_branch_name));
                        
    ICBC_API_SET_VALUE("api.TRADE_DATE", 
                        time, 
                        8);
                        
    ICBC_API_SET_VALUE("api.TRADE_TIME", 
                        time+8, 
                        6);
                        
    ICBC_API_SET_VALUE("api.CODE", 
                        icbc_groupheader->code, 
                        strlen(icbc_groupheader->code));
                        
    ICBC_API_SET_VALUE("api.INFO", 
                        icbc_groupheader->info, 
                        strlen(icbc_groupheader->info));
	return;
}


int nGetBankInfo(T_BANK_INFO *bank_info)
{
	int nRet;
	char sCfgFileName[512+1];

	memset(sCfgFileName, 0, sizeof(sCfgFileName));
	sprintf(sCfgFileName, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);

    /* read from etc file */
	nRet = pflGetProfileString("ICBC_HSBC_BANK_INFO", "ICBC_CNAPS_CODE",
		bank_info->icbc_cnaps_code, 12, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(bank_info->icbc_cnaps_code, "111111111111");
	}
	
	nRet = pflGetProfileString("ICBC_HSBC_BANK_INFO", "ICBC_CNAPS_BIC",
		bank_info->icbc_cnaps_bic, 11, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(bank_info->icbc_cnaps_bic, "AAAAAAAAAAA");
	}
	
	nRet = pflGetProfileString("ICBC_HSBC_BANK_INFO", "HSBC_CNAPS_CODE",
		bank_info->hsbc_cnaps_code, 12, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(bank_info->hsbc_cnaps_code, "222222222222");
	}
	
	nRet = pflGetProfileString("ICBC_HSBC_BANK_INFO", "HSBC_CNAPS_BIC",
		bank_info->hsbc_cnaps_bic, 11, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(bank_info->hsbc_cnaps_bic, "BBBBBBBBBBB");
	}
	
	nRet = pflGetProfileString("ICBC_HSBC_BANK_INFO", "BUSIKIND",
		bank_info->busikind, 2, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(bank_info->busikind, "11");
	}
	
	nRet = pflGetProfileString("ICBC_HSBC_BANK_INFO", "BUSITYPE",
		bank_info->busitype, 5, sCfgFileName);
	if (nRet != 0)
	{
	    strcpy(bank_info->busitype, "40100");
	}
}

char *getstr(char *c)
{
	char *s;
	s = c;
	while(*s != '\0')
	{
        if (*s >= 128 || *s < 0)
        {
            if (*(s + 1) == '\0')
                *s = '\0';
            else
                s = s + 2;
        }
        else
            s++;
    }
	return c;
}

/*add by tianchangjin on 20110805 begin*/
char *getstrtospace(char *c)
{
	char *s;
	s = c;
	while(*s != '\0')
	{
        if (*s >= 128 || *s < 0)
        {
            if (*(s + 1) == '\0')
                *s = ' ';
            else
                s = s + 2;
        }
        else
            s++;
    }
	return c;
}
/*add by tianchangjin on 20110805 end*/

int  nUpdateInqReq(char *sID, char status)
{
    int nRet;
    struct wd_pbicbcinq_area    wd_pbicbcinq;
    
    memset(&wd_pbicbcinq    ,0  ,sizeof(wd_pbicbcinq   ));

    /* �ҵ�ԭ07���ĵļ�¼ */
    memcpy(wd_pbicbcinq.id  ,sID   ,sizeof(wd_pbicbcinq.id) - 1 );
    nRet = DbsPBICBCINQ(DBS_FIND, &wd_pbicbcinq);
    if( nRet != DB_OK )
    {
        HtLog(HTLM_ERR, "DbsPBICBCINQ DBS_FIND=[%d][%s]\n",nRet, sID );
        return -1;
    }

    /* ���ݷ��ص�08���� ����pbicbcinq������ʷ��ϸ��ѯ��   */
    wd_pbicbcinq.status[0] = status;               /* ��Ӧ�� */
    nRet = DbsPBICBCINQ(DBS_IUPD, &wd_pbicbcinq);
    if( nRet != 0 )
    {
        HtLog(HTLM_ERR, "DbsPBICBCINQ DBS_IUPD=[%d][%s]\n",nRet,sID);
        DbRollbackTxn();
        return -2;
    }
    
    DbCommitTxn();  
}

int  nGetInqReqValue(char *sID, int type, char *value)
{
    int nRet;
    struct wd_pbicbcinq_area    wd_pbicbcinq;
    
    memset(&wd_pbicbcinq    ,0  ,sizeof(wd_pbicbcinq   ));

    /* �ҵ�ԭ07���ĵļ�¼ */
    memcpy(wd_pbicbcinq.id  ,sID   ,sizeof(wd_pbicbcinq.id) - 1 );
    nRet = DbsPBICBCINQ(DBS_FIND, &wd_pbicbcinq);
    if( nRet != DB_OK )
    {
        HtLog(HTLM_ERR, "DbsPBICBCINQ DBS_FIND=[%d][%s]\n",nRet, sID );
        return -1;
    }
    switch(type)
    {
        case 1:
            memcpy(value, wd_pbicbcinq.rsv1, 60);
            break;
        case 2:
            memcpy(value, wd_pbicbcinq.rsv2, 60);
            break;
        case 3:
            memcpy(value, wd_pbicbcinq.rsv3, 60);
            break;
        case 4:
            memcpy(value, wd_pbicbcinq.rsv4, 60);
            break;
        case 5:
            memcpy(value, wd_pbicbcinq.rsv5, 60);
            break;
        case 6:
            memcpy(value, wd_pbicbcinq.rsv6, 60);
            break;
        case 7:
            memcpy(value, wd_pbicbcinq.rsv7, 60);
            break;
        case 8:
            memcpy(value, wd_pbicbcinq.rsv8, 60);
            break;
        case 9:
            memcpy(value, wd_pbicbcinq.rsv9, 60);
            break;
        case 10:
            memcpy(value, wd_pbicbcinq.rsv10, 60);
            break;
        default:
            break;
    }
    return 0;
}

int  nUpdateMonitor(char *sID, char status)
{
/*
    int nRet;
    struct wd_pbmsgmonitor_area wd_pbmsgmonitor;
    
    memset(&wd_pbmsgmonitor ,0  ,sizeof(wd_pbmsgmonitor));

    memcpy(wd_pbmsgmonitor.id ,sID ,sizeof(wd_pbmsgmonitor.id)-1);

	nRet = DbsPBMSGMONITOR(DBS_FIND,&wd_pbmsgmonitor);
    if( nRet != DB_OK )
    {
        HtLog(HTLM_ERR, "DbsPBMSGMONITOR DBS_FIND=[%d][%s]\n",nRet, sID );
        return -1;
    }

    wd_pbmsgmonitor.status[0] = status;
    nRet = DbsPBMSGMONITOR(DBS_IUPD,&wd_pbmsgmonitor);
    if( nRet != DB_OK )
    {
        HtLog(HTLM_ERR, "DbsPBMSGMONITOR DBS_IUPD=[%d][%s]\n",nRet,sID);
        DbRollbackTxn();
        return -2;
    }
    DbCommitTxn();
    */
    return 0;
}


int  nUpdateCustCtl(char *accno, char *currtype, int type, char status)
{
    int nRet;
    struct wd_pbcustctl_area	wd_pbcustctl;
    
    memset(&wd_pbcustctl	,0	,sizeof(wd_pbcustctl   ));
    HtLog(HTLM_COM,"actno[%s]",accno);
    HtLog(HTLM_COM,"curcd[%s]",currtype);
	memcpy(wd_pbcustctl.bank_id, PBLS_BANK_ID_ICBC, 3);
	memcpy(wd_pbcustctl.actno,   accno,    strlen(accno));
	memcpy(wd_pbcustctl.curcd,   currtype, 3);
	nRet = DbsPBCUSTCTL(DBS_FIND, &wd_pbcustctl);
	if(nRet != DB_OK )
	{
		HtLog(HTLM_COM,"DbsPBCUSTCTL DBS_FIND sqlca.sqlcode =[%d]",nRet);
		HtLog(HTLM_COM,"wd_pbcustctl.actno=[%s]",wd_pbcustctl.actno);
		HtLog(HTLM_COM,"wd_pbcustctl.curcd=[%s]",wd_pbcustctl.curcd);
	}
    if(type == 1)
    {
	    wd_pbcustctl.rsv7[0] = status;
    }
    else if(type == 2)
    {
        wd_pbcustctl.rsv3[0] = status;
    }
	nRet = DbsPBCUSTCTL(DBS_IUPD, &wd_pbcustctl);
	if(nRet != DB_OK )
	{
		HtLog(HTLM_COM,"DbsPBCUSTCTL DBS_IUPD sqlca.sqlcode =[%d]",nRet);
		HtLog(HTLM_COM,"wd_pbcustctl.actno=[%s]",wd_pbcustctl.actno);
		HtLog(HTLM_COM,"wd_pbcustctl.curcd=[%s]",wd_pbcustctl.curcd);
	}
    return 0;
}


int nAmtDoubleToString15(char *str, double dou)
{
    char tmp[20];
    memset(tmp, 0, sizeof(tmp));
    
    sprintf(tmp, "%15.0f", dou);
    
    if(strlen(tmp) != 15)
    {
        HtLog(HTLM_ERR, "Translate amount to char[15] failed!amount=[%f]\n", dou);
        return -1;
    }
    memcpy(str, tmp, 15);
    return 0;
}

int nUpdatePaymentID(char *sId, int type)
{
    int nRet;
    char md_time[15];

	memset(md_time, 0, sizeof(md_time));
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, md_time);
    
    ICBC_API_SET_VALUE("api.ID", sId, 16);
    if(type == 1)
    {
        nRet = ICBC_CALL_API("INQ_ICBC_10017_REQ");
        if(nRet != 0)
        {
            HtLog(HTLM_ERR,"ICBC_CALL_API INQ_ICBC_10017_REQ ERR=[%d]",nRet);
            return -1;
        }
        ICBC_API_SET_VALUE("api.BUSIDATE", md_time, 8);
        ICBC_API_SET_VALUE("api.IFTRXSERNB", sId, 16);
		nRet = ICBC_CALL_API("ICBC_GEN_REFERNCE");
		if(nRet != 0)
		{
			HtLog(HTLM_ERR,"ICBC_CALL_API ICBC_GEN_REFERNCE ERR=[%d]",nRet);
			return -1;
		}
		nRet = ICBC_CALL_API("OUT_UPDATE_ICBC_10017_REQ");
		if(nRet != 0)
		{
			HtLog(HTLM_ERR,"ICBC_CALL_API OUT_UPDATE_ICBC_10017_REQ ERR=[%d]",nRet);
			return -1;
		}
    }
    else
    {
        nRet = ICBC_CALL_API("INQ_ICBC_10020_REQ");
        if(nRet != 0)
        {
            HtLog(HTLM_ERR,"ICBC_CALL_API INQ_ICBC_10020_REQ ERR=[%d]",nRet);
            return -1;
        }
        ICBC_API_SET_VALUE("api.WDATE", md_time, 8);
        ICBC_API_SET_VALUE("api.KEYMSG", sId, 16);
		nRet = ICBC_CALL_API("ICBC_GEN_REFERNCE");
		if(nRet != 0)
		{
			HtLog(HTLM_ERR,"ICBC_CALL_API ICBC_GEN_REFERNCE ERR=[%d]",nRet);
			return -1;
		}
		nRet = ICBC_CALL_API("OUT_UPDATE_ICBC_10020_REQ");
	    if(nRet != 0)
	    {
	        HtLog(HTLM_ERR,"ICBC_CALL_API OUT_UPDATE_ICBC_10020_REQ ERR=[%d]",nRet);
	        return -1;
	    }
    }

    return 0;
}


/*add by tianchangjin on 20110824 begin*/
/***********************************************/
/*������    str_in �����ַ���                  */
/*          str_out�����ַ���                  */
/*����ֵ��  0 ��������                         */
/*���ܣ�    ���뺺�����ڵ�����ǰ������ַ���*��  */
/***********************************************/
int changestr(char *str_in, char *str_out)
{
    int i;
    int j;
    int len;
    len = strlen(str_in);
    
    for(i=0,j=0;i<len;i++,j++)
    {
        if(*(str_in+i)<='9' && *(str_in+i)>='0')
        {
            if(((*(str_in+i-1)>=128 || *(str_in+i-1)<0) && i!=0 ) || ((*(str_in+i+1)>=128 || *(str_in+i+1)<0) && i!=len-1))
            {
                 *(str_out+j) = '*';
                 *(str_out+j+1) = *(str_in+i);
                 j++;
            }  
            else
            {
                *(str_out+j) = *(str_in+i);
            }       
        }
        else
        {
            *(str_out+j) = *(str_in+i);
        }
    }
    return 0;
}
/*add by tianchangjin on 20110824 end*/