/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: ErrReport.c                                                 */
/* DESCRIPTIONS: The common routines for report error, including             */
/*               ErrReport    -- Report error to ERR SERVER                  */
/*               HandleErrors -- Send error message to queue (internal use)  */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

#include "wd_incl.h"
#include "msglog.h"
#include "glb_def.h"

short HandleErrors(struct wd_pbsyslog_area *ptMsgLog)
{
    short nRet;
    struct
    {
        long lMsgType;
        struct wd_pbsyslog_area tMsgLog;
    } MsgTemp;

	nRet = nCommonMsqInit(CI_ERRSVR);
    if (nRet == -1)
    {
        perror("Get Error Server Message Queue Error");
        return -1;
    }

    MsgTemp.lMsgType = 1L;
    memcpy(&MsgTemp.tMsgLog, ptMsgLog, sizeof(MsgTemp.tMsgLog));
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, MsgTemp.tMsgLog.rec_updt_time);
    nRet = nCommonMsqSend(sizeof(MsgTemp.tMsgLog), (char *)&MsgTemp, 1L,CI_ERRSVR); 
    if (nRet == -1)
    {
        perror("Send Error Server Message Queue Error");
        return -1;
    }

    return 0;
}

/*****************************************************************************/
/* FUNC:   short ErrReport (long lMsgSource,                                 */
/*                          long lErrorCode,                                 */
/*                          long lErrorSubCode,                              */
/*                          long lSeverity,                                  */
/*                          char *sDescription);                             */
/* INPUT:  lMsgSource     -- send message source process id                  */
/*         lErrorCode     -- error code                                      */
/*         lErrorSubCode  -- sub error code                                  */
/*         lSeverity      -- severity                                        */
/*         sDescription   -- error description                               */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Report error to ERR SERVER.                                       */
/*****************************************************************************/
short ErrReport(long lMsgSource, long lErrorCode, long lErrorSubCode,
                long lSeverity, char *sDescription)
{
    struct wd_pbsyslog_area tMsgLog;
	
	memset (&tMsgLog,'\0',sizeof(tMsgLog));

    tMsgLog.msg_src = lMsgSource;
    tMsgLog.msg_code = lErrorCode;
    tMsgLog.msg_subcode = lErrorSubCode;
    tMsgLog.msg_level = lSeverity;
    memset(tMsgLog.msg_desc, ' ', sizeof(tMsgLog.msg_desc)-1);
    sprintf(tMsgLog.msg_desc, "[pid:%08ld]%-45.45s", getpid(), sDescription);

    return(HandleErrors(&tMsgLog));
}

