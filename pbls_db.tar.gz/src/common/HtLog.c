/****************************************************************************/
/* Shanghai Huateng Software System Co. Ltd									*/
/****************************************************************************/
/* PROGRAM NAME: HtLog.c													*/
/* DESCRIPTIONS: 															*/
/****************************************************************************/
/* DATE			PROGRAMMER		DESCRIPTION									*/
/* 2001-01-11  	zhao_jinggang                             					*/
/****************************************************************************/
#include		"htlog.h"


int 	replace_env_var(char *str);
int	 	convert_env(char *str);
int 	GetLogName(char *infile, char *outfile);

/****************************************************************************/
/* FunctionName:   HtLog													*/
/* Input:  																	*/
/* Output:        															*/
/* Return:        															*/
/****************************************************************************/
/* Statement: 	Use HtLog, you must set following environmental variables:	*/
/* 				HT_LOG_MODE: only one choice in ( OFF , SIMPLE , COMPLEX )	*/
/*				HT_LOG_SIZE: n Mbytes (1024 * 1024 bytes)					*/
/****************************************************************************/
/* Example 1:     HtLog("./ht.log", HT_LOG_MODE_COMPLEX, __FILE__,			*/ 
/*						__LINE__, "errmsg is [%s]", strerror(errno) );		*/
/****************************************************************************/
/* Example 2:     HtLog("", HT_LOG_MODE_SIMPLE, __FILE__,					*/ 
/*						__LINE__, "errmsg is [%s]", strerror(errno) );		*/
/****************************************************************************/
/* Example 3:     HtLog(NULL, HT_LOG_MODE_OFF, __FILE__,					*/ 
/*						__LINE__, "errmsg is [%s]", strerror(errno) );		*/
/****************************************************************************/


int HtLog(char *logfile, int level, char *file, int line, char *fmt, ...)
{
va_list ap;
FILE 	*fp=NULL;
char 	filename[MAX_FILE_LEN+1], bakfilename[MAX_FILE_LEN+1]; 
/*len, 
register int i;
*/
int  	cnt,nRet;
int		cur_env_set_level;
char	*ptr=NULL;
struct 	stat statbuf;
time_t  systime;
struct  tm *ptime;
char    s[128];
char    s1[128];
long	base_overflow;
char	filenameshort[256];

	/********************************************************************/
	/*			get 	environmemtal 	variable 	LOG_MODE			*/
	/********************************************************************/
	ptr = (char *)getenv("HT_LOG_MODE");
	if ( ptr == NULL )
	{
		fprintf(stderr, "environmental variable HT_LOG_MODE not set\n");
		return 0;
	}
	else
	{
		if ( strcmp(ptr, "OFF") == 0 )
			cur_env_set_level = HT_LOG_MODE_OFF;
		else if ( strcmp(ptr, "SIMPLE") == 0 )
			cur_env_set_level = HT_LOG_MODE_SIMPLE;
		else if ( strcmp(ptr, "COMPLEX") == 0 )
			cur_env_set_level = HT_LOG_MODE_COMPLEX;
		else if ( strcmp(ptr, "DEBUG") == 0 )
			cur_env_set_level = HT_LOG_MODE_DEBUG;
	}

	if ( cur_env_set_level == HT_LOG_MODE_OFF )/* Need Not Register Log File */
		return 0;

	/********************************************************************/
	/*			get 	environmemtal 	variable 	LOG_MODE			*/
	/********************************************************************/
	ptr = (char *)getenv("HT_LOG_SIZE");		/* multiply by SIZE_UNIT */
	if ( ptr == NULL )
	{
		fprintf(stderr, "environmental variable HT_LOG_SIZE not set, "
						"so use default value 1\n");
		base_overflow = 1;	/* initialize base_overflow to 1 */
	}
	else
		base_overflow = atol(ptr);

	/********************************************************************/
	/*			get 	current 	system	time 	to 	register		*/
	/********************************************************************/
    memset(s, 0, sizeof(s));
	memset(s1,0, sizeof(s1));
	
    systime=time(NULL);
    ptime=localtime(&systime);

/*    strftime(s, sizeof(s), 	"%Y-%m-%d %H:%M:%S|%a %b %d %H:%M:%S %Y", ptime);*/
    strftime(s, sizeof(s), 	"%Y-%m-%d %H:%M:%S", ptime);
	strftime(s1, sizeof(s1), "%Y%m%d", ptime);
	
	/********************************************************************/
	/*			set 	logical		file 	name 						*/
	/********************************************************************/
    memset(filename, 0, sizeof(filename));	/* Log File Name */

    if ( logfile == (char *)NULL ) /* filename is NULL */
    {
		fp = stderr;
    }
    else if (  strlen(logfile) == 0 )	/* filename is "" */
	{
        strcpy(filename, "./ht.log");
	}
    else /* filename is normal string */
	{
        strcpy(filename, logfile);
	}

	if	( level <= cur_env_set_level )
	{
    	if ( fp != stderr ) 
    	{
      		if ( ( fp = fopen(filename, "a+") ) == NULL )
				fp = stderr;
			else
			{
				memset(&statbuf, 0, sizeof(statbuf));
				nRet = stat(filename, &statbuf);
				if ( nRet == 0 && statbuf.st_size >= SIZE_UNIT * base_overflow )
				{
					fclose(fp);

					memset(bakfilename, 0, sizeof(bakfilename));
					sprintf(bakfilename, "%s.%s", filename, s1);
					rename(filename, bakfilename);

      				if ( ( fp = fopen(filename, "a+") ) == NULL )
					fp = stderr;
				}
			}
    	}

		//��ӡʱֻ��ӡ�ļ���
		memset(filenameshort, 0, sizeof(filenameshort));
		memcpy(filenameshort, file, sizeof(filenameshort)-1);
		memcpy(filenameshort, (char *)basename(file), 255);
		
		//cnt=fprintf(fp, "[%s][%s:%4d] ",s, file, line); 
		cnt=fprintf(fp, "[%s][%20s:%4d] ",s, filenameshort, line);
		
		if (level == HT_LOG_MODE_ERR)
		{
			cnt = fprintf(fp ," ERROR%s ===> ", s1);
		}
		else if (level == HT_LOG_MODE_DEBUG)
		{
			cnt = fprintf(fp ,"DEBUG: ", s1);
		}
		va_start(ap, fmt);
    	cnt = vfprintf(fp, fmt, ap);
    	va_end(ap);
	
		fprintf(fp, "\n");
		fflush(fp);

    	if ( fp != stderr ) 
			fclose(fp);

		return cnt;
	}

	return 0;
}

/****************************************************************************/
/* FunctionName:   HtDebugString											*/
/* Input:  																	*/
/* Output:        															*/
/* Return:        															*/
/****************************************************************************/
/* Statement: 	Use HtDebugString, you must set following environmental 	*/
/*				variables:													*/
/*				HT_DEBUG_STRING_MODE: only one choice in ( OFF , ON )		*/
/*				HT_DEBUG_STRING_SIZE: n Mbytes (1024 * 1024 bytes)			*/
/****************************************************************************/
/* Example:     HtDebugString("./ht.log", buf, buflen, __FILE__, __LINE__); */
/****************************************************************************/
short HtDebugString(	char *logfile, 
						char *psBuf, int iLength, 
						char *iFile, int iLine )
{
char 	filename[MAX_FILE_LEN+1], bakfilename[MAX_FILE_LEN+1]; 
struct 	stat statbuf;
int 	cur_env_set_level;
long	base_overflow;
char 	*ptr;
register int i,j=0;
/* replaced by Jasmine 2009-11-4 9:59:12
char 	s[100], temp[5];
*/
char 	s[100], temp[5+1];
time_t  systime;
struct  tm *ptime;
char 	st[128];
char    s1[128];
FILE 	*fp=NULL;
/*int 	cnt;*/
int 	nRet;

	/********************************************************************/
	/*		get 	environmemtal 	variable 	HT_DEBUG_STRING_MODE	*/
	/********************************************************************/
	ptr = (char *)getenv("HT_DEBUG_STRING_MODE");
	if ( ptr == NULL )
	{
		fprintf(stderr, "environmental variable HT_DEBUG_STRING_MODE not set\n");
		return 0;
	}
	else
	{
		if ( strcmp(ptr, "ON") == 0 )
			cur_env_set_level = HT_DEBUG_STRING_MODE_ON;
		else if ( strcmp(ptr, "OFF") == 0 )
			cur_env_set_level = HT_DEBUG_STRING_MODE_OFF;
	}

	if ( cur_env_set_level == HT_DEBUG_STRING_MODE_OFF )
		return 0; 		/* Need Not Register Log File */

	/********************************************************************/
	/*		get	environmemtal 	variable 	HT_DEBUG_STRING_SIZE		*/
	/********************************************************************/
	ptr = (char *)getenv("HT_DEBUG_STRING_SIZE");
	/* multiply by SIZE_UNIT */
	if ( ptr == NULL )
	{
		fprintf(stderr, "environmental variable HT_DEBUG_STRING_SIZE "
						"not set, so use default value 1 \n");

		base_overflow = 1;	/* initialize base_overflow to 1 */
	}
	else
		base_overflow = atol(ptr);

	/********************************************************************/
	/*			get 	current 	system	time 	to 	register		*/
	/********************************************************************/
    memset(st, 0, sizeof(st));
    memset(s1, 0, sizeof(s1));

    systime=time(NULL);
    ptime=localtime(&systime);

/*    strftime(st, sizeof(st),"%Y-%m-%d %H:%M:%S|%a %b %d %H:%M:%S %Y", ptime);*/
    strftime(st, sizeof(st),"%Y-%m-%d %H:%M:%S", ptime);
    strftime(s1, sizeof(s1), "%Y%m%d", ptime);

	/********************************************************************/
	/*			set 	logical		file 	name 						*/
	/********************************************************************/
    memset(filename, 0, sizeof(filename));	/* Log File Name */
    if ( logfile == (char *)NULL ) /* filename is NULL */
    {
		fp = stderr;
    }
    else if (  strlen(logfile) == 0 )	/* filename is "" */
	{
        strcpy(filename, "./ht.log");
	}
    else /* filename is normal string */
	{
        strcpy(filename, logfile);
	}

   	if ( fp != stderr ) 
   	{
		if ( ( fp = fopen(filename, "a+") ) == NULL )
			fp = stderr;
		else
		{
			memset(&statbuf, 0, sizeof(statbuf));
			nRet = stat(filename, &statbuf);
			if ( nRet == 0 && statbuf.st_size >= SIZE_UNIT * base_overflow )
			{
				fclose(fp);
				memset(bakfilename, 0, sizeof(bakfilename));
				sprintf(bakfilename, "%s.%s", filename, s1);
				rename(filename, bakfilename);
				if ( ( fp = fopen(filename, "a+") ) == NULL )
					fp = stderr;
			}
		}
	}

	fprintf(fp, "%s", DOUBLE_LINE);

/*	cnt=fprintf(fp, "Date:[%s] %s\n", st, CorporationTitle); 
	cnt=fprintf(fp, "File:[%s] Line:[%d]\n", iFile, iLine); 
*/	
	fprintf(fp, "Date:[%s]\n", st); 
	fprintf(fp, "File:[%s] Line:[%d]\n", iFile, iLine); 

   	for (i=0; i<iLength; i++)
   	{
      if (j==0)
      {
         memset( s, ' ', sizeof(s));
         sprintf(temp,   "%04d:",i );
         memcpy( s, temp, 5);
         sprintf(temp,   ":%04d",i+15 );
         memcpy( &s[72], temp, 5);
      }
      sprintf( temp, "%02X ", (unsigned char)psBuf[i]);
      memcpy( &s[j*3+5+(j>7)], temp, 3);
      if ( isprint( psBuf[i]))
      {
         s[j+55+(j>7)]=psBuf[i];
      }
      else
      {
         s[j+55+(j>7)]='.';
      }
      j++;
      if ( j==16)
      {
         s[77]=0;
         fprintf(fp, "%s\n", s);
         j=0;
      }
   	}

   	if (j)
   	{
      s[77]=0;
      fprintf(fp, "%s\n\n", s);
   	}

	fflush(fp);

   	if ( fp != stderr ) 
		fclose(fp);

	return 0;
}

/****************************************************************/
/* 	FunctionName:   	replace_env_var							*/
/*	Input,Output:		char *str								*/
/****************************************************************/
/*	Eg:					buf="$(HOME)/src/$TERM"					*/
/*						replace_env_var(buf)					*/
/*						buf=/home/toplink/jinggang/src/vt100	*/
/****************************************************************/
int replace_env_var(char *str)
{
char *ptr=NULL;
char buf[512], field[512];
int	 len=0,nRet,flag;
int  count=1,i,j;

	/********************************************************************/
	/* 		delete 	characters ' ','(',')','\t' from string "str"		*/
	/********************************************************************/
    len=strlen(str);
    memset(buf,0,sizeof(buf));

    for(i=0,j=0;i<len;i++)
    if ( str[i] != ' ' && str[i] != '\t' && str[i] != '(' && str[i] != ')' )
        buf[j++]=str[i];

    memset(str,0, len);
    strcpy(str,buf);

	/********************************************************/
	/* 		distinguish if first character is ' ' or not	*/
	/********************************************************/
	if ( str[0] == '$' )
		flag = 1;
	else
		flag = 2;

	memset(buf, 0, sizeof(buf));
	if ( flag == 1 )
	{
	   	ptr=(char *)strtok((char *)str,"$");
   		while ( ptr != NULL )
		{
			memset(field, 0, sizeof(field));
			sprintf(field,"%c%s",'$',ptr);
			nRet = convert_env(field);
			if ( nRet != 0 )
				return -1;
	
			strcat(buf, field);

			ptr=(char *)strtok((char *)NULL,"$");
		}
	}
	else if ( flag == 2 )
	{
	   	ptr=(char *)strtok((char *)str,"$");
   		while ( ptr != NULL )
		{
			count++;
			if ( count != 2)
			{
				memset(field, 0, sizeof(field));
				sprintf(field,"%c%s",'$',ptr);
				nRet = convert_env(field);
				if ( nRet != 0 )
					return -1;
			}
			else
			{
				memset(field, 0, sizeof(field));
				sprintf(field,"%s",ptr);
			}

			strcat(buf, field);

			ptr=(char *)strtok((char *)NULL,"$");
		}
	}

	len = strlen(buf);
	memcpy(str, buf, len+1);

	return 0;
}

/****************************************************************************/
/* 	FunctionName:	convert_env												*/
/* 	Statement:		convert environment variable to real value in string	*/
/****************************************************************************/
int	 convert_env(char *str)
{
char envbuf[512],buf[512];
char *ptr=NULL,*ptr1=NULL;
int  choice=0;
/*len,*/
	
	memset(buf, 0, sizeof(buf));

   	ptr=(char *)strpbrk((char *)str,"./");
	if ( ptr != NULL )
	{
		choice = 1;
		memset(envbuf, 0, sizeof(envbuf));
		memcpy(envbuf, &str[1], ptr-str-1);
	}
	else
	{
		choice = 2;
		memset(envbuf, 0, sizeof(envbuf));
		strcpy(envbuf,&str[1]);
	}

#ifdef PRT_CONVERT
	printf("before convert, envbuf=[%s]\n", str);	
#endif

	ptr1=(char *)getenv(envbuf);
	if ( ptr1 == (char *)NULL )
	{
		fprintf(stdout, "environment variable [%s] not exist !\n", envbuf);
		return -1;
	}
	else
	{
		if ( choice == 1 )
		{
			strcat(buf, ptr1);
			strcat(buf, ptr);
		}
		else if ( choice == 2 )
			strcat(buf, ptr1);
	}

	/*len=strlen(buf);*/

	memset(str, 0, sizeof(str));
	strcpy(str, buf);

#ifdef PRT_CONVERT
	printf("after  convert, envbuf=[%s]\n", str);
#endif

	return 0;
}

int GetLogName(char *infile, char *outfile )
{
	int nRet;
	char logfile[512];

	if ( infile == NULL )
	{
		strcpy(outfile, "./ht.log");
		return 0;
	}

    memset(logfile, 0, sizeof(logfile));
    strcpy(logfile, infile);

    nRet = replace_env_var(logfile);
    if ( nRet == 0 )
	{
		strcpy(outfile, logfile);
        return 0;
	}
    else
        return nRet;
}

/****************************************************************************/
/* FunctionName:   RecTivoliLog											*/
/* Input:  																	*/
/* Output:        															*/
/* Return:        															*/
/****************************************************************************/
/* Statement: 																*/
/* sysname��10λ���̶�ʹ��Bridge											*/
/* procname��15λ��������													*/
/* errtype��1λ																*/
/* 1 - database error														*/
/* 2 - socket communication error											*/
/* 3 - system message queue error											*/
/* 4 - system command error													*/
/* 5 - business error														*/
/* 6 - MQ error																*/
/* 7 - other error															*/
/* file:__FILE__															*/
/* line: __LINE__															*/
/****************************************************************************/
/* Auther: Jiawei Shen														*/
/****************************************************************************/
void RecTivoliLogC(char *sysname,char *procname, int errtype, char *file,int line, char *fmt, ...)
{
	int 	nRet;
	va_list	ap;
	FILE	*fp = NULL;
	char	sFilename[256+1];
	char	sBakFilename[256 + 1];
	
	char	*ptr=NULL;
	struct 	stat	statbuf;
	struct 	tm *ptime;
	char	s[128];
	char	s1[128];
	time_t	systime;
	long	base_overflow;
	
	memset(s, 0, sizeof(s));
	memset(s1, 0, sizeof(s1));
	systime = time(NULL);
	ptime = localtime(&systime);
	strftime(s, sizeof(s), "%Y-%m-%d %H:%M:%S", ptime);
	strftime(s1, sizeof(s1), "%Y%m%d", ptime);
	
	ptr = (char *)getenv("HT_LOG_SIZE");
	if(ptr == NULL)
	{
		fprintf(stderr, "environmental variable HT_LOG_SIZE not set, "
						"so use default value 1\n");
		base_overflow = 1;
	}
	else
		base_overflow = atol(ptr);
	
	memset(sFilename, 0, sizeof(sFilename));
	sprintf(sFilename, "%s/log/tivoli.log", getenv("APPL"));
	
	fp = fopen(sFilename, "a+");
	if(fp == NULL)
		return;
	
	memset(&statbuf, 0, sizeof(statbuf));
	nRet = stat(sFilename, &statbuf);
	if(nRet == 0 && statbuf.st_size >= SIZE_UNIT*base_overflow)
	{
		fclose(fp);
		
		memset(sBakFilename, 0, sizeof(sBakFilename));
		sprintf(sBakFilename, "%s.%s", sFilename, s1);
		rename(sFilename, sBakFilename);
		
		fp = fopen(sFilename, "a+");
		if(fp == NULL)
			return;
	}
	
	fprintf(fp ,"ERROR<%s><%s><%s><%d><", s, sysname, procname, errtype);
	va_start(ap, fmt);
	vfprintf(fp, fmt, ap);
	va_end(ap);
	
	fprintf(fp, ">");
	/*�ļ�����������ʱ����ʾ*/
	/*fprintf(fp, "<%s><%d>", file, line);*/
	fprintf(fp, "\n\n");
	fflush(fp);
	
	fclose(fp);
}

