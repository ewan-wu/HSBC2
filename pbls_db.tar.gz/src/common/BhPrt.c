/*****************************************************************************/
/*																			 */
/* Product:      															 */
/*																			 */
/*---------------------------------------------------------------------------*/
/*																			 */
/* PROGRAM NAME: bhprintf.c    												 */
/* DESCRIPTIONS: ��ӡ������ˮ�ļ�           			 					 */
/*																			 */
/*---------------------------------------------------------------------------*/
/*																			 */
/* MODIFICATION LOG															 */
/* DATE			PROGRAMMER			DESCRIPTION								 */
/* 2003-07-28   Duan Annie			initial Version Creation				 */
/*****************************************************************************/
#include <stdio.h>
/* #include <varargs.h> */
#include <stdarg.h> 
#include "glb_def.h"

/******************************************************************************/
/*  Function     : cmBhPrintf()                                               */
/*  Description  : printf to batchlog                                         */
/*  Arguments    : va_list                                                    */
/*  Return Value : is the return value of function vfprintf()                 */
/******************************************************************************/
int cmBhPrintf(char *fmt,...)
{
	char conf[80];
	FILE *fp;
	char *nfmt;
	char afmt[80];
	int cnt;
	va_list argptr;
	char	sBhDay[DLEN_DATE + 1];

	memset(sBhDay, 0, sizeof(sBhDay));
	if (GetCurHstStlmDate(sBhDay) != 0)
		strcpy(sBhDay, "00000000");

	memset(conf,'\0', sizeof(conf));
	strcpy(conf, (char*)getenv("APPL"));
	strcat(conf, "/log/batch/batchlog.");
	strcat(conf, sBhDay);

	va_start(argptr,fmt);
	fmt=va_arg(argptr, char *);

    if(strlen(conf) == 0)
		fp = stderr;
	else
	{
		if ((fp=fopen(conf,"a+")) == NULL)
			fp = stderr;
	}

	cnt = vfprintf(fp,fmt,argptr);

	va_end(argptr);

	if (fp != stderr)
		fclose(fp);

	return(cnt);
}

