#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "msglog.h"
//#include "common.h"
#include "ipc.h"

int main(int argc, char *argv[])
{
	short sndsize, rcvsize;
    char sndbuf[MAX_PACKET_LEN];
    char rcvbuf[MAX_PACKET_LEN];
    long lMsgSource;
    long lPid = 0;
    short nRet;
	T_TlrText wdTlrText;

	sndsize = 0;
	rcvsize = 0;
	memset(sndbuf, 0, sizeof(sndbuf));
	memset(rcvbuf, 0, sizeof(sndbuf));

	if(argc != 2)
	{
		printf("usage: %s txno\n", argv[0]);
		return -1;
	}

	nRet = Init();
	if(nRet < 0)
	{
		printf("Init error!nRet[%d]\n", nRet);
		return -1;
	}

	memset(&wdTlrText, 0, sizeof(wdTlrText));
	memset(&wdTlrText.tTitaLabel, ' ', sizeof(wdTlrText.tTitaLabel));

	strcpy(wdTlrText.tTitaLabel.txno, argv[1]);
	memcpy(wdTlrText.tTitaLabel.tlrno, "test", 8);
	memcpy(wdTlrText.tTitaLabel.kinbr, "000", 3);

	switch(atoi(argv[1]))
	{
	case 7027:
		strcpy(wdTlrText.sTitaText, "Blacklist_20091225.xls");
		break;
	
	case 7039:
		strcpy(wdTlrText.sTitaText, "/home/nbstpbdg/cnapsrun/iodata/impdda/537/dda_20100208.xls");
		break;	
	
	case 7038:
		strcpy(wdTlrText.sTitaText, "Vendor_code_20100104.txt");
		break;
	
	case 7044:
		strcpy(wdTlrText.sTitaText, "AML.txt");
		break;

	case 1208:
		strcpy(wdTlrText.sTitaText, "20100101201005142");
		break;

	case 8888:
		strcpy(wdTlrText.sTitaText, "00000000select tlr_id from pbtlrctl;");
		break;
	case 12:
		strcpy(wdTlrText.sTitaText, "aaaaaaaabbbbbbbbccccccccdddddddd");
		break;

	case 23:
		strcpy(wdTlrText.sTitaText, "");
		break;

	case 7051:
		strcpy(wdTlrText.sTitaText, "tt      ");
		break;

	case 7052:
		strcpy(wdTlrText.sTitaText, "tt      ");
		break;
	case 5101:
		strcpy(wdTlrText.sTitaText, "A002ICBC                                                        CNY1234567890                         liudehua01                                                            ");
		break;
	case 5104:
		strcpy(wdTlrText.sTitaText, "10021234567890                         CNY");
		break;

	case 9999:
		strcpy(wdTlrText.sTitaText, "90000001^8810^^^^20091109^20101109^^^^");
		break;

	default:
		printf("invalid txno[%s]\n", argv[1]);
		return -1;
	}

	sndsize = sizeof(wdTlrText.tTitaLabel) + strlen(wdTlrText.sTitaText);

	wdTlrText.tTitaLabel.header[0] = sndsize / 256;
	wdTlrText.tTitaLabel.header[1] = sndsize % 256;

    lPid = getpid();
	printf("lPid[%d]\n", lPid);

	//*****************************************
	//������Ϣ��CI_TLRBDG
	//*****************************************

	memcpy(sndbuf, &wdTlrText, sndsize);
	nRet = nCommonMsqSend(sndsize, sndbuf, lPid, CI_TLRBDG);
	if(nRet != 0)
	{
		perror("nCommonMsqSend error!");
		return;
	}

	printf("sndsize[%ld]\n", sndsize);
	printf("send ok!\n");

	//*****************************************
	//��CI_TLRCOMM������Ϣ
	//*****************************************

	if(nCommonMsqRecvT(&rcvsize, rcvbuf, &lMsgSource, lPid, CI_TLRCOMM) != 0)
	{
		perror("nCommonMsqRecvT error!");
		return;
	}

	printf("rcvsize[%d]\n", rcvsize);
	printf("recv ok!\n");
}

int Init()
{
    short nRet;

	//*****************************************
	//�������ݿ�
	//*****************************************

	nRet = DbConnect();
    if (nRet != 0)
    {
		printf("DbConnect error[%d]\n", nRet);
        return -1;
    }
	printf("DbConnect ok!\n");
	
	//*****************************************
	//��TB_SYSSVC����������ȫ������gMsgqueInf
	//*****************************************

	nRet = nLoadMsqDef();
    if (nRet != 0)
    {
		printf("nLoadMsqDef error[%d]\n", nRet);
        return -1;
	}
	printf("nLoadMsqDef ok!\n");

	//*****************************************
	//��CI_TLRCOMMִ��msgget
	//*****************************************

    nRet = nCommonMsqInit(CI_TLRCOMM);
    if (nRet != 0)
    {
		printf("nCommonMsqInit error[%d]\n", nRet);
        return -1;
    }
	printf("nCommonMsqInit ok!\n");

	//*****************************************
	//��CI_TLRBDGִ��msgget
	//*****************************************

    nRet = nCommonMsqInit(CI_TLRBDG);
    if (nRet != 0)
    {
		printf("nCommonMsqInit error[%d]\n", nRet);
        return -1;
    }
	printf("nCommonMsqInit ok!\n");
    
	//*****************************************
	//�Ͽ����ݿ�
	//*****************************************

	nRet = DbDisConnect();
    if (nRet != 0)
    {
        return -1;
    }
	printf("DbDisConnect ok!\n");

	return 0;
}
