/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: tlrbdg.c                                                    */
/* DESCRIPTIONS: The bridge and convert-in process server.                   */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2003-07-08  XuTonghui     Initial Version Creation                        */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "msgque.h"
#include "msglog.h"
#include "glb_def.h"
#include "wd_incl.h"
#include "ipc.h"

#include "htlog.h"
char logfile[256];

#define STELLER_MAX_CMT_LEN              2000
#define TXNO_FE_CMT_MAX                  4300
#define TXNO_FE_CMT_MIN                  4200

short   InitBridge();
void    vBdgProcess(long,void*); 

/*****************************************************************************/
/* FUNC:   short InitBridge ();                                              */
/* INPUT:  <none>                                                            */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Initialize the BRIDGE server.                                     */
/*         1. Initial the toplink message queues which BRIDGE may use.       */
/*         2. Open the (Connect to) database.                                */
/*         3. Load the route information.                             		 */
/*         4. Close the (Disconnect from) database.                          */
/*****************************************************************************/
short InitBridge()
{
	long lReturn;
	short nRet;

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"InitBridge: begin\n");

	/***************************/
    /* Connect to the database */
	/***************************/
	lReturn = DbConnect();
    if (lReturn != 0)
    {
       	ErrReport(CI_TLRBDG,
               	EI_DATABASE,
               	lReturn,
               	CI_SEVERITY_SYSERROR,
               	ES_DB_OPEN);
       	return -1;
    }

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    		"InitBridge:CONNECT TO DATABASE OK!\n");

	/*****************************************/
    /* Load the server information in SRVINF */
	/*****************************************/
	if (0 != LoadSrvMsq())
	{
       	ErrReport(CI_TLRBDG, 
               	  EI_DATABASE, 
               	  0, 
               	  CI_SEVERITY_SYSERROR,
               	 ES_DB_SELECT);
       	return -1;
	}

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    		"InitBridge:Load server route information from SRVMSQ success!\n");

    /********************************************/
    /* Load the TxnMap information of TXNNOMAP  */
    /********************************************/
    if (0 != LoadTxnnoMap())
    {
        ErrReport(CI_TLRBDG,
                  EI_DATABASE,
                  0,
                  CI_SEVERITY_SYSERROR,
                 ES_DB_SELECT);
        return -1;
    }

    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
         "InitBridge:Load txnnomap information from TXNNOMAP success!\n");

	/*****************************/
    /* Initial the message queue */
	/*****************************/
	nRet = nCommonMsqAllInit(CI_TLRBDG);
	if (nRet != 0) 
    {
       	ErrReport(CI_TLRBDG, 
               	EI_MESSAGEQUEUE, 
               	0, 
               	CI_SEVERITY_SYSERROR,
               	ES_MSGQ_BDG_CONNECT);
       	return -1;
    }

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"InitBridge:Connect BRIDGE MSGQ success!\n");

	/********************************/
    /* Disconnect from the database */
	/********************************/

	lReturn = DbDisConnect();
	if (lReturn != 0)
	{
		ErrReport(CI_TLRBDG,
		 		  EI_DATABASE,
				  lReturn,
				  CI_SEVERITY_SYSERROR,
				  ES_DB_CLOSE);
		return -1;
	}

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    		"InitBridge:success return\n");

    return 0;
}


/*****************************************************************************/
/* FUNC:   void vBdgProcess(void * sDataBuf);          	                     */
/* INPUT:  message data                                                       */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Processing the message.   		                              */
/*         And transfer them                                                 */
/*****************************************************************************/
void vBdgProcess( long lMsgSource, void *sDataBuf )
{
	short nRet,nTxnStep;
	long lReturn;
	long  nMsgSrouce,lSrvId;
	long  lTxnNo,lOutTxnNo;
	char  sTxnNo[CR_CLSTXNNO_LEN+1];
	char  sTxnOutNo[CR_CLSTXNNO_LEN+1];
	char  sTxnRltNo[CR_CLSTXNNO_LEN+1];
    char  sInBuf[sizeof(T_SwtInBufDef)];
    char  sTxnStep[CR_TXNSTEP_LEN+1];
	char  sSrvId[CR_SRVID_LEN+1];
	char  sTermId[CR_TERMID_LEN+1];
	char  sServiceName[CR_SRVNAME_LEN+1];
    char  sTcpLen[3];
	short nTcpLen;
	
	T_SwtInBufDef   *pSwtInBuf;
	T_MsgText  		*pMsgText;
	T_SwtInBufDef   tSwtInBuf;

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
		"vBdgProcess:begin\n");

	pMsgText = (T_MsgText *)sDataBuf;

	memset ( sInBuf,' ',sizeof(sInBuf));
	memset ( &tSwtInBuf,' ',sizeof(tSwtInBuf));
	
	memcpy( &tSwtInBuf.tMsgText,pMsgText,sizeof(tSwtInBuf.tMsgText));
	
	memset ( sTxnOutNo,0,sizeof(sTxnOutNo));
	memcpy(sTxnOutNo, tSwtInBuf.tMsgText.tTitaLabel.txno, 
		sizeof(tSwtInBuf.tMsgText.tTitaLabel.txno));
	memcpy(sTxnRltNo, tSwtInBuf.tMsgText.tTitaLabel.txno, 
		sizeof(tSwtInBuf.tMsgText.tTitaLabel.txno));

#ifdef _DEBUG
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
		"OutTxnNo=[%s]\n",sTxnOutNo);
#endif

	/*lTxnNo = lGetTxnInCode(CI_TLRBDG,sTxnOutNo,sTxnRltNo);*/

	nRet = nGetClsTxno( CI_TLRCOMM, &lTxnNo, sTxnOutNo);
	if ( nRet != 0 )
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"GetClsTxNo error");
	}
	


	sprintf(sTxnNo,"%08d",lTxnNo);
	nTxnStep = 0;
	sprintf(sTxnStep,"%04d",nTxnStep);

#ifdef _DEBUG
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
		"lTxnNo=[%d],nTxnStep=[%d]\n",lTxnNo,nTxnStep);
#endif

	memset ( sTermId,0,sizeof(sTermId));
	sprintf( sTermId,"%08d",lMsgSource );

	memcpy(tSwtInBuf.tMsgText.tTitaLabel.termid,sTermId, 
		sizeof(tSwtInBuf.tMsgText.tTitaLabel.termid));

	memcpy(tSwtInBuf.tIPCHeader.sClsTxnNo,sTxnNo, 
		sizeof(tSwtInBuf.tIPCHeader.sClsTxnNo));
	memcpy(tSwtInBuf.tIPCHeader.sTxnStep,sTxnStep, 
		sizeof(tSwtInBuf.tIPCHeader.sTxnStep));

	lSrvId = nFindServerId(CI_TLRBDG,lTxnNo,0);
	if (lSrvId == 0)
	{
		/* transaction not found */
    	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        	" Transaction not found! OutTxno:[%s] Send the message to MANAGER!\n", 
			sTxnOutNo );
		lSrvId = CI_SYSMNG;
	}
	sprintf(sSrvId,"%08d",lSrvId);

	memcpy(tSwtInBuf.tIPCHeader.sSrcSrvId,sSrvId,
		sizeof(tSwtInBuf.tIPCHeader.sSrcSrvId));
	
#ifdef _DEBUG
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
		"SrvId=[%ld]\n",lSrvId);
#endif

    memcpy(sInBuf,&tSwtInBuf,sizeof(tSwtInBuf)); 


 	memset ( sTcpLen,'\0',sizeof(sTcpLen));
   	memcpy ( sTcpLen,tSwtInBuf.tMsgText.tTitaLabel.header,2 );
    nTcpLen = (unsigned char)sTcpLen[0] * 256
                + (unsigned char)sTcpLen[1];

    nTcpLen = (unsigned char)sTcpLen[0] * 256
                + (unsigned char)sTcpLen[1];

#ifdef _DEBUG
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        "TcpLen is [%d]\n", nTcpLen );
#endif

#ifdef _DEBUG
	HtDebugString(logfile,sInBuf,(int)(nTcpLen+sizeof(tSwtInBuf.tIPCHeader)),
				__FILE__, __LINE__);
#endif

	nRet = nCommonMsqSend(nTcpLen+sizeof(tSwtInBuf.tIPCHeader), 
							sInBuf, CI_TLRBDG, lSrvId );
	if (nRet != 0)
	{
		ErrReport(CI_TLRBDG,
				EI_MESSAGEQUEUE,
				0,
				CI_SEVERITY_SYSERROR,
				ES_MSGQ_WRITE);
	}

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"vBdgProcess:return\n");

	return;
}

/*****************************************************************************/
/* FUNC:   void main ();                                                     */
/* INPUT:  <none>                                                            */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Toplink BRIDGE server main process.                               */
/*         1. InitBridge().                                                  */
/*         2. Main loop: Handle the received messages.                       */
/*****************************************************************************/
void main(int argc, char **argv)
{
	short nRet;
	long lReturn;
	long lMsgSource;
	char sTime[15];
	short nDataLen;
	char sDataBuf[sizeof(T_MsgText)];

	if ( argc != 2 )
	{
		fprintf(stdout, "Usage: bridge <logfile>\n");
		exit(1);
	}

	setbuf(stdout, NULL);
	
    nRet = GetLogName(argv[1], logfile);
    if (nRet != 0 )
    {
		ErrReport(CI_TLRBDG,
				  EI_PROCESS,
				  0,
				  CI_SEVERITY_SYSERROR,
				  ES_PROCESS_EXIT);

		fprintf(stderr, "GetLogName error !\n");
	}

	/**************/
    /* InitBridge */
	/**************/
    nRet = InitBridge();
    if (nRet == -1)
    {
		ErrReport(CI_TLRBDG,
				  EI_PROCESS,
				  0,
				  CI_SEVERITY_SYSERROR,
				  ES_PROCESS_EXIT);
        	exit(1);
    }

	/************************/
	/*  Main loop of BRIDGE */
	/************************/
	while (1)
	{
		lMsgSource = 0;
		nRet = nCommonMsqRecv (&nDataLen, sDataBuf, &lMsgSource, CI_TLRBDG);
		if (nRet != 0) 
		{
			if (errno != EINTR)
			{
				HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
						"\n errno[%d]\n", errno);

				if (nCommonMsqInit(CI_TLRBDG) == -1)
				{
					ErrReport(CI_TLRBDG,
						EI_MESSAGEQUEUE,
						0,
						CI_SEVERITY_SYSERROR,
						ES_MSGQ_READ);
					exit(1);
				}
				continue;
			}
		}

		if( lMsgSource== 0) continue;

		GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				"<<<<<<<<<<<<<<<<<<<< Message received >>>>>>>>>>>>>>>>>>>>\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				"<<<<<<<<<<<<<<<<<<<< [%s] >>>>>>>>>>>>>>>>>>>>\n", sTime);
#ifdef _DEBUG
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				"\n Message received from [%d]! \n", lMsgSource);
#endif

#ifdef _DEBUG
		HtDebugString(logfile, sDataBuf, (int)nDataLen, __FILE__, __LINE__);
#endif

		/****************************/
		/* process received message */
		/****************************/
		vBdgProcess (lMsgSource,sDataBuf);

		GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				"<<<<<<<<<<<<<<<<<<<< Processing End >>>>>>>>>>>>>>>>>>>>\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				"<<<<<<<<<<<<<<<<<<<< [%s] >>>>>>>>>>>>>>>>>>>>\n", sTime);
	
	} /* end of while(1) */

} /* end of main() */
