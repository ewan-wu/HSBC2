/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: pbhubbdg.c                                                 */
/* DESCRIPTIONS: The bridge and convert-in process server.                   */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/signal.h>
#include "msgque.h"
#include "msglog.h"
#include "glb_def.h"
#include "wd_incl.h"
#include "ipc.h"
#include "convert.h"
#include "tivoli.h"

#include "htlog.h"
char logfile[256];

short   InitBridge();
void    vBdgProcess(void*, short); 
void    QuitTerminate(int sig);


/*****************************************************************************/
/* FUNC:   short InitBridge ();                                              */
/* INPUT:  <none>                                                            */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Initialize the BRIDGE server.                                     */
/*         1. Initial the toplink message queues which BRIDGE may use.       */
/*         2. Open the (Connect to) database.                                */
/*         3. Load the route information.                             		 */
/*         4. Close the (Disconnect from) database.                          */
/*****************************************************************************/


/*****************************************************************************/
/* FUNC:   void vBdgProcess(void * sDataBuf);          	                     */
/* INPUT:  message data                                                       */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Processing the message.   		                              */
/*         And transfer them                                                 */
/*****************************************************************************/
void vBdgProcess( void *sDataBuf, short nDataLen )
{
    int					iRet;
    short				nRet;
    long				lTxnNo;
    long				lSrvId;

    
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "vBdgProcess:begin\n");

    
    /* ����ת����CI_PAIDSWT */
	
    lSrvId = CI_PAIDSWT;
		nRet = nCommonMsqSend(nDataLen, sDataBuf, CI_PAIDBDG, lSrvId);
		if (nRet != 0)
		{
			HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "vBdgProcess:return[%s]\n",strerror(errno));
		    ErrReport(CI_PAIDBDG,
				    EI_MESSAGEQUEUE,
				    0,
				    CI_SEVERITY_SYSERROR,
				    ES_MSGQ_WRITE);
			
		}

    HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "vBdgProcess:return\n");

    return;
}

/*****************************************************************************/
/* FUNC:   void main ();                                                     */
/* INPUT:  <none>                                                            */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Toplink BRIDGE server main process.                               */
/*         1. InitBridge().                                                  */
/*         2. Main loop: Handle the received messages.                       */
/*****************************************************************************/
int main(int argc, char **argv)
{
    short nRet;
    long  lMsgSource;
    char  sTime[15];
    short nDataLen=0;
    char  sDataBuf[CNS_MAX_PKT_LEN];

    if ( argc != 2 )
    {
        fprintf(stdout, "Usage: pbhubbdg <logfile>\n");
        exit(1);
    }

    setbuf(stdout, NULL);
    sigset(SIGTERM, QuitTerminate);

    nRet = GetLogName(argv[1], logfile);
    if (nRet != 0 )
    {
        ErrReport(CI_PAIDBDG,
        		  EI_PROCESS,
        		  0,
        		  CI_SEVERITY_SYSERROR,
        		  ES_PROCESS_EXIT);
        fprintf(stderr, "GetLogName error !\n");
    }

    /*********************/
    /* Connect Database  */
    /*********************/
	nRet = DbConnect();	
	if(nRet != 0 )
	{
		HtLog(HTLM_ERR	,"Connect Database Error");
		RecTivoliLogC( "PBLS", "PBPAIDBDG", TIVOLI_DATABASE, __FILE__, __LINE__, "Connect Database Error!");
		exit(1);
	}

    /*********************/
    /* nLoadMsqDef       */
    /*********************/
	nRet = nLoadMsqDef();
	if(nRet != 0 )
	{
		HtLog(HTLM_ERR	,"nLoadMsqDef Error");
		RecTivoliLogC( "PBLS", "PBPAIDBDG", TIVOLI_DATABASE, __FILE__, __LINE__, "Load Message Define Error!");
		exit(1);
	}

    /*********************/
    /* InitMsq           */
    /*********************/
	nRet = nCommonMsqInit(CI_PAIDBDG);	
	if(nRet != 0 )
	{
		HtLog(HTLM_ERR	,"nCommonMsqInit CI_PAIDBDG Error");
		RecTivoliLogC( "PBLS", "PBPAIDBDG", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "Initialize Message Queue Error!");
		exit(1);
	}

	nRet = nCommonMsqInit(CI_PAIDSWT);	
	if(nRet != 0 )
	{
		HtLog(HTLM_ERR	,"nCommonMsqInit CI_PAIDSWT Error");
		RecTivoliLogC( "PBLS", "PBPAIDBDG", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "Initialize Message Queue Error!");
		exit(1);
	}


    /************************/
    /*  Main loop of BRIDGE */
    /************************/
    while (1)
    {
        printf("start to recv msg\n");
        nRet = nCommonMsqRecv (&nDataLen, sDataBuf, &lMsgSource, CI_PAIDBDG);
        if (nRet != 0) 
        {
            if (errno != EINTR)
            {
				RecTivoliLogC( "PBLS", "PBPAIDBDG", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "CALL nCommonMsqRecv Fail!");
                HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "\n errno[%d]\n", errno);

				        if (nCommonMsqInit(CI_PAIDBDG) == -1)
				        {
					        ErrReport(CI_PAIDBDG,
						        EI_MESSAGEQUEUE,
						        0,
						        CI_SEVERITY_SYSERROR,
						        ES_MSGQ_READ);
					        exit(1);
				        }
				        continue;
			      }
		    }

        GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
        HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				    "<<<<<<<<<<<<<<<<<<<< Message received >>>>>>>>>>>>>>>>>>>>\n");
		    HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				    "<<<<<<<<<<<<<<<<<<<< [%s] >>>>>>>>>>>>>>>>>>>>\n", sTime);
		    HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				    "\n Message received from [%d]! \n", lMsgSource);
		    HtDebugString(logfile,sDataBuf,nDataLen,__FILE__,__LINE__);
	
    		/****************************/
    		/* process received message */
    		/****************************/
    		vBdgProcess (sDataBuf, nDataLen);
	
    		GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
    		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    				"<<<<<<<<<<<<<<<<<<<< Processing End >>>>>>>>>>>>>>>>>>>>\n");
    		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    				"<<<<<<<<<<<<<<<<<<<< [%s] >>>>>>>>>>>>>>>>>>>>\n", sTime);
    	    printf("end of recv msg\n");
    } /* end of while(1) */
    return 0;
} /* end of main() */

void QuitTerminate(int sig)
{
    short nRet;
    HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    "\nCnapsBridge PROCESS(%d) Normal[%d] EXIT AT %s\n", getpid(), sig, GetSystemTime());
    
    ErrReport(CI_PAIDBDG,
		  EI_PROCESS,
		  sig, 
      CI_SEVERITY_SYSERROR,
		  "PBPAIDBDG���������˳�");
    
    nRet=DbDisConnect();
    if (nRet != 0)
    {
    		ErrReport(CI_PAIDBDG,
    		 		  EI_DATABASE,
    				  nRet,
    				  CI_SEVERITY_SYSERROR,
    				  ES_DB_CLOSE);
    		return ;
    }
    exit(1);
}
