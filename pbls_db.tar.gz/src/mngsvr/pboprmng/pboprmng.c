/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*                                                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: manager                                                 */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*                                                                      */
/************************************************************************/

#include "pboprmng.h"

T_TOTW_LABTEX     it_totw;
T_TXCOM_AREA      it_txcom;
T_TITA_LABTEX     it_tita;

T_ICBC_GROUPHEADER icbc_groupheader;
T_BANK_INFO        bank_info;

char logfile[256];
static long lMsgSource = 0;

static int  InitGlbVar(void *psDataBuf, short nInDataLen);
static void vTellerProcess(void *psDataBuf, short nInDataLen);
static void HandleExit( );

int main(int argc, char **argv)
{
    int  iRet = 0 ;
    short  nInDataLen = 0;
    char sDataBuf[sizeof(IPCMsgDef)];
	
	
    setbuf( stdout, NULL );
    
    DebugMemory( "Start");
	
    iRet = GetLogName(argv[1], logfile);
    if (iRet != 0 )
    {
        /*ErrReport(CI_OPRMNG,
        		 	EI_PROCESS,
             		  	0,
        		  	CI_SEVERITY_SYSERROR,
        			ES_GET_LOGFILE);*/
        HtLog(HTLM_ERR, "GetLogName Error!" );
        exit(-1);
    }
	
    iRet = InitPboprmng();
    if (iRet != 0 )
    {
        /*ErrReport(CI_OPRMNG,
        		 	EI_PROCESS,
             		  	0,
        		  	CI_SEVERITY_SYSERROR,
        			ES_PROCESS_INIT);*/
        HtLog(HTLM_ERR, "Init Error!" );
        exit(-1);
    }
	
	if (sigset(SIGTERM, (void (*)())HandleExit) == SIG_ERR)
		HtLog(HTLM_ERR, "sigset SIGTERM error");
	
    char api_log_file[256];
    memset(api_log_file, 0, sizeof(api_log_file));
    sprintf(api_log_file, "%s/log/pboprmng_api.log", getenv("APPL"));
	char api_cmd[512];
	memset(api_cmd, 0, sizeof(api_cmd));
	sprintf(api_cmd, "touch %s", api_log_file);
	system(api_cmd);

	/***��������ʱ���ã�������־��Topmq���м�������ʼ��***/
	iRet = ICBC_API_INIT(api_log_file,  ICBC_API_OUTSRC_SVRID);
    if (iRet != 0)
    {
        ErrReport(CI_PAIDSWT, 
                  EI_MESSAGEQUEUE, 
                  0, 
                  CI_SEVERITY_SYSERROR,
                  ES_MSGQ_NET_COMM_CONNECT);
    	HtLog(HTLM_ERR, "ICBC_API_INIT error(%d)", iRet);                  
        exit(1);
    }
    
    /**��ʼ��PBLS����ͷ**begin**/
    memset(&icbc_groupheader, 0, sizeof(icbc_groupheader));
    nGetICBCGroupHeader(&icbc_groupheader);
    
    memset(&bank_info, 0, sizeof(bank_info));
    nGetBankInfo(&bank_info);
    /**��ʼ��PBLS����ͷ**end**/
    
    /* HANDLE TRANSACTION */
    while(1)
    {
        /* READ MANAGE MESSAGE QUEUE */
        memset(sDataBuf, 0 ,sizeof(sDataBuf));
        sigrelse(SIGTERM);
        iRet = nCommonMsqRecv (&nInDataLen, sDataBuf, &lMsgSource, CI_OPRMNG);
        if (iRet != 0)
        {
            if (errno != EINTR)
            {
                if (nCommonMsqInit(CI_OPRMNG) == -1)
                {
                    HtLog(HTLM_ERR, "nCommonMsqInit() error=[%d]", errno); 
                    RecTivoliLogC("PBLS", "MANAGER", TIVOLI_MESSAGEQ, __FILE__, __LINE__, 
                    "Receive Message Error! errno=[%d]",errno );
                    exit(1);
                }
                continue;
            }
        }
        HtDebugString(logfile,  sDataBuf, nInDataLen, __FILE__, __LINE__);
        		
        sighold(SIGTERM);
        switch(lMsgSource)
        {
        	case CI_TLRBDG:				/* ���� */
        		vTellerProcess((void *)sDataBuf, nInDataLen  );
        		break;
        	default:
        		HtLog(HTLM_ERR,
        				"Invalid message source =[%d]", lMsgSource);
        		break;
        }
    }
    //ȫ�����
    ICBC_API_END();
}

/* ���� */
void vTellerProcess(void *psDataBuf, short nInDataLen)
{
    struct wd_pbtlrctl_area wd_tlrctl;
    T_MngBufToTlrDef   tBufToTlr;
    T_MngBufFromTlrDef *ptBufFromTlr;

    int iRet= 0;
    long lTxno=0;
    long nOutLen=0;
    
    char sTxno[DLEN_TXNCD+1];
    
    char sPid[100];
    char sOutLen[10];
    
    memset(&tBufToTlr, 0, sizeof(tBufToTlr));
    memset(sTxno, 0, sizeof(sTxno));
    memset(sPid, 0 , sizeof(sPid));
    memset(sOutLen, 0, sizeof(sOutLen));
	
	HtDebugString(logfile,  psDataBuf, nInDataLen, __FILE__, __LINE__);
	  
    ptBufFromTlr = (T_MngBufFromTlrDef *)psDataBuf;
	
    /*iRet = InitGlbVar(&(ptBufFromTlr->tTlrText), sizeof(ptBufFromTlr->tTlrText.tTitaLabel));*/
    iRet = InitGlbVar(&(ptBufFromTlr->tTlrText), nInDataLen-sizeof(T_IPCHeader));
    if (iRet < 0)
    {
        HtLog(  HTLM_ERR,"InitGlbVar error");
        return ;
    }
    HtDebugString(logfile,  psDataBuf, nInDataLen, __FILE__, __LINE__);
	
    memcpy(sTxno, it_tita.label.txno, DLEN_TXNCD);
    memcpy(sPid, it_tita.label.termid, 8);
    HtLog(HTLM_COM, "sTxno= [%s],sPid=[%s]", sTxno,sPid);

    lTxno = atol(sTxno);

    memset(&wd_tlrctl, 0, sizeof(struct wd_pbtlrctl_area));
    memcpy(wd_tlrctl.tlr_id, it_tita.label.tlrno, sizeof(it_tita.label.tlrno));
    HtLog(HTLM_COM, "wd_tlrctl.tlr_id= [%s]", wd_tlrctl.tlr_id);
    
    iRet = DbsPBTLRCTL(DBS_FIND, &wd_tlrctl);
    if(iRet != DB_OK && iRet != DB_NOTFOUND)
    {
        HtLog(HTLM_ERR, "Dbs_TB_TLRCTL error tlrno[%s],sqlcode[%d]", wd_tlrctl.tlr_id, iRet);
        return;
    }
	
    HtLog(HTLM_COM, "lTxno = [%d], sPid = [%s]", lTxno,sPid);

    /*if((12 != lTxno && 0 != RightTrim(wd_tlrctl.sRsv1)) || iRet == DB_NOTFOUND)
    {
    it_txcom.txrsut = TX_REJECT;	
    strcpy(gsErrDesc, "�ò���Ա��Session�ѹ���,��رմ������µ�½");
    }
    else*/{

        printf("----------------- txn %s begin [%s] -----------------\n", sTxno, GetCurTime2());
        
        switch(lTxno)
        {
            case 5011:
                txn_5011();
                txn_5011End();
                break;	

            case 5012:
                txn_5012();
                txn_5012End();
                break;	

            case 5014:
                txn_5014();
                txn_5014End();
                break;	

            case 5111:
                txn_5111();
                txn_5111End();
                break;	

            case 5112:
                txn_5112();
                txn_5112End();
                break;	

            case 5021:
                txn_5021();
                txn_5021End();
                break;	
                
            case 5912:
                txn_5912();
                txn_5912End();
                break;	

            case 6001:
                txn_6001();
                txn_6001End();
                break;	

            case 6002:
                txn_6002();
                txn_6002End();
                break;	

            case 6003:
                txn_6003();
                txn_6003End();
                break;	

            case 6004:
                txn_6004();
                txn_6004End();
                break;	
                
            case 6011:
                txn_6011();
                txn_6011End();
                break;	

            case 6017:
                txn_6017();
                txn_6017End();
                break;	

            case 6018:
                txn_6018();
                txn_6018End();
                break;	

            case 6020:
                txn_6020();
                txn_6020End();
                break;	

            case 6021:
                txn_6021();
                txn_6021End();
                break;	

            case 6022:
                txn_6022();
                txn_6022End();
                break;	

            case 6023:
                txn_6023();
                txn_6023End();
                break;	
                
            case 6024:
                txn_6024();
                txn_6024End();
                break;	
            case 6025:                
                txn_6025();
                txn_6025End();
                break;	

            case 6026:                
                txn_6026();
                txn_6026End();
                break;	
                                
            case 6090:
                txn_6090();
                txn_6090End();
                break;	

            case 7011:
                txn_7011();
                txn_7011End();
                break;	

            case 7012:
                txn_7012();
                txn_7012End();
                break;	

            case 7030:
                txn_7030();
                txn_7030End();
                break;	

            case 7031:
                txn_7031();
                txn_7031End();
                break;	

            default:
            	HtLog(  HTLM_ERR, "Invalid message txno =[%d]", lTxno);
        } 
        printf("----------------- txn %s end   [%s] -----------------\n\n", sTxno, GetCurTime2());
        HtLog(HTLM_COM, "Process OK");
    }
    if(it_txcom.txrsut != TX_SUCCESS)
    {
        DbRollbackTxn();
        it_totw.label.msgtype = 'E';
    
        /* ���� */
        memcpy(it_totw.label.msgno, "9527", 4);
        memcpy(it_totw.sTotaText, gsErrDesc, strlen(gsErrDesc));
        /* end */
        nOutLen = sizeof(it_totw.label) + strlen(gsErrDesc);
        HtLog(HTLM_ERR, "Process Fail![%d][%d]",sizeof(it_totw.label),strlen(gsErrDesc));
    
    }
	
    if(it_txcom.txrsut == TX_SUCCESS)
    {
        memcpy(sOutLen, it_totw.label.msglng, sizeof(it_totw.label.msglng));
        nOutLen = atol(sOutLen);
        
        DbCommitTxn();
        HtLog(HTLM_COM, "Process Success!");
    }
	
    it_totw.label.process_flag = '0';
	
    it_totw.label.header[0] = nOutLen / 256;
    it_totw.label.header[1] = nOutLen % 256;
	
    memcpy(&tBufToTlr, &it_totw, nOutLen);
    /*
    HtLog(HTLM_COM,"header      [%8.8s]  ",it_totw.label.header      );
    HtLog(HTLM_COM,"clsno       [%6.6s]  ",it_totw.label.clsno       );
    HtLog(HTLM_COM,"termid      [%8.8s]  ",it_totw.label.termid      );
    HtLog(HTLM_COM,"refssn      [%14.14s]",it_totw.label.refssn      );
    HtLog(HTLM_COM,"kinbr       [%3.3s]  ",it_totw.label.kinbr       );
    HtLog(HTLM_COM,"trmseq      [%2.2s]  ",it_totw.label.trmseq      );
    HtLog(HTLM_COM,"ejfno       [%7.7s]  ",it_totw.label.ejfno       );
    HtLog(HTLM_COM,"taskid      [%2.2s]  ",it_totw.label.taskid      );
    HtLog(HTLM_COM,"txno        [%4.4s]  ",it_totw.label.txno        );
    HtLog(HTLM_COM,"tlrno       [%8.8s]  ",it_totw.label.tlrno       );
    HtLog(HTLM_COM,"tlsrno      [%7.7s]  ",it_totw.label.tlsrno      );
    HtLog(HTLM_COM,"tmtype      [%c]  ",it_totw.label.tmtype      );
    HtLog(HTLM_COM,"txdate      [%8.8s]  ",it_totw.label.txdate      );
    HtLog(HTLM_COM,"txtime      [%6.6s]  ",it_totw.label.txtime      );
    HtLog(HTLM_COM,"msgend      [%c]  ",it_totw.label.msgend      );
    HtLog(HTLM_COM,"msgtype     [%c]  ",it_totw.label.msgtype     );
    HtLog(HTLM_COM,"msgno       [%4.4s]  ",it_totw.label.msgno       );
    HtLog(HTLM_COM,"msglng      [%4.4s]  ",it_totw.label.msglng      );
    HtLog(HTLM_COM,"process_flag[%c]  ",it_totw.label.process_flag);
    HtLog(HTLM_COM,"inq_id      [%8.8s]  ",it_totw.label.inq_id      );
	*/
	
    HtLog(HTLM_COM, "nOutLen=[%d]", nOutLen);
    HtDebugString( logfile, (char *)&tBufToTlr, nOutLen , __FILE__, __LINE__);	

    iRet = nCommonMsqSendT(nOutLen, &tBufToTlr, atol(sPid), CI_TLRCOMM);
    if (iRet != 0)
    {
        HtLog(HTLM_ERR, "nCommonMsqSendT = [%d], errno=[%d], %s", iRet, errno, strerror(errno));
        RecTivoliLogC("PBLS", "MANAGER", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "Send Message Error!sqlcode=[%d]",iRet );
        return ;
    }

    HtLog(HTLM_COM,"nCommonMsqSendT OK");
}

int InitPboprmng()
{
    int nRet=0;
	
	if (0 != DbConnect() )
	{
		HtLog(HTLM_ERR, "DbConnect() error");
		return -1;
	}

	/*****************************************/
    /* Load the server information in SRVINF */
	/*****************************************/
	if (0 != LoadSrvMsq())
	{
       	ErrReport(CI_TLRBDG, 
               	  EI_DATABASE, 
               	  0, 
               	  CI_SEVERITY_SYSERROR,
               	 ES_DB_SELECT);
       	return -1;
	}

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    		"InitBridge:Load server route information from SRVMSQ success!\n");

	nRet = nCommonMsqAllInit(CI_TLRCOMM);
	if (nRet != 0) 
   	{
       	ErrReport(CI_OPRMNG, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }
    
    nRet = nCommonMsqAllInit(CI_OPRMNG);
	if (nRet != 0) 
   	{
       	ErrReport(CI_OPRMNG, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }
	  
	/********************************************/
    /* Load the TxnMap information of TXNNOMAP  */
    /********************************************/
#if 0
	if (0 != LoadTxnnoMap())
	{
		HtLog(  HTLM_ERR,
				"LoadTxnnoMap() error");
		return -1; 
	}
	
	if (0 != nLoadMsqDef())
	{
		HtLog(  HTLM_ERR,
				"nLoadMsqDef() error");
		return -1; 
		
	}
#endif
	
	
	/*****************************/
   	/* Initial the message queue */
	/*****************************/
	
    if (0 != nCommonMsqInit(CI_TLRCOMM))
    {
        HtLog(HTLM_ERR, "nCommonMsqInit() error");
        return -1;
    
    }
	
    if (0 != nCommonMsqInit(CI_OPRMNG))
    {
        HtLog(HTLM_ERR, "nCommonMsqInit() error");
        return -1;	
    }
	
    if (0 != nCommonMsqInit(CI_TOCTL_SEQ))
    {
        HtLog(HTLM_ERR,"nCommonMsqInit() error");
        return -1;	
    }
    HtLog(HTLM_COM, " load data success");
	
    return 0;
}
/**********************************************/
/* init glb var and copy databuf to glb var   */
/**********************************************/
/*
int  InitGlbVar(void *psDataBuf, short nInDataLen)
{
	char sTime[20];
	char sCnapsCode[20];
	
	memset(gsBrno, 0 ,sizeof(gsBrno));
	memset(&it_tita, 0 , sizeof(it_tita));
	memset(gsErrDesc, 0, sizeof(gsErrDesc));
	it_txcom.txrsut = TX_SUCCESS;
	it_txcom.rtncd = 0;
	
	memset(sCnapsCode, 0 , sizeof(sCnapsCode));
	memset(gsDBTxtime, 0 , sizeof(gsDBTxtime));
	memset(gsErrDesc, 0, sizeof(gsErrDesc));
	memset(sTime, 0, sizeof(sTime));
	
	if( nInDataLen > MAX_PACKET_LEN)
	{
		HtLog(HTLM_ERR,
				"InitGlbVar:nInDataLen error =[%d]", nInDataLen);
		return -1;
	}
	memcpy(&it_tita,  psDataBuf, nInDataLen);
	
	memcpy(gsBrno, it_tita.label.kinbr, DLEN_BRNO);
	
	cmGetWorkDate(gsBrno, gsDBTxdate, sCnapsCode, gsTBDate);

	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
	memcpy(gsDBTxtime, sTime+8, 6);
		
	HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"gsDBTxdate=[%d],gsDBTxtime = [%s]", gsDBTxdate, gsDBTxtime);
}
*/

int  InitGlbVar(void *psDataBuf, short nInDataLen)
{
    char sTime[20],sCnapsCode[DLEN_LBRNO+1];
    
    memset(gsBrno, 0 ,sizeof(gsBrno));
    memset(&it_tita, 0 , sizeof(it_tita));
    memset(&it_totw, 0 , sizeof(it_totw));
    memset(gsDBTxdate, 0, sizeof(gsDBTxdate));
    memset(gsDBTxtime, 0 , sizeof(gsDBTxtime));
    
    memset(gsErrDesc, 0, sizeof(gsErrDesc));
    memset(sTime, 0, sizeof(sTime));
    
    it_txcom.txrsut = TX_SUCCESS;
    it_txcom.rtncd = 0;
    
    if ( nInDataLen > MAX_PACKET_LEN)
    {
        HtLog(HTLM_ERR,"InitGlbVar:nInDataLen error =[%d]", nInDataLen);
        return -1;
    }
    
    HtDebugString(logfile,  psDataBuf, nInDataLen, __FILE__, __LINE__);
    memcpy(&it_tita,  psDataBuf, nInDataLen);  
    memcpy(gsBrno, it_tita.label.kinbr, DLEN_BRNO);
    
    #if 0
    cmGetWorkDate(gsBrno, gsDBTxdate, sCnapsCode, gsTBDate);
    #endif
    
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
    //added by Jasmine 20100812 begin
    memcpy(gsDBTxdate, sTime, 8);
    //added by Jasmine 20100812 end
    memcpy(gsDBTxtime, sTime+8, 6);
    
    HtLog(HTLM_COM, "gsDBTxdate=[%s], gsDBTxtime = [%s]", gsDBTxdate, gsDBTxtime);  

    TitaMoveTotaCommon(&it_tita.label, &it_totw.label);   

}  
void PrintTOTW()  
{
    HtLog(HTLM_COM,"header      [%8.8s]  ",it_totw.label.header      );  
    HtLog(HTLM_COM,"clsno       [%6.6s]  ",it_totw.label.clsno       );  
    HtLog(HTLM_COM,"termid      [%8.8s]  ",it_totw.label.termid      );  
    HtLog(HTLM_COM,"refssn      [%14.14s]",it_totw.label.refssn      );  
    HtLog(HTLM_COM,"kinbr       [%3.3s]  ",it_totw.label.kinbr       );  
    HtLog(HTLM_COM,"trmseq      [%2.2s]  ",it_totw.label.trmseq      );  
    HtLog(HTLM_COM,"ejfno       [%7.7s]  ",it_totw.label.ejfno       );  
    HtLog(HTLM_COM,"taskid      [%2.2s]  ",it_totw.label.taskid      );  
    HtLog(HTLM_COM,"txno        [%4.4s]  ",it_totw.label.txno        );  
    HtLog(HTLM_COM,"tlrno       [%8.8s]  ",it_totw.label.tlrno       );  
    HtLog(HTLM_COM,"tlsrno      [%7.7s]  ",it_totw.label.tlsrno      );  
    HtLog(HTLM_COM,"tmtype      [%c]  ",it_totw.label.tmtype      );     
    HtLog(HTLM_COM,"txdate      [%8.8s]  ",it_totw.label.txdate      );  
    HtLog(HTLM_COM,"txtime      [%6.6s]  ",it_totw.label.txtime      );  
    HtLog(HTLM_COM,"msgend      [%c]  ",it_totw.label.msgend      );     
    HtLog(HTLM_COM,"msgtype     [%c]  ",it_totw.label.msgtype     );     
    HtLog(HTLM_COM,"msgno       [%4.4s]  ",it_totw.label.msgno       );  
    HtLog(HTLM_COM,"msglng      [%4.4s]  ",it_totw.label.msglng      );  
    HtLog(HTLM_COM,"process_flag[%c]  ",it_totw.label.process_flag);     
    HtLog(HTLM_COM,"inq_id      [%8.8s]  ",it_totw.label.inq_id      );  

} 
void PrintTITA()
{
    HtLog(HTLM_COM,"header   [%8.8s]  ",it_tita.label.header   ); 
    HtLog(HTLM_COM,"clsno    [%6.6s]  ",it_tita.label.clsno    ); 
    HtLog(HTLM_COM,"termid   [%8.8s]  ",it_tita.label.termid   ); 
    HtLog(HTLM_COM,"htrmseq  [%2.2s]  ",it_tita.label.htrmseq  ); 
    HtLog(HTLM_COM,"hejfno   [%7.7s]  ",it_tita.label.hejfno   ); 
    HtLog(HTLM_COM,"opnbr    [%3.3s]  ",it_tita.label.opnbr    ); 
    HtLog(HTLM_COM,"kinbr    [%3.3s]  ",it_tita.label.kinbr    ); 
    HtLog(HTLM_COM,"trmseq   [%2.2s]  ",it_tita.label.trmseq   ); 
    HtLog(HTLM_COM,"ejfno    [%7.7s]  ",it_tita.label.ejfno    ); 
    HtLog(HTLM_COM,"taskid   [%2.2s]  ",it_tita.label.taskid   ); 
    HtLog(HTLM_COM,"tmtype   [%c]  ",it_tita.label.tmtype   );    
    HtLog(HTLM_COM,"txno     [%4.4s]  ",it_tita.label.txno     ); 
    HtLog(HTLM_COM,"hcode    [%c]  ",it_tita.label.hcode    );    
    HtLog(HTLM_COM,"supinit  [%2.2s]  ",it_tita.label.supinit  ); 
    HtLog(HTLM_COM,"tlrno    [%8.8s]  ",it_tita.label.tlrno    ); 
    HtLog(HTLM_COM,"sptlrno  [%8.8s]  ",it_tita.label.sptlrno  ); 
    HtLog(HTLM_COM,"otxtlrno [%8.8s]  ",it_tita.label.otxtlrno ); 
    HtLog(HTLM_COM,"otxtlsrno[%7.7s]  ",it_tita.label.otxtlsrno); 
    HtLog(HTLM_COM,"passwd   [%8.8s]  ",it_tita.label.passwd   ); 
    HtLog(HTLM_COM,"nbcd     [%c]  ",it_tita.label.nbcd     );    
    HtLog(HTLM_COM,"multtx   [%c]  ",it_tita.label.multtx   );    
    HtLog(HTLM_COM,"multno   [%6.6s]  ",it_tita.label.multno   ); 
    HtLog(HTLM_COM,"ip_addr  [%15.15s]",it_tita.label.ip_addr  ); 
    HtLog(HTLM_COM,"inq_id   [%8.8s]  ",it_tita.label.inq_id   ); 

}


void HandleExit( )
{
    DbDisConnect ();
    //ȫ�����
    ICBC_API_END();
    HtLog(HTLM_COM, "Info: Manager server exits!!");
    /*RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "HandleExit Error!" );*/
    exit(1);
}


