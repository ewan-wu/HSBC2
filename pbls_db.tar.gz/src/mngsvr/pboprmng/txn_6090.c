/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �ֹ��ط�                                                */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20110529          hanmeirong              Initial                     */
/************************************************************************/

#include "pboprmng.h"

static struct TIS6090_GROUP
{
    char	 sSysRefno      [16];   /* ϵͳ�ο���   */  
}tis6090;

static struct TOS6090_GROUP
{
    char	 null;
}tos6090;

static	struct wd_pbicbctxn_area	wd_pbicbctxn;
extern  char    logfile[256];

void txn_6090Initial(void);
void txn_6090Process(void);
void txn_6090PutMessage(void);

void txn_6090(void)
{
	txn_6090Initial();

	txn_6090Process();

	txn_6090PutMessage();
}

void txn_6090Initial(void)
{
    memset( &tis6090, 0, sizeof(tis6090) );
    memcpy( &tis6090, it_tita.sTitaText, sizeof(tis6090) );
    memset( &tos6090, 0, sizeof(tos6090) );	
    memset( &wd_pbicbctxn, 0, sizeof(wd_pbicbctxn));
}

void txn_6090Process( void )
{
    
    /********************************************
     *  �ֲ�������������ʼ��
     ********************************************/
    int		nRet = 0;
    char  sBuf[1500+1];
	
	  
    /********************************************
     * ��齻����־����
     * �Ƿ������Ҫ�ط��ĸ�����¼
     ********************************************/
    memcpy(wd_pbicbctxn.id, tis6090.sSysRefno, sizeof(tis6090.sSysRefno));
	HtLog(HTLM_COM	,"�ط����׵�ID=[%s]",wd_pbicbctxn.id);
    
    nRet = DbsPBICBCTXN(DBS_FIND,&wd_pbicbctxn);
    if( nRet != DB_OK )
    {
        HtLog(HTLM_ERR,"DbsPBTXNLOG DBS_FIND=[%d]\n", nRet );
        /* �˴���ErrorTrace   �Ѿ�������Ҫά���ĺ������в��� */
        ERRTRACE( E_DB_PBICBCTXN_RERR, "FIND ERROR! CODE[%d]", nRet );
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
        	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBICBCTXN FIND ERROR! sqlcode=[%d]", nRet );
        return ;
    }
    
    /* ����pbtxnlog���е�substatus = 0-���� snd_cnt = 0 �Ա�oprtmr�ٴ���ѯ���͸ñʽ��� */
    wd_pbicbctxn.substatus[0] = '0';
    wd_pbicbctxn.status[0] = '2';
    wd_pbicbctxn.snd_cnt = 0;
    memset(wd_pbicbctxn.txdate,0,sizeof(wd_pbicbctxn.txdate));
	memcpy(wd_pbicbctxn.snd_tlr ,it_tita.label.tlrno,sizeof(it_tita.label.tlrno));
	HtLog(HTLM_COM	,"�ط����׵�ID=[%s]",wd_pbicbctxn.id);
	HtLog(HTLM_COM	,"wd_pbicbctxn.substatus=[%s]",wd_pbicbctxn.substatus);
	HtLog(HTLM_COM	,"wd_pbicbctxn.snd_cnt=[%d]",wd_pbicbctxn.snd_cnt);
	HtLog(HTLM_COM	,"wd_pbicbctxn.txdate=[%s]",wd_pbicbctxn.txdate);
	
	nRet = DbsPBICBCTXN(DBS_IUPD, &wd_pbicbctxn);
	if( nRet != DB_OK )
	{
	    /* ERRORTRACE ����PBTXNLOG��ʧ�� */
	    ERRTRACE( E_DB_PBICBCTXN_WERR, "FIND ERROR! CODE[%d]", nRet );
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
        	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBICBCTXN UPDATE ERROR! sqlcode=[%d]", nRet );
        return;
	}
    
    /* ��¼����Ա������־�� */
    memset(sBuf,0,sizeof(sBuf));
    sprintf(sBuf,"ϵͳ�ο���[%.16s]",tis6090.sSysRefno);
    
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        /* ��¼����Ա������־������ */
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        return ;
    }
                      

}

void txn_6090PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );
	apitoa( TOTA_LABEL_LENGTH + sizeof(tos6090), sizeof(it_totw.label.msglng), it_totw.label.msglng );
	memcpy( it_totw.sTotaText, &tos6090, sizeof(tos6090) );
}

void txn_6090End( void )
{
}

