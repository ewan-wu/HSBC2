make -f *mak
sleep 1
runpboprmng
