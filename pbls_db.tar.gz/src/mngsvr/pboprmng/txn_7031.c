/************************************************************************/
/*                                                                      */
/* Product: Partner Bank Ling System                                    */
/*          manage module                                               */
/*   txn_7031                                                           */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: BAI code ά����Ȩ                                        */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100824        liusheng              Initial                      */
/************************************************************************/
#include "pboprmng.h"
extern char logfile[256];

static struct TIS7031_GROUP
{
	char	aprv_flag[1];				/*��Ȩ���1-ͨ����0-�ܾ�*/
	char	pb_brno[3];
	char	pb_trans_type[3];
	char	crdb[1];
} tis7031;
	
static struct TOS7031_GROUP
{
	char	null;
} tos7031;

void txn_7031Initial(void);
void txn_7031Process(void);
void txn_7031PutMessage(void);

void txn_7031(void)
{
	txn_7031Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7031Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7031PutMessage();
}

void txn_7031Initial(void)
{  
	memset( &tis7031, 0, sizeof(tis7031) );
	memcpy( &tis7031, it_tita.sTitaText, sizeof(tis7031) );
	memset( &tos7031, 0, sizeof(tos7031) );
}

void txn_7031Process(void)
{
	struct	wd_pbbaicodetmp_area	wdPbbaicodetmp;
	struct	wd_pbbaicode_area		wdPbbaicode;
	int		nRet = 0;
	int		nRet1 = 0;
	char    sBuf[1024];
	char    sStr[6+1];
	
	/*zl add 20100921 begin*/
    printf("aprv_flag=[%1.1s]\n", tis7031.aprv_flag);
    printf("pb_brno=[%3.3s]\n", tis7031.pb_brno);
    printf("pb_trans_type=[%3.3s]\n", tis7031.pb_trans_type);
    printf("crdb=[%1.1s]\n", tis7031.crdb);
	/*zl add 20100921 end*/


	memset( &wdPbbaicodetmp, 0, sizeof(wdPbbaicodetmp) );
	memset( &wdPbbaicode, 0, sizeof(wdPbbaicode) );
	
	memcpy( wdPbbaicodetmp.pb_brno, tis7031.pb_brno, 3 );
	memcpy( wdPbbaicodetmp.pb_trans_type, tis7031.pb_trans_type, 3 );
	memcpy( wdPbbaicodetmp.crdb, tis7031.crdb, 1 );
	
	nRet = DbsPBBAICODETMP( DBS_LOCK, &wdPbbaicodetmp );
	if( nRet != DB_OK && nRet != DB_NOTFOUND )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBBAICODETMP_WERR, "LOCK PBBAICODETMP ERROR [%d]", nRet );
		DbsPBBAICODETMP( DBS_CLOSE );
		RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODETMP LOCK ERROR! sqlcode=[%d]", nRet );
		return ;
	}
	else if( DB_OK == DB_NOTFOUND )
	{
		/* ������BAI codeά����Ϣ�����ڡ� */
		ERRTRACE( E_DE_PBBAICODETMP_NO_EXSIT, "NOT EXSIT RECODER [%d]", nRet );
		DbsPBBAICODETMP( DBS_CLOSE );
		return ;
	}

	if( strncmp(wdPbbaicodetmp.mod_tlr, it_tita.label.tlrno, 8) == 0 )
	{
		/* ������¼�롢��Ȩ����Ա������ͬ���� */
		ERRTRACE( E_TXN_SAMEPERSON_ERR, "[%d]", nRet );
		DbsPBBAICODETMP( DBS_CLOSE );
		return ;
	}

	memcpy( wdPbbaicode.pb_brno, tis7031.pb_brno, 3 );
	memcpy( wdPbbaicode.pb_trans_type, tis7031.pb_trans_type, 3 );
	memcpy( wdPbbaicode.crdb, tis7031.crdb, 1 );
	
	nRet1 = DbsPBBAICODE(DBS_LOCK, &wdPbbaicode);
	if( nRet1 != DB_OK && nRet1 != DB_NOTFOUND )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBBAICODETMP_WERR, "LOCK PBBAICODE ERROR![%d]", nRet1 );
		DbsPBBAICODETMP( DBS_CLOSE );
		DbsPBBAICODE( DBS_CLOSE );
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODE LOCK ERROR! sqlcode=[%d]", nRet );
		return ;
	}
	
	if( '1' == tis7031.aprv_flag[0] )
	{
		/* ǰ̨���� */
		memcpy( wdPbbaicode.pb_desc, wdPbbaicodetmp.pb_desc, 120 );
		memcpy( wdPbbaicode.bai_code, wdPbbaicodetmp.bai_code, 3 );
		memcpy( wdPbbaicode.bai_desc, wdPbbaicodetmp.bai_desc, 120 );
        
		/* ��̨��ֵ */
		memcpy( wdPbbaicode.maker_id, wdPbbaicodetmp.mod_tlr, 8 );
		memcpy( wdPbbaicode.maker_time, wdPbbaicodetmp.mod_time, 14 );
		memcpy( wdPbbaicode.auth_id,it_tita.label.kinbr, 3 );
		GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC,  wdPbbaicode.auth_time );
        
		if( DB_OK == nRet1 )
		{
			if( wdPbbaicodetmp.op_type[0] == 'D' )
			{
				nRet = DbsPBBAICODE( DBS_DELETE, &wdPbbaicode );
				if( nRet != DB_OK )
				{
					ERRTRACE( E_DB_PBBAICODE_DERR, "DELETE PBBAICODE ERROR![%d]", nRet1 );
					DbsPBBAICODETMP( DBS_CLOSE );
					DbsPBBAICODE( DBS_CLOSE );
					if( nRet != DB_ISNULL && nRet != DB_NOTFOUND )
						RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODE DELETE ERROR! sqlcode=[%d]", nRet );
					return ;
				}
			}
			else if( wdPbbaicodetmp.op_type[0] == 'M' )
			{
				nRet = DbsPBBAICODE( DBS_UPDATE, &wdPbbaicode );
				if( nRet != DB_OK )
				{
					ERRTRACE( E_DB_PBBAICODE_WERR, "UPDATE PBBAICODE ERROR![%d]", nRet1 );
					DbsPBBAICODETMP( DBS_CLOSE );
					DbsPBBAICODE( DBS_CLOSE );
					if( nRet != DB_ISNULL && nRet != DB_NOTFOUND )
						RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODE UPDATE ERROR! sqlcode=[%d]", nRet );
					return ;
				}
			}			
		}
		else if(DB_NOTFOUND == nRet1)
		{
			nRet = DbsPBBAICODE( DBS_INSERT, &wdPbbaicode );
			if( nRet != DB_OK )
			{
				ERRTRACE( E_DB_PBBAICODE_IERR, "INSERT PBBAICODE ERROR![%d]", nRet1 );
				DbsPBBAICODETMP( DBS_CLOSE );
				DbsPBBAICODE( DBS_CLOSE );
				RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODE INSERT ERROR! sqlcode=[%d]", nRet );
				return ;
			}
		}
	}
	else if( '0' == tis7031.aprv_flag[0] )
	{
		;//do nothing
	}
	
	/* ������Ȩ���Ǿܾ�����ɾ��PBTLRROLETMP����Ӧ��¼�� */
	nRet = DbsPBBAICODETMP( DBS_DELETE, &wdPbbaicodetmp );
	if( nRet != DB_OK )
	{
		ERRTRACE( E_DB_PBBAICODETMP_DERR, "DELETE PBBAICODE ERROR![%d]", nRet1 );
		DbsPBBAICODETMP( DBS_CLOSE );
		DbsPBBAICODE( DBS_CLOSE );
		if( nRet != DB_ISNULL && nRet != DB_NOTFOUND )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODE DELETE	 ERROR! sqlcode=[%d]", nRet );
		return ;
	}
	
	/*zl add insert log into pbtlrlog begin*/
	memset(sBuf,0,sizeof(sBuf));
	memset(sStr,0,sizeof(sStr));
	if( '1' == tis7031.aprv_flag[0] ){
		memcpy(sStr,"1-��Ȩ",sizeof(sStr)-1);
	}else{
		memcpy(sStr,"0-�ܾ�",sizeof(sStr)-1);
	}
	
	sprintf(sBuf,"��Ȩ����[%s]\n������[%s]\n�����н�������[%s]\n�����н�����������[%s]\n�����ʶ[%s]\nBAI CODE[%s]\nBAI CODE����[%s]",
	sStr,
	wdPbbaicodetmp.pb_brno,
	wdPbbaicodetmp.pb_trans_type,
	wdPbbaicodetmp.pb_desc,
	wdPbbaicodetmp.crdb,
	wdPbbaicodetmp.bai_code,
	wdPbbaicodetmp.bai_desc);
	nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        /* ��¼����Ա������־������ */
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        ERRTRACE(E_PB_RECORD_PBTLRLOG_ERR,"��¼����Ա������־��ʧ��[%d]", nRet); 
        return ;
    }
    
	/*zl add insert log into pbtlrlog end*/


	DbsPBBAICODETMP( DBS_CLOSE );
	DbsPBBAICODE( DBS_CLOSE );
	

	return ;
}

void txn_7031PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy(it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos7031), sizeof(it_totw.label.msglng), it_totw.label.msglng);

	memcpy(it_totw.sTotaText, &tos7031, sizeof(tos7031));
}

void txn_7031End()
{

}
