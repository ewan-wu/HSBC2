/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �����˻���ʷ��ϸ��ѯ(EOD Statement�ֹ�����)             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100803          Zhu Li               Initial                     */
/************************************************************************/

#include "pboprmng.h"
extern char logfile[256];

/* Tita & Tota Text */
static struct TIS6011_GROUP
	{
		char	bank_id[3];   /*�������к�*/
		char	curcd[3];     /*����*/
		char	bankname[60];
		char	actno[35];    /*�ͻ��˺�*/
		char	actname[70];
		char	pflag;        /*��������*/
		char	sdate[8];     /*��ʼ����*/
		char	edate[8];     /*��������*/
} tis6011;
static struct TOS6011_GROUP
{
		char	dummy;
} tos6011;

void txn_6011Initial(void);
void txn_6011Process(void);
void txn_6011PutMessage(void);

void txn_6011(void)
{
	txn_6011Initial();

	txn_6011Process();

	txn_6011PutMessage();
}

void txn_6011Initial(void)
{
		memset(&tis6011, 0, sizeof(tis6011));
		memset(&tos6011, 0, sizeof(tos6011));
		memcpy(&tis6011, it_tita.sTitaText, sizeof(tis6011));
}

void txn_6011Process(void)
{
	/* work */
	char sTmpMsg[256];
	char sBuf[512];
	short nTmpMsgLen;
	long lTarget;
	char sBankId[3+1];
	int nRet;

	memset(sBankId, 0, sizeof(sBankId));
	
	memcpy(sBankId, tis6011.bank_id, sizeof(sBankId)-1);

	memset(sTmpMsg, 0, sizeof(sTmpMsg));
	sprintf(sTmpMsg, "%-10.10s%-3.3s%-3.3s%-35.35s%c%-8.8s%-8.8s",
		"ADHOCSTEOD", tis6011.bank_id, tis6011.curcd, tis6011.actno,
		tis6011.pflag, tis6011.sdate, tis6011.edate);
	nTmpMsgLen = strlen(sTmpMsg);

	lTarget = lCommonGetSrvId(sBankId, "SWT");

	nRet = nCommonMsqSend(nTmpMsgLen, sTmpMsg, CI_OPRMNG, lTarget);
	if (nRet != 0)
	{
		HtLog(HTLM_ERR,"��Ϣ���з��ͳ���\n");
		ERRTRACE(E_SYS_MSQ_SEND_ERR, "��Ϣ���з��ͳ��� lTarget[%ld]", lTarget);
		return;
	}
	
	/* ��¼����Ա������־�� */
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"�������к�[%3.3s]\n����[%3.3s]\n�ͻ��˺�[%35.35s]\n��������[%s]\n��ʼʱ��[%8.8s]\n����ʱ��[%8.8s]",
		tis6011.bank_id, 
		tis6011.curcd, 
		tis6011.actno, 
		GetFlagName(3,&tis6011.pflag), 
		tis6011.sdate, 
		tis6011.edate);
    
	nRet = RecTlrLog( sBuf );
	if( nRet != DB_OK )
	{
		/* ��¼����Ա������־������ */
		RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
		return ;
	}
	return;
}

void txn_6011PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );
	apitoa( TOTA_LABEL_LENGTH + sizeof(tos6011), sizeof(it_totw.label.msglng), it_totw.label.msglng );
	memcpy( it_totw.sTotaText, &tos6011, sizeof(tos6011));
}

void txn_6011End( void )
{
}



