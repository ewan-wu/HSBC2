/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �ͻ�ע����Ϣά��                                        */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100810          Zhu Rui              Initial                     */
/************************************************************************/

#include "pboprmng.h"
extern char logfile[256];

static struct TIS5111_GROUP
{
    char sOptype	[1 ];        /* ��������               */
    char sBankId    [3 ];        /* �����к�               */
    char sBankName  [60];        /* ����������             */
    char sCustActno [35];        /* �ͻ��ں������˺�       */
    char sCurcd     [3 ];        /* ����                   */
    char sCustName  [70];        /* �ͻ��ں���������       */
    char sType		[1 ];        /* ����                   */
    char sStipType  [2 ];        /* ��ת����               */
    char sBranchId  [35];        /* �к� ICBC�㻮�кŷ�ǩ��*/
    char sBranchName[70];        /* ����                   */
    char sO_BankId  [35];        /* �㻮�кŷ�ǩ��(ICBC)   */
    char sO_BankName[70];        /* �Է�������             */
    char sO_Actno   [35];        /* �Է��ͻ��˺�           */
    char sO_Name    [70];        /* �Է��ͻ�����           */
    char sO_CustType[1 ];        /* �Է��ͻ�����           */
}tis5111;

static struct TOS5111_GROUP
{
	char	 null;
}tos5111;

static	struct wd_pbcustreg_area	    wd_pbcustreg;
static  struct wd_pbcustregtmp_area   wd_pbcustregtmp;

void txn_5111Initial(void);
void txn_5111Process(void);
void txn_5111PutMessage(void);

void txn_5111(void)
{
    txn_5111Initial();
    
    txn_5111Process();
    
    txn_5111PutMessage();
}

void txn_5111Initial(void)
{
    memset( &tis5111, 0, sizeof(tis5111) );
    memcpy( &tis5111, it_tita.sTitaText, sizeof(tis5111) );
    memset( &tos5111, 0, sizeof(tos5111) );	
    
    memset( &wd_pbcustreg   , 0, sizeof(wd_pbcustreg    ));
    memset( &wd_pbcustregtmp, 0, sizeof(wd_pbcustregtmp ));
}

void txn_5111Process( void )
{
printf(" sOptype	[%.1s ]\n", tis5111.sOptype	   ); /* ��������   */
printf(" sBankId    [%.3s ]\n", tis5111.sBankId  );/* �����к�   */
printf(" sBankName  [%.60s]\n", tis5111.sBankName);/* ���������� */
printf(" sCustActno [%.35s]\n", tis5111.sCustActno   );/* �ͻ��ں������˺�   */
printf(" sCurcd     [%.3s ]\n", tis5111.sCurcd   );/* ����   */
printf(" sCustName  [%.70s]\n", tis5111.sCustName);/* �ͻ��ں���������   */
printf(" sType		[%.1s ]\n", tis5111.sType		   ); /* ����   */
printf(" sStipType  [%.2s ]\n", tis5111.sStipType);/* ��ת����   */
printf(" sBranchId  [%.35s]\n", tis5111.sBranchId);/* �к� ICBC�㻮�кŷ�ǩ��*/
printf(" sBranchName[%.70s]\n", tis5111.sBranchName  );/* ����   */
printf(" sO_BankId  [%.35s]\n", tis5111.sO_BankId);/* �㻮�кŷ�ǩ��(ICBC)   */
printf(" sO_BankName[%.70s]\n", tis5111.sO_BankName  );/* �Է������� */
printf(" sO_Actno   [%.35s]\n", tis5111.sO_Actno );/* �Է��ͻ��˺�   */
printf(" sO_Name    [%.70s]\n", tis5111.sO_Name  );/* �Է��ͻ�����   */
printf(" sO_CustType[%.1s ]\n", tis5111.sO_CustType  );/* �Է��ͻ�����   */
printf("----------------------------\n");

char buf_sOptype	[1 +1];
char buf_sBankId    [3 +1];
char buf_sBankName  [60+1];
char buf_sCustActno [35+1];
char buf_sCurcd     [3 +1];
char buf_sCustName  [70+1];
char buf_sType		[1 +1];
char buf_sTypeDesc  [50+1];
char buf_sStipType  [2 +1];
char buf_sStipDesc  [50+1];
char buf_sBranchId  [35+1];
char buf_sBranchName[70+1];
char buf_sO_BankId  [35+1];
char buf_sO_BankName[70+1];
char buf_sO_Actno   [35+1];
char buf_sO_Name    [70+1];
char buf_sO_CustType[1 +1];

    /********************************************
     *  �ֲ�������������ʼ��
     ********************************************/
    int		nRet = 0;
    char  sBuf[1500+1];
	
	  
    /********************************************
     * ���ͻ�ע����Ϣ��ʱ����
     * �Ƿ������ά���ĸ�����¼
     ********************************************/
    HtLog(HTLM_COM,"tis5111.sOptype=[%s]\n", tis5111.sOptype);
    memcpy(wd_pbcustregtmp.bank_id  , tis5111.sBankId   , sizeof(tis5111.sBankId   ));
    HtLog(HTLM_COM,"wd_pbcustregtmp.bank_id=[%3.3s]\n", wd_pbcustregtmp.bank_id);
    HtLog(HTLM_COM,"tis.bankname=[%60.60s]\n", tis5111.sBankName);
    memcpy(wd_pbcustregtmp.actno    , tis5111.sCustActno, sizeof(tis5111.sCustActno));
    HtLog(HTLM_COM,"wd_pbcustregtmp.actno=[%35.35s]\n", wd_pbcustregtmp.actno);
    memcpy(wd_pbcustregtmp.curcd    , tis5111.sCurcd    , sizeof(tis5111.sCurcd    ));
    HtLog(HTLM_COM,"wd_pbcustregtmp.curcd=[%3.3s]\n", wd_pbcustregtmp.curcd);
    HtLog(HTLM_COM,"tis.sCustName=[%70.70s]\n", tis5111.sCustName);
    wd_pbcustregtmp.type[0] = tis5111.sType[0] ;
    HtLog(HTLM_COM," wd_pbcustregtmp.type=[%c]\n",  wd_pbcustregtmp.type[0]);
    memcpy(wd_pbcustregtmp.stiptype , tis5111.sStipType , sizeof(tis5111.sStipType ));
    HtLog(HTLM_COM,"wd_pbcustregtmp.stiptype=[%2.2s]\n", wd_pbcustregtmp.stiptype);
    memcpy(wd_pbcustregtmp.o_actno  , tis5111.sO_Actno  , sizeof(tis5111.sO_Actno  ));
    HtLog(HTLM_COM,"wd_pbcustregtmp.o_actno=[%35.35s]\n", wd_pbcustregtmp.o_actno);
    
    nRet = DbsPBCUSTREGTMP(DBS_FIND,&wd_pbcustregtmp);
    if( nRet == DB_OK )
    {
        HtLog(HTLM_COM,"DbsPBCUSTREGTMP DBS_FIND=[%d]\n", nRet);
        ERRTRACE(E_PB_CUSTREGTMP_EXSIT,"�Ѿ�������Ҫά���Ŀͻ�ע����[%d]",nRet);/* �˴���ErrorTrace   �Ѿ�������Ҫά���Ŀͻ�ע����Ϣ */
        return ;
    }
    else if( nRet != DB_NOTFOUND )
    {
        ERRTRACE(E_DB_TB_CUSTREGTMP_RERR,"���ݿ��쳣[%d]", nRet); 
        return;
    }
    
    /********************************************
     * ���ͻ�ע����Ϣ�������Ƿ������ά���Ŀͻ�ע����Ϣ
     ********************************************/
    memcpy(wd_pbcustreg.bank_id  , tis5111.sBankId   , sizeof(tis5111.sBankId   ));
    HtLog(HTLM_COM,"wd_pbcustreg.bank_id=[%3.3s]\n", wd_pbcustreg.bank_id);
    memcpy(wd_pbcustreg.actno    , tis5111.sCustActno, sizeof(tis5111.sCustActno));
    HtLog(HTLM_COM,"wd_pbcustreg.actno=[%35.35s]\n", wd_pbcustreg.actno);
    memcpy(wd_pbcustreg.curcd    , tis5111.sCurcd    , sizeof(tis5111.sCurcd    ));
    HtLog(HTLM_COM,"wd_pbcustreg.curcd=[%3.3s]\n", wd_pbcustreg.curcd);
    wd_pbcustreg.type[0] = tis5111.sType[0] ;
    HtLog(HTLM_COM,"wd_pbcustreg.type=[%c]\n", wd_pbcustreg.type[0]);
    memcpy(wd_pbcustreg.stiptype , tis5111.sStipType , sizeof(tis5111.sStipType ));
    HtLog(HTLM_COM,"wd_pbcustreg.stiptype=[%2.2s]\n", wd_pbcustreg.stiptype);
    memcpy(wd_pbcustreg.o_actno  , tis5111.sO_Actno  , sizeof(tis5111.sO_Actno  ));
    HtLog(HTLM_COM,"wd_pbcustreg.o_actno=[%35.35s]\n", wd_pbcustreg.o_actno);

    nRet = 0 ;
    nRet = DbsPBCUSTREG(DBS_FIND,&wd_pbcustreg);
    if(nRet != DB_OK && nRet != DB_NOTFOUND )
    {
    	HtLog(HTLM_COM,"��ѯpbcustreg���쳣\n");
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREG FIND ERROR! sqlcode=[%d]", nRet );
        ERRTRACE(E_DB_TB_CUSTREG_RERR,"���ݿ��쳣[%d]", nRet); /* ���ݿ��쳣 */
        return;
    }
    else if( nRet == DB_OK && tis5111.sOptype[0] == 'A' )
    {
        HtLog(HTLM_COM,"DbsPBCUSTREG DBS_FIND=[%d]\n", nRet );
        ERRTRACE(E_PB_CUSREG_EXSIT,"������������¼�Ѵ���[%d]",nRet);/* �˴���ErrorTrace   ������������¼�Ѵ��ڣ����� */
        return ;
    }
    else if( nRet == DB_NOTFOUND && ( tis5111.sOptype[0] == 'D' || tis5111.sOptype[0] == 'M'))
    {
    	HtLog(HTLM_COM,"�ж��޸�ɾ������\n");
        ERRTRACE(E_PB_CUSTREG_NOT_EXSIT,"�޸Ļ�ɾ�������������޼�¼[%d]",nRet);/* �޸Ļ�ɾ�������������޼�¼���������� */
        return; 
    }
    
    /* ����ͻ�ע����Ϣ��ʱ�� */
    if( tis5111.sOptype[0] == 'A')
    {
        /* ����һ���ͻ�ע����Ϣ */
        HtLog(HTLM_COM,"��ʼ��������\n");
        wd_pbcustregtmp.status[0] = CUSTREG_STATUS_VALID;
        GetCurHstStlmDate(wd_pbcustregtmp.sdate);
        memcpy(wd_pbcustregtmp.edate, CUST_EDATE_DEFAULT, DLEN_DATE);
        memcpy(wd_pbcustregtmp.name ,      tis5111.sCustName  , sizeof(tis5111.sCustName));
        memcpy(wd_pbcustregtmp.branchid  , tis5111.sBranchId  , sizeof(tis5111.sBranchId));
        memcpy(wd_pbcustregtmp.branchname, tis5111.sBranchName, sizeof(tis5111.sBranchName));               
        memcpy(wd_pbcustregtmp.o_branchid, tis5111.sO_BankId, sizeof(tis5111.sO_BankId));
        memcpy(wd_pbcustregtmp.o_branchname, tis5111.sO_BankName, sizeof(tis5111.sO_BankName));
        memcpy(wd_pbcustregtmp.o_name, tis5111.sO_Name, sizeof(tis5111.sO_Name)); 
        memcpy(wd_pbcustregtmp.mod_dept ,it_tita.label.kinbr,sizeof(it_tita.label.kinbr )); 
        memcpy(wd_pbcustregtmp.mod_tlr  ,it_tita.label.tlrno,sizeof(it_tita.label.tlrno )); 
        HtLog(HTLM_COM,"��������ING\n");
        HtLog(HTLM_COM,"wd_pbcustregtmp.edate=[%8.8s],wd_pbcustregtmp.name=[%70.70s],wd_pbcustregtmp.branchid[%35.35s],wd_pbcustregtmp.branchname[%70.70s],wd_pbcustregtmp.o_branchid[%35.35s],wd_pbcustregtmp.o_branchname[%70.70s],wd_pbcustregtmp.o_name[%70.70s],wd_pbcustregtmp.mod_dept[%3.3s],wd_pbcustregtmp.mod_tlr[%8.8s]",
        wd_pbcustregtmp.edate,wd_pbcustregtmp.name,wd_pbcustregtmp.branchid,wd_pbcustregtmp.branchname,wd_pbcustregtmp.o_branchid,wd_pbcustregtmp.o_branchname,wd_pbcustregtmp.o_name,wd_pbcustregtmp.mod_dept,wd_pbcustregtmp.mod_tlr);
        
        if (tis5111.sO_CustType[0] == CUSTREG_O_ACTYPE_INDV)
    	    wd_pbcustregtmp.o_actype[0]=CUSTREG_O_ACTYPE_INDV;
	    else
	        wd_pbcustregtmp.o_actype[0]=CUSTREG_O_ACTYPE_CORP;
    	  
    	  wd_pbcustregtmp.mod_status[0] = 'A';	
        CommonGetCurrentTimeDB(wd_pbcustregtmp.rec_updt_time);
        HtLog(HTLM_COM,"wd_pbcustregtmp.o_actype=[%c],wd_pbcustregtmp.mod_status = 'A',wd_pbcustregtmp.rec_updt_time=[%8.8s]",wd_pbcustregtmp.o_actype[0],wd_pbcustregtmp.rec_updt_time);
        HtLog(HTLM_COM,"COPY�������\n" );
    }
    else if (tis5111.sOptype[0] == 'M')
    {
        /* �޸� */
        memcpy(wd_pbcustregtmp.status, wd_pbcustreg.status, sizeof(wd_pbcustreg.status)-1);
        memcpy(wd_pbcustregtmp.sdate , wd_pbcustreg.sdate , sizeof(wd_pbcustreg.sdate   ));
        memcpy(wd_pbcustregtmp.edate , wd_pbcustreg.edate , sizeof(wd_pbcustreg.edate   ));   
        memcpy(wd_pbcustregtmp.name ,      tis5111.sCustName  , sizeof(tis5111.sCustName));
        memcpy(wd_pbcustregtmp.branchid, tis5111.sBranchId, sizeof(tis5111.sBranchId));
   	    memcpy(wd_pbcustregtmp.branchname, tis5111.sBranchName, sizeof(tis5111.sBranchName));
        memcpy(wd_pbcustregtmp.o_branchid, tis5111.sO_BankId, sizeof(tis5111.sO_BankId));
        memcpy(wd_pbcustregtmp.o_branchname, tis5111.sO_BankName, sizeof(tis5111.sO_BankName));
		memcpy(wd_pbcustregtmp.o_name, tis5111.sO_Name, sizeof(tis5111.sO_Name));
		memcpy(wd_pbcustregtmp.mod_dept ,it_tita.label.kinbr,sizeof(it_tita.label.kinbr )); 
        memcpy(wd_pbcustregtmp.mod_tlr  ,it_tita.label.tlrno,sizeof(it_tita.label.tlrno ));

        if (tis5111.sO_CustType[0] == CUSTREG_O_ACTYPE_INDV)
    	    wd_pbcustregtmp.o_actype[0]=CUSTREG_O_ACTYPE_INDV;
	    else
	    	wd_pbcustregtmp.o_actype[0]=CUSTREG_O_ACTYPE_CORP;
    	  
    	  	wd_pbcustregtmp.mod_status[0] = 'M';	
        CommonGetCurrentTimeDB(wd_pbcustregtmp.rec_updt_time);
    }
    else if (tis5111.sOptype[0] == 'D')
    {    
        /* ɾ�� */
        memcpy(wd_pbcustregtmp.status   , wd_pbcustreg.status, sizeof(wd_pbcustreg.status)-1);
        memcpy(wd_pbcustregtmp.name     , wd_pbcustreg.name  , sizeof(tis5111.sCustName));
	    memcpy(wd_pbcustregtmp.branchid  , wd_pbcustreg.branchid, sizeof(wd_pbcustreg.branchid)-1);
	    memcpy(wd_pbcustregtmp.branchname, wd_pbcustreg.branchname, sizeof(wd_pbcustreg.branchname)-1);
	    memcpy(wd_pbcustregtmp.o_actype  , wd_pbcustreg.o_actype, sizeof(wd_pbcustreg.o_actype)-1);
	    memcpy(wd_pbcustregtmp.o_name    , wd_pbcustreg.o_name, sizeof(wd_pbcustreg.o_name)-1);

	    memcpy(wd_pbcustregtmp.o_branchid, wd_pbcustreg.o_branchid, sizeof(wd_pbcustreg.o_branchid)-1);
	    memcpy(wd_pbcustregtmp.o_branchname, wd_pbcustreg.o_branchname, sizeof(wd_pbcustreg.o_branchname)-1);
	    memcpy(wd_pbcustregtmp.sdate, wd_pbcustreg.sdate, DLEN_DATE);
	    memcpy(wd_pbcustregtmp.edate, wd_pbcustreg.edate, DLEN_DATE);

		memcpy(wd_pbcustregtmp.mod_dept ,it_tita.label.kinbr,sizeof(it_tita.label.kinbr )); 
        memcpy(wd_pbcustregtmp.mod_tlr  ,it_tita.label.tlrno,sizeof(it_tita.label.tlrno ));
         
        wd_pbcustregtmp.status[0]=	CUSTCTL_STATUS_INVALID ;
        wd_pbcustregtmp.mod_status[0] = 'D';
	    GetCurHstStlmDate(wd_pbcustregtmp.edate);
    }
    
    /* ����ע����Ϣ��ʱ�� */
    HtLog(HTLM_COM,"������ʱ����ʼ\n");
    nRet = DbsPBCUSTREGTMP( DBS_INSERT,&wd_pbcustregtmp );
    if( nRet != DB_OK )
    {
        HtLog(HTLM_COM,"DbsPBCUSTREGTMP DBS_FIND=[%d]\n", nRet);
		if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREGTMP INSERT ERROR! sqlcode=[%d]", nRet );
        ERRTRACE(E_DB_TB_CUSTREGTMP_IERR,"����ͻ�ע����Ϣ��ʱ��ʧ��[%d]",nRet);/* �˴���ErrorTrace   ����ͻ�ע����Ϣ��ʱ��ʧ�� */
        return ;
    }  
    HtLog(HTLM_COM,"������ʱ����ʼ\n");
    /* ��¼����Ա������־�� */
    memset(sBuf,0,sizeof(sBuf));
    /*
    sprintf(sBuf,"��������[%s],�����к�[%3.3s],����������[%60.60s],�ͻ��ں������˺�[%35.35s],����[%3.3s],\
    �ͻ��ں���������[%70.70s],����[%s],��ת����[%2.2s],�к�[%35.35s],����[%70.70s],�Է��к�[%8.8s],\
    �Է�������[%70.70s],�Է��ͻ��˺�[%35.35s],�Է��ͻ�����[%70.70s],�Է��ͻ�����[%1.1s] ",
    */
	MSET(buf_sOptype    );
	MSET(buf_sBankId    );
	MSET(buf_sBankName  );
	MSET(buf_sCustActno );
	MSET(buf_sCurcd     );
	MSET(buf_sCustName  );
	MSET(buf_sType      );
	MSET(buf_sStipType  );
	MSET(buf_sBranchId  );
	MSET(buf_sBranchName);
	MSET(buf_sO_BankId  );
	MSET(buf_sO_BankName);
	MSET(buf_sO_Actno   );
	MSET(buf_sO_Name    );
	MSET(buf_sO_CustType);

	MSET(buf_sTypeDesc  );
	MSET(buf_sStipDesc  );

	strcpy(buf_sTypeDesc, (char *)GetFlagName(6,tis5111.sType));
	strcpy(buf_sStipDesc, (char *)GetFlagName(12,tis5111.sStipType));
	
	strcpy(buf_sOptype    , (char *)apTrim(tis5111.sOptype    , 1));
	strcpy(buf_sBankId    , (char *)apTrim(tis5111.sBankId    , 3));
	strcpy(buf_sBankName  , (char *)apTrim(tis5111.sBankName  , 60));
	strcpy(buf_sCustActno , (char *)apTrim(tis5111.sCustActno , 35));
	strcpy(buf_sCurcd     , (char *)apTrim(tis5111.sCurcd     , 3));
	strcpy(buf_sCustName  , (char *)apTrim(tis5111.sCustName  , 70));
	strcpy(buf_sType      , (char *)apTrim(tis5111.sType      , 1));
	strcpy(buf_sStipType  , (char *)apTrim(tis5111.sStipType  , 2));
	strcpy(buf_sBranchId  , (char *)apTrim(tis5111.sBranchId  , 35));
	strcpy(buf_sBranchName, (char *)apTrim(tis5111.sBranchName, 70));
	strcpy(buf_sO_BankId  , (char *)apTrim(tis5111.sO_BankId  , 35));
	strcpy(buf_sO_BankName, (char *)apTrim(tis5111.sO_BankName, 70));
	strcpy(buf_sO_Actno   , (char *)apTrim(tis5111.sO_Actno   , 35));
	strcpy(buf_sO_Name    , (char *)apTrim(tis5111.sO_Name    , 70));
	strcpy(buf_sO_CustType, (char *)apTrim(tis5111.sO_CustType, 1));

    sprintf(sBuf,"��������[%s]\n�����к�[%s]\n����������[%s]\n�ͻ��ں������˺�[%s]\n\
����[%s]\n�ͻ��ں���������[%s]\n����[%s]\n��ת����[%s]\n�к�[%s]\n����[%s]\n\
�Է����к�[%s]\n�Է�������[%s]\n�Է��ͻ��˺�[%s]\n�Է��ͻ�����[%s]",
    GetFlagName(7,tis5111.sOptype),
    buf_sBankId, 
    buf_sBankName,
    buf_sCustActno,
    buf_sCurcd,
    buf_sCustName,
    buf_sTypeDesc,
    buf_sStipDesc,
    buf_sBranchId,
    buf_sBranchName,
    buf_sO_BankId,
    buf_sO_BankName,
    buf_sO_Actno,
    buf_sO_Name);

    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        ERRTRACE(E_PB_RECORD_PBTLRLOG_ERR,"��¼����Ա������־��ʧ��[%d]",nRet);/* ��¼����Ա������־������ */
        return ;
    } 
                      

}

void txn_5111PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );
	apitoa( TOTA_LABEL_LENGTH + sizeof(tos5111), sizeof(it_totw.label.msglng), it_totw.label.msglng );
	memcpy( it_totw.sTotaText, &tos5111, sizeof(tos5111) );
}

void txn_5111End( void )
{
}

