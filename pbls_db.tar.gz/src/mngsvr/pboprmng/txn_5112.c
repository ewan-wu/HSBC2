/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �ͻ�ע����Ϣά����Ȩ                                        */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100810          Zhu Rui              Initial                     */
/************************************************************************/

#include "pboprmng.h"
extern char logfile[256];

static struct TIS5112_GROUP
{
    char   sAuthType        ;    /* ��Ȩ��־           */  
    char   sBankId      [3 ];    /* �����к�           */
    char   sCustActno   [35];    /* �ͻ��ں��������˺� */
    char   sCurcd       [3 ];    /* ����               */
    char   sType            ;    /* ����               */
    char   sStipType    [2 ];    /* ��ת����           */
    char   sOActno      [35];    /* �Է��˻�           */
}tis5112;

static struct TOS5112_GROUP
{
	char	 null;
}tos5112;

static	struct wd_pbcustreg_area	    wd_pbcustreg;
static  struct wd_pbcustregtmp_area   wd_pbcustregtmp;
extern  char    logfile[256];

void txn_5112Initial(void);
void txn_5112Process(void);
void txn_5112PutMessage(void);

void txn_5112(void)
{
	txn_5112Initial();

	txn_5112Process();

	txn_5112PutMessage();
}

void txn_5112Initial(void)
{
	memset( &tis5112, 0, sizeof(tis5112) );
	memcpy( &tis5112, it_tita.sTitaText, sizeof(tis5112) );
	memset( &tos5112, 0, sizeof(tos5112) );	
	
	memset( &wd_pbcustreg   , 0, sizeof(wd_pbcustreg    ));
	memset( &wd_pbcustregtmp, 0, sizeof(wd_pbcustregtmp ));
}

void txn_5112Process( void )
{
    
    /********************************************
     *  �ֲ�������������ʼ��
     ********************************************/
    int		nRet = 0;
    char  sBuf[1500+1];
	
	  
    /********************************************
     * ���ͻ�ע����Ϣ��ʱ����
     * �Ƿ������ά���ĸ�����¼
     ********************************************/
    memcpy(wd_pbcustregtmp.bank_id  , tis5112.sBankId   , sizeof(tis5112.sBankId   ));
    memcpy(wd_pbcustregtmp.actno    , tis5112.sCustActno, sizeof(tis5112.sCustActno));
    memcpy(wd_pbcustregtmp.curcd    , tis5112.sCurcd    , sizeof(tis5112.sCurcd    ));
    wd_pbcustregtmp.type[0] = tis5112.sType ;
    memcpy(wd_pbcustregtmp.stiptype , tis5112.sStipType , sizeof(tis5112.sStipType ));
    memcpy(wd_pbcustregtmp.o_actno  , tis5112.sOActno   , sizeof(tis5112.sOActno  ));
    
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"bank_id=[%s],actno[%s]curcd[%s],type[%s],stiptype[%s],o_actno[%s]\n", wd_pbcustregtmp.bank_id, wd_pbcustregtmp.actno, wd_pbcustregtmp.curcd, wd_pbcustregtmp.type, wd_pbcustregtmp.stiptype, wd_pbcustregtmp.o_actno);
    
    nRet = DbsPBCUSTREGTMP(DBS_LOCK,&wd_pbcustregtmp);
    if( nRet == DB_NOTFOUND )
    {
    	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"[%d]", nRet );
        ERRTRACE(E_DB_TB_CUSTREGTMP_RERR,"��������Ҫά���Ŀͻ�ע����Ϣ[%d]",nRet);/* �˴���ErrorTrace   �Ѿ�������Ҫά���ĺ������в��� */
        DbsPBCUSTREGTMP( DBS_CLOSE );
        return ;
    }
    else if( nRet != DB_OK )
    {
        ERRTRACE(E_DB_TB_CUSTREGTMP_RERR,"���ݿ��쳣[%d]", nRet);
        if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREGTMP LOCK ERROR! sqlcode=[%d]", nRet );
        DbsPBCUSTREGTMP( DBS_CLOSE );
        return;
    }

    /* �ж�¼�������Ƿ�ͬһ�� */
    if( memcmp(wd_pbcustregtmp.mod_tlr  ,it_tita.label.tlrno    ,sizeof(it_tita.label.tlrno)) == 0 )
    {
        ERRTRACE( E_TXN_SAMEPERSON_ERR, "Md_tlrno=[%s],avp_tlrno=[%8.8s]", wd_pbcustregtmp.mod_tlr, it_tita.label.tlrno );
        DbsPBCUSTREGTMP( DBS_CLOSE );
        return;
    }
    /* ���ͨ�� */
    if( tis5112.sAuthType == '1' )
    {
        /* ��ֵwd_pbcustreg�ṹ */
        memcpy(wd_pbcustreg.bank_id  , tis5112.sBankId   , sizeof(tis5112.sBankId    ));
        memcpy(wd_pbcustreg.actno    , tis5112.sCustActno, sizeof(tis5112.sCustActno ));
        memcpy(wd_pbcustreg.curcd    , tis5112.sCurcd    , sizeof(tis5112.sCurcd     ));
        wd_pbcustreg.type[0] = tis5112.sType ;
        memcpy(wd_pbcustreg.stiptype , tis5112.sStipType , sizeof(tis5112.sStipType ));
        memcpy(wd_pbcustreg.o_actno  , tis5112.sOActno   , sizeof(tis5112.sOActno  ));
        nRet = 0 ; 
        switch(wd_pbcustregtmp.mod_status[0])
        {
            case 'A':  /* new */
                memcpy(wd_pbcustreg.name        ,wd_pbcustregtmp.name        ,sizeof(wd_pbcustreg.name        )-1);   
                memcpy(wd_pbcustreg.status      ,wd_pbcustregtmp.status      ,sizeof(wd_pbcustreg.status      )-1);
                memcpy(wd_pbcustreg.sdate       ,wd_pbcustregtmp.sdate       ,sizeof(wd_pbcustreg.sdate       )-1);
                memcpy(wd_pbcustreg.edate       ,wd_pbcustregtmp.edate       ,sizeof(wd_pbcustreg.edate       )-1);
                memcpy(wd_pbcustreg.branchid    ,wd_pbcustregtmp.branchid    ,sizeof(wd_pbcustreg.branchid    )-1);
                memcpy(wd_pbcustreg.branchname  ,wd_pbcustregtmp.branchname  ,sizeof(wd_pbcustreg.branchname  )-1);
                memcpy(wd_pbcustreg.o_branchid  ,wd_pbcustregtmp.o_branchid  ,sizeof(wd_pbcustreg.o_branchid  )-1);  
                memcpy(wd_pbcustreg.o_branchname,wd_pbcustregtmp.o_branchname,sizeof(wd_pbcustreg.o_branchname)-1);
                memcpy(wd_pbcustreg.o_name      ,wd_pbcustregtmp.o_name      ,sizeof(wd_pbcustreg.o_name      )-1);
                memcpy(wd_pbcustreg.mod_dept    ,wd_pbcustregtmp.mod_dept    ,sizeof(wd_pbcustreg.mod_dept    )-1);
                memcpy(wd_pbcustreg.mod_tlr     ,wd_pbcustregtmp.mod_tlr     ,sizeof(wd_pbcustreg.mod_tlr     )-1);
                wd_pbcustreg.o_actype[0] = wd_pbcustregtmp.o_actype[0];
                CommonGetCurrentTimeDB(wd_pbcustreg.rec_updt_time);
                /* �����жϣ��Ƿ��Ѿ������� */
                nRet = DbsPBCUSTREG( DBS_INSERT, &wd_pbcustreg );
                if( nRet != DB_OK )
                {
                	if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
						RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREG INSERT ERROR! sqlcode=[%d]", nRet );
                    ERRTRACE( E_DB_TB_CUSTREG_IERR, "Insert Table PBCUSTREG Error! sqlcode=[%d]",  nRet );
                    if( nRet == -1 )
                    {
                        ERRTRACE( E_TXN_RECORD_EXIST, " act_no=[%s]", wd_pbcustreg.actno );
                        DbsPBCUSTREGTMP( DBS_CLOSE );
                    }
                    return;
                }
                break;
            case 'M':
            case 'D':
                nRet =  DbsPBCUSTREG(DBS_LOCK, &wd_pbcustreg);
                if( nRet != DB_OK && nRet != DB_NOTFOUND )
                {
                    ERRTRACE( E_DB_TB_CUSTREGTMP_RERR, "Insert Table PBCUSTREGTMP Error!sqlcode=[%d]",  nRet );
                    DbsPBCUSTREGTMP( DBS_CLOSE );
                    DbsPBCUSTREG( DBS_CLOSE );
                    if( nRet != DB_ISNULL )
						RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREG LOCK ERROR! sqlcode=[%d]", nRet );
                    return;
                }
                
                if( wd_pbcustregtmp.mod_status[0] == 'D' )
                {
                    #if 0
                    wd_pbcustreg.status[0] = CUSTCTL_STATUS_INVALID;
                    GetCurHstStlmDate(wd_pbcustreg.edate);
					memcpy(wd_pbcustreg.del_tlr	,it_tita.label.tlrno,sizeof(it_tita.label.tlrno ));
					memcpy(wd_pbcustreg.del_dept,it_tita.label.kinbr,sizeof(it_tita.label.kinbr ));
                    CommonGetCurrentTimeDB(wd_pbcustreg.rec_updt_time);
                    #endif
                    nRet = DbsPBCUSTREG(DBS_DELETE, &wd_pbcustreg);
                    if( nRet != DB_OK )
                    {
                        ERRTRACE( E_DB_TB_CUSTREG_DERR, "Delete PBCUSTREG ERROR! sqlcode=[%d]", nRet );
                        DbsPBCUSTREGTMP( DBS_CLOSE );
                        DbsPBCUSTREG( DBS_CLOSE );
                        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
							RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREG DELETE ERROR! sqlcode=[%d]", nRet );
                        return;
                    }
                }
                else if (wd_pbcustregtmp.mod_status[0] == 'M' )
                {
                    memcpy(wd_pbcustreg.name        ,wd_pbcustregtmp.name        ,sizeof(wd_pbcustreg.name        )-1);   
                    memcpy(wd_pbcustreg.status      ,wd_pbcustregtmp.status      ,sizeof(wd_pbcustreg.status      )-1);
                    memcpy(wd_pbcustreg.sdate       ,wd_pbcustregtmp.sdate       ,sizeof(wd_pbcustreg.sdate       )-1);
                    memcpy(wd_pbcustreg.edate       ,wd_pbcustregtmp.edate       ,sizeof(wd_pbcustreg.edate       )-1);
                    memcpy(wd_pbcustreg.branchid    ,wd_pbcustregtmp.branchid    ,sizeof(wd_pbcustreg.branchid    )-1);
                    memcpy(wd_pbcustreg.branchname  ,wd_pbcustregtmp.branchname  ,sizeof(wd_pbcustreg.branchname  )-1);
                    memcpy(wd_pbcustreg.o_branchid  ,wd_pbcustregtmp.o_branchid  ,sizeof(wd_pbcustreg.o_branchid  )-1);  
                    memcpy(wd_pbcustreg.o_branchname,wd_pbcustregtmp.o_branchname,sizeof(wd_pbcustreg.o_branchname)-1);
                    memcpy(wd_pbcustreg.o_name      ,wd_pbcustregtmp.o_name      ,sizeof(wd_pbcustreg.o_name      )-1);
                    memcpy(wd_pbcustreg.mod_dept    ,wd_pbcustregtmp.mod_dept    ,sizeof(wd_pbcustreg.mod_dept    )-1);
                    memcpy(wd_pbcustreg.mod_tlr     ,wd_pbcustregtmp.mod_tlr     ,sizeof(wd_pbcustreg.mod_tlr     )-1);
                    wd_pbcustreg.o_actype[0] = wd_pbcustregtmp.o_actype[0];
                    CommonGetCurrentTimeDB(wd_pbcustreg.rec_updt_time);
                    
                    nRet = DbsPBCUSTREG( DBS_UPDATE, &wd_pbcustreg );
                    if( nRet != DB_OK )   
                    {           
                        ERRTRACE( E_DB_TB_CUSTREG_WERR , "DbsPBCUSTREG DBS_UPDATE Error! sqlcode=[%d]", nRet );
                        DbsPBCUSTREGTMP( DBS_CLOSE );
                        DbsPBCUSTREG( DBS_CLOSE );
                        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
							RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREG UPDATE ERROR! sqlcode=[%d]", nRet );
                        return;
                    }                            
                }
                DbsPBCUSTREG( DBS_CLOSE );
                break;
            default:
            {
                ERRTRACE( E_TXN_OPTYPE_ERR, "OPERATION ERROR! op_type=[%c]", wd_pbcustregtmp.mod_status[0] );
                DbsPBCUSTREGTMP( DBS_CLOSE );
				return ;
            }
        }
        if( (nRet = DbsPBCUSTREGTMP(DBS_DELETE,&wd_pbcustregtmp)) != DB_OK )
    	{
        	ERRTRACE( E_DB_PB_CUSTREGTMP_DERR, "OPERATION ERROR! op_type=[%c]", wd_pbcustregtmp.mod_status[0] );/* ɾ��pbcustctltmp��ʧ�� */
        	DbsPBCUSTREGTMP( DBS_CLOSE );
        	if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
				RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREGTMP DELETE ERROR! sqlcode=[%d]", nRet );
        return;
    	}
    }
    else if( tis5112.sAuthType == '2')
    {
        /* ��Ȩ�ܾ� */
        if( (nRet = DbsPBCUSTREGTMP(DBS_DELETE,&wd_pbcustregtmp)) != DB_OK )
        {
            ERRTRACE( E_DB_PB_CUSTREGTMP_DERR, "OPERATION ERROR! op_type=[%c]", wd_pbcustregtmp.mod_status[0] );/* ɾ��pbcustctltmp��ʧ�� */
            DbsPBCUSTREGTMP( DBS_CLOSE );
            if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
				RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTREGTMP DELETE ERROR! sqlcode=[%d]", nRet );
            return;
        }
    }
    else
    {
        ERRTRACE( E_AUTH_TYPE_ERR, "AUTH TYPE ERROR! op_type=[%1.1s]", tis5112.sAuthType);/* ��Ȩ��־����ȷ */
        DbsPBCUSTREGTMP( DBS_CLOSE );
        return;
    } 

    DbsPBCUSTREGTMP( DBS_CLOSE );  
HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"xxxxxxxxxxxxxxxxxxxxxxx" );        

	char sTypeName[20];
	char sStipTypeName[20];
	memset(sTypeName	,0	,sizeof(sTypeName    ));
	memset(sStipTypeName,0	,sizeof(sStipTypeName));

	if( tis5112.sType == 'P' )
	{
		strcpy(sTypeName	,"����");
	}
	else if( tis5112.sType == 'C' )
	{
		strcpy(sTypeName    ,"�տ�");
	}

	if(	memcmp(tis5112.sStipType	,"00",2) == 0 )
	{
		strcpy(sStipTypeName,"����ת");
	}
	else if( memcmp(tis5112.sStipType	,"10",2) == 0 )
	{
		strcpy(sStipTypeName,"������ת");
	}

    /* ��¼����Ա������־�� */
    memset(sBuf,0,sizeof(sBuf));
    sprintf(sBuf,"��Ȩ��־=[%s]\n�����к�[%3.3s]\n�ͻ��ں������˺�[%35.35s]\n����[%3.3s]\n����[%s]\n��ת����[%s]\n�Է��˻�[%35.35s]",
    GetFlagName(8,&tis5112.sAuthType),
    tis5112.sBankId,
    tis5112.sCustActno,
    tis5112.sCurcd,
    sTypeName,
    sStipTypeName,
    tis5112.sOActno);
HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"xxxxxxxxxxxxxxxxxxxxxxx" );     
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        /* ��¼����Ա������־������ */
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        return ;
    }
}

void txn_5112PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );
	apitoa( TOTA_LABEL_LENGTH + sizeof(tos5112), sizeof(it_totw.label.msglng), it_totw.label.msglng );
	memcpy( it_totw.sTotaText, &tos5112, sizeof(tos5112) );
}

void txn_5112End( void )
{
}

