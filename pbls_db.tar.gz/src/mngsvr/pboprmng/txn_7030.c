/************************************************************************/
/*                                                                      */
/* Product: Partner Bank Ling System                                    */
/*          manage module                                               */
/*   txn_7030                                                           */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: BAI code ά��                                           */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100824        liusheng              Initial                      */
/************************************************************************/
#include "pboprmng.h"

static struct TIS7030_GROUP
{
	char	op_type[1];	        /* M-�޸ģ�A-������D-ɾ�� */
	char	pb_brno[3];
	char	pb_desc[120];		/* �����н����������� */
	char	pb_trans_type[3];
	char	crdb[1];
	char	bai_code[3];        /* BAI��� */
	char	bai_desc[120];		/* BAI���� */

} tis7030;
	
static struct TOS7030_GROUP
{
	char	null;
} tos7030;

void txn_7030Initial(void);
void txn_7030Process(void);
void txn_7030PutMessage(void);

void txn_7030(void)
{
	txn_7030Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7030Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7030PutMessage();
}

void txn_7030Initial(void)
{  
	memset( &tis7030, 0, sizeof(tis7030) );
	memcpy( &tis7030, it_tita.sTitaText, sizeof(tis7030) );
	memset( &tos7030, 0, sizeof(tos7030) );
}

void txn_7030Process(void)
{
	struct	wd_pbbaicodetmp_area	wdPbbaicodetmp;
	struct	wd_pbbaicode_area		wdPbbaicode;
	int		nRet = 0;
   char    sStr[6+1];
   char    sBuf[1024];
   	
	memset( &wdPbbaicodetmp, 0, sizeof(wdPbbaicodetmp) );
	memset( &wdPbbaicode, 0, sizeof(wdPbbaicode) );
	
	memcpy( wdPbbaicodetmp.pb_brno, tis7030.pb_brno, 3 );
	memcpy( wdPbbaicodetmp.pb_trans_type, tis7030.pb_trans_type, 3 );
	memcpy( wdPbbaicodetmp.crdb, tis7030.crdb, 1 );
	
	nRet = DbsPBBAICODETMP( DBS_FIND, &wdPbbaicodetmp );
	if( nRet != DB_OK && nRet != DB_NOTFOUND )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBBAICODETMP_RERR, "FIND E_DB_PBBAICODETMP_RERR ERROR[%d]", nRet );
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODETMP FIND ERROR! sqlcode=[%d]", nRet );
		return ;
	}
	else if( DB_OK == nRet )
	{
		/* ��������BAI code����ά���У�����Ȩ���ٴ�ά������ */
		ERRTRACE( E_DE_PBBAICODETMP_EXSIT, "FIND E_DB_PBBAICODETMP_RERR ERROR[%d]", nRet );
		return ;
	}
	
	memcpy( wdPbbaicode.pb_brno, tis7030.pb_brno, 3 );
	memcpy( wdPbbaicode.pb_trans_type, tis7030.pb_trans_type, 3 );
	memcpy( wdPbbaicode.crdb, tis7030.crdb, 1 );
	
	nRet = DbsPBBAICODE ( DBS_FIND, &wdPbbaicode );
	if( nRet != DB_OK && nRet != DB_NOTFOUND )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBBAICODE_RERR, "FIND PBBAICODE ERROR[%d]", nRet );
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODETMP FIND ERROR! sqlcode=[%d]", nRet );
		return ;
	}
	
	/* ������ݿ��¼����״̬�Ͳ��������Ƿ��ͻ */
	if( DB_OK == nRet && 'A' == tis7030.op_type[0] )
	{
		/* ������BAI code�Ѵ��ڣ������������� */
		ERRTRACE( E_DE_PBBAICODE_EXSIT, "exsit recoder ERROR[%d]", nRet );
		return ;
	}
	else if( DB_NOTFOUND == nRet && 'M' == tis7030.op_type[0] )
	{
		/* ������BAI code�����ڣ������޸ġ��� */
		ERRTRACE( E_DE_PBBAICODE_NO_EXSIT, "not exsit recoder ERROR[%d]", nRet );
		return ;
		
	}
	else if( DB_NOTFOUND == nRet && 'D' == tis7030.op_type[0] )
	{
		/* ������BAI code�����ڣ�����ɾ������ */
		ERRTRACE( E_DE_PBBAICODE_NO_EXSIT, "not exsit recoder ERROR[%d]", nRet );
		return ;
	}
	
	/* ǰ̨���� */
	memcpy( wdPbbaicodetmp.pb_brno, tis7030.pb_brno, 3 );
	memcpy( wdPbbaicodetmp.pb_trans_type, tis7030.pb_trans_type, 3 );
	memcpy( wdPbbaicodetmp.crdb, tis7030.crdb, 1 );
	memcpy( wdPbbaicodetmp.pb_desc, tis7030.pb_desc, 120 );
	memcpy( wdPbbaicodetmp.bai_code, tis7030.bai_code, 3 );
	memcpy( wdPbbaicodetmp.bai_desc, tis7030.bai_desc, 120 );
	memcpy( wdPbbaicodetmp.op_type, tis7030.op_type, 1 );
	
	/* ��̨��ֵ */
	memcpy( wdPbbaicodetmp.mod_tlr, it_tita.label.tlrno, 8 );
	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC,  wdPbbaicodetmp.mod_time );
	/* ����һ����¼ */
	
	nRet = DbsPBBAICODETMP( DBS_INSERT, &wdPbbaicodetmp );
	if( DB_OK != nRet )
	{
		ERRTRACE( E_DB_PBBAICODETMP_IERR, "INSERT PBBAICODETMP ERROR [%d]", nRet );
		RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBBAICODETMP INSERT ERROR! sqlcode=[%d]", nRet );
		return ;
	}
   
   /*zl add insert pbtlrlog begin*/
	memset(sBuf,0,sizeof(sBuf));
	memset(sStr,0,sizeof(sStr));
	if( 'A' == tis7030.op_type[0] ){
		memcpy(sStr,"A-����",sizeof(sStr)-1);
	}else if ('M' == tis7030.op_type[0] ){
		memcpy(sStr,"M-�޸�",sizeof(sStr)-1);
	}else{
		memcpy(sStr,"D-ɾ��",sizeof(sStr)-1);
	}
	
	sprintf(sBuf,"ά������[%s]\n������[%s]\n�����н�������[%s]\n�����н�����������[%s]\n�����ʶ[%s]\nBAI CODE[%s]\nBAI CODE����[%s]",
	sStr,
	wdPbbaicodetmp.pb_brno,
	wdPbbaicodetmp.pb_trans_type,
	wdPbbaicodetmp.pb_desc,
	wdPbbaicodetmp.crdb,
	wdPbbaicodetmp.bai_code,
	wdPbbaicodetmp.bai_desc);
	nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        /* ��¼����Ա������־������ */
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        ERRTRACE(E_PB_RECORD_PBTLRLOG_ERR,"��¼����Ա������־��ʧ��[%d]", nRet); 
        return ;
    }
   /*zl add insert pbtlrlog end*/

	return ;
}

void txn_7030PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy(it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos7030), sizeof(it_totw.label.msglng), it_totw.label.msglng);

	memcpy(it_totw.sTotaText, &tos7030, sizeof(tos7030));
}

void txn_7030End()
{

}
