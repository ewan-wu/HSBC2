#ifndef _OPRMNG_H
#define _OPRMNG_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <malloc.h>
#include <memory.h>
#include <assert.h>
#include <errno.h>
#include <unistd.h>

#include "ipc.h"
#include "sysdef.h"
#include "msglog.h"
#include "msgque.h"
#include "tivoli.h"
#include "glb_def.h"
#include "glb_err.h"
#include "glb_var.h"
#include "glb_ext.h"
#include "public.h"
#include "status.h"
#include "swttoc.h"
#include "htlog.h"
#include "icbc_api_def.h"
#include "icbc_api.h"
#include "icbc_api_itf.h"
#include "icbc_com.h"


#endif /* _MANAGE_H */
