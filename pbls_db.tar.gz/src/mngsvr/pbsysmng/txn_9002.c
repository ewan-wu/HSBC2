/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: PBLSϵͳ����ά����Ȩ                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100729          Zhu Rui              Initial                     */
/************************************************************************/

#include "pbsysmng.h"

static struct TIS9002_GROUP
{ 
    char   sAuthType      ;   /* ��Ȩ���                       */
}tis9002;

static struct TOS9002_GROUP
{
	char	 null;
}tos9002;

static struct wd_pbsysctl_area        wd_pbsysctl;
static struct wd_pbsysctltmp_area     wd_pbsysctltmp;  

extern  char    logfile[256];

void txn_9002Initial(void);
void txn_9002Process(void);
void txn_9002PutMessage(void);

void txn_9002(void)
{
	txn_9002Initial();

	txn_9002Process();

	txn_9002PutMessage();
}

void txn_9002Initial(void)
{
	memset( &tis9002, 0, sizeof(tis9002) );
	memcpy( &tis9002, it_tita.sTitaText, sizeof(tis9002) );
	memset( &tos9002, 0, sizeof(tos9002) );	
	memset( &wd_pbsysctl    ,0  ,sizeof(wd_pbsysctl));
	memset( &wd_pbsysctltmp ,0  ,sizeof(wd_pbsysctltmp));
	
}

void txn_9002Process( void )
{
    
    /********************************************
     *  �ֲ�������������ʼ��
     ********************************************/
    int		nRet = 0;
    char  sBuf[1500+1];
	  
    /********************************************
     * ���ϵͳ������ʱ����
     * �Ƿ������ά���ĸ�����¼
     ********************************************/
    memcpy(wd_pbsysctltmp.rcd_id, SYS_RECORD_ID, strlen(SYS_RECORD_ID));
    
    nRet = DbsPBSYSCTLTMP(DBS_FIND,&wd_pbsysctltmp);
    if( nRet != DB_OK )
    {
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
        	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBSYSCTLTMP FIND ERROR! sqlcode=[%d]", nRet );
        ERRTRACE(E_PB_SYSCTLTMP_NOT_EXSIT,"��������Ҫ��Ȩ��ϵͳ������¼[%d]",nRet);/* �˴���ErrorTrace   ��������Ҫ��Ȩ��ϵͳ������¼ */
        return ;
    }
	  /* �ж�ά������Ȩ�Ƿ���ͬһ�� */
	if( memcmp(wd_pbsysctltmp.op_tlr, it_tita.label.tlrno, sizeof(it_tita.label.tlrno)) == 0 )
	{
		ERRTRACE( E_TXN_SAMEPERSON_ERR, "Md_tlrno=[%s],avp_tlrno=[%.8s]", wd_pbsysctltmp.op_tlr, it_tita.label.tlrno );
		return;  
	}
	
    nRet = DbsPBSYSCTLTMP( DBS_LOCK, &wd_pbsysctltmp ) ;
    if( nRet != DB_OK )
    {
        /* fail */
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
        	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBSYSCTLTMP LOCK ERROR! sqlcode=[%d]", nRet );
        ERRTRACE( E_DB_PBSYSCTLTMP_DERR, "Delete PBSYSCTLTMP ERROR! sqlcode=[%d]", nRet );
        DbsPBSYSCTLTMP( DBS_CLOSE );
        return;
    }
    /********************************************
     * ��Ȩͨ��
     ********************************************/
    if( tis9002.sAuthType == '1')
    {
        /* �ж�ά�����Ͳ������������� */
        if( wd_pbsysctltmp.op_type[0] != 'M')
        {
            ERRTRACE(E_TXN_OPTYPE_ERR,"ά�����Ͳ���ȷ[%c]",tis9002.sAuthType);/* �˴���ErrorTrace   ά�����Ͳ���ȷ */
            DbsPBSYSCTLTMP( DBS_CLOSE );
            return ;
        }
     
        memcpy(wd_pbsysctl.rcd_id, SYS_RECORD_ID, strlen(SYS_RECORD_ID));
        nRet = DbsPBSYSCTL(DBS_LOCK,&wd_pbsysctl);
        if( nRet != DB_OK && nRet != DB_NOTFOUND )
        {
            if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
            	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBSYSCTL LOCK ERROR! sqlcode=[%d]", nRet );
            if( nRet != DB_NOTFOUND )
            {
                ERRTRACE(E_PB_SYSCTL_NOT_EXSIT,"��������Ҫά����ϵͳ����[%d]",nRet);/* �˴���ErrorTrace   ��������Ҫά����ϵͳ���� */
            }
            DbsPBSYSCTLTMP( DBS_CLOSE );
            return ;
        } 

        /* ������������ */
        wd_pbsysctl.online_days      = wd_pbsysctltmp.online_days;
        wd_pbsysctl.history_max_days = wd_pbsysctltmp.history_max_days;
        wd_pbsysctl.tlr_s_exp_days   = wd_pbsysctltmp.tlr_s_exp_days; 
    
        nRet = DbsPBSYSCTL(DBS_UPDATE,&wd_pbsysctl);
        if( nRet != DB_OK  )
        {
            DbsPBPBANKCTL(DBS_CLOSE,&wd_pbsysctl);
            DbsPBSYSCTLTMP( DBS_CLOSE );
            if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
            	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBSYSCTL UPDATE ERROR! sqlcode=[%d]", nRet );
			ERRTRACE(E_DB_PBSYSCTLTMP_WERR, "rcd_id[%s], sqlcode[%d]", wd_pbsysctltmp.rcd_id, nRet);
            return ;
        }      
    }

    /* ɾ��ϵͳ������ʱ������ */
    nRet = DbsPBSYSCTLTMP( DBS_DELETE, &wd_pbsysctltmp ) ;
    if( nRet != DB_OK )
    {
        /* fail */
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
            RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBSYSCTLTMP DELETE ERROR! sqlcode=[%d]", nRet );
        ERRTRACE( E_DB_PBSYSCTLTMP_DERR, "Delete PBSYSCTLTMP ERROR! sqlcode=[%d]", nRet );
        DbsPBSYSCTLTMP( DBS_CLOSE );
        return;
    }
    DbsPBSYSCTLTMP( DBS_CLOSE );
 
    /* ��¼����Ա������־�� */
	HtLog(HTLM_COM,"��Ȩ���[%c]",tis9002.sAuthType);
    memset(sBuf,0,sizeof(sBuf));
    sprintf(sBuf,"��Ȩ���[%s]",GetFlagName(8,&tis9002.sAuthType));
	HtLog(HTLM_COM,"��Ȩ���[%c]",tis9002.sAuthType);
    
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        /* ��¼����Ա������־������ */
        RecTivoliLogC( "PBLS", "MNGSVR", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        return ;
    }

}

void txn_9002PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );
	apitoa( TOTA_LABEL_LENGTH + sizeof(tos9002), sizeof(it_totw.label.msglng), it_totw.label.msglng );
	memcpy( it_totw.sTotaText, &tos9002, sizeof(tos9002) );
}

void txn_9002End( void )
{
    DbsPBSYSCTL(DBS_CLOSE,&wd_pbsysctl);
    DbsPBSYSCTLTMP(DBS_CLOSE,&wd_pbsysctltmp);
}
