/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  Oracele Inq .
 *
 *  $Id$
 *
 * FileName: cvt_inq.c 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2010/07/14         zy                       Create.
 *  2010/12/22    Jasmine Ding                  Modify to generate file for export/print
 *
 */

/*------------------------ Include files ------------------------*/
#include "pbsysmng.h"
#include "DbComInq.h"

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define _DEBUG	0

#define FUNC_OK        0
#define FUNC_ERR       -1
#define FUNC_OTHER_ERR 9989

#define DLEN_PRE_SQL        80
#define DLEN_END_SQL        80

#define SQL_FRONT       "select * from ( select a__t.*, rownum i__d from ( "
#define SQL_END         " ) a__t ) b__t where i__d < %d and i__d >= %d"
#define SQL_COUNT_FRONT "select count(1) from ( "
#define SQL_COUNT_END   " ) "

#define DLEN_SQL            4*1024 + DLEN_PRE_SQL + DLEN_END_SQL
#define DLEN_BIND_NUM       80
#define DLEN_MAX_ROW_NUM    10
#define DLEN_CONFIG_NUM     3

#define DLEN_SQLCODE        4
#define DLEN_FIELDCNT       4
#define DLEN_RECNO          8
#define DLEN_RECCNT         2
#define DLEN_RECSET         9000-DLEN_SQLCODE-DLEN_FIELDCNT-DLEN_RECNO-DLEN_RECCNT

#define DLEN_SQL_ID     64
#define DLEN_CURE_COUNT 5
#define DLEN_ALL_COUNT  12
#define DLEN_SQL_COUNT  22

#define FLAG_IS_END  '1'
#define FLAG_NOT_END '0'

#define SPLIT_CHAR "^"

#define CHECK(p)                \
do{                             \
    if ( NULL == (p) ){         \
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "["#p"] is NULL"); \
        return (FUNC_OTHER_ERR);\
    }                           \
}while(0);

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/

/*--------------------- Local function declaration --------------*/
static void txn_9989Initial(void);
static void txn_9989Process(void);
static void txn_9989End(void);
static int StdInquireProcess(char *psRec, char *psSqlId, char *psBind, char *psFieldCnt, char *psRecCnt, char *psRecNo, char *psReturn, int *pnRetLen);
static int GeneralInq(char *psSqlId, char *psBindValue, int nStart, int *pnRowNum, int *pnFildNum, char *psReturn, int *pnRetLen, int *pnAllNum);
static int GetSqlString(char *psSql, char *psSqlId, char *psBind, char **ppsRetBindIdx, int *pnBindNum, int *pnSqlLen);
static int InqOraEasyInq(char *psSql, char **ppsBind, int nBindNum, int nStartNum, char *psBuf, int *pnBufLen, int *pnRowNum, int *pnFieldNum);
static int cvtStrNSplit(char **ppsStr, char *psLine, char *psSplitChar, int nNum);
static int antoi(char *psStr, int nLen);
static char * RightTrimX ( char *str, int *len );

/*--------------------- Global variable -------------------------*/
extern char logfile[256];

/*
typedef struct 
{
    char caSQLCode[CR_LEN_SQLCODE];
    char caFieldCnt[CR_LEN_FIELDCNT];
    char caRecNo[CR_LEN_RECNO];
    char caRecCnt[CR_LEN_RECCNT];
    char caRecSet[CR_LEN_RECSET];
}TOS8888_GROUP;
*/

#if 0
#pragma mark -
#pragma mark < Global functions >
#endif
/*--------------------- Global functions ------------------------*/
/**
 * txn_9989
 * prcess 9989 transaction
 * 
 * @param void: void
 * 
 * @return >0  : ok
 *         <0  : err
 */
int txn_9989(void)
{
    /* Init */
    txn_9989Initial();
    if( it_txcom.txrsut != TX_SUCCESS )
        return (FUNC_ERR);
    
    /* Process */
    txn_9989Process();
    if( it_txcom.txrsut != TX_SUCCESS )
        return (FUNC_ERR);
    
    /* End */
    txn_9989End();
    
    return (FUNC_OK);
}

#if 0
#pragma mark -
#pragma mark < Local functions >
#endif
/*--------------------- Local functions -------------------------*/
/**
 * txn_9989Initial
 * Init 9989 Tita message
 *
 * @param void: void
 *
 * @return >0  : ok
 *         NULL: err
 */
static void txn_9989Initial(void)
{   
	return;
}

/**
 * txn_9989Process
 * just invork the CALL_9989_STD_PROCESS
 * porcess the return code
 *
 * @param void: void
 *
 * @return >0  : ok
 *         NULL: err
 */
static void txn_9989Process(void)
{
    int nRet;
    /* added by Jasmine 20101222 begin */
	int iCnt=0;
	FILE *fp;
	char sFilename[256];
	char sTlrno[8+1];
	char sTime[14+1];
	int iRet;
	struct wd_icbc_inquire_cfg_area tInqCfg1;

	memset(sFilename, 0, sizeof(sFilename));
	memset(sTlrno, 0, sizeof(sTlrno));
	memset(sTime, 0, sizeof(sTime));
    /* added by Jasmine 20101222 end */
	
    /* Get All Config info */
    enum {
        CONF_RECNO,
        CONF_SQLID,
        CONF_BIND,
        CONF_NUM
    };
    int nConfigNum;
    char *ppsConfig[CONF_NUM];

    /* added by Jasmine 20101222 begin */
	//reset the recno
	memcpy(it_tita.sTitaText, "00000001", 8);
    /* added by Jasmine 20101222 end */
	
    nConfigNum = cvtStrNSplit(ppsConfig, it_tita.sTitaText, SPLIT_CHAR, CONF_NUM);
    if ( nConfigNum != CONF_NUM ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Get Config err!! [REC_NO:%s][SQL_ID:%s][BIND:%s]", ppsConfig[CONF_RECNO], ppsConfig[CONF_SQLID], ppsConfig[CONF_BIND]);
		ERRTRACE(E_PARA_ERR, "Get Config err!!");
        return;
    }
    
    /* do inquire */
    char sFieldCnt[DLEN_FIELDCNT+1];
    char sRecCnt  [DLEN_RECCNT  +1];
    char sRecNo   [DLEN_RECNO   +1];
    char sReCode  [DLEN_SQLCODE +1];
    char sReturn  [DLEN_RECSET  +1];
    int nRetLen;
    
    memset(sFieldCnt, '\0', sizeof(sFieldCnt));
    memset(sRecCnt  , '\0', sizeof(sRecCnt  ));
    memset(sRecNo   , '\0', sizeof(sRecNo   ));
    memset(sReturn  , '\0', sizeof(sReturn  ));
    nRetLen = sizeof(sReturn);

	while(1)
	{
    	/* added by Jasmine 20101222 begin */
		// open the file for output
		memcpy(sTlrno, it_tita.label.tlrno, 8);
		RightTrim(sTlrno);
		CommonGetCurrentTime(sTime);
		sprintf(sFilename, "$APPL/iodata/tmp/%s_%s.csv", sTlrno, sTime);
		replace_env_var(sFilename);
printf("sFilename[%s]\n", sFilename);

		fp = fopen( sFilename , "w+" );
	    if( fp == NULL )
	    {
	        ERRTRACE( E_SYS_FILE_OPR_ERR, "open file error! filename[%s]", sFilename );
	        strcpy(sReCode, "9527");
	    }

		// get data titles
	    memset(&(tInqCfg1), '\0', sizeof(struct wd_icbc_inquire_cfg_area));
	    strncpy(tInqCfg1.sql_id, ppsConfig[CONF_SQLID], sizeof(tInqCfg1.sql_id));
		RightTrim(tInqCfg1.sql_id);
		strcat(tInqCfg1.sql_id, "_title");
printf("title[%s]\n", tInqCfg1.sql_id);
	    nRet = DbsICBC_INQUIRE_CFG(DBS_FIND, &(tInqCfg1));
	    if ( nRet != DB_OK ) {
	        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"DbsTBL_IBSP_INQUIRE_CFG err..sqlcode[%d]", nRet );
	        strcpy(sReCode, "9527");
	    }
		// write the output to the file
		strcat(tInqCfg1.sql_string, "\n");
		iRet = fwrite(tInqCfg1.sql_string, strlen(tInqCfg1.sql_string), 1, fp);
		if(iRet < 0)
		{
			ERRTRACE( E_SYS_FILE_OPR_ERR, "write file error! filename[%s]", sFilename );
			strcpy(sReCode, "9527");
		}
		/* added by Jasmine 20101222 end */

		// do the universal inquiry
    	nRet = StdInquireProcess(ppsConfig[CONF_RECNO], ppsConfig[CONF_SQLID], ppsConfig[CONF_BIND], sFieldCnt, sRecCnt, sRecNo, sReturn, &(nRetLen));
	
	    /* set return code */
	    memset(sReCode, '\0', sizeof(sReCode));
	    
	    if ( nRet < 0 ) {
	        nRet *= -1;
	    }

	    it_totw.label.msgend = '1';
	    it_totw.label.msgtype = it_tita.label.taskid[1];
	    memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );

	    sprintf(sReCode, "%0*d", DLEN_SQLCODE, nRet);
	    if ( nRet != 0 ) {
	        sprintf(it_totw.sTotaText, "%s00000000000000", sReCode);
	    } else {
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "sReCode[%s]", sReCode);
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "sFieldCnt[%s]", sFieldCnt);
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "sRecCnt[%s]", sRecCnt);
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "sRecNo[%s]", sRecNo);
			sprintf(it_totw.sTotaText, "%s%s%s%s%.*s", sReCode, sFieldCnt, sRecNo, sRecCnt, nRetLen, sReturn); 
			apitoa(TOTA_LABEL_LENGTH + strlen(it_totw.sTotaText), sizeof(it_totw.label.msglng), it_totw.label.msglng);
	    }

		/* added by Jasmine 20101222 begin */
printf("write file... nRetLen[%d],text[%.*s]\n", nRetLen, nRetLen, sReturn);
		// write the output to the file
		iRet = fwrite(sReturn, nRetLen, 1, fp);
		if(iRet < 0)
		{
			ERRTRACE( E_SYS_FILE_OPR_ERR, "write file error! filename[%s]", sFilename );
			strcpy(sReCode, "9527");
		}
printf("atoi(sRecCnt)[%d]\n", atoi(sRecCnt));
		/* added by Jasmine 20101222 end */

		//judge whether to end the inquiry
		if(atoi(sRecCnt)<DLEN_MAX_ROW_NUM)
		{
			break;
		}
	}

	/* added by Jasmine 20101222 begin */
	// close the file
	iRet = fclose(fp);
	if(iRet != 0)
	{
		ERRTRACE( E_SYS_FILE_OPR_ERR, "close file error! filename[%s]", sFilename );
		strcpy(sReCode, "9527");
	}

	// rewrite the totw
	memset(it_totw.sTotaText, 0, sizeof(it_totw.sTotaText));
	sprintf(it_totw.sTotaText, "%s%s", sReCode, sFilename); 
	apitoa(TOTA_LABEL_LENGTH + strlen(it_totw.sTotaText), sizeof(it_totw.label.msglng), it_totw.label.msglng);
	/* added by Jasmine 20101222 end */
}

/**
 * txn_9989End
 * Free 9989 Init resouse
 *
 * @param void: void
 *
 * @return >0  : ok
 *         NULL: err
 */
static void txn_9989End(void)
{
    /* do nothing */
    return;
}

#if 0
#pragma mark -
#pragma mark < General Function >
#endif

/**
 * StdInquireProcess
 * Make sql By SqlId, Make Bind Value Index
 * do inqure and make response pkg
 *
 * @param void: void
 *
 * @return >0  : ok
 *         <0  : err
 */
static int StdInquireProcess(char *psRec, char *psSqlId, char *psBind, char *psFieldCnt, char *psRecCnt, char *psRecNo, char *psReturn, int *pnRetLen)
{
    int nRet;
    int i;
    int nRowNum;
    int nFieldNum;
    
    /* Check the NULL RETURN */
    CHECK(psReturn);
    CHECK(pnRetLen);
    
    /* Set Sql Head */
    int nStart;
    if ( psRec == NULL ) {
        nStart = 0;
        nRowNum = 1;
    } else {
        nStart = atoi(psRec);
        if ( nStart <= 0 ) {
            /* reset start num to 0 */
            nStart = 0;
            
            /* set all Num is 1 */
            nRowNum = 1;
        } else {
            /* set all Num to Max */
            nRowNum = DLEN_MAX_ROW_NUM;
        }
    }
    
    /* do inq */
    nRet = GeneralInq(psSqlId, psBind, nStart, &(nRowNum), &(nFieldNum), psReturn, pnRetLen, NULL);
    if ( nRet != FUNC_OK ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "GeneralInq err!!");
        return (nRet);
    }
    
    if ( psFieldCnt != NULL ) {
        sprintf(psFieldCnt, "%0*d", DLEN_FIELDCNT, nFieldNum       );
    }
      
    if ( psRecCnt != NULL ) {
        sprintf(psRecCnt  , "%0*d", DLEN_RECCNT  , nRowNum         );
    }
      
    if ( psRecNo != NULL ) {
        sprintf(psRecNo   , "%0*d", DLEN_RECNO   , nStart + nRowNum);
    }

    return (FUNC_OK);
}

/**
 * GeneralInq
 * do inq in general way
 *
 * @param void: void
 *
 * @return >0  : ok
 *         <0  : err
 */
static int GeneralInq(char *psSqlId, char *psBindValue, int nStart, int *pnRowNum, int *pnFildNum, char *psReturn, int *pnRetLen, int *pnAllNum)
{
    int nRet;
    
    /* Set Sql Head */
    char sSql[DLEN_SQL+1];
    memset(sSql, '\0', sizeof(sSql));
    
    /* cat sql front */
    if ( nStart > 0 ) {
        sprintf(sSql, "%*s", DLEN_PRE_SQL, SQL_FRONT);
    } else {
        memset(sSql, ' ', DLEN_PRE_SQL);
    }
    
    /* Get Sql String */
    int  nBindNum;
    int  nCenterLen;
    char *ppsBindIdx[DLEN_BIND_NUM+1];
    char *psCenter;
    memset(ppsBindIdx, '\0', sizeof(ppsBindIdx));
    psCenter = sSql + DLEN_PRE_SQL;
    nRet = GetSqlString(psCenter, psSqlId, psBindValue, ppsBindIdx, &(nBindNum), &(nCenterLen));
    if ( nRet != FUNC_OK ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "GetSqlString err!![%d]",nRet);
        return (FUNC_OTHER_ERR);
    }
    
    /* Get Sql End */
    char *psEnd;
    psEnd = psCenter + nCenterLen;
    if ( nStart > 0 ) {
        sprintf(psEnd, SQL_END, nStart+DLEN_MAX_ROW_NUM, nStart);
    }
    
    /* do inquire */
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Sql[%s]", sSql );
    nRet = InqOraEasyInq(sSql, ppsBindIdx, nBindNum, nStart, psReturn, pnRetLen, pnRowNum, pnFildNum);
    if ( nRet != FUNC_OK ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "InqOraEasyInq err!! sql[%s] sqlcode[%d]", sSql, nRet);
        return (nRet);
    }

    /* count all rows */
    if ( pnAllNum != NULL ) {
        char sAllCount[DLEN_SQL_COUNT+1];
        char caTemp;
        int nAllCountLen;
        int nFieldNum;
        int nRowNum;
        
        memset(sAllCount, '\0', sizeof(sAllCount));
        caTemp = sSql[DLEN_PRE_SQL];
        sprintf(sSql, "%*s", DLEN_PRE_SQL, SQL_COUNT_FRONT);
        sSql[DLEN_PRE_SQL] = caTemp;
        sprintf(psEnd, SQL_COUNT_END);
        nAllCountLen = sizeof(sAllCount);
        nRowNum = 1;
        
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Conut Sql[%s]", sSql );
        nRet = InqOraEasyInq(sSql, ppsBindIdx, nBindNum, 1, sAllCount, &(nAllCountLen), &(nRowNum), &(nFieldNum));
        if ( nRet != FUNC_OK ) {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "InqOraEasyInq err!! count sql[%s] err!! sqlcode[%d]", sSql, nRet);
            return (FUNC_ERR);
        }
        
        *pnAllNum = antoi(sAllCount, nAllCountLen);
    }
    
    return (FUNC_OK);
}

/**
 * GetSqlString
 * Make Sql Info
 * get org sql by sqlid
 * get bind value by psBind
 * make string add to psSql
 *
 * @param psSql: return sql string
 * @param psSqlId: sql id
 * @param psBind: bind value
 *
 * @return >0  : ok
 *         NULL: err
 */
static int GetSqlString(char *psSql, char *psSqlId, char *psBind, char **ppsRetBindIdx, int *pnBindNum, int *pnSqlLen)
{
    int nRet;
    int i;
        
    /* Get Sql String */
    struct wd_icbc_inquire_cfg_area tInqCfg;
    memset(&(tInqCfg), '\0', sizeof(struct wd_icbc_inquire_cfg_area));
    strncpy(tInqCfg.sql_id, psSqlId, sizeof(tInqCfg.sql_id));
	/* added by Jasmine 20101222 begin */
	RightTrim(tInqCfg.sql_id);
	strcat(tInqCfg.sql_id, "_file");
printf("sqlid[%s]\n", tInqCfg.sql_id);
	/* added by Jasmine 20101222 end */
    nRet = DbsICBC_INQUIRE_CFG(DBS_FIND, &(tInqCfg));
    if ( nRet != DB_OK ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"DbsTBL_IBSP_INQUIRE_CFG err..sqlcode[%d]", nRet );
        return (FUNC_OTHER_ERR);
    }

    /* sqlit the sql string by "^" */
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "OrgSql[%s]", tInqCfg.sql_string );
    int nSqlNum;
    char *ppsSqlIdx[DLEN_BIND_NUM+1];
    nSqlNum = cvtStrNSplit(ppsSqlIdx, tInqCfg.sql_string, SPLIT_CHAR, DLEN_BIND_NUM+1);
    if ( nSqlNum >= DLEN_BIND_NUM+1 ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Too Many Bind Info then define[%d] err!!", DLEN_BIND_NUM);
        return (FUNC_OTHER_ERR);
    }

    /* sqlit the bind value string by "^" */
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "OrgValue[%s]", psBind );
    int nBindNum;
    char *ppsBindIdx[DLEN_BIND_NUM+1];
    nBindNum = cvtStrNSplit(ppsBindIdx, psBind, SPLIT_CHAR, DLEN_BIND_NUM+1);
    if ( nBindNum >= DLEN_BIND_NUM+1 ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Too Many Bind Info then define[%d] err!!", DLEN_BIND_NUM);
        return (FUNC_OTHER_ERR);
    }

#if _DEBUG
{
	int i;
	printf("---------------------------------\n");
	for(i = 0; i < nBindNum-1; i++)
	{
		printf("%s = [%s]\n", ppsSqlIdx[i+1], ppsBindIdx[i]);
	}
	printf("---------------------------------\n");
}
#endif

    /* Check the Num of sql and bind */
    if ( nSqlNum != nBindNum + 1 ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Bind Num [%d]+1 is not same with Sql Num[%d] err!!", nBindNum, nSqlNum);
        return (FUNC_OTHER_ERR);
    }
    
    /* make sql */
    int nRealNum;
    nRealNum = 0;
    strcat(psSql, ppsSqlIdx[0]);
    for ( i=0; i<nBindNum-1; ++i) {
        if ( *ppsBindIdx[i] != '\0' ) {
            ppsRetBindIdx[nRealNum] = ppsBindIdx[i];
            ++nRealNum;
            strcat(psSql, ppsSqlIdx[i+1]);
        }
    }
    strcat(psSql, ppsSqlIdx[nSqlNum-1]);
    *pnBindNum = nRealNum;
    *pnSqlLen = strlen(psSql);
    
    return (FUNC_OK);
}

/**
 * InqOraEasyInq
 * convert oracle easy aotu inquire
 *
 * @param psSql: the sql string
 * @param ppsBind: the bind value(must end of '\0')
 * @param nBindNum: num of bind value
 * @param psBuf: return buf
 * @param pnBufLen: return buf len
 * @param pnRowNum: return row num (must be set max row num)
 * @param pnFieldNum: rerurn field num
 *
 * @return >0  : ok
 *         <0  : err
 */
static int InqOraEasyInq(char *psSql, char **ppsBind, int nBindNum, int nStartNum, char *psBuf, int *pnBufLen, int *pnRowNum, int *pnFieldNum)
{
    int nRowNum;
    int nRet;
    int i;
    int nRowOffset;
    int nListOffset;
	char sNewline[2];
    
    CHECK(psSql);
    CHECK(ppsBind);
    CHECK(psBuf);
    CHECK(pnBufLen);
    CHECK(pnRowNum);
    CHECK(pnFieldNum);
    
    /* just return  */
    if ( *pnRowNum <= 0 ) {
        *pnBufLen = 0;
        *pnRowNum = 0;
        *pnFieldNum = 0;
        return (FUNC_OK);
    }
    
    /* set bind value */
    for ( i=0; i<nBindNum; ++i) {
        nRet = InqOraSetBind(ppsBind[i], strlen(ppsBind[i]));
        if ( nRet != FUNC_OK ) {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "[%d]: Bind Value[%s] err!!", i, ppsBind[i]);
            InqOraInq(CVT_ORA_INQ_CLOSE, NULL);
            return (FUNC_OTHER_ERR);
        }
    }
    
    /* do inquare */
    nRowNum = 0;
    nRowOffset = 0;
    *pnFieldNum = 0;
    while ( (nRet = InqOraInq(CVT_ORA_INQ_FETCH, psSql)) == FUNC_OK ) {
        nListOffset = 0;
        for ( i=0 ; ; ++i ) {
            char *psTemp;
            int nValueLen;

            psTemp = InqOraGetField(i, &(nValueLen));
            if ( psTemp == NULL ) {
                break;
            }
			/* added by Jasmine 20101222 begin */
#if _DEBUG
printf("** nValueLen[%d], psTemp[%s]\n", nValueLen, psTemp);
#endif
			RightTrimX(psTemp, &nValueLen);
#if _DEBUG
printf("++ nValueLen[%d], psTemp[%s]\n", nValueLen, psTemp);
#endif
			/* added by Jasmine 20101222 end */

            if ( nRowOffset + nListOffset + nValueLen > *pnBufLen ) {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Warning:Sql Return is too long then[%d], stop !!", *pnBufLen);
                goto END;
            }
            memcpy(psBuf+nRowOffset+nListOffset, psTemp, nValueLen);
			/* added by Jasmine 20101222 begin */
			// add comma after every column value
			memcpy(psBuf+nRowOffset+nListOffset+nValueLen, ",", 1);
			nValueLen += 1;
			/* added by Jasmine 20101222 end */
            nListOffset += nValueLen;
        }
        
        nRowOffset += nListOffset;
        if ( nStartNum > 0 ) {
            /* delete rownum len */
            nRowOffset -= 22;
        }
        *pnFieldNum = i;
        ++nRowNum;
        
		/* added by Jasmine 20101222 begin */
		// delete 2 commas around the rownum and add newline
		sNewline[0] = 0x0A;
		sNewline[1] = 0;
		memcpy(psBuf+nRowOffset-2, sNewline, 1);
		nRowOffset--;
printf("nRowOffset[%d], psBuf[%s]\n", nRowOffset, psBuf);
		/* added by Jasmine 20101222 end */

        if ( nRowNum + 1 > *pnRowNum ) {
            break;
        }
    }
printf("after while... nRowOffset[%d], psBuf[%s]\n", nRowOffset, psBuf);

END:    
    InqOraInq(CVT_ORA_INQ_CLOSE, NULL);
    
    if ( nRet != DB_NOTFOUND && nRet != FUNC_OK ) {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Inq[%s] err!! sqlcode[%d]", psSql, nRet);
        return (nRet);
    }
    
    *pnBufLen = nRowOffset;
    *pnRowNum = nRowNum;
    
    return (FUNC_OK);
}

/**
 * cvtStrNSplit
 * split string to short string
 * split by splitchar, the max num is nNum
 *
 * @param ppsStr: short string list
 * @param psLine: source string
 * @param psSplitChar: slplus char(can be many)
 * @param nNum: max num of split
 *
 * @return >0  : ok
 *         <0  : err
 */
static int cvtStrNSplit(char **ppsStr, char *psLine, char *psSplitChar, int nNum)
{
    char *p;
    int n = 1;
    int ntemp;
    
    if ( NULL == psLine || NULL == ppsStr || NULL == psSplitChar){
        return (-1);
    }
    
    *ppsStr++ = p = psLine;
    while ( (p=strpbrk(p, psSplitChar)) && (n<nNum) ) {
        n++;
        *p++ = '\0';
        *ppsStr++ = p;
    }
    
    for ( ntemp = n; ntemp<nNum ; ++ntemp ){
        *ppsStr++ = "";
    }
    
    return (n);
}

/**
 * anti
 * chanage string to num
 * num is the string len of string
 *
 * @param psStr: string
 * @param nNum: string length
 *
 * @return >0  : ok
 *         <0  : err
 */
static int antoi(char *psStr, int nLen)
{
    int nNum;
    char cTemp;
                    
    cTemp = psStr[nLen];
    psStr[nLen] = '\0';
    nNum = atoi(psStr);
    psStr[nLen] = cTemp;
                                    
    return (nNum);
}

/*
 * RightTrimX
 * ȥ��str��β���Ŀ��ַ����޸ĳ���
 * len is the string len of string
 *
 * @param str: string
 * @param len: string length
 *
 * @return   : string
 */
static char * RightTrimX ( char *str, int *len )
{
	char	*s;

	s = str + *len;

	--s;
	while ( s >= str )
	{
	    if ( (*s==' ') || (*s=='\t') || (*s=='\r') || (*s=='\n') )
	    {
			*s = 0;
	        --s;
			(*len)--;
	    }
	    else
	    {
	        break;
	    }
	}

	return str;
}
/*--------------------- End -------------------------------------*/
