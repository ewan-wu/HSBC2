/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*                                                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: manager                                                 */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*                                                                      */
/************************************************************************/

#include "pbsysmng.h"

T_TOTW_LABTEX     it_totw;
T_TXCOM_AREA      it_txcom;
T_TITA_LABTEX     it_tita;

char logfile[256];
static long lMsgSource = 0;

static int  InitGlbVar(void *psDataBuf, short nInDataLen);
static void vTellerProcess(void *psDataBuf, short nInDataLen);
static void HandleExit( );

int main(int argc, char **argv)
{
    int  iRet = 0 ;
    short  nInDataLen = 0;
    char sDataBuf[sizeof(IPCMsgDef)];
	
	
    setbuf( stdout, NULL );
    
    DebugMemory( "Start");
	
    iRet = GetLogName(argv[1], logfile);
    if (iRet != 0 )
    {
        /*ErrReport(CI_SYSMNG,
        		 	EI_PROCESS,
             		  	0,
        		  	CI_SEVERITY_SYSERROR,
        			ES_GET_LOGFILE);*/
        HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__, "GetLogName Error!" );
        exit(-1);
    }
	
    iRet = InitPbsysmng();
    if (iRet != 0 )
    {
        /*ErrReport(CI_SYSMNG,
        		 	EI_PROCESS,
             		  	0,
        		  	CI_SEVERITY_SYSERROR,
        			ES_PROCESS_INIT);*/
        HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__, "Init Error!" );
        exit(-1);
    }
	
	if (sigset(SIGTERM, (void (*)())HandleExit) == SIG_ERR)
		HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"SIGTERM error");
	
    /* HANDLE TRANSACTION */
    while(1)
    {
        /* READ MANAGE MESSAGE QUEUE */
        memset(sDataBuf, 0 ,sizeof(sDataBuf));
        sigrelse(SIGTERM);
        iRet = nCommonMsqRecv (&nInDataLen, sDataBuf, &lMsgSource, CI_SYSMNG);
        if (iRet != 0)
        {
            if (errno != EINTR)
            {
            
                if (nCommonMsqInit(CI_SYSMNG) == -1)
                {
                    HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,
                    	"nCommonMsqInit() error=[%d]",  errno); 
                    RecTivoliLogC("PBLS", "MANAGER", TIVOLI_MESSAGEQ, __FILE__, __LINE__, 
                    "Receive Message Error!sqlcode=[%d]",iRet );
                    exit(1);
                }
                continue;
            }
        }
        HtDebugString(logfile,  sDataBuf, nInDataLen, __FILE__, __LINE__);
        		
        sighold(SIGTERM);
        switch(lMsgSource)
        {
        	case CI_TLRBDG:				/* ���� */
        		vTellerProcess((void *)sDataBuf, nInDataLen  );
        		break;
        	default:
        		HtLog(logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,
        				"Invalid message source =[%d]", lMsgSource);
        		break;
        }
    }
}

/* ���� */
void vTellerProcess(void *psDataBuf, short nInDataLen)
{
    struct wd_pbtlrctl_area wd_tlrctl;
    T_MngBufToTlrDef   tBufToTlr;
    T_MngBufFromTlrDef *ptBufFromTlr;

    int iRet= 0;
    long lTxno=0;
    long nOutLen=0;
    
    char sTxno[DLEN_TXNCD+1];
    
    char sPid[100];
    char sOutLen[10];
    
    memset(&tBufToTlr, 0, sizeof(tBufToTlr));
    memset(sTxno, 0, sizeof(sTxno));
    memset(sPid, 0 , sizeof(sPid));
    memset(sOutLen, 0, sizeof(sOutLen));
	
	  HtDebugString(logfile,  psDataBuf, nInDataLen, __FILE__, __LINE__);
	  
    ptBufFromTlr = (T_MngBufFromTlrDef *)psDataBuf;
	
    /*iRet = InitGlbVar(&(ptBufFromTlr->tTlrText), sizeof(ptBufFromTlr->tTlrText.tTitaLabel));*/
    iRet = InitGlbVar(&(ptBufFromTlr->tTlrText), nInDataLen-sizeof(T_IPCHeader));
    if (iRet < 0)
    {
        HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,"InitGlbVar error");
        return ;
    }
    HtDebugString(logfile,  psDataBuf, nInDataLen, __FILE__, __LINE__);
	
    memcpy(sTxno, it_tita.label.txno, DLEN_TXNCD);
    memcpy(sPid, it_tita.label.termid, 8);
    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "sTxno= [%s],sPid=[%s]", sTxno,sPid);

    lTxno = atol(sTxno);

    memset(&wd_tlrctl, 0, sizeof(struct wd_pbtlrctl_area));
    memcpy(wd_tlrctl.tlr_id, it_tita.label.tlrno, sizeof(it_tita.label.tlrno));
    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "wd_tlrctl.tlr_id= [%s]", wd_tlrctl.tlr_id);
    
    iRet = DbsPBTLRCTL(DBS_FIND, &wd_tlrctl);
    if(iRet != DB_OK && iRet != DB_NOTFOUND)
    {
        HtLog( logfile, HT_LOG_MODE_ERR, __FILE__, __LINE__,
        "Dbs_TB_TLRCTL error tlrno[%s],sqlcode[%d]", wd_tlrctl.tlr_id, iRet);
        return;
    }
	
    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "lTxno = [%d], sPid = [%s]", lTxno,sPid);

    /*if((12 != lTxno && 0 != RightTrim(wd_tlrctl.sRsv1)) || iRet == DB_NOTFOUND)
    {
    it_txcom.txrsut = TX_REJECT;	
    strcpy(gsErrDesc, "�ò���Ա��Session�ѹ���,��رմ������µ�½");
    }
    else*/{

        printf("----------------- txn %s begin [%s] -----------------\n", sTxno, GetCurTime2());
        
        switch(lTxno)
        {
            case 12:
                txn_0012();
                txn_0012End();
                break;	

            case 23:
                txn_0023();
                txn_0023End();
                break;	

            case 24:
                txn_0024();
                txn_0024End();
                break;	

            case 2004:
                txn_2004();
                txn_2004End();
                break;	

            case 2005:
                txn_2005();
                txn_2005End();
                break;	

            case 2006:
                txn_2006();
                txn_2006End();
                break;	

            case 2007:
                txn_2007();
                txn_2007End();
                break;	

            case 2008:
                txn_2008();
                txn_2008End();
                break;	

			/**add by han meirong 20110408***begin***/
			case 2010:
				txn_2010();
				txn_2010End();
				break;

			case 2011:
				txn_2011();
				txn_2011End();
				break;
			/**add by han meirong 20110408***end****/

            case 5101:
                txn_5101();
                txn_5101End();
                break;	

            case 5104:
                txn_5104();
                txn_5104End();
                break;	

            case 7021:
			    txn_7021();
				txn_7021End();
				break;

			case 7022:
			    txn_7022();
				txn_7022End();
				break;
				
            case 7051:
                txn_7051();
                txn_7051End();
                break;	

            case 7052:
                txn_7052();
                txn_7052End();
                break;	
        	
            case 9001:
                txn_9001();
                txn_9001End();
                break;

			case 9002:
				txn_9002();
				txn_9002End();
				break;

            case 9051:
                txn_9051();
                txn_9051End();
                break;	

            case 9052:
                txn_9052();
                txn_9052End();
                break;	

			case 9999:
				if(it_tita.sTitaText[0] == '9')
					txn_9989();
				else
					txn_9999();
				break;

            default:
            	HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__, "Invalid message txno =[%d]", lTxno);
        } 
        printf("----------------- txn %s end   [%s] -----------------\n\n", sTxno, GetCurTime2());
    
        HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Process OK");
    }
    if(it_txcom.txrsut == TX_MODIYPWD)
    {
        DbRollbackTxn();
        it_totw.label.msgtype = 'E';
    
        /* ���� */
        memcpy(it_totw.label.msgno, "1111", 4);
        memcpy(it_totw.sTotaText, gsErrDesc, strlen(gsErrDesc));
        /* end */
        nOutLen = sizeof(it_totw.label);
        HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"Process Fail![%d][%d]",sizeof(it_totw.label),strlen(gsErrDesc));
         
    }
    
    if(it_txcom.txrsut != TX_SUCCESS&&it_txcom.txrsut != TX_MODIYPWD)
    {
        DbRollbackTxn();
        it_totw.label.msgtype = 'E';
    
        /* ���� */
        memcpy(it_totw.label.msgno, "9527", 4);
        memcpy(it_totw.sTotaText, gsErrDesc, strlen(gsErrDesc));
        /* end */
        nOutLen = sizeof(it_totw.label) + strlen(gsErrDesc);
        HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"Process Fail![%d][%d]",sizeof(it_totw.label),strlen(gsErrDesc));
    
    }
	
    if(it_txcom.txrsut == TX_SUCCESS)
    {
        memcpy(sOutLen, it_totw.label.msglng, sizeof(it_totw.label.msglng));
        nOutLen = atol(sOutLen);
        
        DbCommitTxn();
        HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"Process Success!");
    }
	
    it_totw.label.process_flag = '0';
	
    it_totw.label.header[0] = nOutLen / 256;
    it_totw.label.header[1] = nOutLen % 256;
	
    memcpy(&tBufToTlr, &it_totw, nOutLen);
    
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"header      [%8.8s]  ",it_totw.label.header      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"clsno       [%6.6s]  ",it_totw.label.clsno       );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"termid      [%8.8s]  ",it_totw.label.termid      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"refssn      [%14.14s]",it_totw.label.refssn      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"kinbr       [%3.3s]  ",it_totw.label.kinbr       );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"trmseq      [%2.2s]  ",it_totw.label.trmseq      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"ejfno       [%7.7s]  ",it_totw.label.ejfno       );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"taskid      [%2.2s]  ",it_totw.label.taskid      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"txno        [%4.4s]  ",it_totw.label.txno        );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tlrno       [%8.8s]  ",it_totw.label.tlrno       );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tlsrno      [%7.7s]  ",it_totw.label.tlsrno      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tmtype      [%c]  ",it_totw.label.tmtype      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"txdate      [%8.8s]  ",it_totw.label.txdate      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"txtime      [%6.6s]  ",it_totw.label.txtime      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msgend      [%c]  ",it_totw.label.msgend      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msgtype     [%c]  ",it_totw.label.msgtype     );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msgno       [%4.4s]  ",it_totw.label.msgno       );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msglng      [%4.4s]  ",it_totw.label.msglng      );
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"process_flag[%c]  ",it_totw.label.process_flag);
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"inq_id      [%8.8s]  ",it_totw.label.inq_id      );

	
    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"nOutLen=[%d]", nOutLen);
    HtDebugString( logfile, (char *)&tBufToTlr, nOutLen , __FILE__, __LINE__);	

    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"spid=[%s]", sPid);
    iRet = nCommonMsqSendT(nOutLen, &tBufToTlr, atol(sPid), CI_TLRCOMM);
    if (iRet != 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            	"nCommonMsqSendT = [%d], errno=[%d], %s", iRet, errno, strerror(errno));
        RecTivoliLogC("PBLS", "MANAGER", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "Send Message Error!sqlcode=[%d]",iRet );
        return ;
    }

    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"nCommonMsqSendT OK");
}

int InitPbsysmng()
{
    int nRet=0;
	
	if (0 != DbConnect() )
	{
		HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,
       			"DbConnect() error");
		return -1;
	}
	/*****************************************/
	/* Load the server information in SRVINF */
	/*****************************************/
  nRet = nCommonMsqAllInit(CI_TLRCOMM);
	if (nRet != 0) 
   	{
       	ErrReport(CI_SYSMNG, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }
    
    nRet = nCommonMsqAllInit(CI_SYSMNG);
	if (nRet != 0) 
   	{
       	ErrReport(CI_SYSMNG, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }
	  
	/********************************************/
    /* Load the TxnMap information of TXNNOMAP  */
    /********************************************/
#if 0
	if (0 != LoadTxnnoMap())
	{
		HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,
				"LoadTxnnoMap() error");
		return -1; 
	}
	
	if (0 != nLoadMsqDef())
	{
		HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,
				"nLoadMsqDef() error");
		return -1; 
		
	}
#endif
	
	
	/*****************************/
   	/* Initial the message queue */
	/*****************************/
	
    if (0 != nCommonMsqInit(CI_TLRCOMM))
    {
        HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,"nCommonMsqInit() error");
        return -1;
    
    }
	
    if (0 != nCommonMsqInit(CI_SYSMNG))
    {
        HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,"nCommonMsqInit() error");
        return -1;	
    }
	
    if (0 != nCommonMsqInit(CI_TOCTL_SEQ))
    {
        HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,"nCommonMsqInit() error");
        return -1;	
    }
    HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," load data success");
	
    return 0;
}
/**********************************************/
/* init glb var and copy databuf to glb var   */
/**********************************************/
/*
int  InitGlbVar(void *psDataBuf, short nInDataLen)
{
	char sTime[20];
	char sCnapsCode[20];
	
	memset(gsBrno, 0 ,sizeof(gsBrno));
	memset(&it_tita, 0 , sizeof(it_tita));
	memset(gsErrDesc, 0, sizeof(gsErrDesc));
	it_txcom.txrsut = TX_SUCCESS;
	it_txcom.rtncd = 0;
	
	memset(sCnapsCode, 0 , sizeof(sCnapsCode));
	memset(gsDBTxtime, 0 , sizeof(gsDBTxtime));
	memset(gsErrDesc, 0, sizeof(gsErrDesc));
	memset(sTime, 0, sizeof(sTime));
	
	if( nInDataLen > MAX_PACKET_LEN)
	{
		HtLog(logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,
				"InitGlbVar:nInDataLen error =[%d]", nInDataLen);
		return -1;
	}
	memcpy(&it_tita,  psDataBuf, nInDataLen);
	
	memcpy(gsBrno, it_tita.label.kinbr, DLEN_BRNO);
	
	cmGetWorkDate(gsBrno, gsDBTxdate, sCnapsCode, gsTBDate);

	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, sTime);
	memcpy(gsDBTxtime, sTime+8, 6);
		
	HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"gsDBTxdate=[%d],gsDBTxtime = [%s]", gsDBTxdate, gsDBTxtime);
}
*/

int  InitGlbVar(void *psDataBuf, short nInDataLen)
{
    char sTime[20],sCnapsCode[DLEN_LBRNO+1];
    
    memset(gsBrno, 0 ,sizeof(gsBrno));
    memset(&it_tita, 0 , sizeof(it_tita));
    memset(&it_totw, 0 , sizeof(it_totw));
    memset(gsDBTxdate, 0, sizeof(gsDBTxdate));
    memset(gsDBTxtime, 0 , sizeof(gsDBTxtime));
    
    memset(gsErrDesc, 0, sizeof(gsErrDesc));
    memset(sTime, 0, sizeof(sTime));
    
    it_txcom.txrsut = TX_SUCCESS;
    it_txcom.rtncd = 0;
    
    if ( nInDataLen > MAX_PACKET_LEN)
    {
        HtLog(  logfile, HT_LOG_MODE_ERR, __FILE__,__LINE__,"InitGlbVar:nInDataLen error =[%d]", nInDataLen);
        return -1;
    }
    
    HtDebugString(logfile,  psDataBuf, nInDataLen, __FILE__, __LINE__);
    memcpy(&it_tita,  psDataBuf, nInDataLen);  
    memcpy(gsBrno, it_tita.label.kinbr, DLEN_BRNO);
    
    #if 0
    cmGetWorkDate(gsBrno, gsDBTxdate, sCnapsCode, gsTBDate);
    #endif
    
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, sTime);
    //added by Jasmine 20100812 begin
    memcpy(gsDBTxdate, sTime, 8);
    //added by Jasmine 20100812 end
    memcpy(gsDBTxtime, sTime+8, 6);
    
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "gsDBTxdate=[%s], gsDBTxtime = [%s]", gsDBTxdate, gsDBTxtime);  

    TitaMoveTotaCommon(&it_tita.label, &it_totw.label);   

}  
void PrintTOTW()  
{
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"header      [%8.8s]  ",it_totw.label.header      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"clsno       [%6.6s]  ",it_totw.label.clsno       );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"termid      [%8.8s]  ",it_totw.label.termid      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"refssn      [%14.14s]",it_totw.label.refssn      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"kinbr       [%3.3s]  ",it_totw.label.kinbr       );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"trmseq      [%2.2s]  ",it_totw.label.trmseq      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"ejfno       [%7.7s]  ",it_totw.label.ejfno       );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"taskid      [%2.2s]  ",it_totw.label.taskid      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"txno        [%4.4s]  ",it_totw.label.txno        );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tlrno       [%8.8s]  ",it_totw.label.tlrno       );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tlsrno      [%7.7s]  ",it_totw.label.tlsrno      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tmtype      [%c]  ",it_totw.label.tmtype      );     
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"txdate      [%8.8s]  ",it_totw.label.txdate      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"txtime      [%6.6s]  ",it_totw.label.txtime      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msgend      [%c]  ",it_totw.label.msgend      );     
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msgtype     [%c]  ",it_totw.label.msgtype     );     
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msgno       [%4.4s]  ",it_totw.label.msgno       );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"msglng      [%4.4s]  ",it_totw.label.msglng      );  
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"process_flag[%c]  ",it_totw.label.process_flag);     
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"inq_id      [%8.8s]  ",it_totw.label.inq_id      );  

} 
void PrintTITA()
{
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"header   [%8.8s]  ",it_tita.label.header   ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"clsno    [%6.6s]  ",it_tita.label.clsno    ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"termid   [%8.8s]  ",it_tita.label.termid   ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"htrmseq  [%2.2s]  ",it_tita.label.htrmseq  ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"hejfno   [%7.7s]  ",it_tita.label.hejfno   ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"opnbr    [%3.3s]  ",it_tita.label.opnbr    ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"kinbr    [%3.3s]  ",it_tita.label.kinbr    ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"trmseq   [%2.2s]  ",it_tita.label.trmseq   ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"ejfno    [%7.7s]  ",it_tita.label.ejfno    ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"taskid   [%2.2s]  ",it_tita.label.taskid   ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tmtype   [%c]  ",it_tita.label.tmtype   );    
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"txno     [%4.4s]  ",it_tita.label.txno     ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"hcode    [%c]  ",it_tita.label.hcode    );    
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"supinit  [%2.2s]  ",it_tita.label.supinit  ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"tlrno    [%8.8s]  ",it_tita.label.tlrno    ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"sptlrno  [%8.8s]  ",it_tita.label.sptlrno  ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"otxtlrno [%8.8s]  ",it_tita.label.otxtlrno ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"otxtlsrno[%7.7s]  ",it_tita.label.otxtlsrno); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"passwd   [%8.8s]  ",it_tita.label.passwd   ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"nbcd     [%c]  ",it_tita.label.nbcd     );    
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"multtx   [%c]  ",it_tita.label.multtx   );    
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"multno   [%6.6s]  ",it_tita.label.multno   ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"ip_addr  [%15.15s]",it_tita.label.ip_addr  ); 
    HtLog(logfile,HT_LOG_MODE_COMPLEX,__FILE__,__LINE__,"inq_id   [%8.8s]  ",it_tita.label.inq_id   ); 

}


void HandleExit( )
{
    DbDisConnect ();
    HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "Info: Manager server exits!!");
    /*RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "HandleExit Error!" );*/
    exit(1);
}


