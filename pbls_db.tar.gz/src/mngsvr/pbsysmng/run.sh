make -f *mak
sleep 2
runpbsysmng
