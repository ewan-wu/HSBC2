/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1120(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1120_GROUP
	{
		char	actno	[32];
		char	type;
	} tis1120;
	static struct TOS1120_GROUP
	{
		char    name	[60];
		char    bankno	[12];
	} tos1120;

	/* work */
	struct wd_bacctmpl_area	wd_bacctmpl;

	memset(&tis1120, 0, sizeof(tis1120));
	memset(&tos1120, 0, sizeof(tos1120));

	memcpy(&tis1120, ptMngInBuf->sTitaText, sizeof(tis1120));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_bacctmpl, 0, sizeof(wd_bacctmpl));
	memcpy(wd_bacctmpl.actno, tis1120.actno, sizeof(wd_bacctmpl.actno)-1);
	wd_bacctmpl.type[0] = tis1120.type;
	if (DbsBACCTMPL(DBS_FIND, &wd_bacctmpl) == 0)
	{
		/* succeed */
		memcpy(tos1120.name, wd_bacctmpl.name, sizeof(tos1120.name));
		memcpy(tos1120.bankno, wd_bacctmpl.bankno, sizeof(tos1120.bankno));
		memcpy(ptMngOutBuf->sTotaText, &tos1120, sizeof(tos1120));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1120);
		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ�ʺ���Ϣ��¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
}


