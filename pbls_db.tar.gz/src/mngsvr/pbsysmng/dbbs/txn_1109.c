/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1109(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1109_GROUP
	{
		char        bank_code   	[  6];
		char        eis_site_code   [  5];
	} tis1109;
	static struct TOS1109_GROUP
	{
		char        bank_code   	[  6];
		char        eis_site_code   [  5];
		char        cnaps_flag;
		char        cbnk_code   	[ 12];
		char        status;
		char        cls_code    	[  3];
		char        city_code   	[  4];
		char        long_name   	[ 60];
		char        short_name  	[ 20];
		char        address 		[ 60];
		char        postcode    	[  6];
		char        telephone   	[ 30];
		char        email   		[ 30];
		char        eff_date    	[  8];
		char        inv_date    	[  8];
		char        alt_effdate 	[  8];
		char        alt_date    	[ 19];
		char        alt_type;
		char        alt_issno   	[  8];
		char        remark  		[ 60];
	} tos1109;

	/* work */
	struct wd_beisbank_area	wd_beisbank;

	memset(&tis1109, 0, sizeof(tis1109));
	memset(&tos1109, 0, sizeof(tos1109));

	memcpy(&tis1109, ptMngInBuf->sTitaText, sizeof(tis1109));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_beisbank, 0, sizeof(wd_beisbank));
	memcpy(wd_beisbank.bank_code, tis1109.bank_code, 
		sizeof(wd_beisbank.bank_code)-1);
	memcpy(wd_beisbank.eis_site_code, tis1109.eis_site_code, 
		sizeof(wd_beisbank.eis_site_code)-1);
	if (DbsBEISBANK(DBS_FIND, &wd_beisbank) == 0)
	{
		/* succeed */
		memcpy(tos1109.bank_code, wd_beisbank.bank_code, 
			sizeof(tos1109.bank_code));
		memcpy(tos1109.eis_site_code, wd_beisbank.eis_site_code, 
			sizeof(tos1109.eis_site_code));
		tos1109.cnaps_flag = wd_beisbank.cnaps_flag[0]; 
		memcpy(tos1109.cbnk_code, wd_beisbank.cbnk_code, 
			sizeof(tos1109.cbnk_code));
		tos1109.status = wd_beisbank.status[0]; 
		memcpy(tos1109.cls_code, wd_beisbank.cls_code, 
			sizeof(tos1109.cls_code));
		memcpy(tos1109.city_code, wd_beisbank.city_code, 
			sizeof(tos1109.city_code));
		memcpy(tos1109.long_name, wd_beisbank.long_name, 
			sizeof(tos1109.long_name));
		memcpy(tos1109.short_name, wd_beisbank.short_name, 
			sizeof(tos1109.short_name));
		memcpy(tos1109.address, wd_beisbank.address, 
			sizeof(tos1109.address));
		memcpy(tos1109.postcode, wd_beisbank.postcode, 
			sizeof(tos1109.postcode));
		memcpy(tos1109.telephone, wd_beisbank.telephone, 
			sizeof(tos1109.telephone));
		memcpy(tos1109.email, wd_beisbank.email, 
			sizeof(tos1109.email));
		memcpy(tos1109.eff_date, wd_beisbank.eff_date, 
			sizeof(tos1109.eff_date));
		memcpy(tos1109.inv_date, wd_beisbank.inv_date, 
			sizeof(tos1109.inv_date));
		memcpy(tos1109.alt_effdate, wd_beisbank.alt_effdate, 
			sizeof(tos1109.alt_effdate));
		memcpy(tos1109.alt_date, wd_beisbank.alt_date, 
			sizeof(tos1109.alt_date));
		tos1109.alt_type = wd_beisbank.alt_type[0]; 
		memcpy(tos1109.alt_issno, wd_beisbank.alt_issno, 
			sizeof(tos1109.alt_issno));
		memcpy(tos1109.remark, wd_beisbank.remark, 
			sizeof(tos1109.remark));

		memcpy(ptMngOutBuf->sTotaText, &tos1109, sizeof(tos1109));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1109);

		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEIS���д�����Ϣ��¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
}


