/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2020(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2020_GROUP
	{
		char	dept_id;
		char	tlr_id[8];
		char	new_pswd[12];
	} tis2020;
	static struct TOS2020_GROUP
	{
		char	tlr_name[40];
	} tos2020;

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_bsignlog_area	wd_bsignlog;
	char sPswd0[21];
	char sPswd1[21];
	int iRet;

	memset(&tis2020, 0, sizeof(tis2020));
	memset(&tos2020, 0, sizeof(tos2020));

	memcpy(&tis2020, ptMngInBuf->sTitaText, sizeof(tis2020));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	wd_btlrctl.dept_id[0] = tis2020.dept_id;
	memcpy(wd_btlrctl.tlr_id, tis2020.tlr_id, sizeof(wd_btlrctl.tlr_id)-1);

	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) == 0)
	{
		/* succeed */
		if (wd_btlrctl.work_flag[0] == BTLRCTL_WORK_FLAG_OFF)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������ʧ�ܣ��ò���Ա���ɹ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
		/* check password duplicated */
		memset(sPswd0, 0, sizeof(sPswd0));
		memcpy(sPswd0, tis2020.new_pswd, sizeof(tis2020.new_pswd));
		memset(sPswd1, ' ', sizeof(sPswd1));
		memcpy(sPswd1, sPswd0, strlen(sPswd0));
		sPswd1[sizeof(wd_btlrctl.password)-1] = 0;
		if (CheckPasswordDuplicate(sPswd1, wd_btlrctl.recent_pswd_str) != 0)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9529", 4);
			{
			char sError[256];
			strcpy(sError, "������ʧ�ܣ�����Ա������������ʷ��¼�ظ���");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "������ʧ�ܣ��Ƿ��Ĳ���Ա��");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	memcpy(wd_btlrctl.password, tis2020.new_pswd, sizeof(tis2020.new_pswd));
	GetCurrentDateAll(GET_CURRENT_DATE_FLAG_ICBC, wd_btlrctl.last_pswd_chg);
	wd_btlrctl.init_flag[0] = BTLRCTL_INIT_FLAG_OFF;
	CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
	memset(sPswd0, 0, sizeof(sPswd0));
	memcpy(sPswd0, tis2020.new_pswd, sizeof(tis2020.new_pswd));
	memset(sPswd1, ' ', sizeof(sPswd1));
	memcpy(sPswd1, sPswd0, strlen(sPswd0));
	RecordRecentPswdStr(sPswd1, wd_btlrctl.recent_pswd_str);
	if (DbsBTLRCTL(DBS_IUPD, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "������ʧ�ܣ����²���Ա����ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
	else
	{
		/* succeed */

		/* log operator password change */
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));
		wd_bsignlog.dept_id[0] = tis2020.dept_id;
		memcpy(wd_bsignlog.tlr_id, tis2020.tlr_id, sizeof(tis2020.tlr_id));
		CommonGetCurrentTimeDB(wd_bsignlog.act_time);
		wd_bsignlog.act_type[0] = BSIGNLOG_ACTION_TYPE_CHGPSWD;
		memcpy(wd_bsignlog.act_data, 
			tis2020.new_pswd, sizeof(tis2020.new_pswd));
		CommonGetCurrentTimeDB(wd_bsignlog.rec_updt_time);

		if (DbsBSIGNLOG(DBS_INSERT, &wd_bsignlog) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������ʧ�ܣ���¼����Ա��־ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
		else
		{
			/* succeed */
			memcpy(tos2020.tlr_name, wd_btlrctl.tlr_name, sizeof(tos2020.tlr_name));
			memcpy(ptMngOutBuf->sTotaText, &tos2020, sizeof(tos2020));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2020);

			return;
		}
	}
}


