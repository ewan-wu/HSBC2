/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1108(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1108_GROUP
	{
		char	bank_code[12];
	} tis1108;
	static struct TOS1108_GROUP
	{
		char	bank_code	[ 12];
		char    status;
		char    category    [  2];
		char    cls_code    [  3];
		char    dre_code    [ 12];
		char    node_code   [  4];
		char    supr_list   [130];
		char    pbc_code    [ 12];
		char    city_code   [  4];
		char    acct_status;
		char    asalt_date  [  8];
		char    asalt_time  [ 14];
		char    long_name   [ 60];
		char    short_name  [ 20];
		char    address 	[ 60];
		char    postcode    [  6];
		char    telephone   [ 30];
		char    email   	[ 30];
		char    eff_date    [  8];
		char    inv_date    [  8];
		char    alt_date    [ 19];
		char    alt_type;
		char    alt_issno   [  8];
		char    remark  	[ 60];
	} tos1108;

	/* work */
	struct wd_bcnapsbank_area	wd_bcnapsbank;

	memset(&tis1108, 0, sizeof(tis1108));
	memset(&tos1108, 0, sizeof(tos1108));

	memcpy(&tis1108, ptMngInBuf->sTitaText, sizeof(tis1108));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_bcnapsbank, 0, sizeof(wd_bcnapsbank));
	memcpy(wd_bcnapsbank.bank_code, tis1108.bank_code, 
		sizeof(wd_bcnapsbank.bank_code)-1);
	if (DbsBCNAPSBANK(DBS_FIND, &wd_bcnapsbank) == 0)
	{
		/* succeed */
		memcpy(tos1108.bank_code, wd_bcnapsbank.bank_code, 
			sizeof(tos1108.bank_code));
		tos1108.status = wd_bcnapsbank.status[0]; 
		memcpy(tos1108.category, wd_bcnapsbank.category, 
			sizeof(tos1108.category));
		memcpy(tos1108.cls_code, wd_bcnapsbank.cls_code, 
			sizeof(tos1108.cls_code));
		memcpy(tos1108.dre_code, wd_bcnapsbank.dre_code, 
			sizeof(tos1108.dre_code));
		memcpy(tos1108.node_code, wd_bcnapsbank.node_code, 
			sizeof(tos1108.node_code));
		memcpy(tos1108.supr_list, wd_bcnapsbank.supr_list, 
			sizeof(tos1108.supr_list));
		memcpy(tos1108.pbc_code, wd_bcnapsbank.pbc_code, 
			sizeof(tos1108.pbc_code));
		memcpy(tos1108.city_code, wd_bcnapsbank.city_code, 
			sizeof(tos1108.city_code));
		tos1108.acct_status = wd_bcnapsbank.acct_status[0]; 
		memcpy(tos1108.asalt_date, wd_bcnapsbank.asalt_date, 
			sizeof(tos1108.asalt_date));
		memcpy(tos1108.asalt_time, wd_bcnapsbank.asalt_time, 
			sizeof(tos1108.asalt_time));
		memcpy(tos1108.long_name, wd_bcnapsbank.long_name, 
			sizeof(tos1108.long_name));
		memcpy(tos1108.short_name, wd_bcnapsbank.short_name, 
			sizeof(tos1108.short_name));
		memcpy(tos1108.address, wd_bcnapsbank.address, 
			sizeof(tos1108.address));
		memcpy(tos1108.postcode, wd_bcnapsbank.postcode, 
			sizeof(tos1108.postcode));
		memcpy(tos1108.telephone, wd_bcnapsbank.telephone, 
			sizeof(tos1108.telephone));
		memcpy(tos1108.email, wd_bcnapsbank.email, 
			sizeof(tos1108.email));
		memcpy(tos1108.eff_date, wd_bcnapsbank.eff_date, 
			sizeof(tos1108.eff_date));
		memcpy(tos1108.inv_date, wd_bcnapsbank.inv_date, 
			sizeof(tos1108.inv_date));
		memcpy(tos1108.alt_date, wd_bcnapsbank.alt_date, 
			sizeof(tos1108.alt_date));
		tos1108.alt_type = wd_bcnapsbank.alt_type[0]; 
		memcpy(tos1108.alt_issno, wd_bcnapsbank.alt_issno, 
			sizeof(tos1108.alt_issno));
		memcpy(tos1108.remark, wd_bcnapsbank.remark, 
			sizeof(tos1108.remark));

		memcpy(ptMngOutBuf->sTotaText, &tos1108, sizeof(tos1108));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1108);

		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS���д�����Ϣ��¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
}


