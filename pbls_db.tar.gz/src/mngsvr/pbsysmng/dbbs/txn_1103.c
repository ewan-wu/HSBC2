/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1103(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1103_GROUP
	{
		char	resend[4];
	} tis1103;
	static struct TOS1103_GROUP
	{
		char	resend[4];
		char	cnt[2];
		struct
		{
			char	city_code[4];
			char	city_name[20];
			char	city_type;
			char	city_memo[60];
		} dtl[MAX_REC];
	} tos1103;

	/* work */
	char	sResend[4+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bcitycode_area wd_bcitycode;

	memset(&tis1103, 0, sizeof(tis1103));
	memset(&tos1103, 0, sizeof(tos1103));
	memset(sResend, 0, sizeof(sResend));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1103, ptMngInBuf->sTitaText, sizeof(tis1103));
	memcpy(sResend, tis1103.resend, sizeof(tos1103.resend));

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1103 cursor for select ");
	dbfcmd(dbproc, "city_code, city_name, city_type, city_memo ");
	dbfcmd(dbproc, "from BCITYCODE ");
	dbfcmd(dbproc, "where city_code > '%s' ", sResend);
	dbfcmd(dbproc, "order by city_code ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS���д����б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1103 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS���д����б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1103 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bcitycode, 0, sizeof(wd_bcitycode));

		dbcmd(dbproc, "fetch cur_1103 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯCNAPS���д����б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1103 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1103 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bcitycode.city_code));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bcitycode.city_name));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_bcitycode.city_type));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_bcitycode.city_memo));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		memcpy(tos1103.dtl[i].city_code, wd_bcitycode.city_code, 4);
		memcpy(tos1103.dtl[i].city_name, wd_bcitycode.city_name, 20);
		tos1103.dtl[i].city_type = wd_bcitycode.city_type[0]; 
		memcpy(tos1103.dtl[i].city_memo, wd_bcitycode.city_memo, 60);
	}

	dbcmd(dbproc, "close cur_1103 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS���д����б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1103 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS���д����б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1103.cnt, sCnt, 2);
	memcpy(tos1103.resend, wd_bcitycode.city_code, 4);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1103, sizeof(tos1103));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1103);

	return;
}


