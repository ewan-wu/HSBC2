/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1006(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1006_GROUP
	{
		char	usr_id[6];
	} tis1006;
	static struct TOS1006_GROUP
	{
		char	usr_id[6];
		char	usr_name[20];
		char	work_flag;
		char	work_level;
		char	status;
		char	last_status_chg[8];
		char	last_pswd_chg[8];
	} tos1006;

	/* work */
	struct wd_bcusrctl_area	wd_bcusrctl;

	memset(&tis1006, 0, sizeof(tis1006));
	memset(&tos1006, 0, sizeof(tos1006));

	memcpy(&tis1006, ptMngInBuf->sTitaText, sizeof(tis1006));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_bcusrctl, 0, sizeof(wd_bcusrctl));
	memcpy(wd_bcusrctl.usr_id, tis1006.usr_id, sizeof(wd_bcusrctl.usr_id)-1);
	if (DbsBCUSRCTL(DBS_FIND, &wd_bcusrctl) == 0)
	{
		/* succeed */
		tos1006.work_flag = wd_bcusrctl.work_flag[0]; 
		tos1006.work_level = wd_bcusrctl.work_level[0]; 
		tos1006.status = wd_bcusrctl.status[0]; 
		memcpy(tos1006.usr_id, wd_bcusrctl.usr_id, sizeof(tos1006.usr_id));
		memcpy(tos1006.usr_name, wd_bcusrctl.usr_name, 
			sizeof(tos1006.usr_name));
		memcpy(tos1006.last_status_chg, wd_bcusrctl.last_status_chg, 
			sizeof(tos1006.last_status_chg));
		memcpy(tos1006.last_pswd_chg, wd_bcusrctl.last_pswd_chg, 
			sizeof(tos1006.last_pswd_chg));
		
		memcpy(ptMngOutBuf->sTotaText, &tos1006, sizeof(tos1006));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1006);

		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����̨�û���¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}

		return;
	}
}


