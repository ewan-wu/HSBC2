/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1101(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1101_GROUP
	{
		char	resend[4];
	} tis1101;
	static struct TOS1101_GROUP
	{
		char	resend[4];
		char	cnt[2];
		struct
		{
			char	node_code[4];
			char	node_name[20];
			char	node_type;
			char	city_code[4];
			char	node_id[32];
			char	valid_date[8];
			char	expire_date[8];
			char	node_memo[60];
		} dtl[MAX_REC];
	} tos1101;

	/* work */
	char	sResend[4+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bpsnode_area wd_bpsnode;

	memset(&tis1101, 0, sizeof(tis1101));
	memset(&tos1101, 0, sizeof(tos1101));
	memset(sResend, 0, sizeof(sResend));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1101, ptMngInBuf->sTitaText, sizeof(tis1101));
	memcpy(sResend, tis1101.resend, sizeof(tos1101.resend));

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1101 cursor for select ");
	dbfcmd(dbproc, "node_code, node_name, node_type, city_code, ");
	dbfcmd(dbproc, "node_id, valid_date, expire_date, node_memo ");
	dbfcmd(dbproc, "from BPSNODE ");
	dbfcmd(dbproc, "where node_code > '%s' ", sResend);
	dbfcmd(dbproc, "order by node_code ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS֧���ڵ��б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1101 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS֧���ڵ��б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1101 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bpsnode, 0, sizeof(wd_bpsnode));

		dbcmd(dbproc, "fetch cur_1101 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯCNAPS֧���ڵ��б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1101 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1101 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.node_code));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.node_name));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.node_type));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.city_code));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.node_id));
		dbbind(dbproc, 6, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.valid_date));
		dbbind(dbproc, 7, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.expire_date));
		dbbind(dbproc, 8, CHARBIND, (DBINT)0, (BYTE *)(wd_bpsnode.node_memo));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		memcpy(tos1101.dtl[i].node_code, wd_bpsnode.node_code, 4);
		memcpy(tos1101.dtl[i].node_name, wd_bpsnode.node_name, 20);
		tos1101.dtl[i].node_type = wd_bpsnode.node_type[0]; 
		memcpy(tos1101.dtl[i].city_code, wd_bpsnode.city_code, 4);
		memcpy(tos1101.dtl[i].node_id, wd_bpsnode.node_id, 32);
		memcpy(tos1101.dtl[i].valid_date, wd_bpsnode.valid_date, 8);
		memcpy(tos1101.dtl[i].expire_date, wd_bpsnode.expire_date, 8);
		memcpy(tos1101.dtl[i].node_memo, wd_bpsnode.node_memo, 60);
	}

	dbcmd(dbproc, "close cur_1101 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS֧���ڵ��б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1101 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS֧���ڵ��б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1101.cnt, sCnt, 2);
	memcpy(tos1101.resend, wd_bpsnode.node_code, 4);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1101, sizeof(tos1101));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1101);

	return;
}


