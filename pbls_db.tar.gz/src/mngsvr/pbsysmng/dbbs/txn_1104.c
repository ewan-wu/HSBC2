/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1104(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1104_GROUP
	{
		char	bank_code[12];
		char	long_name[60];
		char	address[60];
		char	resend[12];
	} tis1104;
	static struct TOS1104_GROUP
	{
		char	resend[12];
		char	cnt[2];
		struct
		{
			char	bank_code[12];
			char	long_name[60];
			char	postcode[6];
			char	address[60];
			char	dre_code[12];
			char	flag;
		} dtl[MAX_REC];
	} tos1104;

	/* work */
	char	sResend[12+1];
	char	sBankCode[12+2+1];
	char	sLongName[60+2+1];
	char	sAddress[60+2+1];
	char	sCnt[2+1];
	char	sDate0[8+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bcnapsbank_area wd_bcnapsbank;
	struct wd_bsysctl_area wd_bsysctl;

	memset(&tis1104, 0, sizeof(tis1104));
	memset(&tos1104, 0, sizeof(tos1104));
	memset(sResend, 0, sizeof(sResend));
	memset(sBankCode, 0, sizeof(sBankCode));
	memset(sLongName, 0, sizeof(sLongName));
	memset(sAddress, 0, sizeof(sAddress));
	memset(sCnt, 0, sizeof(sCnt));
	memset(sDate0, 0, sizeof(sDate0));

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
	{
		/* succeed */
		memcpy(sDate0, wd_bsysctl.work_date, 8); 
	}
	else
	{
		memcpy(sDate0, "00000000", 8); 
	}

	memcpy(&tis1104, ptMngInBuf->sTitaText, sizeof(tis1104));
	memcpy(sResend, tis1104.resend, sizeof(tos1104.resend));

	strcat(sBankCode, "%");
	memcpy(sBankCode+1, tis1104.bank_code, sizeof(tis1104.bank_code));
	for (i=1; i<13; i++)
		if (sBankCode[i] == ' ')
		{
			sBankCode[i] = '\0';
			break;
		}
	strcat(sBankCode, "%");

	strcat(sLongName, "%");
	memcpy(sLongName+1, tis1104.long_name, sizeof(tis1104.long_name));
	for (i=1; i<61; i++)
		if (sLongName[i] == ' ')
		{
			sLongName[i] = '\0';
			break;
		}
	strcat(sLongName, "%");

	strcat(sAddress, "%");
	memcpy(sAddress+1, tis1104.address, sizeof(tis1104.address));
	for (i=1; i<61; i++)
		if (sAddress[i] == ' ')
		{
			sAddress[i] = '\0';
			break;
		}
	strcat(sAddress, "%");

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1104 cursor for select ");
	dbfcmd(dbproc, "bank_code, long_name, postcode, address, dre_code, ");
	dbfcmd(dbproc, "eff_date, inv_date ");
	dbfcmd(dbproc, "from BCNAPSBANK ");
	dbfcmd(dbproc, "where bank_code > '%s' ", sResend);
	if (strcmp(sBankCode, "%%") != 0)
	{
		dbfcmd(dbproc, "and bank_code like '%s' ", sBankCode);
	}
	if (strcmp(sLongName, "%%") != 0)
	{
		dbfcmd(dbproc, "and long_name like '%s' ", sLongName);
	}
	if (strcmp(sAddress, "%%") != 0)
	{
		dbfcmd(dbproc, "and address like '%s' ", sAddress);
	}
	dbfcmd(dbproc, "order by bank_code ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS�к��б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1104 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS�к��б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1104 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bcnapsbank, 0, sizeof(wd_bcnapsbank));

		dbcmd(dbproc, "fetch cur_1104 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯCNAPS�к��б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1104 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1104 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bcnapsbank.bank_code));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bcnapsbank.long_name));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_bcnapsbank.postcode));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_bcnapsbank.address));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_bcnapsbank.dre_code));
		dbbind(dbproc, 6, CHARBIND, (DBINT)0, (BYTE *)(wd_bcnapsbank.eff_date));
		dbbind(dbproc, 7, CHARBIND, (DBINT)0, (BYTE *)(wd_bcnapsbank.inv_date));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		memcpy(tos1104.dtl[i].bank_code, wd_bcnapsbank.bank_code, 12);
		memcpy(tos1104.dtl[i].long_name, wd_bcnapsbank.long_name, 60);
		memcpy(tos1104.dtl[i].postcode, wd_bcnapsbank.postcode, 6);
		memcpy(tos1104.dtl[i].address, wd_bcnapsbank.address, 60);
		memcpy(tos1104.dtl[i].dre_code, wd_bcnapsbank.dre_code, 12);
		if (memcmp(sDate0, "00000000", 8) == 0)
		{
			tos1104.dtl[i].flag = '0';
		}
		else
		{
			if ((memcmp(sDate0, wd_bcnapsbank.eff_date, 8) < 0) ||
				(memcmp(sDate0, wd_bcnapsbank.inv_date, 8) >= 0))
			{
				if (memcmp(sDate0, wd_bcnapsbank.eff_date, 8) < 0)
					tos1104.dtl[i].flag = '1';
				if (memcmp(sDate0, wd_bcnapsbank.inv_date, 8) >= 0)
					tos1104.dtl[i].flag = '2';
			}
			else
			{
				tos1104.dtl[i].flag = '0';
			}
		}
	}

	dbcmd(dbproc, "close cur_1104 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS�к��б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1104 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS�к��б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1104.cnt, sCnt, 2);
	memcpy(tos1104.resend, wd_bcnapsbank.bank_code, 12);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1104, sizeof(tos1104));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1104);

	return;
}


