/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1011(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1011_GROUP
	{
		char	dept_id;
		char	tlr_id[8];
		char	date1[10];
		char	date2[10];
		char	resend[29];
	} tis1011;
	static struct TOS1011_GROUP
	{
		char	resend[29];
		char	cnt[2];
		struct
		{
			char	dept_id;
			char	tlr_id[8];
			char	act_time[19];
			char	act_type;
			char	act_data[60];
		} dtl[MAX_REC];
	} tos1011;

	/* work */
	char	sResend[29+1];
	char	sDeptId[1+1];
	char	sTlrId[8+1];
	char	sCnt[2+1];
	char	sDate1[10+1];
	char	sDate2[10+2];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bsignlog_area wd_bsignlog;

	memset(&tis1011, 0, sizeof(tis1011));
	memset(&tos1011, 0, sizeof(tos1011));
	memset(sResend, 0, sizeof(sResend));
	memset(sDeptId, 0, sizeof(sDeptId));
	memset(sTlrId, 0, sizeof(sTlrId));
	memset(sCnt, 0, sizeof(sCnt));
	memset(sDate1, 0, sizeof(sDate1));
	memset(sDate2, 0, sizeof(sDate2));

	memcpy(&tis1011, ptMngInBuf->sTitaText, sizeof(tis1011));
	memcpy(sResend, tis1011.resend, 24);
	sDeptId[0] = tis1011.dept_id;
	memcpy(sTlrId, tis1011.tlr_id, 8);
	memcpy(sDate1, tis1011.date1, 10);
	memcpy(sDate2, tis1011.date2, 10);

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1011 cursor for select ");
	dbfcmd(dbproc, "dept_id, tlr_id, act_time, act_type, act_data ");
	dbfcmd(dbproc, "from BSIGNLOG ");
	dbfcmd(dbproc, "where dept_id+tlr_id+act_time+act_type > '%s' ",
		sResend);
	dbfcmd(dbproc, "and dept_id = '%s' ", sDeptId);
	dbfcmd(dbproc, "and tlr_id = '%s' ", sTlrId);

	if (sDate1[0] == ' ' || sDate1[0] == '\0')
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) >= '1900/01/01' ");
	}
	else
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) >= '%s' ", sDate1);
	}

	if (sDate2[0] == ' ' || sDate2[0] == '\0')
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) <= '3999/12/31' ");
	}
	else
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) <= '%s' ", sDate2);
	}

	dbfcmd(dbproc, "order by dept_id, tlr_id, act_time, act_type ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա������־��¼������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1011 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա������־��¼�����������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1011 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));

		dbcmd(dbproc, "fetch cur_1011 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯ����Ա������־��¼��������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1011 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1011 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bsignlog.dept_id));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bsignlog.tlr_id));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_bsignlog.act_time));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_bsignlog.act_type));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_bsignlog.act_data));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		tos1011.dtl[i].dept_id = wd_bsignlog.dept_id[0]; 
		memcpy(tos1011.dtl[i].tlr_id, wd_bsignlog.tlr_id, 8);
		memcpy(tos1011.dtl[i].act_time, wd_bsignlog.act_time, 19);
		tos1011.dtl[i].act_type = wd_bsignlog.act_type[0];
		memcpy(tos1011.dtl[i].act_data, wd_bsignlog.act_data, 60);
	}

	dbcmd(dbproc, "close cur_1011 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա������־��¼�������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1011 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա������־��¼�������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1011.cnt, sCnt, 2);
	memcpy(tos1011.resend, wd_bsignlog.dept_id, 1);
	memcpy(tos1011.resend+1, wd_bsignlog.tlr_id, 8);
	memcpy(tos1011.resend+1+8, wd_bsignlog.act_time, 19);
	memcpy(tos1011.resend+1+8+19, wd_bsignlog.act_type, 1);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1011, sizeof(tos1011));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1011);

	return;
}


