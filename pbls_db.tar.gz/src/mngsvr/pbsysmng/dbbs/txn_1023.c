/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1023(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1023_GROUP
	{
		char	resend[6];
	} tis1023;
	static struct TOS1023_GROUP
	{
		char	resend[6];
		char	cnt[2];
		struct
		{
			char	line_code[6];
			char	line_desc[40];
			char	line_status;
			char	last_sts_chg[19];
			char	line_cfg_data[60];
		} dtl[MAX_REC];
	} tos1023;

	/* work */
	char	sResend[6+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_blinectl_area wd_blinectl;

	memset(&tis1023, 0, sizeof(tis1023));
	memset(&tos1023, 0, sizeof(tos1023));
	memset(sResend, 0, sizeof(sResend));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1023, ptMngInBuf->sTitaText, sizeof(tis1023));
	memcpy(sResend, tis1023.resend, sizeof(tis1023.resend));

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1023 cursor for select ");
	dbfcmd(dbproc, "line_code, line_desc, line_status, ");
	dbfcmd(dbproc, "last_sts_chg, line_cfg_data ");
	dbfcmd(dbproc, "from BLINECTL ");
	dbfcmd(dbproc, "where convert(char(6), line_code) > '%s' ", sResend);
	dbfcmd(dbproc, "order by convert(char(6), line_code) ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ��·�б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1023 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ��·�б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1023 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_blinectl, 0, sizeof(wd_blinectl));

		dbcmd(dbproc, "fetch cur_1023 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯ��·�б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1023 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1023 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, INTBIND, (DBINT)0, (BYTE *)&(wd_blinectl.line_code));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_blinectl.line_desc));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_blinectl.line_status));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_blinectl.last_sts_chg));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_blinectl.line_cfg_data));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		{
		char	sTemp[7];
		sprintf(sTemp, "%d", wd_blinectl.line_code);
		memset(tos1023.dtl[i].line_code, ' ', 6);
		memcpy(tos1023.dtl[i].line_code, sTemp, strlen(sTemp));
		}
		memcpy(tos1023.dtl[i].line_desc, wd_blinectl.line_desc, 40);
		tos1023.dtl[i].line_status = wd_blinectl.line_status[0]; 
		memcpy(tos1023.dtl[i].last_sts_chg, wd_blinectl.last_sts_chg, 19);
		memcpy(tos1023.dtl[i].line_cfg_data, wd_blinectl.line_cfg_data, 60);
	}

	dbcmd(dbproc, "close cur_1023 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ��·�б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1023 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ��·�б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1023.cnt, sCnt, 2);
	memset(tos1023.resend, ' ', sizeof(tos1023.resend));
	{
	char sTemp[7];
	sprintf(sTemp, "%d", wd_blinectl.line_code);
	memcpy(tos1023.resend, sTemp, strlen(sTemp));
	}

	memcpy(ptMngOutBuf->sTotaText, &tos1023, sizeof(tos1023));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1023);

	return;
}


