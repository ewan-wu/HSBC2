/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1105(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1105_GROUP
	{
		char	bank_code[6];
		char	long_name[60];
		char	address[60];
		char	eis_site_code[5];
		char	short_name[20];
		char	resend[11];
	} tis1105;
	static struct TOS1105_GROUP
	{
		char	resend[11];
		char	cnt[2];
		struct
		{
			char	bank_code[6];
			char	long_name[60];
			char	address[60];
			char	postcode[6];
			char	eis_site_code[5];
			char	short_name[20];
			char	cnaps_flag;
			char	cbnk_code[12];
			char	flag;
		} dtl[MAX_REC];
	} tos1105;

	/* work */
	char	sResend[12+1];
	char	sBankCode[6+2+1];
	char	sEisSiteCode[5+2+1];
	char	sLongName[60+2+1];
	char	sAddress[60+2+1];
	char	sShortName[20+2+1];
	char	sCnt[2+1];
	char	sDate0[8+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_beisbank_area wd_beisbank;
	struct wd_bsysctl_area wd_bsysctl;

	memset(&tis1105, 0, sizeof(tis1105));
	memset(&tos1105, 0, sizeof(tos1105));
	memset(sResend, 0, sizeof(sResend));
	memset(sBankCode, 0, sizeof(sBankCode));
	memset(sLongName, 0, sizeof(sLongName));
	memset(sAddress, 0, sizeof(sAddress));
	memset(sEisSiteCode, 0, sizeof(sEisSiteCode));
	memset(sShortName, 0, sizeof(sShortName));
	memset(sCnt, 0, sizeof(sCnt));
	memset(sDate0, 0, sizeof(sDate0));

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
	{
		/* succeed */
		memcpy(sDate0, wd_bsysctl.work_date, 8); 
	}
	else
	{
		memcpy(sDate0, "00000000", 8); 
	}

	memcpy(&tis1105, ptMngInBuf->sTitaText, sizeof(tis1105));
	memcpy(sResend, tis1105.resend, sizeof(tis1105.resend));
	sResend[6] = 0;

	strcat(sBankCode, "%");
	memcpy(sBankCode+1, tis1105.bank_code, sizeof(tis1105.bank_code));
	for (i=1; i<7; i++)
		if (sBankCode[i] == ' ')
		{
			sBankCode[i] = '\0';
			break;
		}
	strcat(sBankCode, "%");

	strcat(sLongName, "%");
	memcpy(sLongName+1, tis1105.long_name, sizeof(tis1105.long_name));
	for (i=1; i<61; i++)
		if (sLongName[i] == ' ')
		{
			sLongName[i] = '\0';
			break;
		}
	strcat(sLongName, "%");

	strcat(sAddress, "%");
	memcpy(sAddress+1, tis1105.address, sizeof(tis1105.address));
	for (i=1; i<61; i++)
		if (sAddress[i] == ' ')
		{
			sAddress[i] = '\0';
			break;
		}
	strcat(sAddress, "%");

	strcat(sEisSiteCode, "%");
	memcpy(sEisSiteCode+1, tis1105.eis_site_code, sizeof(tis1105.eis_site_code));
	for (i=1; i<6; i++)
		if (sEisSiteCode[i] == ' ')
		{
			sEisSiteCode[i] = '\0';
			break;
		}
	strcat(sEisSiteCode, "%");

	strcat(sShortName, "%");
	memcpy(sShortName+1, tis1105.short_name, sizeof(tis1105.short_name));
	for (i=1; i<21; i++)
		if (sShortName[i] == ' ')
		{
			sShortName[i] = '\0';
			break;
		}
	strcat(sShortName, "%");

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1105 cursor for select ");
	dbfcmd(dbproc, "bank_code, eis_site_code, long_name, ");
	dbfcmd(dbproc, "short_name, postcode, address, cnaps_flag, cbnk_code, ");
	dbfcmd(dbproc, "eff_date, inv_date ");
	dbfcmd(dbproc, "from BEISBANK ");
	/*
	dbfcmd(dbproc, "where bank_code+eis_site_code > '%s' ", sResend);
	*/
	dbfcmd(dbproc, "where bank_code > '%s' ", sResend);
	if (strcmp(sBankCode, "%%") != 0)
	{
		dbfcmd(dbproc, "and bank_code like '%s' ", sBankCode);
	}
	if (strcmp(sLongName, "%%") != 0)
	{
		dbfcmd(dbproc, "and long_name like '%s' ", sLongName);
	}
	if (strcmp(sAddress, "%%") != 0)
	{
		dbfcmd(dbproc, "and address like '%s' ", sAddress);
	}
	if (strcmp(sShortName, "%%") != 0)
	{
		dbfcmd(dbproc, "and short_name like '%s' ", sShortName);
	}
	if (strcmp(sEisSiteCode, "%%") != 0)
	{
		dbfcmd(dbproc, "and eis_site_code like '%s' ", sEisSiteCode);
	}
	/*
	dbfcmd(dbproc, "order by bank_code, eis_site_code ");
	*/
	dbfcmd(dbproc, "order by bank_code ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEIS�к��б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1105 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEIS�к��б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1105 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_beisbank, 0, sizeof(wd_beisbank));

		dbcmd(dbproc, "fetch cur_1105 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯEIS�к��б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1105 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1105 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.bank_code));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.eis_site_code));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.long_name));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.short_name));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.postcode));
		dbbind(dbproc, 6, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.address));
		dbbind(dbproc, 7, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.cnaps_flag));
		dbbind(dbproc, 8, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.cbnk_code));
		dbbind(dbproc, 9, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.eff_date));
		dbbind(dbproc, 10, CHARBIND, (DBINT)0, (BYTE *)(wd_beisbank.inv_date));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		memcpy(tos1105.dtl[i].bank_code, wd_beisbank.bank_code, 6);
		memcpy(tos1105.dtl[i].eis_site_code, wd_beisbank.eis_site_code, 5);
		memcpy(tos1105.dtl[i].long_name, wd_beisbank.long_name, 60);
		memcpy(tos1105.dtl[i].short_name, wd_beisbank.short_name, 20);
		memcpy(tos1105.dtl[i].postcode, wd_beisbank.postcode, 6);
		memcpy(tos1105.dtl[i].address, wd_beisbank.address, 60);
		tos1105.dtl[i].cnaps_flag = wd_beisbank.cnaps_flag[0];
		memcpy(tos1105.dtl[i].cbnk_code, wd_beisbank.cbnk_code, 12);

		if (memcmp(sDate0, "00000000", 8) == 0)
		{
			tos1105.dtl[i].flag = '0';
		}
		else
		{
			if ((memcmp(sDate0, wd_beisbank.eff_date, 8) < 0) ||
				(memcmp(sDate0, wd_beisbank.inv_date, 8) >= 0))
			{
				if (memcmp(sDate0, wd_beisbank.eff_date, 8) < 0)
					tos1105.dtl[i].flag = '1';
				if (memcmp(sDate0, wd_beisbank.inv_date, 8) >= 0)
					tos1105.dtl[i].flag = '2';
			}
			else
			{
				tos1105.dtl[i].flag = '0';
			}
		}
	}

	dbcmd(dbproc, "close cur_1105 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEIS�к��б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1105 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEIS�к��б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1105.cnt, sCnt, 2);
	memcpy(tos1105.resend, wd_beisbank.bank_code, 6);
	memcpy(tos1105.resend+6, wd_beisbank.eis_site_code, 5);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1105, sizeof(tos1105));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1105);

	return;
}


