/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1119(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1119_GROUP
	{
		char        bank_code   	[  6];
	} tis1119;
	static struct TOS1119_GROUP
	{
		char        long_name   	[ 60];
		char        short_name  	[ 20];
		char		eis_site_code	[  5];
	} tos1119;

	/* work */
	struct wd_beisbank_area	wd_beisbank;
	struct wd_bsysctl_area wd_bsysctl;
	char    sDate0[8+1];

	memset(&tis1119, 0, sizeof(tis1119));
	memset(&tos1119, 0, sizeof(tos1119));

	memcpy(&tis1119, ptMngInBuf->sTitaText, sizeof(tis1119));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_beisbank, 0, sizeof(wd_beisbank));
	memcpy(wd_beisbank.bank_code, tis1119.bank_code, 
		sizeof(wd_beisbank.bank_code)-1);
	if (DbsBEISBANK(DBS_FIND, &wd_beisbank) == 0)
	{
		/* succeed */
		memcpy(tos1119.long_name, wd_beisbank.long_name, 
			sizeof(tos1119.long_name));
		memcpy(tos1119.short_name, wd_beisbank.short_name, 
			sizeof(tos1119.short_name));
		memcpy(tos1119.eis_site_code, wd_beisbank.eis_site_code, 
			sizeof(tos1119.eis_site_code));

		if (wd_beisbank.cnaps_flag[0] == 'N')
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѡ��������Ѽ���CNAPS,��ʹ��CNAPS����!");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}

		memset(sDate0, 0, sizeof(sDate0));
		memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
		memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
		if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
		{
			memcpy(sDate0, wd_bsysctl.work_date, 8);
		}
		else
		{
			memcpy(sDate0, "00000000", 8);
		}

		if (memcmp(sDate0, "00000000", 8) != 0)
		{
			if ((memcmp(sDate0, wd_beisbank.eff_date, 8) < 0) ||
				(memcmp(sDate0, wd_beisbank.inv_date, 8) >= 0))
			{
				if (memcmp(sDate0, wd_beisbank.eff_date, 8) < 0)
				{
					/* fail */
					ptMngOutBuf->tTotaLabel.msgtype = 'E';
					memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
					{
					char sError[256];
					strcpy(sError, "�����д�����δ��Ч��");
					memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
					*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
					}
					return;
				}
				if (memcmp(sDate0, wd_beisbank.inv_date, 8) >= 0)
				{
					/* fail */
					ptMngOutBuf->tTotaLabel.msgtype = 'E';
					memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
					{
					char sError[256];
					strcpy(sError, "�����д�����ʧЧ��");
					memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
					*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
					}
					return;
				}
			}
		}

		memcpy(ptMngOutBuf->sTotaText, &tos1119, sizeof(tos1119));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1119);
		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEIS���д�����Ϣ��¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
}


