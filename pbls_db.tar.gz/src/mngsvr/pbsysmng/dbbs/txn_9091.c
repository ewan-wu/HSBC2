/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_9091(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS9091_GROUP
	{
		char	filename[60];
	} tis9091;
	static struct TOS9091_GROUP
	{
		char	dummy;
	} tos9091;

	/* work */
	char	sCmd[1024];
	char	sFileName[61];
	char	sTime[15];

	memset(&tis9091, 0, sizeof(tis9091));
	memset(&tos9091, 0, sizeof(tos9091));

	memcpy(&tis9091, ptMngInBuf->sTitaText, sizeof(tis9091));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(sFileName, 0, sizeof(sFileName));
	memcpy(sFileName, tis9091.filename, sizeof(tis9091.filename));

	memset(sTime, 0, sizeof(sTime));
	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);

	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/bin/batch/bankcode %s/iodata/%s > %s/log/bankcode.log.%s &",
		getenv("APPL"), getenv("APPL"), sFileName, getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	/* fail */
	/*
	ptMngOutBuf->tTotaLabel.msgtype = 'E';
	memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
	{
	char sError[256];
	strcpy(sError, "CNAPS�͵��������к��ļ���XML��������������");
	memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
	}
	return;
	*/

	/* succeed */
	memcpy(ptMngOutBuf->sTotaText, &tos9091, sizeof(tos9091));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos9091);
	return;
}

