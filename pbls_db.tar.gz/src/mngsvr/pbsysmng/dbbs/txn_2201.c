/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

extern DBPROCESS *dbproc;

void Process_2201(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2201_GROUP
	{
		char	dept_id;
	} tis2201;
	static struct TOS2201_GROUP
	{
		char	dept_name[60];
	} tos2201;

	/* work */
	struct wd_bdeptctl_area	wd_bdeptctl;
	struct wd_bdrefctl_area wd_bdrefctl;
	struct wd_bptypmap_area wd_bptypmap;
	RETCODE ret;
	int i,j;

	memset(&tis2201, 0, sizeof(tis2201));
	memset(&tos2201, 0, sizeof(tos2201));

	memcpy(&tis2201, ptMngInBuf->sTitaText, sizeof(tis2201));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	/* check department */
	memset(&wd_bdeptctl, 0, sizeof(wd_bdeptctl));
	wd_bdeptctl.dept_id[0] = tis2201.dept_id;
	if (DbsBDEPTCTL(DBS_FIND, &wd_bdeptctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ʼ�����Ųο��ſ��Ƽ�¼���������Ų����ڣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbfcmd(dbproc, "declare cur_2201 cursor for select ");
	dbfcmd(dbproc, "pay_type ");
	dbfcmd(dbproc, "from BPTYPMAP ");
	dbfcmd(dbproc, "order by pay_type ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ʼ�����Ųο��ſ��Ƽ�¼������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_2201 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ʼ�����Ųο��ſ��Ƽ�¼�����������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_2201 ");
		dbsqlexec(dbproc);
		return;
	}

	while (1)
	{
		memset(&wd_bptypmap, 0, sizeof(wd_bptypmap));
		memset(&wd_bdrefctl, 0, sizeof(wd_bdrefctl));

		dbcmd(dbproc, "fetch cur_2201 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS)
			break;

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ʼ�����Ųο��ſ��Ƽ�¼��������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "deallocate cursor cur_2201 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "close cur_2201 ");
			dbsqlexec(dbproc);
			return;
		}

		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bptypmap.pay_type));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}
		if (j < 1) break;

		wd_bdrefctl.dept_id[0] = wd_bdeptctl.dept_id[0];
		wd_bdrefctl.pay_type[0] = wd_bptypmap.pay_type[0];
		memcpy(wd_bdrefctl.next_refno, "0000", 4);
		CommonGetCurrentTimeDB(wd_bdrefctl.rec_updt_time);

		if (DbsBDREFCTL(DBS_INSERT, &wd_bdrefctl) != 0)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ʼ�����Ųο��ſ��Ƽ�¼������������Ƽ�¼������");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "deallocate cursor cur_2201 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "close cur_2201 ");
			dbsqlexec(dbproc);
			return;
		}
	}

	dbcmd(dbproc, "close cur_2201 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ʼ�����Ųο��ſ��Ƽ�¼�������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_2201 ");
		dbsqlexec(dbproc);
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_2201 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ʼ�����Ųο��ſ��Ƽ�¼�������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	/* succeed */
	memcpy(tos2201.dept_name, wd_bdeptctl.dept_name, sizeof(tos2201.dept_name));

	memcpy(ptMngOutBuf->sTotaText, &tos2201, sizeof(tos2201));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2201);
	return;
}


