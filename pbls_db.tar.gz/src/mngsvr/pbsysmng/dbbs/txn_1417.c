/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1417(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1417_GROUP
	{
		char	resend[16];
	} tis1417;
	static struct TOS1417_GROUP
	{
		char	resend[16];
		char	cnt[2];
		struct
		{
			char	cnaps_date[8];
			char	cls_ssn[8];
			char	update_type;
			char	update_type_desc[60];
			char	type_code[8];
			char	type_name[20];
			char	type_data[18];
			char	update_style;
			char	update_style_desc[60];
			char	update_date[8];
		} dtl[MAX_REC];
	} tos1417;

	/* work */
	char	sResend[16+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_btblcmttime417_area wd_btblcmttime417;

	memset(&tis1417, 0, sizeof(tis1417));
	memset(&tos1417, 0, sizeof(tos1417));
	memset(sResend, 0, sizeof(sResend));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1417, ptMngInBuf->sTitaText, sizeof(tis1417));
	memcpy(sResend, tis1417.resend, sizeof(tos1417.resend));

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1417 cursor for select ");
	dbfcmd(dbproc, "cnaps_date, cls_ssn, update_type, update_type_desc, ");
	dbfcmd(dbproc, "type_code, type_name, type_data, update_style, ");
	dbfcmd(dbproc, "update_style_desc, update_date ");
	dbfcmd(dbproc, "from Btblcmttime417 ");
	dbfcmd(dbproc, "where cnaps_date+cls_ssn > '%s' ", sResend);
	dbfcmd(dbproc, "order by cnaps_date, cls_ssn ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPSʱ������б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1417 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPSʱ������б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1417 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_btblcmttime417, 0, sizeof(wd_btblcmttime417));

		dbcmd(dbproc, "fetch cur_1417 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯCNAPSʱ������б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1417 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1417 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.cnaps_date));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.cls_ssn));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.update_type));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.update_type_desc));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.type_code));
		dbbind(dbproc, 6, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.type_name));
		dbbind(dbproc, 7, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.type_data));
		dbbind(dbproc, 8, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.update_style));
		dbbind(dbproc, 9, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.update_style_desc));
		dbbind(dbproc, 10, CHARBIND, (DBINT)0, (BYTE *)(wd_btblcmttime417.update_date));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		memcpy(tos1417.dtl[i].cnaps_date, wd_btblcmttime417.cnaps_date, 8);
		memcpy(tos1417.dtl[i].cls_ssn, wd_btblcmttime417.cls_ssn, 8);
		tos1417.dtl[i].update_type = wd_btblcmttime417.update_type[0]; 
		memcpy(tos1417.dtl[i].update_type_desc, 
			wd_btblcmttime417.update_type_desc, 60);
		memcpy(tos1417.dtl[i].type_code, wd_btblcmttime417.type_code, 8);
		memcpy(tos1417.dtl[i].type_name, wd_btblcmttime417.type_name, 20);
		memcpy(tos1417.dtl[i].type_data, wd_btblcmttime417.type_data, 18);
		tos1417.dtl[i].update_style = wd_btblcmttime417.update_style[0]; 
		memcpy(tos1417.dtl[i].update_style_desc, 
			wd_btblcmttime417.update_style_desc, 60);
		memcpy(tos1417.dtl[i].update_date, wd_btblcmttime417.update_date, 8);
	}

	dbcmd(dbproc, "close cur_1417 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPSʱ������б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1417 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPSʱ������б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1417.cnt, sCnt, 2);
	memcpy(tos1417.resend, wd_btblcmttime417.cnaps_date, 8);
	memcpy(tos1417.resend+8, wd_btblcmttime417.cls_ssn, 8);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1417, sizeof(tos1417));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1417);

	return;
}


