/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_9081(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS9081_GROUP
	{
		char	dummy;
	} tis9081;
	static struct TOS9081_GROUP
	{
		char	dummy;
	} tos9081;

	/* work */
	char	sCmd[1024];
	char	sTime[15];

	memset(&tis9081, 0, sizeof(tis9081));
	memset(&tos9081, 0, sizeof(tos9081));

	memcpy(&tis9081, ptMngInBuf->sTitaText, sizeof(tis9081));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(sTime, 0, sizeof(sTime));
	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);

	/* send - Out */
	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/sbin/dbeftftp.sh O > %s/log/batch/dbeftftp_out.log.%s &",
		getenv("APPL"), getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	/* recv - In */
	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/sbin/dbeftftp.sh I > %s/log/batch/dbeftftp_in.log.%s &",
		getenv("APPL"), getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	/* read IN offline files, insert local database */
	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, 
		"%s/bin/batch/read_offline_file > %s/log/batch/read_offline_file.log.%s &",
		getenv("APPL"), getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	/* fail */
	/*
	ptMngOutBuf->tTotaLabel.msgtype = 'E';
	memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
	{
	char sError[256];
	strcpy(sError, "�ļ���������");
	memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
	}
	return;
	*/

	/* succeed */
	memcpy(ptMngOutBuf->sTotaText, &tos9081, sizeof(tos9081));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos9081);
	return;
}

