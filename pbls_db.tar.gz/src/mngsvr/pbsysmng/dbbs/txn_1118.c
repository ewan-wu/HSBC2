/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1118(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1118_GROUP
	{
		char	bank_code[12];
	} tis1118;
	static struct TOS1118_GROUP
	{
		char    long_name   [ 60];
		char    short_name  [ 20];
		char	dre_code	[ 12];
		char	dre_node	[  4];
	} tos1118;

	/* work */
	struct wd_bcnapsbank_area	wd_bcnapsbank;
	struct wd_bcnapsbank_area	wd_bcnapsbank_dre;
	struct wd_bsysctl_area		wd_bsysctl;
	char    sDate0[8+1];

	memset(&tis1118, 0, sizeof(tis1118));
	memset(&tos1118, 0, sizeof(tos1118));

	memcpy(&tis1118, ptMngInBuf->sTitaText, sizeof(tis1118));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_bcnapsbank, 0, sizeof(wd_bcnapsbank));
	memcpy(wd_bcnapsbank.bank_code, tis1118.bank_code, 
		sizeof(wd_bcnapsbank.bank_code)-1);
	if (DbsBCNAPSBANK(DBS_FIND, &wd_bcnapsbank) == 0)
	{
		/* succeed */
		memcpy(tos1118.long_name, wd_bcnapsbank.long_name, 
			sizeof(tos1118.long_name));
		memcpy(tos1118.short_name, wd_bcnapsbank.short_name, 
			sizeof(tos1118.short_name));
		memcpy(tos1118.dre_code, wd_bcnapsbank.dre_code, 
			sizeof(tos1118.dre_code));

		memset(&wd_bcnapsbank_dre, 0, sizeof(wd_bcnapsbank_dre));
		memcpy(wd_bcnapsbank_dre.bank_code, wd_bcnapsbank.dre_code, 
			sizeof(wd_bcnapsbank_dre.bank_code)-1);
		if (DbsBCNAPSBANK(DBS_FIND, &wd_bcnapsbank_dre) == 0)
		{
			memcpy(tos1118.dre_node, wd_bcnapsbank_dre.node_code, 4);
		}
		else
		{
			memcpy(tos1118.dre_node, wd_bcnapsbank_dre.bank_code+3, 4);
		}

		memset(sDate0, 0, sizeof(sDate0));
		memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
		memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
		if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
		{
			memcpy(sDate0, wd_bsysctl.work_date, 8);
		}
		else
		{
			memcpy(sDate0, "00000000", 8);
		}

		if (memcmp(sDate0, "00000000", 8) != 0)
		{
			if ((memcmp(sDate0, wd_bcnapsbank.eff_date, 8) < 0) ||
				(memcmp(sDate0, wd_bcnapsbank.inv_date, 8) >= 0))
			{
				if (memcmp(sDate0, wd_bcnapsbank.eff_date, 8) < 0)
				{
					/* fail */
					ptMngOutBuf->tTotaLabel.msgtype = 'E';
					memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
					{
					char sError[256];
					strcpy(sError, "�����д�����δ��Ч��");
					memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
					*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
					}
					return;
				}
				if (memcmp(sDate0, wd_bcnapsbank.inv_date, 8) >= 0)
				{
					/* fail */
					ptMngOutBuf->tTotaLabel.msgtype = 'E';
					memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
					{
					char sError[256];
					strcpy(sError, "�����д�����ʧЧ��");
					memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
					*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
					}
					return;
				}
			}
		}

		memcpy(ptMngOutBuf->sTotaText, &tos1118, sizeof(tos1118));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1118);
		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS���д�����Ϣ��¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
}


