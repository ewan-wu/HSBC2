/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_4250(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	char sTmp[100],sTmp2[100],sTmp3[100];
	RETCODE           ret;
	char             sSqlTmp[500];
	struct wd_bpaytxnlog_area paytxnlog;
	int i;
		
	static struct TIS4250_GROUP
	{
		char    sSendBankCode[12];
		char	sClsSsn[8];
		char    cmt051[8];
	} tis4250;
	static struct TOS4250_GROUP
	{
		char  		cmt52a  [ 12];
		char  		cmt011  [ 12];
		char  		cmt58a  [ 12];
		char  		cmt012  [ 12];
		char  		cmt32a1 [  3];
		char  		cmt32a2 [ 15];
		char  		cmt051  [  8];
		char  		cmt02b  [  3];
		char  		cmt005  [  8];
		char  		cmtcq1  [ 32];
		char  		cmtcr1  [ 60];
		char  		cmtcq2  [ 32];
		char  		cmtcr2  [ 60];
		char  		cmt010  [  4];
		char  		cmt0b9  [  4];
		char		status;
		char        mdepno;
		char        moprid[8];
	} tos4250;
	
	memset(&tis4250, 0, sizeof(tis4250));
	memset(&tos4250, 0, sizeof(tos4250));
	memset(&paytxnlog	,0, sizeof(paytxnlog));
	
	memcpy(&tis4250, ptMngInBuf->sTitaText, sizeof(tis4250));
	memset(sTmp,0,sizeof(sTmp));
	memcpy(sTmp,tis4250.sClsSsn,8);
	memset(sTmp2,0,sizeof(sTmp2));
	memcpy(sTmp2,tis4250.sSendBankCode,12);
	memset(sTmp3,0,sizeof(sTmp3));
	memcpy(sTmp3,tis4250.cmt051,8);
		
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	
	sprintf(sSqlTmp,"select * from BPAYTXNLOG where p_status = '1' and p_sender = '%s' and p_refno = '%s' and p_work_date = '%s' and p_io_flag='I'",sTmp2,sTmp,sTmp3);
	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
				char sError[256];
				
				strcpy(sError, "��ѯ����֧����¼���������ݿ����");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}else
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_refno));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_refno_eft));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_sender));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_work_date));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_io_flag));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cr_flag));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cr_appno));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cr_status));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_proc_cd));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_status));
			dbbind(dbproc, 12, INTBIND, (DBINT)0, 
				(BYTE *)&(paytxnlog.p_cmt_type));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cmt_localtime));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cmt_io));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_mt_type));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_mt_localtime));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_mt_io));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_value_date));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_curr_cd));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_amount));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_sender_clr));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_receiver));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_receiver_clr));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payer_bnk));
			dbbind(dbproc, 25, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payer_act));
			dbbind(dbproc, 26, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payer_name));
			dbbind(dbproc, 27, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payer_addr));
			dbbind(dbproc, 28, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payee_bnk));
			dbbind(dbproc, 29, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payee_act));
			dbbind(dbproc, 30, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payee_name));
			dbbind(dbproc, 31, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_payee_addr));
			dbbind(dbproc, 32, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_pay_type));
			dbbind(dbproc, 33, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_bill_date));
			dbbind(dbproc, 34, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_bill_no));
			dbbind(dbproc, 35, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_bill_type));
			dbbind(dbproc, 36, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_bill_enc));
			dbbind(dbproc, 37, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_amount_a1));
			dbbind(dbproc, 38, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_amount_a2));
			dbbind(dbproc, 39, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_lend_rate));
			dbbind(dbproc, 40, INTBIND, (DBINT)0, 
				(BYTE *)&(paytxnlog.p_lend_term));
			dbbind(dbproc, 41, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_refno));
			dbbind(dbproc, 42, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_sender));
			dbbind(dbproc, 43, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_work_date));
			dbbind(dbproc, 44, INTBIND, (DBINT)0, 
				(BYTE *)&(paytxnlog.p_o_cmt_type));
			dbbind(dbproc, 45, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_cmt_localtime));
			dbbind(dbproc, 46, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_cmt_io));
			dbbind(dbproc, 47, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_mt_type));
			dbbind(dbproc, 48, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_mt_localtime));
			dbbind(dbproc, 49, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_o_mt_io));
			dbbind(dbproc, 50, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cntr_cd_s));
			dbbind(dbproc, 51, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_cntr_cd_r));
			dbbind(dbproc, 52, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_text));
			dbbind(dbproc, 53, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_memo));
			dbbind(dbproc, 54, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_data_1));
			dbbind(dbproc, 55, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.p_data_2));
			dbbind(dbproc, 56, CHARBIND, (DBINT)0, 
				(BYTE *)(paytxnlog.rec_updt_time));
				
			i = 0;
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
				i++;
			if (i < 1) 
			{
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
					char sError[256];
					
					strcpy(sError, "��ѯ����֧����¼��������¼δ�ҵ���");
					memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
					*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				}
				return;
			}
		}
		memcpy(tos4250.cmt52a  ,paytxnlog.p_receiver, 12);
		memcpy(tos4250.cmt011  ,paytxnlog.p_receiver_clr, 12);
		memcpy(tos4250.cmt58a  ,paytxnlog.p_sender, 12);
		memcpy(tos4250.cmt012  ,paytxnlog.p_sender_clr, 12);
		memcpy(tos4250.cmt32a1 ,paytxnlog.p_curr_cd,  3);
		memcpy(tos4250.cmt32a2 ,paytxnlog.p_amount, 15);
		memcpy(tos4250.cmt051  ,paytxnlog.p_value_date,  8);
		sprintf(sTmp,"%03d",paytxnlog.p_cmt_type);
		memcpy(tos4250.cmt02b  ,sTmp,  3);
		memcpy(tos4250.cmt005  ,paytxnlog.p_refno,  8);
		memcpy(tos4250.cmtcq1  ,paytxnlog.p_payer_act, 32);
		memcpy(tos4250.cmtcr1  ,paytxnlog.p_payer_name, 60);
		memcpy(tos4250.cmtcq2  ,paytxnlog.p_payee_act, 32);
		memcpy(tos4250.cmtcr2  ,paytxnlog.p_payee_name, 60);
		memcpy(tos4250.cmt010  ,paytxnlog.p_cntr_cd_r,  4);
		memcpy(tos4250.cmt0b9  ,paytxnlog.p_cntr_cd_s,  4);
		tos4250.status = paytxnlog.p_cr_status[0];      
		tos4250.mdepno = 'X';
		memcpy(tos4250.moprid,"00000000",8);
	}
	
	memcpy(ptMngOutBuf->sTotaText, &tos4250, sizeof(tos4250));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos4250);
	
	return;
}


