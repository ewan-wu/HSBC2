/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1012(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1012_GROUP
	{
		char	dept_id;
		char	date1[10];
		char	date2[10];
		char	resend[22];
	} tis1012;
	static struct TOS1012_GROUP
	{
		char	resend[22];
		char	cnt[2];
		struct
		{
			char	dept_id;
			char	act_time[19];
			char	act_type;
			char	act_subtype;
			char	act_data[60];
		} dtl[MAX_REC];
	} tos1012;

	/* work */
	char	sResend[22+1];
	char	sDeptId[1+1];
	char	sCnt[2+1];
	char	sDate1[10+1];
	char	sDate2[10+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bscmlog_area wd_bscmlog;

	memset(&tis1012, 0, sizeof(tis1012));
	memset(&tos1012, 0, sizeof(tos1012));
	memset(sResend, 0, sizeof(sResend));
	memset(sDeptId, 0, sizeof(sDeptId));
	memset(sCnt, 0, sizeof(sCnt));
	memset(sDate1, 0, sizeof(sDate1));
	memset(sDate2, 0, sizeof(sDate2));

	memcpy(&tis1012, ptMngInBuf->sTitaText, sizeof(tis1012));
	memcpy(sResend, tis1012.resend, 22);
	sDeptId[0] = tis1012.dept_id;
	memcpy(sDate1, tis1012.date1, 10);
	memcpy(sDate2, tis1012.date2, 10);

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1012 cursor for select ");
	dbfcmd(dbproc, "dept_id, act_time, act_type, act_subtype, act_data ");
	dbfcmd(dbproc, "from BSCMLOG ");
	dbfcmd(dbproc, "where dept_id+act_time+act_type+act_subtype > '%s' ",
		sResend);
	dbfcmd(dbproc, "and dept_id = '%s' ", sDeptId);

	if (sDate1[0] == ' ' || sDate1[0] == '\0')
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) >= '1900/01/01' ");
	}
	else
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) >= '%s' ", sDate1);
	}

	if (sDate2[0] == ' ' || sDate2[0] == '\0')
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) <= '3999/12/31' ");
	}
	else
	{
		dbfcmd(dbproc, "and substring(act_time, 1, 10) <= '%s' ", sDate2);
	}

	dbfcmd(dbproc, "order by dept_id, act_time, act_type, act_subtype ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����/����Աά����־������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1012 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����/����Աά����־�����������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1012 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bscmlog, 0, sizeof(wd_bscmlog));

		dbcmd(dbproc, "fetch cur_1012 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯ����/����Աά����־��������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1012 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1012 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bscmlog.dept_id));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bscmlog.act_time));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_bscmlog.act_type));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_bscmlog.act_subtype));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_bscmlog.act_data));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		tos1012.dtl[i].dept_id = wd_bscmlog.dept_id[0]; 
		memcpy(tos1012.dtl[i].act_time, wd_bscmlog.act_time, 19);
		tos1012.dtl[i].act_type = wd_bscmlog.act_type[0];
		tos1012.dtl[i].act_subtype = wd_bscmlog.act_subtype[0];
		memcpy(tos1012.dtl[i].act_data, wd_bscmlog.act_data, 60);
	}

	dbcmd(dbproc, "close cur_1012 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����/����Աά����־�������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1012 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����/����Աά����־�������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1012.cnt, sCnt, 2);
	memcpy(tos1012.resend, wd_bscmlog.dept_id, 1);
	memcpy(tos1012.resend+1, wd_bscmlog.act_time, 19);
	memcpy(tos1012.resend+1+19, wd_bscmlog.act_type, 1);
	memcpy(tos1012.resend+1+19+1, wd_bscmlog.act_subtype, 1);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1012, sizeof(tos1012));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1012);

	return;
}


