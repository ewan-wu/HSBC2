/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_9082(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS9082_GROUP
	{
		char	dummy;
	} tis9082;
	static struct TOS9082_GROUP
	{
		char	dummy;
	} tos9082;

	/* work */
	char	sCmd[1024];
	char	sTime[15];
	struct wd_bsysctl_area wd_bsysctl;
	char	sWorkDate[9];

	memset(&tis9082, 0, sizeof(tis9082));
	memset(&tos9082, 0, sizeof(tos9082));

	memcpy(&tis9082, ptMngInBuf->sTitaText, sizeof(tis9082));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(sTime, 0, sizeof(sTime));
	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);

	memset(sWorkDate, 0, sizeof(sWorkDate));
	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
	{
		memcpy(sWorkDate, wd_bsysctl.work_date, sizeof(sWorkDate)-1);
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "�����ѻ��ļ���������ȡϵͳ�������ڳ�����");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
	}
	return;
	}

	/* process offline messages */
	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, 
		"%s/bin/batch/process_offline_msg %s > %s/log/process_offline_msg.log.%s &",
		getenv("APPL"), sWorkDate, getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	/* succeed */
	memcpy(ptMngOutBuf->sTotaText, &tos9082, sizeof(tos9082));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos9082);
	return;
}

