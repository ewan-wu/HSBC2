/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1025(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1025_GROUP
	{
		char	resend;
	} tis1025;
	static struct TOS1025_GROUP
	{
		char	resend;
		char	cnt[2];
		struct
		{
			char	dept_id;
			char	dept_id_eft[2];
			char	dept_name[60];
			char	work_flag;
			char	work_type;
		} dtl[MAX_REC];
	} tos1025;

	/* work */
	char	sResend[1+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bdeptctl_area wd_bdeptctl;

	memset(&tis1025, 0, sizeof(tis1025));
	memset(&tos1025, 0, sizeof(tos1025));
	memset(sResend, 0, sizeof(sResend));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1025, ptMngInBuf->sTitaText, sizeof(tis1025));
	sResend[0] = tis1025.resend;

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1025 cursor for select ");
	dbfcmd(dbproc, "dept_id, dept_id_eft, dept_name, work_flag, work_type ");
	dbfcmd(dbproc, "from BDEPTCTL ");
	dbfcmd(dbproc, "where dept_id > '%s' ", sResend);
	dbfcmd(dbproc, "order by dept_id ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ�����б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1025 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ�����б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1025 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bdeptctl, 0, sizeof(wd_bdeptctl));

		dbcmd(dbproc, "fetch cur_1025 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯ�����б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1025 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1025 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bdeptctl.dept_id));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bdeptctl.dept_id_eft));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_bdeptctl.dept_name));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_bdeptctl.work_flag));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_bdeptctl.work_type));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		tos1025.dtl[i].dept_id = wd_bdeptctl.dept_id[0]; 
		memcpy(tos1025.dtl[i].dept_id_eft, wd_bdeptctl.dept_id_eft, 2);
		memcpy(tos1025.dtl[i].dept_name, wd_bdeptctl.dept_name, 60);
		tos1025.dtl[i].work_flag = wd_bdeptctl.work_flag[0];
		tos1025.dtl[i].work_type = wd_bdeptctl.work_type[0];
	}

	dbcmd(dbproc, "close cur_1025 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ�����б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1025 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ�����б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1025.cnt, sCnt, 2);
	tos1025.resend = wd_bdeptctl.dept_id[0];
		
	memcpy(ptMngOutBuf->sTotaText, &tos1025, sizeof(tos1025));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1025);

	return;
}


