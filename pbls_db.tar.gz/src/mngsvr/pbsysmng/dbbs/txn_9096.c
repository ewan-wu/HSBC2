/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

extern DBPROCESS *dbproc;

void Process_9096(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS9096_GROUP
	{
		char	dummy;
	} tis9096;
	static struct TOS9096_GROUP
	{
		char	oflag;
	} tos9096;

	/* work */
	char	sCmd[1024];
	char	sTime[15];
	RETCODE ret;
	int		count, i;

	memset(&tis9096, 0, sizeof(tis9096));
	memset(&tos9096, 0, sizeof(tos9096));

	memcpy(&tis9096, ptMngInBuf->sTitaText, sizeof(tis9096));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	count = 0;
	dbfcmd(dbproc, "select count(*) from Btblcmt417 ");
	dbfcmd(dbproc, "where substring(cmtc42,1,1) <> '1' ");
	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, INTBIND, (DBINT)0, (BYTE *)&(count));
			i = 0;
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1)
			{
				count = 0;
				break;
			}
		}
	}
	printf("9096:count=[%d]\n", count);
	if (count == 0) 
	{
		tos9096.oflag = '1';
	}
	else
	{
		tos9096.oflag = '0';

		memset(sTime, 0, sizeof(sTime));
		GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
		memset(sCmd, 0, sizeof(sCmd));
		sprintf(sCmd, "%s/bin/batch/process_cmt417_file > %s/log/batch/process_cmt417_file.log.%s &",
			getenv("APPL"), getenv("APPL"), sTime);
		printf("sCmd [%s]\n", sCmd);
		system(sCmd);
	}

	/* fail
	ptMngOutBuf->tTotaLabel.msgtype = 'E';
	memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
	{
	char sError[256];
	strcpy(sError, "����REPORT�ļ���������");
	memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
	}
	return;
	*/

	/* succeed */
	memcpy(ptMngOutBuf->sTotaText, &tos9096, sizeof(tos9096));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos9096);
	return;
}

