/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1102(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1102_GROUP
	{
		char	resend[3];
	} tis1102;
	static struct TOS1102_GROUP
	{
		char	resend[3];
		char	cnt[2];
		struct
		{
			char	cls_code[3];
			char	cls_code_desc[30];
			char	class_no;
			char	class_desc[20];
			char	business_type[60];
		} dtl[MAX_REC];
	} tos1102;

	/* work */
	char	sResend[3+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bclscode_area wd_bclscode;

	memset(&tis1102, 0, sizeof(tis1102));
	memset(&tos1102, 0, sizeof(tos1102));
	memset(sResend, 0, sizeof(sResend));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1102, ptMngInBuf->sTitaText, sizeof(tis1102));
	memcpy(sResend, tis1102.resend, sizeof(tos1102.resend));

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1102 cursor for select ");
	dbfcmd(dbproc, "cls_code, cls_code_desc, class_no, class_desc, ");
	dbfcmd(dbproc, "business_type ");
	dbfcmd(dbproc, "from BCLSCODE ");
	dbfcmd(dbproc, "where cls_code > '%s' ", sResend);
	dbfcmd(dbproc, "order by cls_code ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS��������б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1102 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS��������б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1102 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bclscode, 0, sizeof(wd_bclscode));

		dbcmd(dbproc, "fetch cur_1102 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯCNAPS��������б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1102 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1102 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bclscode.cls_code));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bclscode.cls_code_desc));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_bclscode.class_no));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_bclscode.class_desc));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_bclscode.business_type));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		memcpy(tos1102.dtl[i].cls_code, wd_bclscode.cls_code, 3);
		memcpy(tos1102.dtl[i].cls_code_desc, wd_bclscode.cls_code_desc, 30);
		tos1102.dtl[i].class_no = wd_bclscode.class_no[0]; 
		memcpy(tos1102.dtl[i].class_desc, wd_bclscode.class_desc, 20);
		memcpy(tos1102.dtl[i].business_type, wd_bclscode.business_type, 60);
	}

	dbcmd(dbproc, "close cur_1102 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS��������б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1102 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯCNAPS��������б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1102.cnt, sCnt, 2);
	memcpy(tos1102.resend, wd_bclscode.cls_code, 3);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1102, sizeof(tos1102));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1102);

	return;
}


