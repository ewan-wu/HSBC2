/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2015(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2015_GROUP
	{
		char	dept_id;
		char	tlr_id[8];
	} tis2015;
	static struct TOS2015_GROUP
	{
		char	tlr_name[40];
	} tos2015;

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_bsignlog_area	wd_bsignlog;

	memset(&tis2015, 0, sizeof(tis2015));
	memset(&tos2015, 0, sizeof(tos2015));

	memcpy(&tis2015, ptMngInBuf->sTitaText, sizeof(tis2015));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	wd_btlrctl.dept_id[0] = tis2015.dept_id;
	memcpy(wd_btlrctl.tlr_id, tis2015.tlr_id, sizeof(wd_btlrctl.tlr_id)-1);

	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����Ȩ�޻ָ�ʧ�ܣ��Ƿ��Ĳ���Ա��");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	GetCurrentDateAll(GET_CURRENT_DATE_FLAG_ICBC, wd_btlrctl.last_status_chg);
	CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
	if (DbsBTLRCTL(DBS_IUPD, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����Ȩ�޻ָ�ʧ�ܣ����²���Ա״̬ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
	else
	{
		/* succeed */

		/* log operator status change */
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));
		wd_bsignlog.dept_id[0] = tis2015.dept_id;
		memcpy(wd_bsignlog.tlr_id, tis2015.tlr_id, sizeof(tis2015.tlr_id));
		CommonGetCurrentTimeDB(wd_bsignlog.act_time);
		wd_bsignlog.act_type[0] = BSIGNLOG_ACTION_TYPE_RCVAUTH;
		CommonGetCurrentTimeDB(wd_bsignlog.rec_updt_time);

		if (DbsBSIGNLOG(DBS_INSERT, &wd_bsignlog) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "����Ȩ�޻ָ�ʧ�ܣ���¼����Ա��־ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
		else
		{
			/* succeed */
			memcpy(tos2015.tlr_name, wd_btlrctl.tlr_name, sizeof(tos2015.tlr_name));
			memcpy(ptMngOutBuf->sTotaText, &tos2015, sizeof(tos2015));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2015);

			return;
		}
	}
}


