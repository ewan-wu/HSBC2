/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_9095(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS9095_GROUP
	{
		char	workdate[8];
	} tis9095;
	static struct TOS9095_GROUP
	{
		char	dummy;
	} tos9095;

	/* work */
	char	sCmd[1024];
	char	sWorkDate[9];
	char	sTime[15];

	memset(&tis9095, 0, sizeof(tis9095));
	memset(&tos9095, 0, sizeof(tos9095));

	memcpy(&tis9095, ptMngInBuf->sTitaText, sizeof(tis9095));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(sWorkDate, 0, sizeof(sWorkDate));
	memcpy(sWorkDate, tis9095.workdate, sizeof(tis9095.workdate));

	memset(sTime, 0, sizeof(sTime));
	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);

	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/bin/batch/paytxnlog_daily_rpt %s > %s/log/batch/paytxnlog_daily_rpt.log.%s &",
		getenv("APPL"), sWorkDate, getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/bin/batch/cnapsmsglog_daily_rpt %s > %s/log/batch/cnapsmsglog_daily_rpt.log.%s &",
		getenv("APPL"), sWorkDate, getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/bin/batch/tlrpswderr_daily_report %s > %s/log/batch/tlrpswderr_daily_report.log.%s &",
		getenv("APPL"), sWorkDate, getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	/* fail */
	/*
	ptMngOutBuf->tTotaLabel.msgtype = 'E';
	memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
	{
	char sError[256];
	strcpy(sError, "����REPORT�ļ���������");
	memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
	}
	return;
	*/

	/* succeed */
	memcpy(ptMngOutBuf->sTotaText, &tos9095, sizeof(tos9095));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos9095);
	return;
}

