/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1201(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1201_GROUP
	{
		char	resend;
	} tis1201;
	static struct TOS1201_GROUP
	{
		char	resend;
		char	cnt[2];
		struct
		{
			char	pay_type;
			char	pay_type_eft[2];
		} dtl[MAX_REC];
	} tos1201;

	/* work */
	char	sResend[1+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_bptypmap_area wd_bptypmap;

	memset(&tis1201, 0, sizeof(tis1201));
	memset(&tos1201, 0, sizeof(tos1201));
	memset(sResend, 0, sizeof(sResend));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1201, ptMngInBuf->sTitaText, sizeof(tis1201));
	sResend[0] = tis1201.resend;

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1201 cursor for select ");
	dbfcmd(dbproc, "pay_type, pay_type_eft ");
	dbfcmd(dbproc, "from BPTYPMAP ");
	dbfcmd(dbproc, "where pay_type > '%s' ", sResend);
	dbfcmd(dbproc, "order by pay_type ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEFT��BRIDGE֧�����Ͷ����б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1201 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEFT��BRIDGE֧�����Ͷ����б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1201 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_bptypmap, 0, sizeof(wd_bptypmap));

		dbcmd(dbproc, "fetch cur_1201 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯEFT��BRIDGE֧�����Ͷ����б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1201 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1201 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_bptypmap.pay_type));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_bptypmap.pay_type_eft));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		tos1201.dtl[i].pay_type = wd_bptypmap.pay_type[0];
		memcpy(tos1201.dtl[i].pay_type_eft, wd_bptypmap.pay_type_eft, 2);
	}

	dbcmd(dbproc, "close cur_1201 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEFT��BRIDGE֧�����Ͷ����б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1201 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯEFT��BRIDGE֧�����Ͷ����б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1201.cnt, sCnt, 2);
	tos1201.resend = wd_bptypmap.pay_type[0];

	memcpy(ptMngOutBuf->sTotaText, &tos1201, sizeof(tos1201));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1201);

	return;
}


