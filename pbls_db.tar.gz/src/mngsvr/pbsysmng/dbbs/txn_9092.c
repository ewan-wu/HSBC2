/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_9092(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS9092_GROUP
	{
		char	filename[60];
	} tis9092;
	static struct TOS9092_GROUP
	{
		char	dummy;
	} tos9092;

	/* work */
	char	sCmd[1024];
	char	sFileName[61];
	char	sTime[15];

	memset(&tis9092, 0, sizeof(tis9092));
	memset(&tos9092, 0, sizeof(tos9092));

	memcpy(&tis9092, ptMngInBuf->sTitaText, sizeof(tis9092));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(sFileName, 0, sizeof(sFileName));
	memcpy(sFileName, tis9092.filename, sizeof(tis9092.filename));

	memset(sTime, 0, sizeof(sTime));
	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);

	memset(sCmd, 0, sizeof(sCmd));
	sprintf(sCmd, "%s/bin/batch/bankcode_for_eft %s/iodata/%s > %s/log/bankcode_for_eft.log.%s &",
		getenv("APPL"), getenv("APPL"), sFileName, getenv("APPL"), sTime);

	printf("sCmd [%s]\n", sCmd);
	system(sCmd);

	/* fail */
	/*
	ptMngOutBuf->tTotaLabel.msgtype = 'E';
	memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
	{
	char sError[256];
	strcpy(sError, "����EFT�к��ļ���������");
	memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
	}
	return;
	*/

	/* succeed */
	memcpy(ptMngOutBuf->sTotaText, &tos9092, sizeof(tos9092));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos9092);
	return;
}

