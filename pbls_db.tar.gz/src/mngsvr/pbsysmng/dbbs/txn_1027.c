/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/
#include <sybfront.h>
#include <sybdb.h>

#include "manager.h"

#define MAX_REC     10

extern DBPROCESS *dbproc;

void Process_1027(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1027_GROUP
	{
		char	dept_id;
		char	resend[9];
	} tis1027;
	static struct TOS1027_GROUP
	{
		char	resend[9];
		char	cnt[2];
		struct
		{
			char	dept_id;
			char	tlr_id[8];
			char	tlr_name[40];
			char	init_flag;
			char	work_flag;
			char	work_level;
			char	status;
			char	last_status_chg[8];
			char	last_pswd_chg[8];
			char	add_by_dept_id;
			char	add_by_tlr_id[8];
			char	auth_by_dept_id;
			char	auth_by_tlr_id[8];
			char	retry;
		} dtl[MAX_REC];
	} tos1027;

	/* work */
	char	sResend[9+1];
	char	sDeptId[1+1];
	char	sCnt[2+1];
	RETCODE ret;
	int i,j;
	int endflag;
	struct wd_btlrctl_area wd_btlrctl;

	memset(&tis1027, 0, sizeof(tis1027));
	memset(&tos1027, 0, sizeof(tos1027));
	memset(sResend, 0, sizeof(sResend));
	memset(sDeptId, 0, sizeof(sDeptId));
	memset(sCnt, 0, sizeof(sCnt));

	memcpy(&tis1027, ptMngInBuf->sTitaText, sizeof(tis1027));
	sDeptId[0] = tis1027.dept_id;
	memcpy(sResend, tis1027.resend, sizeof(tis1027.resend));

	endflag = 0;

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	dbfcmd(dbproc, "declare cur_1027 cursor for select ");
	dbfcmd(dbproc, "dept_id, tlr_id, tlr_name, init_flag, work_flag, work_level, ");
	dbfcmd(dbproc, "status, last_status_chg, last_pswd_chg, ");
	dbfcmd(dbproc, "add_by_dept_id, add_by_tlr_id, ");
	dbfcmd(dbproc, "auth_by_dept_id, auth_by_tlr_id, pswd_retry_cnt ");
	dbfcmd(dbproc, "from BTLRCTL ");
	dbfcmd(dbproc, "where dept_id+tlr_id > '%s' ", sResend);
	if (sDeptId[0] != '*')
	{
		dbfcmd(dbproc, "and dept_id = '%s' ", sDeptId);
	}
	dbfcmd(dbproc, "order by dept_id, tlr_id ");

	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա�б�������׼�����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "open cur_1027 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա�б������������ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		dbcmd(dbproc, "deallocate cursor cur_1027 ");
		dbsqlexec(dbproc);
		return;
	}

	for (i = 0; i < MAX_REC; i++)
	{
		memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));

		dbcmd(dbproc, "fetch cur_1027 ");
		dbsqlexec(dbproc);

		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS) 
		{
			endflag = 1;
			break;
		}

		if (ret != SUCCEED)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "��ѯ����Ա�б���������ȡ���ݳ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			dbcmd(dbproc, "close cur_1027 ");
			dbsqlexec(dbproc);
			dbcmd(dbproc, "deallocate cursor cur_1027 ");
			dbsqlexec(dbproc);
			return;
		}
		
		dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.dept_id));
		dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.tlr_id));
		dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.tlr_name));
		dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.init_flag));
		dbbind(dbproc, 5, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.work_flag));
		dbbind(dbproc, 6, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.work_level));
		dbbind(dbproc, 7, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.status));
		dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
			(BYTE *)(wd_btlrctl.last_status_chg));
		dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
			(BYTE *)(wd_btlrctl.last_pswd_chg));
		dbbind(dbproc, 10, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.add_by_dept_id));
		dbbind(dbproc, 11, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.add_by_tlr_id));
		dbbind(dbproc, 12, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.auth_by_dept_id));
		dbbind(dbproc, 13, CHARBIND, (DBINT)0, (BYTE *)(wd_btlrctl.auth_by_tlr_id));
		dbbind(dbproc, 14, INTBIND, (DBINT)0, (BYTE *)&(wd_btlrctl.pswd_retry_cnt));

		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS)
		{
			j++;
		}

		if (j < 1)
		{
			endflag = 1;
			break;
		}

		tos1027.dtl[i].dept_id = wd_btlrctl.dept_id[0]; 
		memcpy(tos1027.dtl[i].tlr_id, wd_btlrctl.tlr_id, 8);
		memcpy(tos1027.dtl[i].tlr_name, wd_btlrctl.tlr_name, 40);
		tos1027.dtl[i].init_flag = wd_btlrctl.init_flag[0];
		tos1027.dtl[i].work_flag = wd_btlrctl.work_flag[0];
		tos1027.dtl[i].work_level = wd_btlrctl.work_level[0];
		tos1027.dtl[i].status = wd_btlrctl.status[0];
		memcpy(tos1027.dtl[i].last_status_chg, wd_btlrctl.last_status_chg, 8);
		memcpy(tos1027.dtl[i].last_pswd_chg, wd_btlrctl.last_pswd_chg, 8);
		tos1027.dtl[i].add_by_dept_id = wd_btlrctl.add_by_dept_id[0]; 
		memcpy(tos1027.dtl[i].add_by_tlr_id, wd_btlrctl.add_by_tlr_id, 8);
		tos1027.dtl[i].auth_by_dept_id = wd_btlrctl.auth_by_dept_id[0]; 
		memcpy(tos1027.dtl[i].auth_by_tlr_id, wd_btlrctl.auth_by_tlr_id, 8);
		tos1027.dtl[i].retry = wd_btlrctl.pswd_retry_cnt + 0x30;
	}

	dbcmd(dbproc, "close cur_1027 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա�б��������ر����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	dbcmd(dbproc, "deallocate cursor cur_1027 ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա�б��������ͷ����ݲ�ѯ������");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	if (endflag == 1)
		ptMngOutBuf->tTotaLabel.msgend = '1';
	else
		ptMngOutBuf->tTotaLabel.msgend = '0';

	sprintf(sCnt, "%02d", i);
	memcpy(tos1027.cnt, sCnt, 2);
	memcpy(tos1027.resend, wd_btlrctl.dept_id, 1);
	memcpy(tos1027.resend+1, wd_btlrctl.tlr_id, 8);
		
	memcpy(ptMngOutBuf->sTotaText, &tos1027, sizeof(tos1027));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1027);

	return;
}


