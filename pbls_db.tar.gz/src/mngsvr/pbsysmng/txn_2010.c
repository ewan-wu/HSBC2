/************************************************************************/
/*                                                                      */
/* Product: Partner Bank Ling System                                    */
/*          manage module                                               */
/*   txn_2010                                                           */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ����Ա������                                         */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20110407        HanMeirong            Initial                      */
/************************************************************************/
#include "pbsysmng.h"

extern char logfile[256];

static struct TIS2010_GROUP
{
	char	old_pswd[8];
	char	new_pswd[8];
} tis2010;

static struct TOS2010_GROUP
{
	char	null;
} tos2010;

void txn_2010Initial(void);
void txn_2010Process(void);
void txn_2010PutMessage(void);

void txn_2010(void)
{
	txn_2010Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_2010Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_2010PutMessage();
}

void txn_2010Initial(void)
{  
	memset(&tis2010, 0, sizeof(tis2010));
	memcpy(&tis2010, it_tita.sTitaText, sizeof(tis2010));
	memset(&tos2010, 0, sizeof(tos2010));
}

void txn_2010Process(void)
{
	struct	wd_pbtlrctltmp_area	wdPbtlrctltmp;
	struct	wd_pbtlrctl_area	wdPbtlrctl;
	int		nRet = 0;
	char	sBuf[1500];

	char sPswd0[21];
	char sPswd1[21];

	char	log_work_flag[50+1];
	
	memset( &wdPbtlrctltmp, 0, sizeof(wdPbtlrctltmp) );
	memset( &wdPbtlrctl, 0, sizeof(wdPbtlrctl) );

	memcpy( wdPbtlrctltmp.tlr_id, it_tita.label.tlrno,8);
	memcpy( wdPbtlrctltmp.dept_id, "000",strlen("000"));
	
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"it_tita.sTitaText =[%s]\n",it_tita.sTitaText);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"it_tita.label.tlrno =[%8.8s]\n",it_tita.label.tlrno);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctltmp.tlr_id=[%8.8s]\n",wdPbtlrctltmp.tlr_id);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctltmp.dept_id=[%3.3s]\n",wdPbtlrctltmp.dept_id);
	nRet = DbsPBTLRCTLTMP( DBS_FIND, &wdPbtlrctltmp );
	if( nRet != DB_OK && nRet != DB_NOTFOUND )
	{		
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBTLRCTLTMP_RERR, "DBS_FIND PBTLRCTLTMP ERROR![%d]", nRet );
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTLTMP FIND ERROR! sqlcode=[%d]", nRet );
		return ;
	}
	else if( DB_OK == nRet )
	{
		/* �������ò���Ա����ά���У�����Ȩ���ٴ��޸�*/
		ERRTRACE( E_DB_PBTLRCTLTMP_STA_ERR, "PBTLRCTLTMP �Ѵ��ڼ�¼![%d]", nRet );
		return ;
	}

	
	memcpy( wdPbtlrctl.tlr_id, it_tita.label.tlrno, 8 );
	memcpy( wdPbtlrctl.dept_id, "000",strlen("000"));
	
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctl.tlr_id=[%8.8s]\n",wdPbtlrctl.tlr_id);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctl.dept_id=[%3.3s]\n",wdPbtlrctl.dept_id);

	nRet = DbsPBTLRCTL( DBS_LOCK, &wdPbtlrctl );
	if( nRet != DB_OK && nRet != DB_NOTFOUND )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBTLRCTL_RERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet );
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL FIND ERROR! sqlcode=[%d]", nRet );
		return ;
	}

	else if( DB_NOTFOUND == nRet)
	{
		/* ����������Ա��Ϣ�����ڣ������޸ġ��� */
		ERRTRACE( E_DB_PBTLRCTL_NO_EXSIT, "����Ա��Ϣ�����ڣ������޸�![%d]", nRet );
		return ;
	}


    memset(sPswd0, 0, sizeof(sPswd0));
    memset(sPswd1, ' ', sizeof(sPswd1));
    memcpy(sPswd0, tis2010.old_pswd, sizeof(tis2010.old_pswd));
	memcpy(sPswd1, sPswd0, strlen(sPswd0));
	sPswd1[sizeof(sPswd1)-1] = '\0';
	RightTrim(wdPbtlrctl.password);
	RightTrim(sPswd1);

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"this is wdPbtlrctl.password=[%s]\n",wdPbtlrctl.password);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"this is sPswd1=[%s]\n",sPswd1);

	if (strcmp(sPswd1,wdPbtlrctl.password) != 0)
	{
		
		ERRTRACE( E_PBICBCTXN_OLDPWD_ERR, "������ʧ�ܣ�����Ա���������[%d]",nRet);
		DbsPBTLRCTL(DBS_CLOSE, &wdPbtlrctl );
		return ;

	}


    memset(sPswd0, 0, sizeof(sPswd0));
    memset(sPswd1, ' ', sizeof(sPswd1));
	memcpy(sPswd0, tis2010.new_pswd, sizeof(tis2010.new_pswd));
	memcpy(sPswd1, sPswd0, strlen(sPswd0));
	sPswd1[sizeof(sPswd1)-1] = '\0';
    RightTrim(wdPbtlrctl.password);
	RightTrim(sPswd1);

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"this is wdPbtlrctl.password=[%s]\n",wdPbtlrctl.password);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," sPswd1=[%s]\n",sPswd1);

	if (strcmp(sPswd1,wdPbtlrctl.password) == 0)
	{

		ERRTRACE( E_DB_PBTLRCTL_NO_EXSIT, "�������������һ�����������޸�![%d]",nRet);
		DbsPBTLRCTL(DBS_CLOSE, &wdPbtlrctl );
		return ;
	}



	/* ǰ̨���� */
	memcpy( wdPbtlrctl.tlr_id, it_tita.label.tlrno, 8 );
	memcpy( wdPbtlrctl.password,tis2010.new_pswd, sizeof(tis2010.new_pswd) );
	/* ��̨��ֵ */
	CommonGetCurrentDate(wdPbtlrctl.last_pswd_chg);	

	printf("wdPbtlrctl.tlr_id=[%8.8s]\n",wdPbtlrctl.tlr_id);
	printf("wdPbtlrctl.dept_id=[%3.3s]\n",wdPbtlrctl.dept_id);
	printf("wdPbtlrctl.tlr_name=[%60.60s]\n",wdPbtlrctl.tlr_name);
	printf("wdPbtlrctl.work_flag=[%1.1s]\n",wdPbtlrctl.work_flag);
	printf("wdPbtlrctl.rights=[%20.20s]\n",wdPbtlrctl.rights);
	printf("wdPbtlrctl.add_dept=[%3.3s]\n",wdPbtlrctl.add_dept);
	printf("wdPbtlrctl.add_tlr=[%8.8s]\n",wdPbtlrctl.add_tlr);
	printf("wdPbtlrctl.add_date=[%20.20s]\n",wdPbtlrctl.add_date);
	
	/*���²���Ա��¼��*/ 
	nRet = DbsPBTLRCTL( DBS_UPDATE, &wdPbtlrctl );
	if( nRet != DB_OK )
	{
		/*�������ݿ����*/
		ERRTRACE( E_DB_PBTLRCTL_IERR, "�������ʧ��SSQLCODE=[%d]", nRet );
		RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL UPDATE  ERROR! sqlcode=[%d]", nRet );
		DbsPBTLRCTL(DBS_CLOSE, &wdPbtlrctl );
		return ;
	}

	DbsPBTLRCTL(DBS_CLOSE, &wdPbtlrctl );

	/*write the operation log*/
	MSET(log_work_flag);
	strcpy(log_work_flag, (char *)GetFlagName(10,wdPbtlrctl.work_flag));
	
	sprintf( sBuf, "ά������[%s]\n����Ա����[%s]\n����Ա����[%s]\n��������[%s]\n��ɫID[%s]", 
	GetFlagName(7,"M"), 
	wdPbtlrctl.tlr_id ,
	wdPbtlrctl.tlr_name, 
	log_work_flag,
	wdPbtlrctl.rights );
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        ERRTRACE( E_DB_TB_TLRLOG_IERR, "��¼������־��Ϣ����[%d]", nRet);
        return ;
    }
	return ;
}

void txn_2010PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy(it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos2010), sizeof(it_totw.label.msglng), it_totw.label.msglng);

	memcpy(it_totw.sTotaText, &tos2010, sizeof(tos2010));
}

void txn_2010End()
{

}
