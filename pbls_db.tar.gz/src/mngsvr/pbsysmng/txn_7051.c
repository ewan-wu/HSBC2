/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ���ڲ���ԱȨ�޻ָ�                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100730          Zhu Rui              Initial                     */
/************************************************************************/

#include "pbsysmng.h"

static struct TIS7051_GROUP
{
    char	tlr_id[8];
}tis7051;

static struct TOS7051_GROUP
{
    char null;
}tos7051;

static struct wd_pbtlrctl_area wd_pbtlrctl;
extern  char    logfile[256];

void txn_7051Initial(void);
void txn_7051Process(void);
void txn_7051PutMessage(void);
void txn_7051End(void);
void txn_7051(void)
{
	txn_7051Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7051Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7051PutMessage();
}

void txn_7051Initial(void)
{	
    memset(&tis7051, 0, sizeof(tis7051));
    memcpy(&tis7051, it_tita.sTitaText, sizeof(tis7051));
    memset(&tos7051, 0, sizeof(tos7051));
    memset(&wd_pbtlrctl, 0, sizeof(wd_pbtlrctl));	
}

void txn_7051Process(void)
{
    int nRet = 0;
    char sBuf[1500+1];
    memset(sBuf,0,sizeof(sBuf));
	
    memcpy(wd_pbtlrctl.tlr_id   ,tis7051.tlr_id,DLEN_TLRNO);
    memcpy(wd_pbtlrctl.dept_id  ,"000"  ,strlen("000"));
    nRet = DbsPBTLRCTL(DBS_LOCK, &wd_pbtlrctl);
    if (nRet != 0)
    {
        if(nRet == DB_NOTFOUND)
		{
			ERRTRACE(E_TLR_NOTEXIST, "����Ȩ�޻ָ�ʧ�ܣ�tlrno[%s]", wd_pbtlrctl.tlr_id); 
			return;
		}
        ERRTRACE(E_DB_TB_TLRCTL_RERR, "����Ȩ�޻ָ�ʧ�ܣ�tlrno[%s]",wd_pbtlrctl.tlr_id);
        return;
    }

    GetCurrentDateAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbtlrctl.last_status_chg);
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbtlrctl.rec_updt_time);
    if (DbsPBTLRCTL(DBS_UPDATE, &wd_pbtlrctl) != 0)
    {
        /* fail ���ݿ��쳣*/
        RecTivoliLogC("PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DB Error!" );
        ERRTRACE(E_DB_TB_TLRCTL_WERR, "����Ȩ�޻ָ�ʧ�ܣ�tlrno[%s]", wd_pbtlrctl.tlr_id);
        return;
    }

	  /* 3.��¼����Ա��־�� */
    sprintf(sBuf, "�ָ�Ȩ�޲���Ա[%s]", tis7051.tlr_id);

    nRet = RecTlrLog(sBuf);
    if(nRet != DB_OK)
    {
        ERRTRACE(E_DB_TB_TLRLOG_IERR,"��¼������־��Ϣ����[%d]", nRet);
        return;
    }
	printf("\ntxn_7051 succeed\n");
}

void txn_7051PutMessage(void)
{
    it_totw.label.msgend = '1';
    it_totw.label.msgtype = it_tita.label.taskid[1];
    memcpy(it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD);
    apitoa(TOTA_LABEL_LENGTH + sizeof(tos7051), sizeof(it_totw.label.msglng), it_totw.label.msglng);
    memcpy(it_totw.sTotaText, &tos7051, sizeof(tos7051));
}

void txn_7051End()
{
    DbsPBTLRCTL(DBS_CLOSE,&wd_pbtlrctl);
}
