/************************************************************************/
/*                                                                      */
/* Product: Partner Bank Ling System                                    */
/*          manage module                                               */
/*   txn_2008                                                           */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ����Ա��Ϣ��Ȩ                                           */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100819        LiuSheng              Initial                      */
/************************************************************************/
#include "pbsysmng.h"

extern char logfile[256];

static struct TIS2008_GROUP
{
	char	tlr_id[8];
	char	auth_flag[1];	/* 1-��Ȩ 0-�ܾ� */
} tis2008;

static struct TOS2008_GROUP
{
	char	null;
} tos2008;

void txn_2008Initial(void);
void txn_2008Process(void);
void txn_2008PutMessage(void);

void txn_2008(void)
{
	txn_2008Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_2008Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_2008PutMessage();
}

void txn_2008Initial(void)
{  
	memset(&tis2008, 0, sizeof(tis2008));
	memcpy(&tis2008, it_tita.sTitaText, sizeof(tis2008));
	memset(&tos2008, 0, sizeof(tos2008));
}

void txn_2008Process(void)
{
	struct	wd_pbtlrctltmp_area	wdPbtlrctltmp;
	struct	wd_pbtlrctl_area	wdPbtlrctl;
	int		nRet = 0;
	int		nRet1 = 0;
	char	sBuf[1500];
	
	memset( &wdPbtlrctltmp, 0, sizeof(wdPbtlrctltmp) );
	memset( &wdPbtlrctl, 0, sizeof(wdPbtlrctl) );
	
	memcpy( wdPbtlrctltmp.tlr_id, tis2008.tlr_id, 8 );
	memcpy( wdPbtlrctltmp.dept_id, "000",strlen("000"));
	
	nRet = DbsPBTLRCTLTMP( DBS_LOCK, &wdPbtlrctltmp );
	if( nRet == DB_NOTFOUND )
	{
		/* ����������Աά����Ϣ�����ڡ��� */
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctltmp.tlr_id=[%8.8s],dept_id=[%3.3s]\n",wdPbtlrctltmp.tlr_id, wdPbtlrctltmp.dept_id );
		ERRTRACE( E_DB_PBTLRCTLTMP_NO_EXSIT, "LOCK PBTLRCTLTMP ERROR![%d]", nRet );
		DbsPBTLRCTLTMP( DBS_CLOSE );
		if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTLTMP LOCK ERROR! sqlcode=[%d]", nRet );
		return ;
	}
	else if( nRet != DB_OK )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBTLRCTLTMP_WERR, "LOCK PBTLRCTLTMP ERROR![%d]", nRet );
		DbsPBTLRCTLTMP( DBS_CLOSE );
		return ;
	}
	
	if( strncmp(wdPbtlrctltmp.add_tlr, it_tita.label.tlrno, 8) == 0 )
	{
		/* ������¼�롢��Ȩ����Ա������ͬ���� */
		ERRTRACE( E_TXN_SAMEPERSON_ERR, "¼�롢��Ȩ����Ա������ͬ!" );
		DbsPBTLRCTLTMP( DBS_CLOSE );
		return ;
	}

	memcpy( wdPbtlrctl.tlr_id, tis2008.tlr_id, 8 );
	memcpy( wdPbtlrctl.dept_id, "000",strlen("000"));
	nRet1 = DbsPBTLRCTL( DBS_LOCK, &wdPbtlrctl );
	if( nRet1 != DB_OK && nRet1 != DB_NOTFOUND )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBTLRCTL_WERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet1 );
		DbsPBTLRCTL( DBS_CLOSE );
		DbsPBTLRCTLTMP( DBS_CLOSE );
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL LOCK ERROR! sqlcode=[%d]", nRet );
		return ;
	}

	if( '1' == tis2008.auth_flag[0] )
	{
		if( wdPbtlrctltmp.op_type[0] == 'M' || wdPbtlrctltmp.op_type[0] == 'A' )
		{
			/* ǰ̨���� */
			memcpy( wdPbtlrctl.tlr_name, wdPbtlrctltmp.tlr_name, 60 );
			memcpy( wdPbtlrctl.work_flag, wdPbtlrctltmp.work_flag, 1 );
			memcpy( wdPbtlrctl.rights, wdPbtlrctltmp.rights, 20 );
			/* ��̨��ֵ */
			memcpy( wdPbtlrctl.status, "0", 1 );	/* 0-δ��¼ */
			GetCurrentDateAll(GET_CURRENT_DATE_FLAG_SYS,  wdPbtlrctl.last_status_chg );
			memcpy( wdPbtlrctl.add_tlr, wdPbtlrctltmp.add_tlr, 8 );
			memcpy( wdPbtlrctl.add_date, wdPbtlrctltmp.add_date, 8 );
			memcpy( wdPbtlrctl.auth_tlr, it_tita.label.tlrno, 8 );
			GetCurrentDateAll(GET_CURRENT_DATE_FLAG_SYS,  wdPbtlrctl.auth_date );
			memcpy( wdPbtlrctl.auth_dept, it_tita.label.kinbr, 3 );
			memcpy( wdPbtlrctl.mod_tlr, wdPbtlrctltmp.add_tlr, 8 );
			memcpy( wdPbtlrctl.mod_date, wdPbtlrctltmp.add_date, 8 );
			memcpy( wdPbtlrctl.mod_dept, wdPbtlrctltmp.dept_id, 3 );
			memcpy( wdPbtlrctl.dept_id, "000", strlen("000"));
        	
			if( DB_OK == nRet1 )
			{
				nRet = DbsPBTLRCTL( DBS_UPDATE, &wdPbtlrctl );
				if( nRet != DB_OK && nRet != DB_NOTFOUND )
				{
					/* ��������ȡ���ݿ�������� */
					ERRTRACE( E_DB_PBTLRCTL_WERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet );
					DbsPBTLRCTL( DBS_CLOSE );
					DbsPBTLRCTLTMP( DBS_CLOSE );
					if( nRet != DB_ISNULL )
						RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL UPDATE ERROR! sqlcode=[%d]", nRet );
					return ;
				}
			}
			else if( DB_NOTFOUND == nRet1 )
			{
				nRet = DbsPBTLRCTL( DBS_INSERT, &wdPbtlrctl );
				if( nRet != DB_OK && nRet != DB_NOTFOUND )
				{
					/* ��������ȡ���ݿ�������� */
					ERRTRACE( E_DB_PBTLRCTL_IERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet );
					DbsPBTLRCTL( DBS_CLOSE );
					DbsPBTLRCTLTMP( DBS_CLOSE );
					RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL INSERT ERROR! sqlcode=[%d]", nRet );
					return ;
				}
			}
		}
		else
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctl.tlr_id=[%8.8s]\n",wdPbtlrctl.tlr_id);
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctl.dept_id=[%3.3s]\n",wdPbtlrctl.dept_id);
			nRet = DbsPBTLRCTL( DBS_DELETE, &wdPbtlrctl );
			if( nRet != DB_OK && nRet != DB_NOTFOUND )
			{
				/* ��������ȡ���ݿ�������� */
				ERRTRACE( E_DB_PBTLRCTL_DERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet );
				DbsPBTLRCTL( DBS_CLOSE );
				DbsPBTLRCTLTMP( DBS_CLOSE );
				if( nRet != DB_ISNULL )
					RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL DELETE ERROR! sqlcode=[%d]", nRet );
				return ;
			}
		}
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctltmp.tlr_id=[%8.8s]\n",wdPbtlrctltmp.tlr_id);
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctltmp.dept_id=[%3.3s]\n",wdPbtlrctltmp.dept_id);
		nRet = DbsPBTLRCTLTMP( DBS_DELETE, &wdPbtlrctltmp );
		if( nRet != DB_OK && nRet != DB_NOTFOUND )
		{
			/* ��������ȡ���ݿ�������� */
			ERRTRACE( E_DB_PBTLRCTLTMP_DERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet );
			DbsPBTLRCTLTMP( DBS_CLOSE );
			if( nRet != DB_ISNULL )
				RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTLTMP DELETE ERROR! sqlcode=[%d]", nRet );
			return ;
		}
		DbsPBTLRCTLTMP( DBS_CLOSE );
	}
	else if( '0' == tis2008.auth_flag[0] )
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctltmp.tlr_id=[%8.8s]\n",wdPbtlrctltmp.tlr_id);
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctltmp.dept_id=[%3.3s]\n",wdPbtlrctltmp.dept_id);
		nRet = DbsPBTLRCTLTMP( DBS_DELETE, &wdPbtlrctltmp );
		if( nRet != DB_OK && nRet != DB_NOTFOUND )
		{
			/* ��������ȡ���ݿ�������� */
			ERRTRACE( E_DB_PBTLRCTLTMP_DERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet );
			DbsPBTLRCTLTMP( DBS_CLOSE );
			if( nRet != DB_ISNULL )
				RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTLTMP DELETE ERROR! sqlcode=[%d]", nRet );
			return ;
		}
		DbsPBTLRCTLTMP( DBS_CLOSE );
	}
	DbsPBTLRCTL( DBS_CLOSE );
	
	sprintf( sBuf, "��Ȩ����[%s]\n����Ա����[%.8s]", GetFlagName(9,&tis2008.auth_flag), tis2008.tlr_id );
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        ERRTRACE( E_DB_TB_TLRLOG_IERR, "��¼������־��Ϣ����[%d]", nRet);
        return ;
    }
	
	return ;
}

void txn_2008PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy(it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos2008), sizeof(it_totw.label.msglng), it_totw.label.msglng);

	memcpy(it_totw.sTotaText, &tos2008, sizeof(tos2008));
}

void txn_2008End()
{

}
