/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �������в���ά����Ȩ                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100728          Zhu Rui              Initial                     */
/************************************************************************/

#include "pbsysmng.h"

static struct TIS7022_GROUP
{ 
    char     sBankId      [3 ];   /* �����к�                       */
    char	 sAuthType    [1 ];   /* ��������  1-ͨ�� 2-�ܾ�        */ 
}tis7022;

static struct TOS7022_GROUP
{
	char	 null;
}tos7022;

static	struct  wd_pbpbankctltmp_area	wd_pbpbankctltmp;
static  struct  wd_pbpbankctl_area    wd_pbpbankctl;
extern  char    logfile[256];

void txn_7022Initial(void);
void txn_7022Process(void);
void txn_7022PutMessage(void);

void txn_7022(void)
{
	txn_7022Initial();

	txn_7022Process();

	txn_7022PutMessage();
}

void txn_7022Initial(void)
{
	memset( &tis7022, 0, sizeof(tis7022) );
	memcpy( &tis7022, it_tita.sTitaText, sizeof(tis7022) );
	memset( &tos7022, 0, sizeof(tos7022) );	
	memset( &wd_pbpbankctltmp, 0, sizeof(wd_pbpbankctltmp));
	memset( &wd_pbpbankctl   , 0, sizeof(wd_pbpbankctl   ));
}

void txn_7022Process( void )
{
    
    /********************************************
     *  �ֲ�������������ʼ��
     ********************************************/
    int		nRet = 0;
    char  sBuf[1500+1];
    char  sFrequency11[5+1];
	
	memset(sFrequency11, 0, sizeof(sFrequency11));
	  
    /********************************************
     * ���ݴ�������к��ҳ������в���������ʱ����
     * ��Ҫ��Ȩ������
     ********************************************/
    memcpy(wd_pbpbankctltmp.bank_id, tis7022.sBankId, sizeof(tis7022.sBankId));
    
    nRet = DbsPBPBANKCTLTMP(DBS_LOCK,&wd_pbpbankctltmp);
    if( nRet != DB_OK )
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"DbsPBPBANKCTLTMP DBS_LOCK=[%d]\n", nRet );
        ERRTRACE(E_PB_PBANKCTLTMP_NOT_EXSIT,"��������Ҫά���ĺ������в���[%d]",nRet);/* �˴���ErrorTrace   ��������Ҫά���ĺ������в��� */
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
        	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBPBANKCTLTMP LOCK ERROR! sqlcode=[%d]", nRet );
        return ;
    }
	/* �ж�ά������Ȩ�Ƿ���ͬһ�� */
	if( memcmp(wd_pbpbankctltmp.add_tlr, it_tita.label.tlrno, sizeof(it_tita.label.tlrno)) == 0 )
	{
		ERRTRACE( E_TXN_SAMEPERSON_ERR, "Md_tlrno=[%s],avp_tlrno=[%s]", wd_pbpbankctltmp.add_tlr, it_tita.label.tlrno );
        return;  
	}
    
    /********************************************
     * ��Ȩͨ��
     ********************************************/
    if( tis7022.sAuthType[0] == '1')
    {
        /* �ж�ά�����Ͳ������������� */
        if( wd_pbpbankctltmp.op_type[0] != 'M')
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"ά�����Ͳ�Ϊ=[%c]��ΪM-�޸�\n", wd_pbpbankctltmp.op_type );
            ERRTRACE(E_AUTH_TYPE_ERR,"ά�����Ͳ���ȷ[%c]",wd_pbpbankctltmp.op_type);/* �˴���ErrorTrace   ά�����Ͳ���ȷ */
            return ;
        }
        
        memcpy(wd_pbpbankctl.bank_id, tis7022.sBankId, sizeof(tis7022.sBankId));
        nRet = DbsPBPBANKCTL(DBS_LOCK,&wd_pbpbankctl);
        if( nRet != DB_OK && nRet != DB_NOTFOUND )
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"DbsPBPBANKCTL DBS_LOCK=[%d]\n", nRet );
            if( nRet != DB_NOTFOUND )
            {                                                                                                                             
                RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Select table TB_ACTINFOTMP Error! sqlcode=[%d]", nRet );
                ERRTRACE(E_PB_PBANKCTLTMP_NOT_EXSIT,"��������Ҫά���ĺ������в���[%d]",nRet);/* �˴���ErrorTrace   ��������Ҫά���ĺ������в��� */
            }
            return ;
        } 

        /* ������������ */
        memcpy(wd_pbpbankctl.bank_id       ,wd_pbpbankctltmp.bank_id      ,sizeof(wd_pbpbankctltmp.bank_id      ));   
        memcpy(wd_pbpbankctl.whs_inq       ,wd_pbpbankctltmp.whs_inq      ,sizeof(wd_pbpbankctltmp.whs_inq      ));  
        memcpy(wd_pbpbankctl.whe_inq       ,wd_pbpbankctltmp.whe_inq      ,sizeof(wd_pbpbankctltmp.whe_inq      ));  
        memcpy(wd_pbpbankctl.whs_pay       ,wd_pbpbankctltmp.whs_pay      ,sizeof(wd_pbpbankctltmp.whs_pay      ));  
        memcpy(wd_pbpbankctl.whe_pay       ,wd_pbpbankctltmp.whe_pay      ,sizeof(wd_pbpbankctltmp.whe_pay      ));  
        wd_pbpbankctl.frequency11  = wd_pbpbankctltmp.frequency11  ;  
        memcpy(wd_pbpbankctl.his_inq_time2 ,wd_pbpbankctltmp.his_inq_time2,sizeof(wd_pbpbankctltmp.his_inq_time2));   
        memcpy( wd_pbpbankctl.cust_flag, wd_pbpbankctltmp.cust_flag, 1 ); 
        memcpy( wd_pbpbankctl.steod_flag, wd_pbpbankctltmp.steod_flag, 1 ); 
        memcpy( wd_pbpbankctl.stind_flag, wd_pbpbankctltmp.stind_flag, 1 );   
        
        nRet = DbsPBPBANKCTL(DBS_UPDATE,&wd_pbpbankctl);
        if( nRet != DB_OK  )
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"DbsPBPBANKCTL DBS_UPDATE=[%d]\n", nRet );                                                                                                                            
            RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Select table TB_ACTINFOTMP Error! sqlcode=[%d]", nRet );
            DbsPBPBANKCTL(DBS_CLOSE,&wd_pbpbankctl);
            return ;
        }      
    }
    
    /* ɾ���������в�����ʱ������ */
    nRet = DbsPBPBANKCTLTMP( DBS_DELETE, &wd_pbpbankctltmp ) ;
    if( nRet != DB_OK )
    {
        /* fail */
        ERRTRACE( E_DB_PBPBANKCTLTMP_DERR, "Delete PBPBANKCTLTMP ERROR! sqlcode=[%d]", nRet ); 
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBPBANKCTLTMP DBS_DELETE! sqlcode=[%d]", nRet );
        return;
    }
    
    /* ��¼����Ա������־�� */
    memset(sBuf,0,sizeof(sBuf));
    sprintf(sBuf,"�����к�[%s]\n��������[%s]",wd_pbpbankctltmp.bank_id,GetFlagName(8,&tis7022.sAuthType));
    
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        /* ��¼����Ա������־������ */
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        return ;
    }

}

void txn_7022PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );
	apitoa( TOTA_LABEL_LENGTH + sizeof(tos7022), sizeof(it_totw.label.msglng), it_totw.label.msglng );
	memcpy( it_totw.sTotaText, &tos7022, sizeof(tos7022) );
}

void txn_7022End( void )
{
    DbsPBPBANKCTL(DBS_CLOSE,&wd_pbpbankctl);
    DbsPBPBANKCTLTMP(DBS_CLOSE,&wd_pbpbankctltmp);
}

