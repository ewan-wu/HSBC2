/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  Convert module all oracle proc c fucntion.
 *
 *  $Id$
 *
 * FileName: cvt_oracle.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2010/06/17         zy                       Create.
 *
 */

#ifndef _CVT_ORACLE_H_20100617103748_
#define _CVT_ORACLE_H_20100617103748_

/*------------------------ Include files ------------------------*/

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define CVT_ORA_INQ_FETCH 1
#define CVT_ORA_INQ_CLOSE 2

#define DB_COM_INQ_ERR 9999

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/

#if 0
#pragma mark -
#pragma mark < Global functions declaration >
#endif
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif
    
    int InqOraExecSql(char *psSql);
    int InqOraInq(int nType, char *psSql);
    int InqOraFieldNum();
    char * InqOraGetField(int nIdx, int *pnValueLen);
    int InqOraSetBind(char *psValue, int nLen);
    
#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /* _CVT_ORACLE_H_20100617103748_ */
/*--------------------- End -------------------------------------*/
