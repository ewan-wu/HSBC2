/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ǿ��ǩ�˽��ף�������                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100730          Zhu Rui              Initial                     */
/************************************************************************/

#include "pbsysmng.h"

static struct TIS7052_GROUP
{
    char tlrno[8];
}tis7052;

static struct TOS7052_GROUP
{
    char null;
} tos7052;

static struct wd_pbtlrctl_area wd_pbtlrctl;
extern char    logfile[256];

void txn_7052Initial(void);
void txn_7052Process(void);
void txn_7052PutMessage(void);

void txn_7052(void)
{
	txn_7052Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7052Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_7052PutMessage();
}

void txn_7052Initial(void)
{
    memset(&wd_pbtlrctl,0,sizeof(wd_pbtlrctl));
    memset(&tis7052, 0, sizeof(tis7052));
    memcpy(&tis7052, it_tita.sTitaText, sizeof(tis7052));
    memset(&tos7052, 0, sizeof(tos7052));
}

void txn_7052Process(void)
{
    int     nRet = 0;
    char    sBuf[1500+1];
    
    memset(sBuf ,0  ,sizeof(sBuf));
    
    /*  1. ��ס��PBTLRCTL�н�������Ա�ļ�¼ */
    memcpy(wd_pbtlrctl.tlr_id   ,tis7052.tlrno,DLEN_TLRNO);
    memcpy(wd_pbtlrctl.dept_id  ,"000"  ,strlen("000"));
	
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "tlr_id =[%s]", wd_pbtlrctl.tlr_id  );
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "dept_id=[%s]", wd_pbtlrctl.dept_id );


    nRet = DbsPBTLRCTL(DBS_LOCK, &wd_pbtlrctl);
    if (nRet != 0)
    {
        /* fail */
        if(nRet == DB_NOTFOUND)
        {
    		ERRTRACE(E_TLR_NOTEXIST, "����Ա����ʧ�ܣ�tlrno[%s]", wd_pbtlrctl.tlr_id); 
			return;
        }
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL)
        	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL LOCK ERROR! sqlcode=[%d]", nRet );
    	ERRTRACE(E_DB_TB_TLRCTL_RERR, "����Ա����ʧ�ܣ�tlrno[%s]", wd_pbtlrctl.tlr_id); 
		return;
    }
    
    wd_pbtlrctl.status[0] = '0';
    GetCurrentDateAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbtlrctl.last_status_chg);
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbtlrctl.rec_updt_time);
    if (DbsPBTLRCTL(DBS_UPDATE, &wd_pbtlrctl) != 0)
    {
        /* fail */
        /*���ݿ��쳣*/
        RecTivoliLogC("PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DB Error!" );
        ERRTRACE(E_DB_TB_TLRCTL_WERR, "����Ա����ʧ�ܣ�tlrno[%s]", wd_pbtlrctl.tlr_id);
        return;
    }

    /*��ά����־*/
    sprintf(sBuf, "����Ա�����ɹ�,�������Ĳ���Ա[%.8s]", tis7052.tlrno);
    
    nRet = RecTlrLog(sBuf);
    if(nRet != DB_OK)
    {
        ERRTRACE(E_DB_TB_TLRLOG_IERR,"��¼������־��Ϣ����[%d]", nRet);
        return;
    }

    
}

void txn_7052PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy(it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos7052), sizeof(it_totw.label.msglng), it_totw.label.msglng);
	memcpy(it_totw.sTotaText, &tos7052, sizeof(tos7052));
}

void txn_7052End()
{
    DbsPBTLRCTL(DBS_CLOSE,&wd_pbtlrctl);
}
