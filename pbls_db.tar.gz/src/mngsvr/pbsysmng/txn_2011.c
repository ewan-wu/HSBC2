/************************************************************************/
/*                                                                      */
/* Product: Partner Bank Ling System                                    */
/*          manage module                                               */
/*   txn_2011                                                           */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ����Ա����ǿ�Ʊ��                                         */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20110407        HanMeirong            Initial                      */
/************************************************************************/
#include "pbsysmng.h"

extern char logfile[256];

static struct TIS2011_GROUP
{
	char	tlr_id[8];
	char	new_pswd[12];
} tis2011;

static struct TOS2011_GROUP
{
	char	null;
} tos2011;

void txn_2011Initial(void);
void txn_2011Process(void);
void txn_2011PutMessage(void);

void txn_2011(void)
{
	txn_2011Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_2011Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	txn_2011PutMessage();
}

void txn_2011Initial(void)
{  
	memset(&tis2011, 0, sizeof(tis2011));
	memcpy(&tis2011, it_tita.sTitaText, sizeof(tis2011));
	memset(&tos2011, 0, sizeof(tos2011));
}

void txn_2011Process(void)
{
	struct	wd_pbtlrctl_area	wdPbtlrctl;
	int		nRet = 0;
	char	sBuf[1500];


	char	log_work_flag[50+1];
	
	memset( &wdPbtlrctl, 0, sizeof(wdPbtlrctl) );
	
	
	memcpy( wdPbtlrctl.tlr_id, tis2011.tlr_id, 8 );
	memcpy( wdPbtlrctl.dept_id, "000",strlen("000"));
	
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctl.tlr_id=[%8.8s]\n",wdPbtlrctl.tlr_id);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"wdPbtlrctl.dept_id=[%3.3s]\n",wdPbtlrctl.dept_id);
	
	nRet = DbsPBTLRCTL(DBS_LOCK, &wdPbtlrctl );
	if( nRet != DB_OK && nRet != DB_NOTFOUND )
	{
		/* ��������ȡ���ݿ�������� */
		ERRTRACE( E_DB_PBTLRCTL_RERR, "DBS_FIND PBTLRCTL ERROR![%d]", nRet );
		if( nRet != DB_ISNULL )
			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL FIND ERROR! sqlcode=[%d]", nRet );
		return ;
	}

	else if( DB_NOTFOUND == nRet)
	{
		/* ����������Ա��Ϣ�����ڣ������޸ġ��� */
		ERRTRACE( E_DB_PBTLRCTL_NO_EXSIT, "����Ա��Ϣ�����ڣ������޸�![%d]", nRet );
		return ;
	}


	/* ǰ̨���� */
	memcpy( wdPbtlrctl.tlr_id, tis2011.tlr_id, 8 );
	memcpy( wdPbtlrctl.password,tis2011.new_pswd, sizeof(tis2011.new_pswd) );
	/* ��̨��ֵ */
	/* Modify by ZBR @ 2011-08-25 START */
	/* ǿ���޸������LASG_PSWD_CHG��Ϊ00000000������ǩ������0012�ж��Ƿ�ǿ���޸Ĺ����� */
	/* CommonGetCurrentDate(wdPbtlrctl.last_pswd_chg); */
	memcpy( wdPbtlrctl.last_pswd_chg,"00000000",8);
	/* Modify by ZBR @ 2011-08-25 END */
	
	printf("wdPbtlrctl.tlr_id=[%8.8s]\n",wdPbtlrctl.tlr_id);
	printf("wdPbtlrctl.dept_id=[%3.3s]\n",wdPbtlrctl.dept_id);
	printf("wdPbtlrctl.tlr_name=[%60.60s]\n",wdPbtlrctl.tlr_name);
	printf("wdPbtlrctl.work_flag=[%1.1s]\n",wdPbtlrctl.work_flag);
	printf("wdPbtlrctl.rights=[%20.20s]\n",wdPbtlrctl.rights);
	printf("wdPbtlrctl.add_dept=[%3.3s]\n",wdPbtlrctl.add_dept);
	printf("wdPbtlrctl.add_tlr=[%8.8s]\n",wdPbtlrctl.add_tlr);
	printf("wdPbtlrctl.add_date=[%20.20s]\n",wdPbtlrctl.add_date);
	
	/*���²���Ա��¼��*/ 
	nRet = DbsPBTLRCTL( DBS_UPDATE, &wdPbtlrctl );
	if( nRet != DB_OK )
	{
		/*�������ݿ����*/
		ERRTRACE( E_DB_PBTLRCTLTMP_IERR, "�������ʧ��[%d]", nRet );
		RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBTLRCTL UPDATE  ERROR! sqlcode=[%d]", nRet );
		DbsPBTLRCTL(DBS_CLOSE, &wdPbtlrctl );
		return ;
	}

	DbsPBTLRCTL(DBS_CLOSE, &wdPbtlrctl );
	/*write the operation log*/
	MSET(log_work_flag);
	strcpy(log_work_flag, (char *)GetFlagName(10,wdPbtlrctl.work_flag));
	
	sprintf( sBuf, "ά������[%s]\n����Ա����[%s]\n����Ա����[%s]\n��������[%s]\n��ɫID[%s]", 
	GetFlagName(7,"M"), 
	wdPbtlrctl.tlr_id ,
	wdPbtlrctl.tlr_name, 
	log_work_flag,
	wdPbtlrctl.rights );
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        ERRTRACE( E_DB_TB_TLRLOG_IERR, "��¼������־��Ϣ����[%d]", nRet);
        return ;
    }
	return ;
}

void txn_2011PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy(it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos2011), sizeof(it_totw.label.msglng), it_totw.label.msglng);

	memcpy(it_totw.sTotaText, &tos2011, sizeof(tos2011));
}

void txn_2011End()
{

}
