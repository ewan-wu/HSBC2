/************************************************************************/
/*                                                                      */
/* Product: BOA Parter Bank Link System                                 */
/*          transaction logic module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �ͻ���Ϣά����Ȩ                                        */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20100809          Zhu Rui              Initial                     */
/************************************************************************/

#include "pbsysmng.h"
extern char logfile[256];  

static struct TIS5104_GROUP
{
    char	sAuthType    ;       /* ��Ȩ���                       */  
    char   sBankId      [3 ];   /* �����к�                       */
    char   sCustActno   [35];   /* �ͻ��ں������˺�               */
    char   sCurcd       [3 ];   /* ����                           */
}tis5104;

static struct TOS5104_GROUP
{
	char	 null;
}tos5104;

static	struct wd_pbcustctl_area	    wd_pbcustctl;
static  struct wd_pbcustctltmp_area   wd_pbcustctltmp;
extern  char    logfile[256];

void txn_5104Initial(void);
void txn_5104Process(void);
void txn_5104PutMessage(void);

void txn_5104(void)
{
	txn_5104Initial();

	txn_5104Process();

	txn_5104PutMessage();
}

void txn_5104Initial(void)
{
	memset( &tis5104, 0, sizeof(tis5104) );
	memcpy( &tis5104, it_tita.sTitaText, sizeof(tis5104) );
	memset( &tos5104, 0, sizeof(tos5104) );	
	
	memset( &wd_pbcustctl   , 0, sizeof(wd_pbcustctl    ));
	memset( &wd_pbcustctltmp, 0, sizeof(wd_pbcustctltmp ));
}

void txn_5104Process( void )
{
    
    /********************************************
     *  �ֲ�������������ʼ��
     ********************************************/
    int		nRet = 0;
    char  sBuf[1500+1];
    char  str[6+1];
    
     /********************************************
     * ���ͻ�������ʱ����
     * �Ƿ������ά���ĸ�����¼
     ********************************************/
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"tis5104.sAuthType =[%c]\n",tis5104.sAuthType );
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"tis5104.sBankId   =[%3.3s]\n",tis5104.sBankId   );
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"tis5104.sCustActno=[%35.35s]\n",tis5104.sCustActno);
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"tis5104.sCurcd    =[%3.3s]\n",tis5104.sCurcd    );   
     
     
    memcpy(wd_pbcustctltmp.bank_id  , tis5104.sBankId   , sizeof(tis5104.sBankId    ));
    memcpy(wd_pbcustctltmp.actno    , tis5104.sCustActno, sizeof(tis5104.sCustActno ));
    memcpy(wd_pbcustctltmp.curcd    , tis5104.sCurcd    , sizeof(tis5104.sCurcd     ));
    
    nRet = DbsPBCUSTCTLTMP(DBS_LOCK,&wd_pbcustctltmp);
    if( nRet != DB_OK )
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,"DbsPBCUSTCTLTMP DBS_LOCK=[%d]\n", nRet);
        ERRTRACE(E_DB_PB_CUSTCTLTMP_RERR,"DBS_LOCK DbsPBCUSTCTLTMP [%d]", nRet); 
        DbsPBCUSTCTLTMP(DBS_CLOSE,&wd_pbcustctltmp);
        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
        	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTCTLTMP LOCK ERROR! sqlcode=[%d]", nRet );
        return ;
    }
    else if( nRet == DB_NOTFOUND )
    {
        ERRTRACE(E_DB_PB_CUSTCTLTMP_RERR,"���ݿ��쳣[%d]", nRet); 
        return;
    }
    
    /* �ж�¼�������Ƿ�ͬһ�� */
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," �ж�¼�������Ƿ�ͬһ�� "  );
    if( memcmp(wd_pbcustctltmp.mod_tlr  ,it_tita.label.tlrno    ,sizeof(it_tita.label.tlrno)) == 0 )
    {
        ERRTRACE( E_TXN_SAMEPERSON_ERR, "Md_tlrno=[%s],avp_tlrno=[%8.8s]", wd_pbcustctltmp.mod_tlr, it_tita.label.tlrno );
        return;
    }
    
    
    /* ���ͨ�� */
    if( tis5104.sAuthType == '1' )
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," ���ͨ�� "  );
        /* ��ֵwd_pbcustctl�ṹ */
        memcpy(wd_pbcustctl.bank_id  , tis5104.sBankId   , sizeof(tis5104.sBankId    ));
        memcpy(wd_pbcustctl.actno    , tis5104.sCustActno, sizeof(tis5104.sCustActno ));
        memcpy(wd_pbcustctl.curcd    , tis5104.sCurcd    , sizeof(tis5104.sCurcd     ));
        nRet = 0 ;
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," wd_pbcustctltmp.mode_type=[%c] ",wd_pbcustctltmp.mode_type[0]  );
        switch(wd_pbcustctltmp.mode_type[0])
        {
            case 'A':  /* new */
                memcpy(wd_pbcustctl.bank_id  , tis5104.sBankId      , sizeof(tis5104.sBankId    ));
                memcpy(wd_pbcustctl.actno    , tis5104.sCustActno   , sizeof(tis5104.sCustActno ));
                memcpy(wd_pbcustctl.curcd    , tis5104.sCurcd       , sizeof(tis5104.sCurcd     ));
                memcpy(wd_pbcustctl.status   , wd_pbcustctltmp.status,sizeof(wd_pbcustctl.status)-1);
                memcpy(wd_pbcustctl.name     , wd_pbcustctltmp.name , sizeof(wd_pbcustctl.name)-1);
                memcpy(wd_pbcustctl.sdate    , wd_pbcustctltmp.sdate, sizeof(wd_pbcustctl.sdate)-1);
                memcpy(wd_pbcustctl.edate    , wd_pbcustctltmp.edate, sizeof(wd_pbcustctl.edate)-1);
                wd_pbcustctl.mt940_seqno = wd_pbcustctltmp.mt940_seqno;
                wd_pbcustctl.mt942_seqno = wd_pbcustctltmp.mt942_seqno;
                memcpy(wd_pbcustctl.mod_tlr	 ,wd_pbcustctltmp.mod_tlr   ,sizeof(wd_pbcustctltmp.mod_tlr ));
                memcpy(wd_pbcustctl.mod_dept ,wd_pbcustctltmp.mod_dept   ,sizeof(wd_pbcustctltmp.mod_dept));
                memcpy(wd_pbcustctl.mod_time ,wd_pbcustctltmp.mod_time   ,sizeof(wd_pbcustctltmp.mod_time));
                memcpy(wd_pbcustctl.au_tlr	 ,it_tita.label.tlrno   ,sizeof(it_tita.label.tlrno ));  
                GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbcustctl.au_time); 
                GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbcustctl.rec_updt_time);             
                
                /* �����жϣ��Ƿ��Ѿ������� */
                nRet = DbsPBCUSTCTL( DBS_INSERT, &wd_pbcustctl );
                if( nRet != DB_OK )
                {   
                    ERRTRACE( E_DB_PB_CUSTCTL_IERR, "Insert Table PBCUSTCTL Error! sqlcode=[%d]",  nRet );
                    if( nRet == -1 )
                    {
                        ERRTRACE( E_TXN_RECORD_EXIST, " act_no=[%s]", wd_pbcustctl.actno );
                    }
                    DbsPBCUSTCTL(DBS_CLOSE,&wd_pbcustctl);
        			RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTCTL INSERT ERROR! sqlcode=[%d]", nRet );
                    return;
                }
                break;
            case 'M':
            case 'D':
                nRet =  DbsPBCUSTCTL(DBS_LOCK, &wd_pbcustctl);
                if( nRet != DB_OK && nRet != DB_NOTFOUND )
                {
                    ERRTRACE(E_DB_PB_CUSTCTL_IERR , "Insert Table TB_ACTINFO Error!sqlcode=[%d]",  nRet );
                    DbsPBCUSTCTL(DBS_CLOSE,&wd_pbcustctl);
                    if( nRet != DB_ISNULL )
                    	RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTCTL LOCK ERROR! sqlcode=[%d]", nRet );
                    return;
                }
                
                if( wd_pbcustctltmp.mode_type[0] == 'D' )
                {
                    #if 0
                    wd_pbcustctl.status[0] = CUSTCTL_STATUS_INVALID;
                    GetCurHstStlmDate(wd_pbcustctl.edate);
                    memcpy(wd_pbcustctl.mod_tlr	 ,wd_pbcustctltmp.mod_tlr   ,sizeof(wd_pbcustctltmp.mod_tlr ));
                    memcpy(wd_pbcustctl.mod_dept ,wd_pbcustctltmp.mod_dept   ,sizeof(wd_pbcustctltmp.mod_dept));
                    memcpy(wd_pbcustctl.mod_time ,wd_pbcustctltmp.mod_time   ,sizeof(wd_pbcustctltmp.mod_time));
					memcpy(wd_pbcustctl.del_tlr	,it_tita.label.tlrno   ,sizeof(it_tita.label.tlrno ));
                    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbcustctl.au_time); 
                    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbcustctl.rec_updt_time);
                    #endif
                    nRet = DbsPBCUSTCTL(DBS_DELETE, &wd_pbcustctl);
                    if( nRet != DB_OK )
                    {
                        ERRTRACE(E_DB_PB_CUSTCTL_IERR  , "Delete PBCUSTCTL ERROR! sqlcode=[%d]", nRet );
                        DbsPBCUSTCTL(DBS_CLOSE,&wd_pbcustctl);
                        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
                    		RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTCTL DELETE ERROR! sqlcode=[%d]", nRet );
                        return;
                    }
                }
                else if (wd_pbcustctltmp.mode_type[0] == 'M' )
                {
                    memcpy(wd_pbcustctl.bank_id  , tis5104.sBankId      , sizeof(tis5104.sBankId    )); 
                    memcpy(wd_pbcustctl.actno    , tis5104.sCustActno   , sizeof(tis5104.sCustActno )); 
                    memcpy(wd_pbcustctl.curcd    , tis5104.sCurcd       , sizeof(tis5104.sCurcd     )); 
                    wd_pbcustctl.status[0] = CUSTCTL_STATUS_VALID;
                    memcpy(wd_pbcustctl.name     , wd_pbcustctltmp.name , sizeof(wd_pbcustctl.name)-1); 
                    memcpy(wd_pbcustctl.mod_tlr	 ,wd_pbcustctltmp.mod_tlr   ,sizeof(wd_pbcustctltmp.mod_tlr ));
                    memcpy(wd_pbcustctl.mod_dept ,wd_pbcustctltmp.mod_dept   ,sizeof(wd_pbcustctltmp.mod_dept));
                    memcpy(wd_pbcustctl.mod_time ,wd_pbcustctltmp.mod_time   ,sizeof(wd_pbcustctltmp.mod_time));
                    memcpy(wd_pbcustctl.au_tlr	 ,it_tita.label.tlrno   ,sizeof(it_tita.label.tlrno ));
                    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbcustctl.au_time);
                    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_SYS, wd_pbcustctl.rec_updt_time);    
                    
                    nRet = DbsPBCUSTCTL( DBS_UPDATE, &wd_pbcustctl );
                    if( nRet != DB_OK )   
                    {
                        ERRTRACE( E_DB_PB_CUSTCTL_WERR, "DbsPBCUSTCTL DBS_UPDATE Error! sqlcode=[%d]", nRet );
                        DbsPBCUSTCTL(DBS_CLOSE,&wd_pbcustctl);
                        if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
                    		RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTCTL UPDATE ERROR! sqlcode=[%d]", nRet );
                        return;
                    }                            
                }
                break;
            default:
            {
                ERRTRACE( E_TXN_OPTYPE_ERR, "OPERATION ERROR! op_type=[%c]", wd_pbcustctltmp.mode_type );
                return ;
            }
        }
        nRet=DbsPBCUSTCTLTMP(DBS_DELETE,&wd_pbcustctltmp);
    	if(nRet != DB_OK )
    	{
        	ERRTRACE( E_DB_PB_CUSTCTLTMP_DERR, "OPERATION ERROR! Sqlcode=[%d]", nRet );
        	DbsPBCUSTCTLTMP(DBS_CLOSE,&wd_pbcustctltmp);
        	if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
				RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTCTLTMP DELETE ERROR! sqlcode=[%d]", nRet );
        	return;
    	}
    }
    else if( tis5104.sAuthType == '2')
    {
        if( (nRet = DbsPBCUSTCTLTMP(DBS_DELETE,&wd_pbcustctltmp)) != DB_OK )
        {
            ERRTRACE( E_DB_PB_CUSTCTLTMP_DERR, "OPERATION ERROR! op_type=[%c]", wd_pbcustctltmp.mode_type );
            DbsPBCUSTCTLTMP(DBS_CLOSE,&wd_pbcustctltmp);
            if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
				RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "DbsPBCUSTCTLTMP DELETE ERROR! sqlcode=[%d]", nRet );
            return;
        }
    }
    else
    {
        /* ��Ȩ�������ȷ */
        ERRTRACE( E_AUTH_TYPE_ERR, "AUTH TYPE ERROR! AuthType=[%c]", tis5104.sAuthType);
        return;
    }
    
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," ��¼����Ա������־��1"  );
        
    /* ��¼����Ա������־�� */
    memset(sBuf,0,sizeof(sBuf));
    /*zl add memo 20100920 begin*/
    memset(str,0,sizeof(str));
    if( tis5104.sAuthType == '1'){
    	memcpy(str,"1-��Ȩ",sizeof(str)-1);
    }else{
		memcpy(str,"2-�ܾ�",sizeof(str)-1);
    }
     /*zl add memo 20100920 end*/
    sprintf(sBuf,"��Ȩ���[%s]�����к�[%3.3s]�ͻ��ں������˺�[%35.35s]����[%3.3s]",
             str,wd_pbcustctltmp.bank_id,wd_pbcustctltmp.actno,wd_pbcustctltmp.curcd);
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," ��¼����Ա������־��2"  );
    nRet = RecTlrLog( sBuf );
    if( nRet != DB_OK )
    {
        /* ��¼����Ա������־������ */
        RecTivoliLogC( "PBLS", "MANAGER", TIVOLI_DATABASE, __FILE__, __LINE__, "Insert table PBtlrLog Error! sqlcode=[%d]", nRet );
        ERRTRACE( E_PB_RECORD_PBTLRLOG_ERR, "��¼����Ա������־������! op_type=[%1.1s]", tis5104.sAuthType);
        return ;
    }
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__," =====txn 5104 end====="  );       

}

void txn_5104PutMessage(void)
{
	it_totw.label.msgend = '1';
	it_totw.label.msgtype = it_tita.label.taskid[1];
	memcpy( it_totw.label.msgno, it_tita.label.txno, DLEN_TXNCD );
	apitoa( TOTA_LABEL_LENGTH + sizeof(tos5104), sizeof(it_totw.label.msglng), it_totw.label.msglng );
	memcpy( it_totw.sTotaText, &tos5104, sizeof(tos5104) );
}

void txn_5104End( void )
{
    DbsPBCUSTCTL(DBS_CLOSE, &wd_pbcustctl);
    DbsPBCUSTCTLTMP(DBS_CLOSE,&wd_pbcustctltmp);
}
