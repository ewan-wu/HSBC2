#include <stdio.h>

int main(int argc, char **argv)
{
	char sFilename[100];
	char LineBuf[100];
	char sFilenameCnt[100];
	char sFilenameDst[100];
	char sCmd[100];
	int  nRet;
	int  nFlag = 100;
	char *sNum;
	char *sStr;
	char *sLineBuf;
	char sCnt[100];
	char sBuff[1000000];
	FILE *fp, *fpSrc, *fpDst;
	int  i = 0;
	int  nBuffLen = 0;
	if(argc != 2){

        fprintf(stdout, "Usage: spfile  <filename>\n");

        exit(1);

    }
	
	memset(sFilename, 0, sizeof(sFilename));
    memset(sFilenameCnt, 0, sizeof(sFilenameCnt));
    memset(sFilenameDst, 0, sizeof(sFilenameDst));
    sprintf(sFilename, "%s", argv[1]);
    sprintf(sFilenameCnt, "%s.count", sFilename);
    sprintf(sFilenameDst, "%s.dst", sFilename);
    sprintf(sCmd, "%s/sbin/count.sh %s %s",getenv("APPL"), sFilename, sFilenameCnt);
    nRet = system(sCmd);
    
	if(nRet == 0){

        printf("system nRet=[%d]\n", nRet);

        fp = fopen(sFilenameCnt, "r");

        if (fp == NULL){

            printf("Couldn't open data file! [%s]\n", sFilenameCnt);

            fclose(fp);

            return -1;

        }
		while(1){

            if(fgets(LineBuf,100, fp) == NULL){

                printf("read null\n");

                break;

            }

            sprintf(sCnt, "%s", LineBuf); 
			
			break;

        }

		fclose(fp);	
        
		printf("sCnt=[%s]\n", sCnt);
        
		fpSrc = fopen(sFilename, "r");

        if (fpSrc == NULL){

            printf("Couldn't open data file! [%s]\n", sFilename);

            fclose(fp);

            return -1;

        }

		while(1){

            if(fgets(LineBuf,100, fpSrc) == NULL){

                printf("read null\n");

                break;

            }

            if(strstr(LineBuf, "RecCount") != NULL){
				
				sNum = sCnt;
				sLineBuf = LineBuf;
				
				while(*sLineBuf != '\0'){
				
					if(*sLineBuf >= '0' && *sLineBuf <= '9'){
					
						*sLineBuf = *sNum++;
						
						if(*sNum == '\0'){
						
							*sLineBuf = *(sLineBuf + 1);
							nFlag = i;	
						}
					
					}
					
					if(i > nFlag){
					
						*sLineBuf = *(sLineBuf + 1);
					
					}
					
					sLineBuf++;	
					i++;
				
				}
				
				printf("LineBuf is [%s]\n", LineBuf);

            }

			sprintf(sBuff + nBuffLen, "%s", LineBuf);
			nBuffLen = strlen(sBuff);
        
		}

        fclose(fpSrc);	
		
		fpDst = fopen(sFilenameDst, "w");

        if (fpDst == NULL){

            printf("Couldn't open data file! [%s]\n", sFilenameDst);

            fclose(fpDst);
		}

		fwrite(sBuff, sizeof(char), strlen(sBuff), fpDst);
        fclose(fpDst);
	
	}
}
