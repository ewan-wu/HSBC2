
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <time.h>
#include <signal.h>
#include <malloc.h>
#include <memory.h>
#include <assert.h>
#include <errno.h>
#include <dirent.h>

#include "ipc.h"
#include "glb_def.h"
#include "glb_ext.h"
#include "glb_err.h"
#include "msglog.h"
#include "msgque.h"
#include "htlog.h"

//#define E_SYS_SYSTEM_ERR    1830
#define E_GS_GENERAL_ERROR  1831
#define E_DB_DECLARE_ERR    1832
#define E_DB_OPEN_ERR       1833
#define E_DB_FETCH_ERR      1834

T_TOTW_LABTEX     it_totw;
T_TXCOM_AREA      it_txcom;
T_TITA_LABTEX     it_tita;
