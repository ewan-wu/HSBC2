/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: msq.c                                                       */
/* DESCRIPTIONS: UNIX message queue programming support.                     */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

/*==========================================================================*

	EXPORT(S)
	~~~~~~~~~
	int MsqCreate (key_t key, mode_t mode);
	int MsqCreateExcl (key_t key, mode_t mode);
	int MsqGet (key_t key, mode_t mode);
	int MsqClose (int msqid);
	int MsqCount (int msqid);
	int MsqSend (int msqid, T_Msgbuf *pmsg, size_t nbytes);
	int MsqSendType (int msqid, T_Msgbuf *pmsg, size_t nbytes, long mtype);
	int MsqRecvType (int msqid, T_Msgbuf *pmsg, size_t nbytes, long mtype);
	int MsqRecv (int msqid, T_Msgbuf *pmsg, size_t nbytes);
	int MsqClear (int msqid);
	int MsqChown (int msqid, uid_t uid, gid_t gid);
	int MsqChmod (int msqid, mode_t mode);
	void DumpC (FILE *fp, const char *buf, size_t nbytes);
	void MsgbufDump (FILE *fp, T_Msgbuf *pmsg, size_t nbytes);
	int MsqDump (FILE *fp, int msqid, int count);
	int MsqInfo (int msqid, struct msqid_ds *pqds);
	int MsgbufInput (FILE *fp, T_Msgbuf *pmsg, size_t msgsz, int flag);
	int MsqWrite (FILE *fp, int msqid, int flag);

*==========================================================================*/

#include	"msq.h"

/*--------------------------------------------------------------------------*

	NAME			MsqCreate: create message queue if non-exist;
							     otherwise get current message queue

	USAGE		  	int MsqCreate (key_t key, mode_t mode);

	PARAM			key: message queue key
					mode: message queue access mode

	RETURN	   >= 0 -- success; message queue identifier
					-1   -- failure

*--------------------------------------------------------------------------*/

int MsqCreate (key_t key, mode_t mode) {

	return (msgget (key, IPC_CREAT | (mode & C_MsqPerm)));

	} /* end of MsqCreate() */

/*--------------------------------------------------------------------------*

	NAME			MsqCreateExcl: create message queue if non-exist;
										otherwise return error flag (excl)

	USAGE		  	int MsqCreateExcl (key_t key, mode_t mode);

	PARAM			key: message queue key
					mode: message queue access mode

	RETURN	   >= 0 -- success; message queue identifier
					-1   -- failure

*--------------------------------------------------------------------------*/

int MsqCreateExcl (key_t key, mode_t mode) {

	return (msgget (key, IPC_CREAT | IPC_EXCL | (mode & C_MsqPerm)));

	} /* end of MsqCreateExcl() */

/*--------------------------------------------------------------------------*

	NAME			MsqGet: get message queue identifier

	USAGE		  	int MsqGet (key_t key, mode_t mode);

	PARAM			key: message queue key
					mode: message queue access mode

	RETURN	   >= 0 -- success; message queue identifier
					-1   -- failure

*--------------------------------------------------------------------------*/

int MsqGet (key_t key, mode_t mode) {

	return (msgget (key, mode & C_MsqPerm));

	} /* end of MsqGet() */

/*--------------------------------------------------------------------------*

	NAME			MsqClose: close message queue

	USAGE		  	int MsqClose (int msqid);

	PARAM			msqid: message queue identifier

	RETURN	   0  -- success
					-1 -- failure

*--------------------------------------------------------------------------*/

int MsqClose (int msqid) {

	struct msqid_ds qds;

	return (msgctl (msqid, IPC_RMID, &qds));

	} /* end of MsqClose() */

/*--------------------------------------------------------------------------*

	NAME			MsqCount: count number of messages on queue

	USAGE		  	int MsqCount (int msqid);

	PARAM			msqid: message queue identifier

	RETURN	   >= 0  -- success; number of messages on queue
					-1    -- failure

*--------------------------------------------------------------------------*/

int MsqCount (int msqid) {

	struct msqid_ds qds;

	if (msgctl (msqid, IPC_STAT, &qds) == -1) return (-1); /* failure */

	return (qds.msg_qnum); /* number of messages on queue */

	} /* end of MsqCount() */

/*--------------------------------------------------------------------------*

	NAME			MsqSend: send message to message queue

	USAGE		  	int MsqSend (int msqid, T_Msgbuf *pmsg, size_t nbytes);

	PARAM			msqid: message queue identifier
					pmsg: ptr to message buffer (T_Msgbuf)
               nbytes: message text length in bytes

	RETURN	   0  -- success
					-1 -- failure

*--------------------------------------------------------------------------*/

int MsqSend (int msqid, T_Msgbuf *pmsg, size_t nbytes) {

	/* IPC method: wait (blocking) */
	return (msgsnd (msqid, (struct msgbuf *) pmsg, nbytes, 0));

	} /* end of MsqSend() */

/*--------------------------------------------------------------------------*

	NAME			MsqSendType: send message of specified type to message queue

	USAGE		  	int MsqSendType (int msqid, T_Msgbuf *pmsg, size_t nbytes,
							long mtype);

	PARAM			msqid: message queue identifier
					pmsg: ptr to message buffer (T_Msgbuf)
					nbytes: message text length in bytes
					mtype: message type

	RETURN	   0  -- success
					-1 -- failure

*--------------------------------------------------------------------------*/

int MsqSendType (int msqid, T_Msgbuf *pmsg, size_t nbytes, long mtype) {

	pmsg->mtype = mtype;
	return (MsqSend (msqid, pmsg, nbytes));

	} /* end of MsqSendType() */

/*--------------------------------------------------------------------------*

	NAME			MsqRecvType: read message of specified type from msg queue

	USAGE		  	int MsqRecvType (int msqid, T_Msgbuf *pmsg, size_t nbytes,
							long mtype);

	PARAM			msqid: message queue identifier
					pmsg: ptr to message buffer (T_Msgbuf)
					nbytes: message text length in bytes
					mtype: message type

	RETURN	   >= 0 -- success; actual number of bytes placed into mtext
					-1   -- failure

*--------------------------------------------------------------------------*/

int MsqRecvType (int msqid, T_Msgbuf *pmsg, size_t nbytes, long mtype) {

	/* IPC method: wait (blocking) */
	return (msgrcv (msqid, (struct msgbuf *) pmsg, nbytes, mtype, 0));

	} /* end of MsqRecvType() */

/*--------------------------------------------------------------------------*

	NAME			MsqRecv: read first message from msg queue (of any type)

	USAGE		  	int MsqRecv (int msqid, T_Msgbuf *pmsg, size_t nbytes);

	PARAM			msqid: message queue identifier
					pmsg: ptr to message buffer (T_Msgbuf)
					nbytes: message text length in bytes

	RETURN	   >= 0 -- success; actual number of bytes placed into mtext
					-1   -- failure

*--------------------------------------------------------------------------*/

int MsqRecv (int msqid, T_Msgbuf *pmsg, size_t nbytes) {

	/* get first message in queue of any type; method: wait (blocking) */
	return (MsqRecvType (msqid, pmsg, nbytes, C_MsqAnyT));

	} /* end of MsqRecv() */

/*--------------------------------------------------------------------------*

	NAME			MsqClear: clear message queue

	USAGE		  	int MsqClear (int msqid);

	PARAM			msqid: message queue identifier

	RETURN	   0  -- success
					-1 -- failure

*--------------------------------------------------------------------------*/

int MsqClear (int msqid) {

	T_MsgbufL msgbuf; /* large message */
   int flag; /* return flag of MsqCount() */

	/* read out all messages on queue */
	while ((flag = MsqCount (msqid)) > 0)
		if (MsqRecv (msqid, (T_Msgbuf *) &msgbuf, C_MsgbufL) < 0)
			return (-1); /* failure */

	if (flag == -1) return (-1); /* failure */
   return (0); /* success */

	} /* end of MsqClear() */

/*--------------------------------------------------------------------------*

	NAME			MsqChown: change message queue owner and/or group

	USAGE		  	int MsqChown (int msqid, uid_t uid, gid_t gid);

	PARAM			msqid: message queue identifier
					uid: user id
					gid: group id

	RETURN	   0  -- success
					-1 -- failure

*--------------------------------------------------------------------------*/

int MsqChown (int msqid, uid_t uid, gid_t gid) {

	struct msqid_ds qds;

	if (msgctl (msqid, IPC_STAT, &qds) == C_MsqNone) return (-1);

	if (uid != C_MsqNone) qds.msg_perm.uid = uid;
	if (gid != C_MsqNone) qds.msg_perm.gid = gid;

	if (msgctl (msqid, IPC_SET, &qds) == -1) return (-1);

	return (0); /* success */

	} /* end of MsqChown() */

/*--------------------------------------------------------------------------*

	NAME			MsqChmod: change message queue access mode

	USAGE		  	int MsqChmod (int msqid, mode_t mode);

	PARAM			msqid: message queue identifier
					mode: message queue access mode

	RETURN	   0  -- success
					-1 -- failure

*--------------------------------------------------------------------------*/

int MsqChmod (int msqid, mode_t mode) {

	struct msqid_ds qds;

	if (msgctl (msqid, IPC_STAT, &qds) == -1) return (-1);

	qds.msg_perm.mode &= (~ C_MsqPerm);
	qds.msg_perm.mode |= (mode & C_MsqPerm);

	if (msgctl (msqid, IPC_SET, &qds) == -1) return (-1);

	return (0); /* success */

	} /* end of MsqChmod() */

/*--------------------------------------------------------------------------*

	NAME			DumpC: dump n bytes to file in char

	USAGE		  	void DumpC (FILE *fp, const char *buf, size_t nbytes);

	PARAM			fp: ptr to output file
					buf: ptr to char buffer
					nbytes: number of bytes to dump

	RETURN      none

*--------------------------------------------------------------------------*/

void DumpC (FILE *fp, const char *buf, size_t nbytes) {

	int i;

	for (i = 0; i < nbytes; i++) {
		if (isprint (buf[i]) && buf[i] != '|') {
			fprintf (fp, "%c|", buf[i]);
         continue;
         }
		fprintf (fp, "%02Xh|", buf[i]);
		} /* end of for */

   fprintf (fp, "|"); /* end of data */

	} /* end of DumpC() */

/*--------------------------------------------------------------------------*

	NAME			MsgbufDump: dump message buffer to file

	USAGE		  	void MsgbufDump (FILE *fp, T_Msgbuf *pmsg, size_t nbytes);

	PARAM			fp: ptr to output file
					pmsg: ptr to message buffer
					nbytes: mtext size in bytes

	RETURN      none

*--------------------------------------------------------------------------*/

void MsgbufDump (FILE *fp, T_Msgbuf *pmsg, size_t nbytes) {
   /* mtext size & message type*/
	fprintf (fp, "MsgLen = %d  MsgType = %d\n", nbytes, pmsg->mtype); 
	/*
	DumpC (fp, pmsg->mtext, nbytes);
	*/
	DebugString(pmsg->mtext, nbytes, __LINE__);

	} /* end of MsgbufDump() */

/*--------------------------------------------------------------------------*

	NAME			MsqDump: dump messages on queue to file

	USAGE		  	int MsqDump (FILE *fp, int msqid, int count);

	PARAM			fp: ptr to output file
   				msqid: message queue identifier
               count: number of messages to dump; C_MsqAll to dump all msgs

	RETURN      >=0 -- success; number of messages dumped
					-1  -- failure

*--------------------------------------------------------------------------*/

int MsqDump (FILE *fp, int msqid, int count) {

	T_MsgbufL msgbuf; /* large message */
   int cnmsg = 0; /* count of messages dumped */
   int cnbyte; /* number of bytes received */

	while (MsqCount (msqid) > 0) {
   	if (cnmsg >= count && count != C_MsqAll) break;
      memset (&msgbuf, 0, sizeof (msgbuf));
      if ((cnbyte = MsqRecv (msqid, (T_Msgbuf *) &msgbuf, C_MsgbufL)) == -1)
      	return (-1);
		MsgbufDump (fp, (T_Msgbuf *) &msgbuf, cnbyte);
		fputc ('\n', fp); /* newline for msg end */
		fflush (fp); /* flush file buffer */
      cnmsg++;
      }

   return (cnmsg); /* success */

	} /* end of MsqDump() */

/*--------------------------------------------------------------------------*

	NAME			MsqInfo: get message queue information

	USAGE		  	int MsqInfo (int msqid, struct msqid_ds *pqds);

	PARAM			msqid: message queue identifier
               pqds: ptr to msqid data structure

	RETURN      0  -- success
					-1 -- failure

*--------------------------------------------------------------------------*/

int MsqInfo (int msqid, struct msqid_ds *pqds) {

	if (msgctl (msqid, IPC_STAT, pqds) == -1) return (-1);

	return (0); /* success */

	} /* end of MsqInfo() */

/*--------------------------------------------------------------------------*

	NAME			_GetToken: get a data token from msg data file

	USAGE		  	int _GetToken (FILE *fp);

	PARAM			fp: ptr to msg data file

	RETURN      >= 0     -- success; token data
               C_MsgEnd -- success; msg data end
   				C_MsgErr -- failure; msg data error

*--------------------------------------------------------------------------*/

static int _GetToken (FILE *fp) {

	char str[5]; /* token buffer */
	char ch; /* char data */
   int hex; /* hex data */
	int i = 0;

	while (! feof (fp)) {
		if ((ch = fgetc (fp)) == '|') break; /* token end */
		str[i++] = ch;
		if (i > 4) return (C_MsgErr); /* overflow */
		}
	str[i] = 0;

   switch (i) {
   	case 0: /* msg end */
      	return (C_MsgEnd);
      case 1: /* char data */
      	return (str[0]);
      case 3: /* hex data */
      	if (sscanf (str, "%xh", &hex) != 1) return (C_MsgErr);
         return (hex);
      default: /* msg data error */
      	return (C_MsgErr);
   	}

	} /* end of _GetToken() */

/*--------------------------------------------------------------------------*

	NAME			MsgbufInput: get a message from msg data file

	USAGE		  	int MsgbufInput (FILE *fp, T_Msgbuf *pmsg, size_t msgsz,
							int flag);

	PARAM			fp: ptr to msg data file
   				pmsg: ptr to message buffer
               msgsz: mtext maximum length
               flag: to check length or not (C_MsgCheck or C_MsgNoCheck)

	RETURN      >= 0     -- success; mtext length
               C_MsgEOF -- success; msg data file EOF
   				C_MsgErr -- failure; msg data error
               C_MsgOVF -- failure; msgbuf overflow

*--------------------------------------------------------------------------*/

int MsgbufInput (FILE *fp, T_Msgbuf *pmsg, size_t msgsz, int flag) {

	int msglen;
	int token; /* data token */
	int cnbyte = 0; /* number of bytes in mtext */
	int t; /* temp storage for fscanf() */

   if ((t = fscanf (fp, "!len=%d", &msglen)) == EOF) return (C_MsgEOF);
   if (t != 1) return (C_MsgErr);
   if ((t = fscanf (fp, "!mtype=%d", &pmsg->mtype)) == EOF) return (C_MsgEOF);
   if (t != 1) return (C_MsgErr);
   if ((t = fscanf (fp, "!mtext=")) == EOF) return (C_MsgEOF);
   if (t != 0) return (C_MsgErr);

	while ((token = _GetToken (fp)) != C_MsgEnd) {
   	if (cnbyte >= msgsz) return (C_MsgOVF);
   	if (token == C_MsgErr) return (C_MsgErr);
      pmsg->mtext[cnbyte++] = token;
      }                                       

   if (flag == C_MsgCheck && cnbyte != msglen) return (C_MsgErr);

	return (cnbyte);

	} /* end of MsgbufInput() */

/*--------------------------------------------------------------------------*

	NAME			MsqWrite: write messages from msg data file to queue

	USAGE		  	int MsqWrite (FILE *fp, int msqid, int flag);

	PARAM			fp: ptr to msg data file
               msqid: message queue identifier
   				flag: to check length or not (C_MsgCheck or C_MsgNoCheck)

	RETURN      >= 0     -- success; number of messages written
               C_MsgErr -- failure; msg data error
               C_MsgOVF -- failure; msgbuf overflow

*--------------------------------------------------------------------------*/

int MsqWrite (FILE *fp, int msqid, int flag) {

	T_MsgbufL msgbuf;
   int cnmsg = 0; /* msg count */
   int cnbyte; /* mtext length */

   while (! feof (fp)) {
   	memset (&msgbuf, 0, sizeof (msgbuf));
      cnbyte = MsgbufInput (fp, (T_Msgbuf *)&msgbuf, C_MsgbufL, flag);
      if (cnbyte == C_MsgEOF) break;
      if (cnbyte == C_MsgErr) return (C_MsgErr);
		if (cnbyte == C_MsgOVF) return (C_MsgOVF );
     	if (MsqSend (msqid, (T_Msgbuf *) &msgbuf, cnbyte) == -1) return (-1);
      cnmsg++;
		fgetc (fp);
      }

   return (cnmsg);

	} /* end of MsqWrite() */
