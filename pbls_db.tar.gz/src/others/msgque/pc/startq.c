/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: startq.c                                                    */
/* DESCRIPTIONS: The tool to run(start up) a CERTAIN toplink message queue.  */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>
#include "msgque.h"

void main(int argc, char **argv)
{
    int xbasekey;
	int nMsgQueKey;
    int nMsgQueID;
	short nMaxQueue;
	char sFileName[80];
	
	if (argc != 2) 
	{
		printf("\n Argument error!\n");
		return;
	}

/*	strcpy(sFileName, getenv("TOPCFG"));
	xbasekey = GetProfileInt("MSGQUE", "BASE_KEY", sFileName);
	nMaxQueue = GetProfileInt("MSGQUE", "QUEUE_NUM", sFileName);
*/
    sscanf(argv[1], "%i", &nMsgQueKey);
/*	if ((nMsgQueKey <= xbasekey) || (nMsgQueKey > xbasekey + nMaxQueue))
	{
		printf("\n Key Invalid!\n");
		return;
	}
*/
    nMsgQueID = msgget( nMsgQueKey, MSG_FLAG | IPC_CREAT );
    if( nMsgQueID < 0 )
    {
        printf("Create message queue %d error\n", nMsgQueKey);
        getchar();
        exit(-1);
    }
    else
        printf("Create message queue %d ok\n", nMsgQueKey);
}

