/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: stopq.c                                                     */
/* DESCRIPTIONS: The tool to kill(shutdown) a CERTAIN toplink message queue. */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>
#include <msgque.h>

void main(int argc, char **argv)
{
	int ret;
    int xbasekey;
	int nMsgQueKey;
    int nMsgQueID;
    short nMaxQueue;
    char sFileName[80];

	if (argc != 2)
	{
		printf("\n Argument error!\n");
		return;
	}

/*    strcpy(sFileName, getenv("TOPCFG"));
    xbasekey = GetProfileInt("MSGQUE", "BASE_KEY", sFileName);
    nMaxQueue = GetProfileInt("MSGQUE", "QUEUE_NUM", sFileName);
*/
	sscanf(argv[1], "%i", &nMsgQueKey);
/*	if ((nMsgQueKey <= xbasekey) || (nMsgQueKey > xbasekey + nMaxQueue))
	{
		printf("\n Key Invalid!\n");
		return;
	}
*/           
    nMsgQueID = msgget(nMsgQueKey, MSG_FLAG);
    if( nMsgQueID < 0 )
    {
        printf("message queue %d not exist\n", nMsgQueKey);
    }
    else
    {
        ret = msgctl(nMsgQueID, IPC_RMID, NULL);
        if(ret < 0)
        {
            printf("Delete message queue %d error\n", nMsgQueKey);
        }
    }
}

