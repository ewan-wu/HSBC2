/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: dumpq.c                                                     */
/* DESCRIPTIONS: The tool to dump toplink message queues.                    */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

#include	<stdio.h>
#include	<stdlib.h>
#include <string.h>
#include	"msq.h"

extern int errno;

/*--------------------------------------------------------------------------*

	NAME			main: dump messages on queue

	USAGE		  	void main (int argc, char ** argv);

	PARAM			argc: arguments count
					argv: arguments list

	EXIT			0 -- success
   					1 -- failure
*--------------------------------------------------------------------------*/

void main (int argc, char ** argv) {

	key_t msqkey;   /* msg queue key */
	char *sCount;   /* points to count of msgs to be dumped */
	long  msqid;     /* msg queue ID */
	int  count;     /* count of msgs to be dumped */
	int  cnmsg;     /* count of msgs dumped */
	int  nTotal;    /* total of msgs dumped */
	int  i;

	setbuf (stdout, NULL);
	setbuf (stderr, NULL);

	if (argc < 2) 
	{ /* check params count */

		fprintf (stderr, "Usage: dumpq { <MsgQueKey|MsgID>[:Count] ... }\n"
							  "       Count(def.): -1 (all)\n");
		exit (1);
	}

    for( i = 1, nTotal = 0; i < argc; i++ ) 
	{ 
		/* get params */
   		if( sscanf( argv[i], "%i", &msqkey ) != 1 ) 
		{
   			fprintf( stderr, "DUMPQ: Cannot get MsgQueKey from \"%s\"\n", 
						argv[i] );
   			exit(1);
      	}

		if( ( sCount = strchr( argv[i], ':' ) ) == NULL ) 
		   count = C_MsqAll; /* dump all msg from the queue */
		else if( sscanf( ++sCount, "%i", &count ) != 1 ) 
		{
   			fprintf( stderr, "DUMPQ: Cannot get Count from \"%s\"\n", argv[i] );
   			exit (1);
   		}

   		if( msqkey == IPC_PRIVATE || 
			( msqid = MsqGet (msqkey, C_MsqR ) ) == -1 ) 
		{
			msqid = msqkey;
   		}
   
   		if( (cnmsg = MsqDump( stdout, msqid, count ) ) == -1 ) 
		{
   			fprintf( stderr, 
					"DUMPQ: Cannot dump message from queue %d (0x%X) :: %s\n",
   				   msqkey, msqkey, strerror (errno));
   			exit (1);
   		}

   		printf( "DUMPQ: %d message(s) dumped from queue %d (0x%X)\n",
   				   cnmsg, msqkey, msqkey);

      	nTotal += cnmsg;

   	}

	if( argc > 2 ) printf( "DUMPQ: total = %d\n", nTotal );

} /* end of main() */
