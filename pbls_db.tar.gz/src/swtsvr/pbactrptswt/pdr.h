/* typedef structures for PDR file begin */
typedef struct 	//M940 Header
{
	char sLogo[10];
	char sDate[8];
	char sTime[6];
	char sFileseq[2];
	char sTotc[5];
	char sTotl[5];
	char sTota[5];
}T_HBHDM940;
typedef struct 	//M940 body
{
	char sSeqno[2];
	char sOpen_date[8];
	char sPayeractno[32];
	char sPayername[28];
	char sObal_indicator;
	char sObal_date[6];
	char sObal_curcy[3];
	char sObal_amount[15];
	char sTrns_date[6];
	char sPost_Date[4];
	char sTrns_indicator;
	char sTrans_amount[15];
	/*modify by tianchangjin on 20110804 begin*/
	char sNarrative1[70];
	char sNarrative2[70];
	char sNarrative3[70];
	char sNarrative4[70];
	/*modify by tianchangjin on 20110804 end*/
	char sCbal_indicator;
	char sCbal_date[6];
	char sCbal_curcy[3];
	char sCbal_amount[15];
	char sRsv1[35];
	char sRsv2[130];
	char sRsv3[1];
}T_HBBDM940;



typedef struct 	//File Header
{
	char	RecordType[6];
	char	FileCreationDate[8];
	char	FileCreationTime[6];
	char	FileSourceIdentifier[7];
	char	Filler[559];
}T_FHDR01;
typedef struct 	//Statement Header
{
	char	RecordType[6];
	char	AccountIdentifier[35];
	char	Statementdate[8];
	char	AccountCurrencyCode[3];
	char	SenderID[21];
	char	StatementNumber[5];
	char	SequenceNumber[3];
	char	TransactionReferenceNumber[16];
	char	RelatedReferenceNumber[16];
	char	FileType[2];
	char	Filler[471];
}T_FSHD10;
typedef struct 	//Statement Header Routing Information
{
	char	RecordType[6];
	char	ExternalSystemAddress[35];
	char	ExternalSystemAddressQualifier[3];
	char	ExternalSystemDepartment[35];
	char	ExternalSystemDepartmentQualifier[3];
	char	Filler[504];
}T_FSHD11;
typedef struct 	//Statement Opening/Closing Balance
{
	char	RecordType[6];
	char	Balancedetailcreationdate[8];
	char	OpeningAvailableBalance[15];
	char	OpeningAvailableBalanceDebitCreditIndicator[1];
	char	OpeningBalance[15];
	char	OpeningBalanceDebitCreditIndicator[1];
	char	ClosingAvailableBalance[15];
	char	ClosingAvailableBalanceDebitCreditIndicator[1];
	char	ClosingBalance[15];
	char	ClosingBalanceDebitCreditIndicator[1];
	char	StatementTotalDebits[15];
	char	StatementTotalCredits[15];
	char	Filler[478];
}T_FOCB20;
typedef struct 	//Statement Future Available Balance
{
	char	RecordType[6];
	char	ForwardBalancedetaildateOne[8];
	char	ForwardBalanceamountOne[15];
	char	ForwardBalanceDebitCreditIndicatorOne[1];
	char	ForwardBalancedetaildateTwo[8];
	char	ForwardBalanceamountTwo[15];
	char	ForwardBalanceDebitCreditIndicatorTwo[1];
	char	ForwardBalancedetaildateThree[8];
	char	ForwardBalanceamountThree[15];
	char	ForwardBalanceDebitCreditIndicatorThree[1];
	char	ForwardBalancedetaildateFour[8];
	char	ForwardBalanceamountFour[15];
	char	ForwardBalanceDebitCreditIndicatorFour[1];
	char	ForwardBalancedetaildateFive[8];
	char	ForwardBalanceamountFive[15];
	char	ForwardBalanceDebitCreditIndicatorFive[1];
	char	Filler[460];
}T_FFAB30;
typedef struct 	//Statement Information to Account Owner
{
	char	RecordType[6];
	char	StatementInformation[65];
	char	Filler[515];
}T_FTXT35;
typedef struct 	//Statement Line
{
	char	RecordType[6];
	char	ValueDate[8];
	char	InterestValueDate[8];
	char	EntryDate[8];
	char	TransactionDate[8];
	char	DebitCreditIndicator[1];
	char	FundsCode[1];
	char	TransactionAmount[15];
	char	TransactionTypeIdentificationCode[4];
	char	SupplementaryDetails[34];
	char	SourceApplicationCode[3];
	char	TransactionCode[2];
	char	EntryType[4];
	char	AccountOwnerReference[6];
	char	AccountOwnerInformation[3];
	char	PostingType[1];
	char	BAICode[3];
	char	Filler[471];
}T_FSLD40;
typedef struct 	//Statement Line Extended Information
{
	char	RecordType[6];
	char	PaymentCode[3];
	char	SubPaymentCode[3];
	char	InstructionReference[3];
	char	RemittanceReference[20];
	char	PaymentItemConsolidationIndicator[1];
	char	BulkPaymentReference[35];
	char	PricingRoutingCode[2];
	char	STPPaymentIndicator[1];
	char	BusinessFunctionCode[3];
	char	DepositItemCount[6];
	char	BeneficiaryISOResidenceCode[2];
	char	RemittanceStatusCode[1];
	char	OriginalRegisteredCurrencyCode[4];
	char	OriginalRegisteredAmount[15];
}T_FSLD41_1;
typedef struct	//UTF-16
{
	char	OriginatingPartyinLocalLanguage[96];
	char	BeneficiaryPartyInLocalLanguage[96];
	char	BeneficiaryInformationInLocalLanguage[280];
}T_FSLD41_2;
typedef struct
{
	char	Filler[9];
}T_FSLD41_3;
typedef struct 	//Statement Line Reference Information
{
	char	RecordType[6];
	char	TransactionRefNumberfortheAccount[35];
	char	SendingBanksReference[35];
	char	GBSReference[35];
	char	Filler[475];
}T_FRFF45;
typedef struct 	//Statement Line Information to Account Owner
{
	char	RecordType[6];
	char	InformationtoAccountOwnerDescription1[50];
	char	InformationtoAccountOwnerDescription2[50];
	char	Filler[480];
}T_FSLT50;
typedef struct 	//File Trailer
{
	char	RecordType[6];
	char	Filecreationdate[8];
	char	Filecreationtime[6];
	char	FileSourceIdentifier[7];
	char	TrailerRecordCount[7];
	char	Filler[552];
}T_FTRL99;
/* typedef structures for PDR file end */
