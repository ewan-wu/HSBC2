/*****************************************************************************/
/*  Shanghai HuaTeng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2003. All rights reserved.                                 */
/*                                                                           */
/*  File:        pbpaidswt.c                                                 */
/*  Description: process 01 Message and Gen PDR CRD BAL                      */
/*                                                                           */
/*  History      Date     Description                                        */
/*  ~~~~~~~      ~~~~     ~~~~~~~~~~~                                        */
/*****************************************************************************/

#include "pbrptswt.h"
char	logfile[256];
T_TITA_LABTEX     it_tita;	//for RecTlrLog()

#define _DEBUG

#define DBGLOG(...) HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__, __VA_ARGS__);

void QuitTerminate();
void vSwtPAIDReqProcess(void *,int);
void vSwtPAIDRspProcess(void *,int);
void vSwtPAIDSysTmrProcess(void *,int);
void vSwtPAIDOtherSwtProcess(void *,int);  
static  char    sRetStr[256];

int main(int argc, char *argv[])
{
    short   nReturnCode;
    char    sIpcMsgInText[MAX_PACKET_LEN];
    long    lMsgSource;
    short   nMsgInLen;
    char    sTxnNo[CR_CLSTXNNO_LEN+1];
    int     nRet =0;

    /* ������ */
    if ( argc != 2 )
    {
        fprintf(stdout, "Usage: pbpaidswt < logfile >\n");
        exit(0);
    }

    sigset(SIGTERM, QuitTerminate);

    setbuf(stdout,NULL);

    /* ������־ */
    nReturnCode = GetLogName(argv[1], logfile);
    if (nReturnCode!= 0 )
    {
        ErrReport(CI_RPTSWT,
        	EI_PROCESS,
        	0,
        	CI_SEVERITY_SYSERROR,
        	ES_PROCESS_EXIT);
        fprintf(stderr, "GetLogName error !\n");
    }

    /* ��ʼ��PAIDSWT */
    nReturnCode = nInitMsgQue(CI_RPTSWT, logfile);
    if (nReturnCode != 0)
    {
        ErrReport( CI_RPTSWT ,
        	    EI_PROCESS ,
        	    nReturnCode,
        	    CI_SEVERITY_SYSERROR,
        	    "PAIDSWT��ʼ����");
        HtLog(HTLM_ERR, "nInitMsgQue(CI_RPTSWT) error");
        exit(1);
    }

	nRet = nCommonMsqInit(CI_PAIDCOMM);
    if (nRet != 0)
    {
        ErrReport(CI_RPTSWT, 
                  EI_MESSAGEQUEUE, 
                  0, 
                  CI_SEVERITY_SYSERROR,
                  ES_MSGQ_NET_COMM_CONNECT);
    	HtLog(HTLM_ERR, "nCommonMsqInit(CI_PAIDCOMM) error");                  
        exit(1);
    }    

	nRet = nCommonMsqInit(CI_TOCTL_SEQ);
    if (nRet != 0)
    {
        ErrReport(CI_RPTSWT, 
                  EI_MESSAGEQUEUE, 
                  0, 
                  CI_SEVERITY_SYSERROR,
                  ES_MSGQ_NET_COMM_CONNECT);
    	HtLog(HTLM_ERR, "nCommonMsqInit(CI_TOCTL_SEQ) error");                  
        exit(1);
    }    

    HtLog(HTLM_COM, "PAIDSWT: Init Switch End\n");

    /* ��ѭ�� */
    while(1)
    {
        DBGLOG("Waiting for MsqRecv:");
    
        /* ����Ϣ�������ȡ��Ϣ */
        nMsgInLen=0;
        memset(sIpcMsgInText, 0, sizeof(sIpcMsgInText));
        nReturnCode = nCommonMsqRecv(&nMsgInLen, sIpcMsgInText, &lMsgSource, CI_RPTSWT);  
        if (nReturnCode != 0) 
        {
            HtLog(HTLM_ERR, "Exit from MsqRecv:[%d]\n", nReturnCode);
            ErrReport(CI_RPTSWT,
                    EI_MESSAGEQUEUE,
                    nReturnCode,
                    CI_SEVERITY_SYSERROR,
                    ES_MSGQ_SWT_READ);
            RecTivoliLogC( "PBLS", "PBRPTSWT", TIVOLI_MESSAGEQ, __FILE__, __LINE__,"CommonMsqRecv Fail! ERRCODE[%d]", nReturnCode );
            exit(1);
        }
    
    DBGLOG("<<<The Message start>>>\n");   
    HtDebugString(logfile, sIpcMsgInText, nMsgInLen, __FILE__, __LINE__);
    
    
    /* �ж���Ϣ��Դ���ֱ��� */
    switch (lMsgSource)
    {
        case CI_PAIDBDG:
    	      break;
    	case CI_SYSTMR:
            vSwtPAIDSysTmrProcess(sIpcMsgInText,nMsgInLen);
    		    break;
    	case CI_CCBSWT:
    	case CI_ICBCINSWT:
    	case CI_CITICSWT:
    		    break;
    	default:
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Receive unknown message, nMsgSource=[%d]\n", lMsgSource);
            break;
    }
    
    HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"<<<The Message end>>>\n");
    } /*end while */
}

void QuitTerminate(int sig)
{
    short nRet;
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nPAIDSWT PROCESS(%d) Normal[%d] EXIT AT %s\n", getpid(), sig, GetSystemTime());
    ErrReport(CI_RPTSWT,
            EI_PROCESS,
            sig, 
       	    CI_SEVERITY_SYSERROR,
            "PAIDSWT���������˳�");
    DbDisConnect();
    exit(0);
}


/****************************************************************************/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:                                                               */
/****************************************************************************/
void vSwtPAIDSysTmrProcess(void *sIpcMsgInText,int iLen)
{
    char						*pIpcText;
    int							nRet;

    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Enter vSwtPAIDSysTmrProcess() ...\n");

    pIpcText = sIpcMsgInText;

    /**********************************************************************/
    /* PDR����������                                                      */
    /**********************************************************************/
    if (memcmp(pIpcText, "PAIDPDR", 7) == 0)
    {
		nRet = nPAIDGenPDR(sIpcMsgInText, logfile);
		if(nRet < 0)
		{
			HtLog(HTLM_ERR, "nPAIDGenPDR nRet[%d]", nRet);
			return;
		}
        return;
    }

    /**********************************************************************/
    /* CDR����������                                                      */
    /**********************************************************************/
    if (memcmp(pIpcText, "PAIDCDR", 7) == 0)
    {
		nRet = nPAIDGenCDR(sIpcMsgInText, logfile);
		if(nRet < 0)
		{
			HtLog(HTLM_ERR, "nPAIDGenCDR nRet[%d]", nRet);
			return;
		}
        return;
    }


    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Normal Exit vSwtPAIDSysTmrProcess() ...\n");

    return;
}


