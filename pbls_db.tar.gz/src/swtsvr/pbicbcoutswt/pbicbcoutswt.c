/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: pbicbcoutswt.c                                              */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/

#include "pbicbcoutswt.h"
char    logfile[256];
static char cfgfile[256];/**�����ļ�·��**/
T_ICBC_GROUPHEADER icbc_groupheader;
T_BANK_INFO        bank_info;

T_TITA_LABTEX     it_tita;  //for RecTlrLog()

void QuitTerminate();
void vSwtICBCSysTmrProcess(void *sIpcMsgInText);
void vSwtICBCOprTmrProcess(void *sIpcMsgInText);


int main(int argc, char *argv[])
{
    short   nReturnCode;
    char    sIpcMsgInText[MAX_PACKET_LEN];
    long    lMsgSource;
    short   nMsgInLen;
    char    sTxnNo[CR_CLSTXNNO_LEN+1];
    long    lTxnNo;
    int nRet;

    if ( argc != 2 )
    {
        fprintf(stdout, "Usage: icbcswt < logfile >\n");
        exit(0);
    }

    sigset(SIGTERM, QuitTerminate);

    setbuf(stdout,NULL);

    nReturnCode = GetLogName(argv[1], logfile);
    if (nReturnCode!= 0 )
    {
        ErrReport(CI_ICBCSWT,
            EI_PROCESS,
            0,
            CI_SEVERITY_SYSERROR,
            ES_PROCESS_EXIT);
        fprintf(stderr, "GetLogName error !\n");
    }

    nReturnCode = nInitMsgQue(CI_ICBCOUTSWT, logfile);
    if (nReturnCode != 0)
    {
        ErrReport( CI_ICBCSWT ,
            EI_PROCESS ,
            nReturnCode,
            CI_SEVERITY_SYSERROR,
            "ICBCSWT��ʼ����");
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "ICBCSWT: Init Msg Que Error!\n");
        exit(1);
    }
    char api_log_file[256];
    memset(api_log_file, 0, sizeof(api_log_file));
    sprintf(api_log_file, "%s/log/pbicbcoutswt_api.log", getenv("APPL"));
    char api_cmd[512];
    memset(api_cmd, 0, sizeof(api_cmd));
    sprintf(api_cmd, "touch %s", api_log_file);
    system(api_cmd);


    /***��������ʱ���ã�������־��Topmq���м�������ʼ��***/
    nRet = ICBC_API_INIT(api_log_file,  ICBC_API_OUTSRC_SVRID);
    if (nRet != 0)
    {
        ErrReport(CI_PAIDSWT,
                  EI_MESSAGEQUEUE,
                  0,
                  CI_SEVERITY_SYSERROR,
                  ES_MSGQ_NET_COMM_CONNECT);
        HtLog(HTLM_ERR, "ICBC_API_INIT error(%d)", nRet);
        exit(1);
    }

    /**��ʼ��PBLS����ͷ**begin**/
    memset(&icbc_groupheader, 0, sizeof(icbc_groupheader));
    nGetICBCGroupHeader(&icbc_groupheader);

    memset(&bank_info, 0, sizeof(bank_info));
    nGetBankInfo(&bank_info);
    /**��ʼ��PBLS����ͷ**end**/

    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"ICBCSWT: Init Switch End\n");

    while(1)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Waiting for MsqRecv: \n");

        nMsgInLen=0;
        memset(sIpcMsgInText, 0, sizeof(sIpcMsgInText));

        nReturnCode = nCommonMsqRecv(&nMsgInLen, sIpcMsgInText, &lMsgSource, CI_ICBCOUTSWT);
        if (nReturnCode != 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Exit from MsqRecv:[%d]\n", nReturnCode);
            ErrReport(CI_ICBCSWT,
                EI_MESSAGEQUEUE,
                nReturnCode,
                CI_SEVERITY_SYSERROR,
                ES_MSGQ_SWT_READ);
            RecTivoliLogC( "PBLS", "PBICBCOUTSWT", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "CommonMsqRecv ERROR!ERRCODE[%d]", nReturnCode );
            exit(1);
        }

        HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"<<<The Message start>>>\n");
        HtDebugString(logfile, sIpcMsgInText, nMsgInLen, __FILE__, __LINE__);

        memset(sTxnNo, 0, sizeof(sTxnNo));
        memcpy(sTxnNo, sIpcMsgInText, CR_CLSTXNNO_LEN);
        lTxnNo = atol(sTxnNo);
        /***************ICBC****BEGIN**************/

        switch (lMsgSource)
        {
            case CI_SYSTMR:
            case CI_OPRMNG:
                    vSwtICBCSysTmrProcess(sIpcMsgInText);
                    break;
            case CI_OPRTMR:
                    vSwtICBCOprTmrProcess(sIpcMsgInText);
                    break;
            default:
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                    "Receive unknown message, nMsgSource=[%d]\n", lMsgSource);
                    break;
        }


        HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"<<<The Message end>>>\n");
    } /* while */

    return 0;
}

void QuitTerminate(int sig)
{
    short nRet;
    HtLog(HTLM_COM, "ICBCSWT PROCESS(%d) Normal[%d] EXIT AT %s\n", getpid(), sig, GetSystemTime());
    ErrReport(CI_ICBCSWT,
      EI_PROCESS,
      sig,
          CI_SEVERITY_SYSERROR,
      "ICBCSWT���������˳�");
    //ȫ�����
    ICBC_API_END();
    DbDisConnect();
    exit(0);
}

/****************************************************************************/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:                                                               */
/****************************************************************************/
void vSwtICBCSysTmrProcess(void *sIpcMsgInText)
{
    char                        *pIpcText;
    int                         nRet;
    int                         nRet1;
    int                         nRet2;
    int snd_priority;
    char sTemp[9];
    HtLog(HTLM_COM, "Enter vSwtICBCSysTmrProcess() ...\n");

    pIpcText = sIpcMsgInText;

    /***************************************************************/
    /* ��03����                                                    */
    /***************************************************************/
    /* ��ȡ��·���������ļ���,�õ����ķ������ȼ�*/
    memset(cfgfile, 0, sizeof(cfgfile));
    sprintf(cfgfile, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);
    if (pflGetProfileString("SND_FIRST", "SND_PRIORITY", sTemp,8, cfgfile) == 0)
    {
        snd_priority = atoi(sTemp);
    }
    else
    {
        snd_priority = 7;
    }
    /* ��ȡ��·���������ļ��� */        
    if (memcmp(pIpcText, "STEOD", 5) == 0)
    {
        nRet = nChkPBSTEODFlag(PBLS_BANK_ID_ICBC, "0");
        if(nRet!=0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"�����Ѿ����ʹ���...\n");
            return;
        }
        
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"STEOD���ľ��������ȼ���..[%d].\n",snd_priority);
        if(snd_priority==7)
        {        
            nRet2 = nIcbcGenAndSendMsg07(sIpcMsgInText, 1);
            if (nRet2 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }
            
            nRet1 = nIcbcGenAndSendMsg03(sIpcMsgInText, 1);
            if (nRet1 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"������ϸ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"������ϸ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }
        }
        else
        {
            nRet1 = nIcbcGenAndSendMsg03(sIpcMsgInText, 1);
            if (nRet1 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"������ϸ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"������ϸ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }  
            nRet2 = nIcbcGenAndSendMsg07(sIpcMsgInText, 1);
            if (nRet2 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }          
        }


        if(nRet1 == 0 && nRet2 == 0)
        {
            nRet = nSetPBSTEODFlag(PBLS_BANK_ID_ICBC, "1");
        }
    }


    /***************************************************************/
    /* 03���ĵĲ���                                                */
    /***************************************************************/
    else if (memcmp(pIpcText, "ADHOCSTEOD", 10) == 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"ADHOCSTEOD���ľ��������ȼ���..[%d].\n",snd_priority);
        if(snd_priority==7)
        {
            nRet2 = nIcbcGenAndSendMsg07(sIpcMsgInText, 2);
            if (nRet2 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }   
            nRet1 = nIcbcGenAndSendMsg03(sIpcMsgInText, 2);
            if (nRet1 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03 AD HOC���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03 AD HOC���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }
        }
        else
        {
            nRet1 = nIcbcGenAndSendMsg03(sIpcMsgInText, 2);
            if (nRet1 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03 AD HOC���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03 AD HOC���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }
            
            nRet2 = nIcbcGenAndSendMsg07(sIpcMsgInText, 2);
            if (nRet2 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }                     
        }

        if(nRet1 == 0 && nRet2 == 0)
        {
            nRet = nSetPBSTEODFlag(PBLS_BANK_ID_ICBC, "1");
        }
    }


    /***************************************************************/
    /* ��11����                                                    */
    /***************************************************************/
    else if (memcmp(pIpcText, "STIND", 5) == 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"STIND���ľ��������ȼ���..[%d].\n",snd_priority);
        if(snd_priority==7)
        {
            nRet2 = nIcbcGenAndSendMsg07(sIpcMsgInText, 3);
            if (nRet2 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }
            
            nRet1 = nIcbcGenAndSendMsg03(sIpcMsgInText, 3);
            if (nRet1 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }
        }
        else
        {
            nRet1 = nIcbcGenAndSendMsg03(sIpcMsgInText, 3);
            if (nRet1 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"03���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }  
            nRet2 = nIcbcGenAndSendMsg07(sIpcMsgInText, 3);
            if (nRet2 == 0)
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ������� ...\n");
            }
            else
            {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"����ѯ���ķ��ʹ���ʧ�� [%d]\n", nRet);
            }
                      
        }


    }

    /***************************************************************/
    /* ǰ̨���ô��ǽ���ָ������ʵʱ��ѯʱ                 */
    /***************************************************************/
    if (memcmp(pIpcText, "PAYINQ", 6) == 0)
    {
        nRet = nIcbcGenAndSendMsg05(sIpcMsgInText, logfile);
        if (nRet == 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"05���ķ��ʹ������� ...\n");
        }
        else
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"05���ķ��ʹ���ʧ�� [%d]\n", nRet);
        }
        return;
    }
    
    /***************************************************************/
    /* Intra-Day errmsg                                         */
    /***************************************************************/
    else if (memcmp(pIpcText, "ERRMSG ", 6) == 0)
    {
        return;
    }

    if(nRet == 0)
    {
        DbCommitTxn();
    }
    else
    {
        DbRollbackTxn();
    }

    HtLog(HTLM_COM, "Normal Exit vSwtICBCSysTmrProcess() ...\n");

    return;
}

/****************************************************************************/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:                                                               */
/****************************************************************************/
void vSwtICBCOprTmrProcess(void *sIpcMsgInText)
{
    char                        *pIpcText;
    char                        sTime[15];
    int                         nRet;

    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "Enter vSwtICBCOprTmrProcess() ...\n");

    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);

    pIpcText = sIpcMsgInText;

    /***************************************************************/
    /* ��01����                                                    */
    /* OPRTMR�������ĸ�ʽ��TXNPAY(6)+ ID(16)                       */
    /***************************************************************/
    if (memcmp(pIpcText, "TXNPAY", 6) == 0)
    {
        nRet = nIcbcGenAndSendMsg01(sIpcMsgInText, logfile);
        if (nRet == 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"01���ķ��ʹ������� ...\n");
        }
        else
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"01���ķ��ʹ���ʧ�� [%d]\n", nRet);
        }
        return;
    }

    /***************************************************************/
    /* ��05����                                                    */
    /***************************************************************/
    if (memcmp(pIpcText, "PAYINQ", 6) == 0)
    {
        nRet = nIcbcGenAndSendMsg05(sIpcMsgInText, logfile);
        if (nRet == 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"05���ķ��ʹ������� ...\n");
        }
        else
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"05���ķ��ʹ���ʧ�� [%d]\n", nRet);
        }
        return;
    }

    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "Normal Exit vSwtICBCOprTmrProcess() ...\n");
    if(nRet == 0)
    {
        DbCommitTxn();
    }
    else
    {
        DbRollbackTxn();
    }
    return;
}
