/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: pbicbcinswt.c                                              */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/

#include "pbicbcinswt.h"

char	logfile[256];

void QuitTerminate();

int main(int argc, char *argv[])
{
    short   nReturnCode;
    char	  sTxnNo[CR_CLSTXNNO_LEN+1];
    long	  lTxnNo;
    char    sRetStr[256+1];
    char    sPkgNo[5+1];
    int     iPkgNo;
    int     nRet;
	struct	wd_pbicbcinq_area	wd_pbicbcinq;
    
    
    T_ICBC_API_IPCMSG     tIcbcApiIpcmsg;
	
    if ( argc != 2 )
    {
        fprintf(stdout, "Usage: icbcswt < logfile >\n");
        exit(0);
    }

    sigset(SIGTERM, QuitTerminate);

    setbuf(stdout,NULL);

    /* ������־ */
    nReturnCode = GetLogName(argv[1], logfile);
    if (nReturnCode!= 0 )
    {
        ErrReport(CI_ICBCINSWT,
        	EI_PROCESS,
        	0,
        	CI_SEVERITY_SYSERROR,
        	ES_PROCESS_EXIT);
        fprintf(stderr, "GetLogName error !\n");
    }

    /* ��ʼ����Ϣ���� */
    nReturnCode = nInitMsgQue(CI_ICBCINSWT, logfile);
    if (nReturnCode != 0)
    {
        ErrReport( CI_ICBCINSWT ,
        	EI_PROCESS ,
        	nReturnCode,
        	CI_SEVERITY_SYSERROR,
        	"ICBCSWT��ʼ����");
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        	"ICBCSWT: Init Msg Que Error!\n");
        exit(1);
    }

    nReturnCode = nInitMsgQue(CI_PAIDSWT, logfile);
    if (nReturnCode != 0)
    {
        ErrReport( CI_ICBCINSWT ,
        	EI_PROCESS ,
        	nReturnCode,
        	CI_SEVERITY_SYSERROR,
        	"E3SWT��ʼ����");
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        	"ICBCSWT: Init E3SWT Msg Que Error!\n");
        exit(1);
    }
    
    /*added by tsx 2016-11-17 begin*/
    nReturnCode = nInitMsgQue(CI_ACTRPTSWT, logfile);
    if (nReturnCode != 0)
    {
        ErrReport( CI_ICBCINSWT ,
        	EI_PROCESS ,
        	nReturnCode,
        	CI_SEVERITY_SYSERROR,
        	"ICBCSWT��ʼ����");
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        	"CI_ACTRPTSWT: Init Msg Que Error!\n");
        exit(1);
    }
   /* added by tsx 2016-11-17 end*/
   
    char api_log_file[256];
    memset(api_log_file, 0, sizeof(api_log_file));
    sprintf(api_log_file, "%s/log/pbicbcinswt_api.log", getenv("APPL"));
	char api_cmd[512];
	memset(api_cmd, 0, sizeof(api_cmd));
	sprintf(api_cmd, "touch %s", api_log_file);
	system(api_cmd);
    nRet = ICBC_API_INIT(api_log_file, ICBC_API_OUTDEST_SVRID);
    if (nRet != 0)
    {
        ErrReport(CI_PAIDSWT, 
                  EI_MESSAGEQUEUE, 
                  0, 
                  CI_SEVERITY_SYSERROR,
                  ES_MSGQ_NET_COMM_CONNECT);
    	HtLog(HTLM_ERR, "ICBC_API_INIT error(%d)", nRet);                  
        exit(1);
    }
    

    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"ICBCSWT: Init Switch End\n");

    while(1)
    {
        /* ����CALL_ICBC_RECV������Ϣ */
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Waiting for MsqRecv: \n");
        memset( &tIcbcApiIpcmsg    ,   0   ,sizeof(tIcbcApiIpcmsg));
        memset( sPkgNo    ,   0   ,sizeof(sPkgNo));
        
        nReturnCode = ICBC_API_RECV(&tIcbcApiIpcmsg);
        if( nReturnCode != 0 )
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Exit from MsqRecv:[%d]\n", nReturnCode);
            ErrReport(CI_ICBCINSWT,
                EI_MESSAGEQUEUE,
                nReturnCode,
                CI_SEVERITY_SYSERROR,
                ES_MSGQ_SWT_READ);
            exit(1);
        }
        
        HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "\n����ID=[%16.16s]\n���ı��=[%5.5s]\n��������=[%8.8s]\n"
                "ԭ����ID=[%16.16s]\nԭ���ı��=[%5.5s]\nԭ��������=[%8.8s]"
                "\ncResndFlg=[%c]\nsExtData=[%32.32s]",
                tIcbcApiIpcmsg.sId, tIcbcApiIpcmsg.sPkgNo, tIcbcApiIpcmsg.sWorkDate,
                tIcbcApiIpcmsg.sOId, tIcbcApiIpcmsg.sOPkgNo, tIcbcApiIpcmsg.sOWorkDate,
                tIcbcApiIpcmsg.cResndFlg, tIcbcApiIpcmsg.sExtData);
                
        /* ȡ�����ĺ� */
        memcpy(sPkgNo   ,tIcbcApiIpcmsg.sPkgNo ,sizeof(sPkgNo) - 1);
        
        HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"���ı��=[%s]\n",sPkgNo);
        
        if(memcmp(sPkgNo, ICBC_BANK_DLTY01, strlen(ICBC_BANK_DLTY01)) == 0)
        {
            iPkgNo = ICBC_BANK_DLTY01_VALUE;
        }
        else
        {
            iPkgNo = atoi(sPkgNo);
        }
        
        
        /* ���ݷ��صı��ı�ŷֱ���ö�Ӧ�ĺ����������� */
        /* �ڸ������в������������������ĵĴ���д�ڲ�ͬ�ĺ����� */
        switch(iPkgNo)
        {
			case 0:
				/* ����ICBCFE�����ı��� ��¼��TVILILOG */
                HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"ICBCFE����[%s], id[%.16s], ԭ����[%.2s], ԭID[%.16s]\n",
                	tIcbcApiIpcmsg.sExtData, tIcbcApiIpcmsg.sId, 
                	tIcbcApiIpcmsg.sOPkgNo, tIcbcApiIpcmsg.sOId);

				if(memcmp(tIcbcApiIpcmsg.sOPkgNo, ICBC_RMB_PAYMENT_REQ, 5) != 0
				    && memcmp(tIcbcApiIpcmsg.sOPkgNo, ICBC_FCY_PAYMENT_REQ, 5) != 0)
				{
					//ICBC����0000 ���� 2-����ʧ��
				    nRet = UpdICBCInq(tIcbcApiIpcmsg.sOId, "2", 0);
					if(nRet != 0)
					{
						HtLog(HTLM_ERR, "update pbicbcinq error! [%d]", nRet);
					}
					else
					{
												HtLog(HTLM_COM, "update pbicbcinq success");
					}
				}
				//
				else
				{
				    //ICBC����0000 ���ǽ����� ����pcicbctxn 4-����ʧ��
				    nRet = UpdPbicbctxnInq(tIcbcApiIpcmsg.sOId, "4", 0);
					if(nRet != 0)
					{
						HtLog(HTLM_ERR, "update pbicbcinq error! [%d]", nRet);
					}
					else
					{
						HtLog(HTLM_COM, "update pbicbcinq success");
					}				    
				}

			    //������Ϣ��ر� 2-��Ӧ��
			    nRet = UpdMonitor(tIcbcApiIpcmsg.sOId, "2");
				if(nRet != 0)
				{
					HtLog(HTLM_ERR, "update pbmsgmonitor error! [%d]", nRet);
				}
				else
				{
					HtLog(HTLM_COM, "update pbmsgmonitor success");
				}
				break;
            case ICBC_RMB_PAYMENT_RSP_VALUE:
            case ICBC_FCY_PAYMENT_RSP_VALUE:
                /* �������ǽ���Ӧ���� */
                nRet = ProcessIcbcMsg02(&tIcbcApiIpcmsg);
                if( nRet != 0 )
                {
                    HtLog(HTLM_ERR, "���ǽ���Ӧ���Ĵ���ʧ��=[%d]\n", nRet);
                }
				else
                {
                    HtLog(HTLM_COM, "���ǽ���Ӧ���Ĵ����ɹ�\n");
                }
                break;
            case ICBC_ACT_DETAILS_RSP_VALUE:
                /* �����˻���ϸ��ѯӦ���� */
                nRet = ProcessIcbcMsg04(&tIcbcApiIpcmsg);
                if( nRet != 0 )
                {
                    HtLog(HTLM_ERR, "�˻���ϸ��ѯӦ���Ĵ���ʧ��=[%d]\n", nRet);
                }
				else
                {
                    HtLog(HTLM_COM, "�˻���ϸ��ѯӦ���Ĵ����ɹ�\n");
                }
                break;
            case ICBC_RMB_INQUIRY_RSP_VALUE:
            case ICBC_FCY_INQUIRY_RSP_VALUE:
                /* ��������״̬��ѯӦ���� */
                nRet = ProcessIcbcMsg06(&tIcbcApiIpcmsg);
                if( nRet != 0 )
                {
                    HtLog(HTLM_ERR, "����״̬��ѯӦ���Ĵ���ʧ��=[%d]\n", nRet);
                }
				else
                {
                    HtLog(HTLM_COM, "����״̬��ѯӦ���Ĵ����ɹ�\n");
                }
                break;
            case ICBC_ACT_BALANCE_RSP_VALUE:
                /* �����˻�����ѯӦ���� */
                nRet = ProcessIcbcMsg08(&tIcbcApiIpcmsg);
                if( nRet != 0 )
                {
                    HtLog(HTLM_ERR, "�˻�����ѯӦ���Ĵ���ʧ��=[%d]\n", nRet);
                }
				else
                {
                    HtLog(HTLM_COM, "�˻�����ѯӦ���Ĵ����ɹ�\n");
                }
                break;
            case ICBC_BANK_DLTY01_VALUE:
                /**�������ж��˱��� **/
                nRet = ProcessIcbcMsgDlty(&tIcbcApiIpcmsg);
                if( nRet != 0 )
                {
                    HtLog(HTLM_ERR, "���ж��˱��Ĵ���ʧ��=[%d]\n", nRet);
                }
				else
                {
                    HtLog(HTLM_COM, "���ж��˱��Ĵ����ɹ�\n");
                }
                break;
            default:
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"�Ƿ��ı��ı��=[%s]\n", sPkgNo);
                break;
        }
        
		//�ɹ�ʱ�ύ���񣬴���ʱ�ع�
		if(0 == nRet)
		{
			DbCommitTxn();
		}
		else
		{
			DbRollbackTxn();
		}
		
        HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"<<<The Message end>>>\n");
    } /* while */
    ICBC_API_END();
    return 0;
}

void QuitTerminate(int sig)
{
    short nRet;
    HtLog(HTLM_COM, "ICBCSWT PROCESS(%d) NORMAL[%d] EXIT\n", getpid(), sig);
    ErrReport(CI_ICBCINSWT,
      EI_PROCESS,
      sig, 
      CI_SEVERITY_SYSERROR,
      "ICBCSWT���������˳�");
    ICBC_API_END();
    DbDisConnect();
    exit(0);
}
