/*****************************************************************************/
/*  Shanghai HuaTeng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2003. All rights reserved.                                 */
/*                                                                           */
/*  File:        pbhubswt.c                                                 */
/*  Description: process 01 Message and Gen PDR CRD BAL                      */
/*                                                                           */
/*  History      Date     Description                                        */
/*  ~~~~~~~      ~~~~     ~~~~~~~~~~~                                        */
/*****************************************************************************/

#include "pbhubswt.h"
char	logfile[256];
static  char    cfgfile[256];
static  long    isRepair;
/* Add by ZBR 2011-08-10 START */
/* ��HUBͨѶ�������෢��5�������ʼ� */
static  int mail_snd_count = 5;
/* Add by ZBR 2011-08-10 END */

T_ICBC_GROUPHEADER icbc_groupheader;
T_BANK_INFO        bank_info;

#define _DEBUG

#define DBGLOG(...) HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__, __VA_ARGS__);

void QuitTerminate();
void vSwtHUBReqProcess(void *,int);
int  nSwtHUBReqPAY1Process(void *,int, char *);
void vSwtHUBReqBALEProcess(void *,int, char *);
void nSwtHUBReqLOGNProcess(void *,int, char *);
void nSwtHUBReqLOGFProcess(void *,int, char *);
void nSwtHUBReqH111Process(void *,int, char *);
void nSwtHUBReqH000Process(void *,int, char *);
void vSwtHUBOtherSwtProcess(void *,int);  
void vSwtHUBSysTmrProcess(void *,int);  
static  char    sRetStr[256];

int main(int argc, char *argv[])
{
    short   nReturnCode;
    char    sIpcMsgInText[MAX_PACKET_LEN];
    long    lMsgSource;
    short   nMsgInLen;
    char    sTxnNo[CR_CLSTXNNO_LEN+1];
    int     nRet =0;
    char    sTemp[9];

    /* ������ */
    if ( argc != 2 )
    {
        fprintf(stdout, "Usage: pbhubswt < logfile >\n");
        exit(0);
    }

    sigset(SIGTERM, QuitTerminate);

    setbuf(stdout,NULL);

    /* ������־ */
    nReturnCode = GetLogName(argv[1], logfile);
    if (nReturnCode!= 0 )
    {
        ErrReport(CI_PAIDSWT,
        	EI_PROCESS,
        	0,
        	CI_SEVERITY_SYSERROR,
        	ES_PROCESS_EXIT);
        fprintf(stderr, "GetLogName error !\n");
    }

    /* ��ʼ��HUBSWT */
    nReturnCode = nInitMsgQue(CI_PAIDSWT, logfile);
    if (nReturnCode != 0)
    {
        ErrReport( CI_PAIDSWT ,
        	    EI_PROCESS ,
        	    nReturnCode,
        	    CI_SEVERITY_SYSERROR,
        	    "PAIDSWT��ʼ����");
        HtLog(HTLM_ERR, "nInitMsgQue(CI_PAIDSWT) error");
        exit(1);
    }

	nRet = nCommonMsqInit(CI_PAIDCOMM);
    if (nRet != 0)
    {
        ErrReport(CI_PAIDSWT, 
                  EI_MESSAGEQUEUE, 
                  0, 
                  CI_SEVERITY_SYSERROR,
                  ES_MSGQ_NET_COMM_CONNECT);
    	HtLog(HTLM_ERR, "nCommonMsqInit(CI_HUBCOMM) error");                  
        exit(1);
    }
    
    char api_log_file[256];
    memset(api_log_file, 0, sizeof(api_log_file));
    sprintf(api_log_file, "%s/log/pbhubswt_api.log", getenv("APPL"));
    nRet = ICBC_API_INIT(api_log_file, ICBC_API_OUTSRC_SVRID);
    if (nRet != 0)
    {
        ErrReport(CI_PAIDSWT, 
                  EI_MESSAGEQUEUE, 
                  0, 
                  CI_SEVERITY_SYSERROR,
                  ES_MSGQ_NET_COMM_CONNECT);
    	HtLog(HTLM_ERR, "ICBC_API_INIT error(%d)", nRet);                  
        exit(1);
    }
    
    memset(&icbc_groupheader, 0, sizeof(icbc_groupheader));
    nGetICBCGroupHeader(&icbc_groupheader);
    
    memset(&bank_info, 0, sizeof(bank_info));
    nGetBankInfo(&bank_info);
    
    HtLog(HTLM_COM, "HUBSWT: Init Switch End\n");

    /* ��ѭ�� */
    while(1)
    {
        /*��ȡ���ã��ж��Ƿ���Ҫ�˹�REPAIR�к�*/
        memset(sTemp, 0, sizeof(sTemp));
        memset(cfgfile, 0, sizeof(cfgfile));
        sprintf(cfgfile, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);
        
        if (pflGetProfileString("REPAIR_CONFIG", "IS_REPAIR", sTemp,8, cfgfile) == 0)
        {
            isRepair = atoi(sTemp);
        }
        else
        {
            isRepair = 0;
        }
        
        DBGLOG("Waiting for MsqRecv:");
    
        /* ����Ϣ�������ȡ��Ϣ */
        nMsgInLen=0;
        memset(sIpcMsgInText, 0, sizeof(sIpcMsgInText));
        nReturnCode = nCommonMsqRecv(&nMsgInLen, sIpcMsgInText, &lMsgSource, CI_PAIDSWT);  
        if (nReturnCode != 0) 
        {
            HtLog(HTLM_ERR, "Exit from MsqRecv:[%d]\n", nReturnCode);
			RecTivoliLogC( "PBLS", "PBHUBSWT", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "CommonMsqRecv ERROR!ERRCODE[%d]", nReturnCode );
            ErrReport(CI_PAIDSWT,
                    EI_MESSAGEQUEUE,
                    nReturnCode,
                    CI_SEVERITY_SYSERROR,
                    ES_MSGQ_SWT_READ);
            ICBC_API_END();
            exit(1);
        }
    
    DBGLOG("<<<The Message start>>>\n");   
    HtDebugString(logfile, sIpcMsgInText, nMsgInLen, __FILE__, __LINE__);
    
    
    /* �ж���Ϣ��Դ���ֱ��� */
    switch (lMsgSource)
    {
        case CI_PAIDBDG:
            vSwtHUBReqProcess(sIpcMsgInText,nMsgInLen);
    	      break;
    	case CI_CCBSWT:
    	case CI_ICBCINSWT:
    	case CI_CITICSWT:
            vSwtHUBOtherSwtProcess(sIpcMsgInText,nMsgInLen);
    		    break;
        case CI_SYSTMR:
            vSwtHUBSysTmrProcess(sIpcMsgInText,nMsgInLen);
    		    break;
    	default:
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Receive unknown message, nMsgSource=[%d]\n", lMsgSource);
            break;
    }
    
    HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"<<<The Message end>>>\n");
    } /*end while */
    ICBC_API_END();
}

void QuitTerminate(int sig)
{
    short nRet;
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nHUBSWT PROCESS(%d) Normal[%d] EXIT AT %s\n", getpid(), sig, GetSystemTime());
    ErrReport(CI_PAIDSWT,
            EI_PROCESS,
            sig, 
       	    CI_SEVERITY_SYSERROR,
            "HUBSWT���������˳�");
    ICBC_API_END();
    DbDisConnect();
    exit(0);
}

/****************************************************************************/
/*    DESCRIPTIONS:����PBHUBBDG��PYA1��BALE����                                    */
/*    AUTHOR:                                                               */
/****************************************************************************/
void vSwtHUBReqProcess(void *sIpcMsgInText,int nMsgInLen)
{
    int nRet;
    int DupFlag = 0;
    char sRefNo[16+1];  
    char sId[16+1];
    char hub_tab_id[16+1];
    T_HUB_MSG hub_msg;
    
    memset(&hub_msg, 0, sizeof(T_HUB_MSG));
    memset(hub_tab_id, 0, sizeof(hub_tab_id));
    memcpy(&hub_msg  ,(char *)sIpcMsgInText  ,nMsgInLen );
    memset(sRefNo, 0, sizeof(sRefNo));
    /* ���ý����Ƿ�Ϊ�ظ����� */
    memcpy(sRefNo   ,hub_msg.tHubHead.msg_id   ,sizeof(sRefNo) - 1 );
	HtLog(HTLM_COM,"[���ñ����Ƿ�Ϊ�ظ�����]sRefNo=[%s]",sRefNo);
    nRet = HubMsgCheckDuplicate(sRefNo);
    if( nRet != 0 )
    {
        HtLog(HTLM_ERR,"��[%4.4s]��[%16.16s]Ϊ�ظ�����", 
                hub_msg.tHubHead.msg_type, hub_msg.tHubHead.msg_id);
        DupFlag = 1;
    }
    HtLog(HTLM_COM,"[���Ĳ������ݿ���]sRefNo=[%s]",sRefNo);
    nRet = IpcMsgIntoDB(sIpcMsgInText, DupFlag, hub_tab_id, nMsgInLen);
    if( nRet != 0 )
    {
        HtLog(HTLM_ERR,"�ñ�[%4.4s]��[%16.16]���������ݿ�ʧ�ܣ�", 
                hub_msg.tHubHead.msg_type, hub_msg.tHubHead.msg_id);
        return;
    }
    if(DupFlag != 1)
    {
        HtLog(HTLM_COM,"��������[%4.4s], sRefNo=[%s]", hub_msg.tHubHead.msg_type, sRefNo);
        if(memcmp(hub_msg.tHubHead.msg_type, "PAY1", 4) == 0)
        {
            nSwtHUBReqPAY1Process(sIpcMsgInText, nMsgInLen, hub_tab_id);
        }
        else if(memcmp(hub_msg.tHubHead.msg_type, "BALE", 4) == 0)
        {
            vSwtHUBReqBALEProcess(sIpcMsgInText, nMsgInLen, hub_tab_id);
        }
        else if(memcmp(hub_msg.tHubHead.msg_type, "LOGN", 4) == 0)
        {
            nSwtHUBReqLOGNProcess(sIpcMsgInText, nMsgInLen, hub_tab_id);
        }
        else if(memcmp(hub_msg.tHubHead.msg_type, "LOGF", 4) == 0)
        {
            nSwtHUBReqLOGFProcess(sIpcMsgInText, nMsgInLen, hub_tab_id);
        }
        else if(memcmp(hub_msg.tHubHead.msg_type, "H111", 4) == 0)
        {
            nSwtHUBReqH111Process(sIpcMsgInText, nMsgInLen, hub_tab_id);
        }
        HtLog(HTLM_COM,"��������[%4.4s]����, sRefNo=[%s]", hub_msg.tHubHead.msg_type, sRefNo);
    }
    else
    {
        HtLog(HTLM_COM,"�����ظ�����[%4.4s], sRefNo=[%s]", hub_msg.tHubHead.msg_type, sRefNo);
    }
    return;
}




/* �յ���Ӧ���ĺ󣬽�δ��Ӧ�������� */
void nSwtHUBReqH111Process(void *sIpcMsgInText, int nMsgInLen, char *hub_tab_id)
{
    int       nRet;
    char      cnt[9];
    int       icnt;
    struct wd_pbhubmsg_area wd_pbhubmsg;

    /* ���ܽ��������״̬Ϊ�Ѵ��� */
    HubMsgUpdtDB(hub_tab_id, 'N', '3');

    memset(cnt, 0, sizeof(cnt));
    memset(&wd_pbhubmsg, 0, sizeof(wd_pbhubmsg));
    memcpy(wd_pbhubmsg.id, PBLS_HUB_HEART, strlen(PBLS_HUB_HEART));
    
    nRet = DbsPBHUBMSG(DBS_FIND, &wd_pbhubmsg);
	if (nRet != 0 && nRet != DB_NOTFOUND)
	{
    	HtLog(HTLM_ERR,	"DBS_FIND PBHUBMSG Error!nRet:[%d]\n", nRet);
		return;
	}
	if(nRet == DB_NOTFOUND)
	{
    	memset(wd_pbhubmsg.rsv1, 0, sizeof(wd_pbhubmsg.rsv1));
    	memcpy(wd_pbhubmsg.rsv1, "00000000", 8);
    	nRet = DbsPBHUBMSG(DBS_INSERT, &wd_pbhubmsg);
    	if (nRet != 0)
    	{
        	HtLog(HTLM_ERR,	"DBS_INSERT PBHUBMSG Error! nRet:[%d]\n", nRet);
        	DbRollbackTxn();
    		return;
    	}
	}
	else
	{
    	memset(wd_pbhubmsg.rsv1, 0, sizeof(wd_pbhubmsg.rsv1));
    	memcpy(wd_pbhubmsg.rsv1, "00000000", 8);
    	
    	nRet = DbsPBHUBMSG(DBS_IUPD, &wd_pbhubmsg);
    	if (nRet != 0)
    	{
        	HtLog(HTLM_ERR,	"DBS_UPDATE PBHUBMSG Error! nRet:[%d]\n", nRet);
        	DbRollbackTxn();
    		return;
    	}
    }
	DbCommitTxn();
	return;    
}


/*
��ϵͳ���������л��������״̬ʱ���յ��˳����Ĳ������κδ�����
*/
void nSwtHUBReqLOGFProcess(void *sIpcMsgInText, int nMsgInLen, char *hub_tab_id)
{
    char      sCmd[512];
    int       nRet;
    struct wd_pbsysctl_area wd_pbsysctl;
    memset(sCmd, 0, sizeof(sCmd));
    memset(&wd_pbsysctl, 0, sizeof(wd_pbsysctl));
    nRet = 0;
    
    HubMsgUpdtDB(hub_tab_id, 'N', '3');
    
	memcpy(wd_pbsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_pbsysctl.rcd_id) - 1);
    
    //��ѯϵͳ���Ʊ�
	nRet = DbsPBSYSCTL(DBS_LOCK, &wd_pbsysctl);
	if (nRet != 0)
	{
    	HtLog(HTLM_ERR,	"DBS_LOCK PBSYSCTL Error! nRet[%d]\n", nRet);
		return;
	}
    
	//�жϵ�ǰϵͳ״̬�������л���������򷵻�
	if (wd_pbsysctl.sys_status[0] == '0' + STATUS_BATCH)
	{
	    HtLog(HTLM_ERR,	"ϵͳ��ǰ���ڵǳ���״̬,�������ǳ�!");
	    DbsPBSYSCTL(DBS_CLOSE, &wd_pbsysctl);
		return;
	}

	if (wd_pbsysctl.sys_status[0] == '0' + STATUS_BATCH_DONE)
	{
	    HtLog(HTLM_ERR,	"ϵͳ��ǰ���ڵǳ����״̬,�������ǳ�!");
    	HtLog(HTLM_COM,	"Batch Already Done!");
    	DbsPBSYSCTL(DBS_CLOSE, &wd_pbsysctl);
		return;
	}
    wd_pbsysctl.sys_status[0] = CHAR_STATUS_BATCH;
    nRet = DbsPBSYSCTL(DBS_UPDATE, &wd_pbsysctl);
    if(nRet != 0)
    {
    	HtLog(HTLM_ERR,	"UPDATE PBSYSCTL failed[%d]!");
    	DbsPBSYSCTL(DBS_CLOSE, &wd_pbsysctl);
    	DbRollbackTxn();
    	return;
	}
    DbsPBSYSCTL(DBS_CLOSE, &wd_pbsysctl);
    /*add by tianchangjin on 20111008 begin*/
    DbCommitTxn();
    /*add by tianchangjin on 20111008 end*/
    
	sprintf(sCmd, "%s/bin/batch/pbls_night_batch.sh %s %d &", getenv("APPL"),
		wd_pbsysctl.work_date, wd_pbsysctl.history_max_days);
    
    HtLog(HTLM_COM, "sCmd[%s]", sCmd);
	if (system(sCmd) == 0)
	{
		HtLog(HTLM_COM,	"SysTimer_Night_Batch:Night Batch Started!");
	}
	else
	{	
	    HtLog(HTLM_ERR,	"SysTimer_Night_Batch:Night Batch Start Error!");
	    DbRollbackTxn();
    }
    DbCommitTxn();
    return;
}


/*
ֻ�е�ϵͳ�����������״̬ʱ���յ���¼���ĲŸ���ϵͳ״̬��
*/
void nSwtHUBReqLOGNProcess(void *sIpcMsgInText, int nMsgInLen, char *hub_tab_id)
{
    int       nRet;
    struct wd_pbsysctl_area wd_pbsysctl;
    memset(&wd_pbsysctl, 0, sizeof(wd_pbsysctl));
    nRet = 0;
    
    HubMsgUpdtDB(hub_tab_id, 'N', '3');
    
	memcpy(wd_pbsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_pbsysctl.rcd_id) - 1);
    
    //��ѯϵͳ���Ʊ�
	nRet = DbsPBSYSCTL(DBS_LOCK, &wd_pbsysctl);
	if (nRet != 0)
	{
    	HtLog(HTLM_ERR,	"DBS_LOCK PBSYSCTL Error! nRet[%d]\n", nRet);
		return;
	}
    
	//�жϵ�ǰϵͳ״̬�������л���������򷵻�
	if (wd_pbsysctl.sys_status[0] != '0' + STATUS_BATCH_DONE)
	{
    	HtLog(HTLM_ERR,	"ϵͳ��ǰ�����ڵǳ����״̬,��������¼!");
    	DbsPBSYSCTL(DBS_CLOSE, &wd_pbsysctl);
		return;
	}
    wd_pbsysctl.sys_status[0] = CHAR_STATUS_ON;
    nRet = DbsPBSYSCTL(DBS_UPDATE,&wd_pbsysctl);
    if(nRet != 0)
    {
    	HtLog(HTLM_ERR,	"UPDATE PBSYSCTL failed[%d]!");
    	DbsPBSYSCTL(DBS_CLOSE, &wd_pbsysctl);
    	HtLog(HTLM_ERR,	"PBLS LOG ON FAILED!");
    	DbRollbackTxn();
    	return;
	}
    DbsPBSYSCTL(DBS_CLOSE,&wd_pbsysctl);
    DbCommitTxn();
    return;
}



/****************************************************************************/
/*    DESCRIPTIONS:����PBHUBBDG��Pay1����                                    */
/*    AUTHOR:                                                               */
/****************************************************************************/
int nSwtHUBReqPAY1Process(void *sIpcMsgInText, int nMsgInLen, char *hub_tab_id)
{
    int nRet;
    int iTxnFlag;
    int nSysWork;
	int nWork;
	int nDateFlag;
    char sRefNo[20+1];  
    char sRetStr[256];
    char sTmpAmount[15+1]; 
    char sId[16+1];
    char sActNo[34+1];
    char sMsgType[5+1];
	char sPayerActno[34+1];
	char sPayeeActno[34+1];
	char sValDate[8+1];

	char H_bank_id[3+1];
	char H_msg_date[8+1];
    
    struct wd_pbicbctxn_area wd_pbicbctxn;
    
    T_HUB_PAY1_MSG          tHubPay1Msg;
    T_HUB_MSG               hub_msg;
    FILE *fp;
    char sFileName[257];
    int  nbodylen;
    int  nfilesize;
    char sbodylen[9];
    char sfilesize[9];
    char md_time[14+1];
    int  DupFlag = 0;
	char sRecvBank[13];
	char sPayeeBank[13];
	char sPayeeAddr[71];
	int  nRepairFlag = 0;
	int  nManualRepair = 0;
	/* add by tianchangjin on 20110728 begin */
	int  nAddrFlag = 0;
	/* add by tianchangjin on 20110728 end */
	int  nRMBorFCY = 0;     /* RMB = 1, FCY = 2 */
    
    
    memset(&sRefNo          ,0  ,sizeof(sRefNo      ));
    /*memset(&tPaidKeyMsg     ,0  ,sizeof(tPaidKeyMsg ));*/
    
    memset(&sId     ,0  ,sizeof(sId     ));
    memset(&sActNo  ,0  ,sizeof(sActNo  ));
    memset(&sMsgType,0  ,sizeof(sMsgType));
	memset(H_bank_id,0	,sizeof(H_bank_id));
	memset(H_msg_date,0	,sizeof(H_msg_date));
    
    memset(&wd_pbicbctxn        ,0  ,sizeof(wd_pbicbctxn     ));
    memset(md_time        ,0  ,sizeof(md_time     ));
    memset(&tHubPay1Msg        ,0  ,sizeof(tHubPay1Msg     ));
    memset(&hub_msg        ,0  ,sizeof(hub_msg     ));
    memset(sFileName        ,0  ,sizeof(sFileName     ));
    memset(sbodylen        ,0  ,sizeof(sbodylen     ));
    memset(sfilesize        ,0  ,sizeof(sfilesize     ));
	memset(sRecvBank        ,0  ,sizeof(sRecvBank     ));
	memset(sPayeeBank        ,0  ,sizeof(sPayeeBank     ));
	memset(sPayeeAddr        ,0  ,sizeof(sPayeeAddr     ));
    
    
    memcpy(&hub_msg  ,(char *)sIpcMsgInText  ,nMsgInLen );
    memcpy(sFileName, hub_msg.file_name, sizeof(hub_msg.file_name));
    RightTrim(sFileName);
    
    HtLog(HTLM_COM,"��PAY1���ױ����ļ�[%s]",sFileName);
    fp = fopen(sFileName, "r");
    if(fp == NULL)
    {
        HtLog(HTLM_ERR,"��PAY1���ױ����ļ�[%s]ʧ�ܣ�",sFileName);
        HubMsgUpdtDB(hub_tab_id, 'N', '2');
        return -1;
    }
    
    nRet = fread(&(hub_msg.tHubHead), 1, sizeof(hub_msg.tHubHead), fp);
    if(nRet != sizeof(hub_msg.tHubHead))
    {
        HtLog(HTLM_ERR,"��PAY1���ױ����ļ�[%s]�ж�ȡ����ͷʧ�ܣ�",sFileName);
        HubMsgUpdtDB(hub_tab_id, 'N', '2');
        fclose(fp);
        return -2;
    }
    
    memcpy(sbodylen, hub_msg.tHubHead.msg_length, 8);
    nbodylen = atoi(sbodylen);
    memcpy(sfilesize, hub_msg.file_size, 8);
    nfilesize = atoi(sfilesize);
    if((nbodylen + sizeof(hub_msg.tHubHead)) != nfilesize)
    {
        HtLog(HTLM_ERR,"PAY1���ױ����ļ�[%s]��BODY���Ȳ���ȷ\n����ͷ�б����峤��[%d],�ļ�����Ϊ[%d]",
            sFileName, nbodylen + sizeof(hub_msg.tHubHead), nfilesize);
        HubMsgUpdtDB(hub_tab_id, 'N', '2');
        fclose(fp);
        return -3;
    }

    nRet = fread(&tHubPay1Msg, 1, sizeof(tHubPay1Msg), fp);
    if(nRet != sizeof(tHubPay1Msg))
    {
        HtLog(HTLM_ERR,"��PAY1���ױ����ļ�[%s]�ж�ȡ������ʧ�ܣ�",sFileName);
        HubMsgUpdtDB(hub_tab_id, 'N', '2');
        fclose(fp);
        return -4;
    }
    fclose(fp);
    
    vShowPay1Msg(&tHubPay1Msg);
    
    /* ���ܽ��׽��������״̬Ϊ�Ѵ��� */
    HubMsgUpdtDB(hub_tab_id, tHubPay1Msg.indicate, '3');

    /* ���ý����Ƿ�Ϊ�ظ����� */
    memcpy(sRefNo   ,tHubPay1Msg.seqno   ,sizeof(sRefNo) - 1 );
    RightTrim(sRefNo);
	HtLog(HTLM_COM,"[���ý����Ƿ�Ϊ�ظ�����]sRefNo=[%s]",sRefNo);
    nRet = HUBTxnCheckDuplicate(sRefNo);
    if( nRet != 0 )
    {
        HtLog(HTLM_ERR,"�ý����Ƿ�Ϊ�ظ�����sRefNo=[%s]", sRefNo);
		RecTivoliLogC( "PBLS", "PBHUBSWT", TIVOLI_BUSINESS, __FILE__, __LINE__, 
		    "Repeat transactions(PAY1) HUB_REFNO=[%s]",sRefNo);
        DupFlag = 1 ;
    }
    char sSysStatus[2];
    memset(sSysStatus, 0, sizeof(sSysStatus));
    nRet = nGetSysStatus(sSysStatus);
    if(nRet == 0 && sSysStatus[0] == CHAR_STATUS_ON)
    {
        /*ϵͳΪ��¼״̬*/
        nSysWork = 1;
    }
    else
    {
        /*ϵͳΪ�˳�״̬*/
        nSysWork = 0;
    }

	/* ����Ƿ��ڹ�����  0-�ǹ����� 1-������  */
	memcpy(H_bank_id, PBLS_BANK_ID_ICBC, 3);
	GetCurrentDateAll(GET_CURRENT_DATE_FLAG_ICBC, H_msg_date);
	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, md_time);
	char nature_time[15];
	memset(nature_time, 0, sizeof(nature_time));
	CommonGetCurrentTime(nature_time);

	if (ChkBankWorkDay(H_bank_id, H_msg_date, &nWork) != 0)	
	{
        HtLog(HTLM_ERR,"��ȡ�����ձ�־ʧ�� !");
		RecTivoliLogC( "PBLS", "PBHUBSWT", TIVOLI_BUSINESS, __FILE__, __LINE__, "FETCH WORK FLAG ERROR!");
		return -5;
	}
    /*�����HUB���ף��ж�VDATE*/
	if(tHubPay1Msg.indicate == 'N')
	{
    	/* ���PAID����С�ڵ���ϵͳ���� ֱ�ӷ��� MADE SEND */
    	if( memcmp(H_msg_date	,tHubPay1Msg.vdate	, 8 ) >= 0 )
    	{
    		memcpy(sValDate	,H_msg_date	,sizeof(sValDate) - 1);	
    		nDateFlag = 1;
    	}
    	else if ( memcmp(H_msg_date   ,tHubPay1Msg.vdate , 8 ) < 0 )
    	{
    		/* ���PAID֧�����ڴ���ϵͳ���� ��ֱ�ӷ��� MADE    */
    		nDateFlag = 0;
    	}
	}
	/*�����SWEEPING���ף������ж�VDATE*/
	else
	{
	    nDateFlag = 1;
	}
    ICBC_CALL_API_BEGIN();

	
	/* ����տ��˿������к�Ϊ�գ��򲻷��ͣ�״̬ΪC-��repair */
	if(memcmp(tHubPay1Msg.curcy, ICBC_CURCD_RMB_RMB, 3) == 0
	    ||memcmp(tHubPay1Msg.curcy, ICBC_CURCD_RMB_CNY, 3) == 0)
	{
	    HtLog(HTLM_COM,"[����Ҹ���]����=[%3.3s]",tHubPay1Msg.curcy);
	    nRMBorFCY = 1;
    }
    else
    {
        HtLog(HTLM_COM,"[��Ҹ���]����=[%3.3s]",tHubPay1Msg.curcy);
        nRMBorFCY = 2;
    }
    
    if(nRMBorFCY == 1)
    {
    	memcpy(sPayeeBank,tHubPay1Msg.payeebrno, 12 );
    	RightTrim(sPayeeBank);
    	if(strlen(sPayeeBank) < 12)
    	{
    		nRepairFlag = 1;
    	}
    	nSetRMBPaymentValues(&tHubPay1Msg);
    }
    else
    {
        memcpy(sPayeeBank,tHubPay1Msg.payeebrno, 12 );
    	RightTrim(sPayeeBank);
    	if(strlen(sPayeeBank) < 11)
    	{
    		nRepairFlag = 1;
			/* add by tianchangjin on 20110728 begin */
			memcpy(sPayeeAddr, tHubPay1Msg.payeeaddr, sizeof(tHubPay1Msg.payeeaddr));
			RightTrim(sPayeeAddr);
			if(strlen(sPayeeAddr) == 0)
				nAddrFlag = 1;
			/* add by tianchangjin on 20110728 end */

			
    	}
    	nSetFCYPaymentValues(&tHubPay1Msg);
    }
    strcpy(wd_pbicbctxn.rsv5, sPayeeBank);
    if(nRepairFlag == 1)
    {
        memcpy(sPayeeAddr, tHubPay1Msg.payeeaddr, sizeof(tHubPay1Msg.payeeaddr));
        RightTrim(sPayeeAddr);
        HtLog(HTLM_COM,"�Է�����[%s]",sPayeeAddr);
        nRet = nRepairOppBankInfo(sPayeeAddr, tHubPay1Msg.curcy, sRecvBank);
        HtLog(HTLM_COM,"�Է�����[%s], �޸����[%d], �޸����к�[%s]", 
                sPayeeAddr, nRet, sRecvBank);
        if(nRet != 0)
        {
            HtLog(HTLM_COM,"�Ƿ���ҪREPAIR 1��ʾ��ҪREPAIR��������ֵ��ʾ����Ҫ,REPAIR[%d]",isRepair);
            if(isRepair==1)
                nManualRepair = 1;
            else
                nManualRepair = 0;
        }
        else
        {
            if(nRMBorFCY == 1 )
            {
               /**����տ���Ϊ����,�տ����кŲ���ֵ,�����б���**/
               // ICBC_API_SET_VALUE("api.RBNKCODE", sRecvBank, CNAPS_CODE_LEN);
            }
            else
            {
                ICBC_API_SET_VALUE("api.FIELD571", sRecvBank, BIC_CODE_LEN);
            }
            wd_pbicbctxn.rsv4[0] = '2';
        }
    }
    else
    {
        if(nRMBorFCY == 1 )
        {
            ICBC_API_SET_VALUE("api.RBNKCODE", sPayeeBank, CNAPS_CODE_LEN);
        }
        else
        {
            ICBC_API_SET_VALUE("api.FIELD571", sPayeeBank, BIC_CODE_LEN);
        }
        wd_pbicbctxn.rsv4[0] = '1';
    }
    
    if(nRMBorFCY == 1)
    {
        nRet = ICBC_CALL_API("OUT_MADE_ICBC_10017_REQ");
        if(nRet != 0)
        {
    	    HtLog(HTLM_ERR,"ICBC_CALL_API OUT_MADE_ICBC_10017_REQ failed, pbhubmsg id=[%s] return=[%d]",
                        hub_tab_id, nRet);
            ICBC_CALL_API_END();
            return -6;
        }
    }
    else
    {
        nRet = ICBC_CALL_API("OUT_MADE_ICBC_10020_REQ");
        if(nRet != 0)
        {
    	    HtLog(HTLM_ERR,"ICBC_CALL_API OUT_MADE_ICBC_10020_REQ failed, pbhubmsg id=[%s] return=[%d]",
                        hub_tab_id, nRet);
            ICBC_CALL_API_END();
            return -7;
        }
    }
    DBGLOG("���ײ�����ı��ɹ�");
    ICBC_API_GET_VALUE("api.ID", sId, 16);
    memcpy(wd_pbicbctxn.id, sId, 16);
    wd_pbicbctxn.source[0] = '1';
    wd_pbicbctxn.txtype[0] = 'P';
    memcpy(wd_pbicbctxn.vdate     , tHubPay1Msg.vdate, sizeof(tHubPay1Msg.vdate));
    memcpy(wd_pbicbctxn.paid_refno, tHubPay1Msg.seqno, sizeof(tHubPay1Msg.seqno));
    memcpy(wd_pbicbctxn.pb_bank_id, PBLS_BANK_ID_ICBC , 3);
    memcpy(wd_pbicbctxn.curcd, tHubPay1Msg.curcy, 3);
    char max60text[61];
    memset(max60text, 0, sizeof(max60text));
    memcpy(max60text, tHubPay1Msg.payeeaddr, 60);
    getstr(max60text);
    memcpy(wd_pbicbctxn.rsv6,       max60text, strlen(max60text));
    wd_pbicbctxn.crdb[0] = 'D';
    wd_pbicbctxn.snd_cnt = 0;
    memcpy(wd_pbicbctxn.rsv2,       hub_msg.tHubHead.msg_id, 16);
    memcpy(wd_pbicbctxn.md_tlr,     "SYS99999",  8);
    memcpy(wd_pbicbctxn.md_time,    nature_time,     14);
    wd_pbicbctxn.rsv3[0] = tHubPay1Msg.indicate;
    wd_pbicbctxn.status[0] = TXNLOG_STATUS_INPUT;
    nRet = DbsPBICBCTXN(DBS_INSERT, &wd_pbicbctxn);
    if(nRet != DB_OK )
    {
        if(nRMBorFCY == 1)
        {
            ICBC_CALL_API("OUT_CANCEL_ICBC_10017_REQ");
        }
        else
        {
            ICBC_CALL_API("OUT_CANCEL_ICBC_10020_REQ");
        }
        HtLog(HTLM_ERR, "DbsPBICBCTXN DBS_INSERT, sId=[%s],nRet=[%d]",sId, nRet);
		RecTivoliLogC( "PBLS", "PBHUBSWT", 
		                TIVOLI_DATABASE, __FILE__, __LINE__,
		                "DbsPBICBCTXN DBS_INSERT ERROR! sId=[%s],nRet=[%d]",
		                sId, nRet);
        DbRollbackTxn();
        return -9;
    }
    DBGLOG("���ײ���ͻ������ɹ�");
    DbCommitTxn();
    
    memset(&wd_pbicbctxn        ,0  ,sizeof(wd_pbicbctxn     ));
    memcpy(wd_pbicbctxn.id, sId, 16);
    nRet = DbsPBICBCTXN(DBS_LOCK, &wd_pbicbctxn);
    if(nRet != DB_OK )
    {
        HtLog(HTLM_ERR, "DbsPBICBCTXN DBS_LOCK, sId=[%s],nRet=[%d]",sId, nRet);
		RecTivoliLogC( "PBLS", "PBHUBSWT", 
		                TIVOLI_DATABASE, __FILE__, __LINE__,
		                "DbsPBICBCTXN DBS_LOCK ERROR! sId=[%s],nRet=[%d]",
		                sId, nRet);
        DbRollbackTxn();
        return -9;
    }
    HtLog(HTLM_COM,"HUB��Ϣ��[%16.16s],PBLS��Ϣ��[%16.16s],HUB���׺�[%s],PBLS���׺�[%16.16s]",
		            hub_msg.tHubHead.msg_id,hub_tab_id, sRefNo, sId);

    iTxnFlag = PaidCheckIfinTxnTime();
    HtLog(HTLM_COM,"nSysWork=     [%d] 0-ϵͳΪ�˳�״̬  1-ϵͳΪ��¼״̬",nSysWork);
	HtLog(HTLM_COM,"iTxnFlag=     [%d] 0-���ڽ���ʱ����  1-�����ڽ���ʱ����",iTxnFlag);
	HtLog(HTLM_COM,"nWork   =     [%d] 0-�ǹ����� 1-������",nWork);
	HtLog(HTLM_COM,"nDateFlag=    [%d] 0-δ��֧�����ڽ��� 1-С�ڻ���ڵ�ǰϵͳ���ڽ��� ",nDateFlag);
	HtLog(HTLM_COM,"DupFlag =     [%d] 0-�������� 1-����",DupFlag);
	HtLog(HTLM_COM,"nAddrFlag =   [%d] 0-�������� 1-�տ�����Ϣ��ȫ�Ľ���",nAddrFlag);
	HtLog(HTLM_COM,"nManualRepair=[%d] 0-����Repair 1-��ҪRepair ",nManualRepair);
    if( nSysWork == 1 
        && iTxnFlag == 0 
        && nWork == 1 
        && nDateFlag == 1 
        && DupFlag == 0 
        && nManualRepair == 0
        /* add by tianchangjin on 20110728 begin */
        && nAddrFlag == 0)
        /* add by tianchangjin on 20110728 end */
    {
         /* ���ڽ���ʱ���� ���ڹ�����ʱ�䷶Χ�� */
		DBGLOG("�������͵Ľ���");
        /* ����֧��ָ��  */
    	nRet = nUpdatePaymentID(sId, nRMBorFCY);
    	if( nRet != 0 )
    	{
    		HtLog(HTLM_ERR,"nUpdatePaymentID=[%s][%d]", sId, nRet);
    		RecTivoliLogC( "PBLS", "PBHUBSWT", 
    		                TIVOLI_BUSINESS, 
    		                __FILE__, __LINE__, 
    		                "nUpdatePaymentID Fail id=[%16.16s]",sId);
    		DbsPBICBCTXN(DBS_CLOSE, &wd_pbicbctxn);
    		ICBC_CALL_API_END();
    		return -8;
    	}
		ICBC_CALL_API_END();
        /***ICBC_API_SEND֮ǰ,��Commitȷ�����ı��Ѿ�����,ICBC����ʵʱ�鵽���º������***/ 
        DbCommitTxn();
        
        T_ICBC_API_IPCMSG tIpcMsg;
    	memset(&tIpcMsg, 0, sizeof(tIpcMsg));
        memcpy(tIpcMsg.sId, sId, 16);
        if(nRMBorFCY == 1)
        {
            memcpy(tIpcMsg.sPkgNo, ICBC_RMB_PAYMENT_REQ, 5);
        }
        else
        {
            memcpy(tIpcMsg.sPkgNo, ICBC_FCY_PAYMENT_REQ, 5);
        }
        memcpy(tIpcMsg.sWorkDate, md_time, 8);
        tIpcMsg.cResndFlg = '0';
        
    	nRet = ICBC_API_SEND(&tIpcMsg);
        if( nRet != 0 ) 
        {
			RecTivoliLogC( "PBLS", "PBHUBSWT", 
			                TIVOLI_DATABASE, 
			                __FILE__, __LINE__,
			                "CALL_ICBC_SEND Fail sId=[%s],nRet=[%d]",sId, nRet);
			HtLog(HTLM_ERR,"CALL_ICBC_SEND Fail sId=[%s],nRet=[%d]",sId, nRet);
			wd_pbicbctxn.snd_cnt = 1;
			wd_pbicbctxn.status[0] = TXNLOG_STATUS_SENDFAL;
			wd_pbicbctxn.substatus[0] = TXNLOG_SUB_STATUS_NORMAL;
            memcpy(wd_pbicbctxn.txdate, md_time, 8);
            
        	memcpy(wd_pbicbctxn.ck_tlr, "SYS99999", 8);
        	CommonGetCurrentTime(wd_pbicbctxn.ck_time);
        	
        	memcpy(wd_pbicbctxn.snd_tlr, "SYS99999", 8);
        	CommonGetCurrentTime(wd_pbicbctxn.snd_time);
        	
        	memcpy(wd_pbicbctxn.au_tlr, "SYS99999", 8);
        	CommonGetCurrentTime(wd_pbicbctxn.au_time);
        	
    	    sprintf(wd_pbicbctxn.remarks, "���ú���API����ʧ��[%d]", nRet);
        }
        if( nRet == 0 )
        {
            DBGLOG("���׷��ͳɹ�");
            wd_pbicbctxn.snd_cnt = 1;
            wd_pbicbctxn.status[0] = TXNLOG_STATUS_SENDSUC;
            wd_pbicbctxn.substatus[0] = TXNLOG_SUB_STATUS_NORMAL;
            memcpy(wd_pbicbctxn.txdate, md_time, 8);
            
        	memcpy(wd_pbicbctxn.ck_tlr, "SYS99999", 8);
        	CommonGetCurrentTime(wd_pbicbctxn.ck_time);
        	
        	memcpy(wd_pbicbctxn.snd_tlr, "SYS99999", 8);
        	CommonGetCurrentTime(wd_pbicbctxn.snd_time);
        	
        	memcpy(wd_pbicbctxn.au_tlr, "SYS99999", 8);
        	CommonGetCurrentTime(wd_pbicbctxn.au_time);
        }
        
        nRet = DbsPBICBCTXN(DBS_UPDATE, &wd_pbicbctxn);
        if(nRet != DB_OK )
        {
            HtLog(HTLM_ERR, "DbsPBICBCTXN DBS_INSERT, sId=[%s],nRet=[%d]",sId, nRet);
			RecTivoliLogC( "PBLS", "PBHUBSWT", 
			                TIVOLI_DATABASE, __FILE__, __LINE__,
			                "DbsPBICBCTXN UPDATE ERROR! sId=[%s],nRet=[%d]",
			                sId, nRet);
            DbsPBICBCTXN(DBS_CLOSE, &wd_pbicbctxn);
            DbRollbackTxn();
            return -9;
        }
        DBGLOG("���¿ͻ������ɹ�");
        DbsPBICBCTXN(DBS_CLOSE, &wd_pbicbctxn);
        DbCommitTxn();
        /* ��¼��Ϣ��ر� */
        memcpy(sActNo   , tHubPay1Msg.payeract , 32);
        if(nRMBorFCY == 1)
        {
            memcpy(sMsgType, ICBC_RMB_PAYMENT_REQ, 5);
        }
        else
        {
            memcpy(sMsgType, ICBC_FCY_PAYMENT_REQ, 5);
        }
        nRet = RecMonitor(sId,sActNo,sMsgType);
        if(nRet != 0 )
        {
            HtLog(HTLM_ERR,"��¼��Ϣ��ر�����sId=[%s],nRet=[%d]",sId, nRet);
			RecTivoliLogC( "PBLS", "PBHUBSWT", 
			                TIVOLI_DATABASE, __FILE__, __LINE__,
			                "INSERT INTO pbMsgmonitor ERROR!ID=%s],sqlcode =[%d]", 
			                sId, nRet );
			DbRollbackTxn();
			return -10;
        }
        DbCommitTxn();
    }
    else
    {
        
       	memcpy(wd_pbicbctxn.ck_tlr, "SYS99999", 8);
       	CommonGetCurrentTime(wd_pbicbctxn.ck_time);
        	
       	memcpy(wd_pbicbctxn.au_tlr, "SYS99999", 8);
       	CommonGetCurrentTime(wd_pbicbctxn.au_time);
		
		/* �ǽ���ʱ���� ���� �ǹ����� */
        if(DupFlag == 1)
        {
            DBGLOG("���˽���");
            wd_pbicbctxn.status[0] = TXNLOG_STATUS_REJECT;
            strcpy(wd_pbicbctxn.remarks, "HUB���к��ظ�!");
            memcpy(wd_pbicbctxn.txdate, md_time, 8);
            if(nRMBorFCY == 1)
            {
                ICBC_CALL_API("OUT_CANCEL_ICBC_10017_REQ");
            }
            else
            {
                ICBC_CALL_API("OUT_CANCEL_ICBC_10020_REQ");
            }
        }
        else if (nManualRepair == 1)
        {
            DBGLOG("��Repair����");
            wd_pbicbctxn.status[0] = TXNLOG_STATUS_NEEDREPAIR;
            wd_pbicbctxn.substatus[0] = TXNLOG_SUB_STATUS_NORMAL;
			strcpy(wd_pbicbctxn.remarks, "�տ����кŲ�ȫ���벹��!");
			wd_pbicbctxn.rsv4[0] = '3';
        }
		/* add by tianchangjin on 20110728 begin */
		else if(nAddrFlag == 1)
		{
			DBGLOG("�տ�����Ϣ��ȫ����");
            wd_pbicbctxn.status[0] = TXNLOG_STATUS_REJECT;
            strcpy(wd_pbicbctxn.remarks, "�տ�����Ϣ��ȫ");
            memcpy(wd_pbicbctxn.txdate, md_time, 8);
            if(nRMBorFCY == 1)
            {
                ICBC_CALL_API("OUT_CANCEL_ICBC_10017_REQ");
            }
            else
            {
                ICBC_CALL_API("OUT_CANCEL_ICBC_10020_REQ");
            }
		}
		/* add by tianchangjin on 20110728 end */
		else
        {
            DBGLOG("����ѯ���͵Ľ���");
            wd_pbicbctxn.status[0] = TXNLOG_STATUS_APPROVE; 
            wd_pbicbctxn.substatus[0] = TXNLOG_SUB_STATUS_NORMAL;  
        }
        ICBC_CALL_API_END();
        nRet = DbsPBICBCTXN(DBS_UPDATE, &wd_pbicbctxn);
        if( nRet != DB_OK )
        {
            HtLog(HTLM_ERR, "DbsPBICBCTXN DBS_INSERT, sId=[%s],nRet=[%d]",sId, nRet);
			RecTivoliLogC( "PBLS", "PBHUBSWT", 
			                TIVOLI_DATABASE, __FILE__, __LINE__,
			                "DbsPBICBCTXN UPDATE ERROR! sId=[%s],nRet=[%d]",
			                sId, nRet);
            DbsPBICBCTXN(DBS_CLOSE, &wd_pbicbctxn);
            DbRollbackTxn();
            return -11;
        }
        DBGLOG("���¿ͻ������ɹ�");
        DbsPBICBCTXN(DBS_CLOSE, &wd_pbicbctxn);
        DbCommitTxn();
    }
    
    return;
}

/****************************************************************************/
/*    DESCRIPTIONS:����PBHUBBDG��BALE����                                    */
/*    ����ϵͳ��ǰ״̬��Σ��������Ͳ�ѯ���� */
/*    AUTHOR:                                                               */
/****************************************************************************/
void vSwtHUBReqBALEProcess(void *sIpcMsgInText,int nMsgInLen, char *hub_tab_id)
{
    int nRet;
    T_HUB_BALE_MSG          tHubBaleMsg;
    T_HUB_MSG               hub_msg;
    FILE *fp;
    char sFileName[257];
    int  nbodylen;
    int  nfilesize;
    int  nActnoNum;
    char sbodylen[9];
    char sfilesize[9];
    char sActnoNum[9];
    char sActnoCurcd[36];
    char *sActnoList;
    int  i;
    int  DupFlag = 0;
    char *p_pos;
    char *p_tmp;
    int  nActnoSize;
    
    memset(&tHubBaleMsg        ,0  ,sizeof(tHubBaleMsg     ));
    memset(&hub_msg        ,0  ,sizeof(hub_msg     ));
    memset(sFileName        ,0  ,sizeof(sFileName     ));
    memset(sbodylen        ,0  ,sizeof(sbodylen     ));
    memset(sfilesize        ,0  ,sizeof(sfilesize     ));
    memset(sActnoNum        ,0  ,sizeof(sActnoNum     ));
    
    
    memcpy(&hub_msg  ,(char *)sIpcMsgInText  ,nMsgInLen );
    memcpy(sFileName, hub_msg.file_name, sizeof(hub_msg.file_name));
    RightTrim(sFileName);
    
    HtLog(HTLM_COM,"��BALE�����ļ�[%s]",sFileName);
    fp = fopen(sFileName, "r");
    if(fp == NULL)
    {
        HtLog(HTLM_COM,"��BALE�����ļ�[%s]ʧ�ܣ�",sFileName);
        HubMsgUpdtDB(hub_tab_id, 'S', '2');
        return;
    }
    
    nRet = fread(&(hub_msg.tHubHead), 1, sizeof(hub_msg.tHubHead), fp);
    if(nRet != sizeof(hub_msg.tHubHead))
    {
        HtLog(HTLM_COM,"��BALE�����ļ�[%s]�ж�ȡ����ͷʧ�ܣ�",sFileName);
        HubMsgUpdtDB(hub_tab_id, 'S', '2');
        fclose(fp);
        return;
    }
    
    memcpy(sbodylen, hub_msg.tHubHead.msg_length, 8);
    nbodylen = atoi(sbodylen);
    memcpy(sfilesize, hub_msg.file_size, 8);
    nfilesize = atoi(sfilesize);
    if((nbodylen + sizeof(hub_msg.tHubHead)) != nfilesize)
    {
        HtLog(HTLM_COM,"BALE�����ļ�[%s]��BODY���Ȳ���ȷ\n����ͷ�б����峤��[%d],�ļ�����Ϊ[%d]",
            sFileName, nbodylen + sizeof(hub_msg.tHubHead), nfilesize);
        HubMsgUpdtDB(hub_tab_id, 'S', '2');
        fclose(fp);
        return;
    }

    nRet = fread(sActnoNum, 1, 8, fp);
    if(nRet != 8)
    {
        HtLog(HTLM_COM,"��BALE�����ļ�[%s]�ж�ȡ�ʺ�����ʧ�ܣ�",sFileName);
        HubMsgUpdtDB(hub_tab_id, 'S', '2');
        fclose(fp);
        return;
    }
    nActnoNum = atoi(sActnoNum);
    HtLog(HTLM_COM,"BALE�����ļ�[%s]���ʺ�����Ϊ��[%s][%d]��",
            sFileName, sActnoNum, nActnoNum);
    
    if(nActnoNum == 0)
    {
        HtLog(HTLM_COM,"BALE�����ļ�[%s]���ʺ�����Ϊ0",
                sFileName);
        HubMsgUpdtDB(hub_tab_id, 'S', '3');
        fclose(fp);
        return;
    }
    nActnoSize = nbodylen - 8;
    sActnoList = (char *)malloc(nActnoSize+2);
    if(sActnoList == NULL)
    {
        HtLog(HTLM_COM,"MALLOC failed [%d]",
            sizeof(char) * (nbodylen - 8));
        HubMsgUpdtDB(hub_tab_id, 'S', '2');
        fclose(fp);
        return;
    }
    memset(sActnoList, 0, sizeof(nActnoSize+1));
    nRet = fread(sActnoList, 1, nActnoSize, fp);
    if(nRet != nActnoSize)
    {
        HtLog(HTLM_COM,"��BALE�����ļ�[%s]�ж�ȡ�ʺ��б�ʧ�ܣ�",sFileName);
        HubMsgUpdtDB(hub_tab_id, 'S', '2');
        free(sActnoList);
        fclose(fp);
        return;
    }
    fclose(fp);
    HubMsgUpdtDB(hub_tab_id, 'S', '3');
    sActnoList[nActnoSize] = '|';
    p_pos = sActnoList;
    while(*p_pos == '|')
    {
        p_pos++;
    }
    p_tmp = p_pos;
    
    while(*p_tmp != 0)
    {
        if(*p_tmp == '|')
        {
            memset(sActnoCurcd, 0,sizeof(sActnoCurcd));
            memcpy(sActnoCurcd, p_pos, p_tmp - p_pos);
            RightTrim(sActnoCurcd);
            HtLog(HTLM_COM,"�����ʺ�[%s]", sActnoCurcd);
            if(strlen(sActnoCurcd) > 0)
            {
                nRet = nSendBALEToICBC(sActnoCurcd, hub_msg.tHubHead.msg_id);
                HtLog(HTLM_COM,"�����ʺ�[%s], ����[%d]", sActnoCurcd, nRet);
            }
            p_tmp++;
            p_pos = p_tmp;
        }
        else
        {
            p_tmp++;
        }
    }
    free(sActnoList);
    return;
}

/****************************************************************************/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:                                                               */
/****************************************************************************/
void vSwtHUBOtherSwtProcess(void *sIpcMsgInText,int iLen)
{
    char             *pIpcText;
    int              nRet;
    struct           wd_pbicbctxn_area   wd_pbicbctxn;
    
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "Enter vSwtPAIDOtherSwtProcess() ...\n");
    
    pIpcText = sIpcMsgInText;
    
    /**********************************************************************/
    /* ����M999���ĸ�PBHUBCOMM(PBICBCINSWT��Ҫ���жϣ��ֹ�¼��Ľ��ײ���PBHUBSWT)*/
    /* ����: PAID02BACK(10)+PKGNO(5)+ID(16)+STATUS(1)+CODE(4)+INFO(256)   */
    /**********************************************************************/
    if (memcmp(pIpcText, "PAID02BACK", 10) == 0)
    {
        /*PBICBCINSWT��PBHUBSWT�Ľṹ*/
        T_PBLS_M999_MSG tPBLSM999Msg;
        /*PBHUBSWT��PBHUBCOMM�Ľṹ*/
        T_HUB_MSG        tHubMsg;
        /*PBLS��HUB��M999���Ľṹ*/
        T_HUB_M999_MSG  tHubM999Msg;
        
        memset(&wd_pbicbctxn    ,0  ,sizeof(wd_pbicbctxn));
        memset(&tHubMsg       ,' '  ,sizeof(tHubMsg ));
        memset(&tPBLSM999Msg       ,' '  ,sizeof(tPBLSM999Msg ));
        memcpy(&tPBLSM999Msg, pIpcText, sizeof(tPBLSM999Msg ));
        
        /* ����ID�ҳ�MSQID+COREID */
        memcpy(wd_pbicbctxn.id, tPBLSM999Msg.id, 16);
		HtLog(HTLM_COM,"wd_pbicbctxn.id =[%s]\n",wd_pbicbctxn.id);
        nRet = DbsPBICBCTXN(DBS_FIND,&wd_pbicbctxn);
        if( nRet != DB_OK )
        {
            HtLog(HTLM_ERR,"DbsPBICBCTXN FIND ERROR! ID=[%s],ERRCODE[%d]",wd_pbicbctxn.id, nRet );
            if( nRet != DB_NOTFOUND && nRet != DB_ISNULL )
            {
            	RecTivoliLogC( "PBLS", "PBHUBSWT", TIVOLI_DATABASE, __FILE__, __LINE__,
            	    "DbsPBICBCTXN FIND ERROR! ERRCODE[%d]", nRet );
            }
            return;                                                                    
        }
        if(wd_pbicbctxn.source[0] != '1')
        {
            HtLog(HTLM_COM,"txn source is manual[%16.16s]", tPBLSM999Msg.id);
            return;
        }
        char ssn[8 + 1];
        char md_time[14+1];
        char msg_id[16+1];
        char bdlength[8+1];
        char file_name[256+1];
        char file_size[8+1];
        char file_path[256+1];
        FILE *fp;
        
        memset(&ssn    , 0, sizeof(ssn)); 
        memset(&md_time    , 0, sizeof(md_time)); 
        memset(&msg_id    , 0, sizeof(msg_id)); 
        memset(&bdlength    , 0, sizeof(bdlength)); 
        memset(&file_name    , 0, sizeof(file_name)); 
        memset(&file_size    , 0, sizeof(file_size)); 
        memset(&file_path    , 0, sizeof(file_path)); 
        
        RightTrim(tPBLSM999Msg.info);
        memset(&tHubM999Msg    ,' '  ,sizeof(tHubM999Msg));
        tHubM999Msg.status = tPBLSM999Msg.status;
        memcpy(tHubM999Msg.code, tPBLSM999Msg.code, 4);
        memcpy(tHubM999Msg.info, tPBLSM999Msg.info, strlen(tPBLSM999Msg.info));
        RightTrim(wd_pbicbctxn.paid_refno);
        memcpy(tHubM999Msg.hub_refno, wd_pbicbctxn.paid_refno, strlen(wd_pbicbctxn.paid_refno));
        memcpy(tHubM999Msg.vdate, wd_pbicbctxn.vdate, 8);
        memcpy(tHubM999Msg.senddate, wd_pbicbctxn.snd_time, 8);
        tHubM999Msg.indicate = wd_pbicbctxn.rsv3[0];
        
        tHubMsg.msg_io = 'O';
        
        GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, md_time);
        nGenerateMsgID(md_time, msg_id);
        sprintf(bdlength, "%08d", sizeof(T_HUB_M999_MSG));
        
        memcpy(tHubMsg.tHubHead.msg_id, msg_id, 16);
        memcpy(tHubMsg.tHubHead.msg_type, "M999", 4);
        memcpy(tHubMsg.tHubHead.msg_length, bdlength, 8);
        memcpy(tHubMsg.tHubHead.msg_channel, HUB_PBLS_HEAD_CHANNEL, 14);
        
        sprintf(file_path, "%s/iodata/hub/outrt/%8.8s/", getenv("APPL"), md_time);
        mkdir(file_path, S_IRWXU|S_IRWXG|S_IRWXO);
        sprintf(file_name, "%s/iodata/hub/outrt/%8.8s/M999_%16.16s.MSG", 
                        getenv("APPL"), md_time, msg_id);
        
        sprintf(file_size, "%08d", sizeof(T_HUB_HEAD) + sizeof(T_HUB_M999_MSG));
        memcpy(tHubMsg.file_name, file_name, strlen(file_name));
        memcpy(tHubMsg.file_size, file_size, 8);
        
        fp = fopen(file_name, "w+");
        if(fp == NULL)
        {
            HtLog(HTLM_ERR,"open M999 RSP FILE [%s] failed!", file_name);
            return;
        }
        nRet = fwrite(&(tHubMsg.tHubHead), 1, sizeof(T_HUB_HEAD), fp);
        if(nRet != sizeof(T_HUB_HEAD))
        {
            HtLog(HTLM_ERR,"write M999 RSP to FILE [%s] failed!", file_name);
            fclose(fp);
            return;
        }
        nRet = fwrite(&tHubM999Msg, 1, sizeof(T_HUB_M999_MSG), fp);
        if(nRet != sizeof(T_HUB_M999_MSG))
        {
            HtLog(HTLM_ERR,"write M999 RSP to FILE [%s] failed!", file_name);
            fclose(fp);
            return;
        }
        fclose(fp);
        nRet = nCommonMsqSend(sizeof(T_HUB_MSG), (char *)(&tHubMsg), CI_PAIDSWT, CI_PAIDCOMM);
        if (nRet != 0) 
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "PAIDSWT Send to PAIDCOMM FAIL [%d]\n", nRet);
			RecTivoliLogC( "PBLS", "PBHUBSWT", TIVOLI_MESSAGEQ, __FILE__, __LINE__,"CommonMsqSend Fail!ERRCODE[%d]", nRet );
            exit(1);
        }
        PbHubMsgIntoDB(&tHubMsg, tHubM999Msg.indicate);
        return;
    }
    /*PBICBCINSWT��Ҫ���жϣ�����SWEEPING������ѯ��Ҫ��PBHUBSWT*/
    else if (memcmp(pIpcText, "PAID08BACK", 10) == 0)
    {
        /*PBICBCINSWT��PBHUBSWT�Ľṹ*/
        T_HUB_BALA_MSG   tHubBalaMsg;
        /*PBHUBSWT��PBHUBCOMM�Ľṹ*/
        T_HUB_MSG        tHubMsg;

        memset(&tHubMsg, ' ', sizeof(tHubMsg ));
        memset(&tHubBalaMsg, ' ', sizeof(tHubBalaMsg ));
        memcpy(&tHubBalaMsg, pIpcText, sizeof(tHubBalaMsg ));
        
        char ssn[8 + 1];
        char md_time[14+1];
        char msg_id[16+1];
        char bdlength[8+1];
        char file_name[256+1];
        char file_size[8+1];
        char file_path[256+1];
        char sHubBalaMsg[256+1];
        FILE *fp;
        
        memset(&ssn    , 0, sizeof(ssn)); 
        memset(&md_time    , 0, sizeof(md_time)); 
        memset(&msg_id    , 0, sizeof(msg_id)); 
        memset(&bdlength    , 0, sizeof(bdlength)); 
        memset(&file_name    , 0, sizeof(file_name)); 
        memset(&file_size    , 0, sizeof(file_size)); 
        memset(&file_path    , 0, sizeof(file_path));
        memset(&sHubBalaMsg   , 0, sizeof(sHubBalaMsg)); 
        
        tHubMsg.msg_io = 'O';
        
        GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, md_time);
        nGenerateMsgID(md_time, msg_id);
        sprintf(bdlength, "%08d", sizeof(T_HUB_BALA_MSG));
        
        memcpy(tHubMsg.tHubHead.msg_id, msg_id, 16);
        memcpy(tHubMsg.tHubHead.msg_type, "BALA", 4);
        memcpy(tHubMsg.tHubHead.msg_length, bdlength, 8);
        memcpy(tHubMsg.tHubHead.msg_channel, HUB_PBLS_HEAD_CHANNEL, 14);
        
        sprintf(file_path, "%s/iodata/hub/outrt/%8.8s/", getenv("APPL"), md_time);
        mkdir(file_path, S_IRWXU|S_IRWXG|S_IRWXO);
        sprintf(file_name, "%s/iodata/hub/outrt/%8.8s/BALA_%16.16s.MSG", 
                        getenv("APPL"), md_time, msg_id);
        
        sprintf(file_size, "%08d", sizeof(T_HUB_HEAD) + (sizeof(T_HUB_BALA_MSG)-10));
        memcpy(tHubMsg.file_name, file_name, strlen(file_name));
        memcpy(tHubMsg.file_size, file_size, 8);
        
        fp = fopen(file_name, "w+");
        if(fp == NULL)
        {
            HtLog(HTLM_ERR,"open M999 RSP FILE [%s] failed!", file_name);
            return;
        }
        nRet = fwrite(&(tHubMsg.tHubHead), 1, sizeof(T_HUB_HEAD), fp);
        if(nRet != sizeof(T_HUB_HEAD))
        {
            HtLog(HTLM_ERR,"write M999 RSP to FILE [%s] failed!", file_name);
            fclose(fp);
            return;
        }
        memcpy(sHubBalaMsg, &tHubBalaMsg, sizeof(T_HUB_BALA_MSG));
        nRet = fwrite(sHubBalaMsg+10, 1, sizeof(T_HUB_BALA_MSG)-10, fp);
        if(nRet != (sizeof(T_HUB_BALA_MSG)-10))
        {
            HtLog(HTLM_ERR,"write M999 RSP to FILE [%s] failed!,nRet[%d],sizeof(T_HUB_M999_MSG)[%d]", file_name,nRet,sizeof(T_HUB_M999_MSG));
            fclose(fp);
            return;
        }
        fclose(fp);
        nRet = nCommonMsqSend(sizeof(T_HUB_MSG), (char *)(&tHubMsg), CI_PAIDSWT, CI_PAIDCOMM);
        if (nRet != 0) 
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "PAIDSWT Send to PAIDCOMM FAIL [%d]\n", nRet);
			RecTivoliLogC( "PBLS", "PBHUBSWT", TIVOLI_MESSAGEQ, __FILE__, __LINE__,"CommonMsqSend Fail!ERRCODE[%d]", nRet );
            exit(1);
        }
        PbHubMsgIntoDB(&tHubMsg, 'S');
        return;
    }
    
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "Normal Exit vSwtPAIDOtherSwtProcess() ...\n");
    
    return;
}



void vSwtHUBSysTmrProcess(void *sIpcMsgInText,int nMsgInLen)
{
    char             *pIpcText;
    int              nRet;
    struct           wd_pbicbctxn_area   wd_pbicbctxn;
    
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "Enter vSwtHUBSysTmrProcess() ...\n");
    
    pIpcText = sIpcMsgInText;
    
    /**********************************************************************/
    /* ����M999���ĸ�PBHUBCOMM(PBICBCINSWT��Ҫ���жϣ��ֹ�¼��Ľ��ײ���PBHUBSWT)*/
    /* ����: PAID02BACK(10)+PKGNO(5)+ID(16)+STATUS(1)+CODE(4)+INFO(256)   */
    /**********************************************************************/
    if (memcmp(pIpcText, "HUBHEART00", 10) == 0)
    {
        nSwtHUBReqH000Process(sIpcMsgInText, nMsgInLen, PBLS_HUB_HEART);
    }
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "exit vSwtHUBSysTmrProcess() ...\n");
    return;
}

void nSwtHUBReqH000Process(void *sIpcMsgInText, int nMsgInLen, char *hub_tab_id)
{
    int       nRet;
    char      cnt[9];
    int       icnt;
    char      s_max_count[5];
    int       i_max_count;
    struct wd_pbhubmsg_area wd_pbhubmsg;
    
    memset(cnt, 0, sizeof(cnt));
    memset(s_max_count, 0, sizeof(s_max_count));
    memset(&wd_pbhubmsg, 0, sizeof(wd_pbhubmsg));
    
    memcpy(wd_pbhubmsg.id, hub_tab_id, strlen(hub_tab_id));
    
    nRet = DbsPBHUBMSG(DBS_FIND, &wd_pbhubmsg);
	if (nRet != 0 && nRet != DB_NOTFOUND)
	{
    	HtLog(HTLM_ERR,	"DBS_FIND PBHUBMSG Error!nRet:[%d]\n", nRet);
		return;
	}
	if(nRet == DB_NOTFOUND)
	{
    	memset(wd_pbhubmsg.rsv1, 0, sizeof(wd_pbhubmsg.rsv1));
    	memcpy(wd_pbhubmsg.rsv1, "00000000", 8);
    	nRet = DbsPBHUBMSG(DBS_INSERT, &wd_pbhubmsg);
    	if (nRet != 0)
    	{
        	HtLog(HTLM_ERR,	"DBS_INSERT PBHUBMSG Error! nRet:[%d]\n", nRet);
        	DbRollbackTxn();
    		return;
    	}
    	DbCommitTxn();
	}
	
    icnt = atoi(wd_pbhubmsg.rsv1);
	if(icnt < 0)
	{
	    icnt = 0;
	}
	char sCfgFileName[512+1];

	memset(sCfgFileName, 0, sizeof(sCfgFileName));
	sprintf(sCfgFileName, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);

    /* read from etc file */
	nRet = pflGetProfileString("HUB_HEART_CONFIG", "MAX_WARNING_COUNT",
		s_max_count, 4, sCfgFileName);
	if (nRet != 0)
	{
	    i_max_count = MAX_HUB_PBLS_COUNT;
	}
	else
	{
	    i_max_count = atoi(s_max_count);
	    if(i_max_count<0)
    	{
    	    i_max_count = MAX_HUB_PBLS_COUNT;
    	}
	}
	
	if(icnt >= i_max_count)
	{
	    HtLog(HTLM_ERR,	"HUB����[%d]����������δ�ظ�\n", icnt);
	    /*�����ʼ�*/
		/* Add by ZBR 2011-08-02 START */
		if (mail_snd_count > 0){
			mail_snd_count --;
			/* ����Ϊ16 */
			/* Modify by ZBR 2011-09-20 START */
			char sSubject[22] = "HUB��PBLS��·�Ͽ�����";
			/* ����Ϊ64 */
			/* Modify by ZBR 2011-09-13 START */
			char sBody[60] ;
			memset(sBody, 0, sizeof(sBody));
			char mail_nature_time[16];
			memset(mail_nature_time, 0, sizeof(mail_nature_time));
			CommonGetCurrentTime(mail_nature_time);
			char mail_hour [3];
			char mail_minute [3];
			mail_hour[0] = mail_nature_time[8];
			mail_hour[1] = mail_nature_time[9];
			mail_minute[0] = mail_nature_time[10];
			mail_minute[1] = mail_nature_time[11];
			
			sprintf (sBody,"���, ��%c%c��%c%c��, HUB��PBLS��·�Ͽ�, ���顣",mail_hour[0],mail_hour[1],mail_minute[0],mail_minute[1]);
			/* Modify by ZBR 2011-09-13 END */
			/* Modify by ZBR 2011-09-20 END */
			int smtpRet = smtpSendPbls (sSubject,sBody);
			if (smtpRet != 0){
				/* ���ͳ��� */
				HtLog(HTLM_ERR,	"����SMTP�ʼ�����,�������[%d]\n", smtpRet);
			} else {
				HtLog(HTLM_ERR,	"�ʼ����ͳɹ�������ԭ��HUB����[%d]����������δ�ظ�\n", icnt);
			}
		} else {
			HtLog(HTLM_ERR,	"�ʼ�δ���ͣ�ԭ���ʼ����ʹ����Ѿ��ﵽ����ֵmail_snd_count\n");
			/* Add by ZBR 2011-10-08 START */
			return;
			/* Add by ZBR 2011-10-08 END */
		}
		
		/* Add by ZBR 2011-08-02 END */
	/* Add by ZBR 2011-08-10 START */
	}else {
		mail_snd_count = 5;
	}
	/* Add by ZBR 2011-08-10 END */
    
    /*PBHUBSWT��PBHUBCOMM�Ľṹ*/
    T_HUB_MSG        tHubMsg;
    memset(&tHubMsg, 0, sizeof(tHubMsg));
    
    tHubMsg.msg_io = 'O';

    
    char ssn[8 + 1];
    char md_time[14+1];
    char msg_id[16+1];
    char bdlength[8+1];
    char file_name[256+1];
    char file_size[8+1];
    char file_path[256+1];
    FILE *fp;
    
    memset(&ssn    , 0, sizeof(ssn)); 
    memset(&md_time    , 0, sizeof(md_time)); 
    memset(&msg_id    , 0, sizeof(msg_id)); 
    memset(&bdlength    , 0, sizeof(bdlength)); 
    memset(&file_name    , 0, sizeof(file_name)); 
    memset(&file_size    , 0, sizeof(file_size)); 
    memset(&file_path    , 0, sizeof(file_path)); 
    
    tHubMsg.msg_io = 'O';
    
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, md_time);
    nGenerateMsgID(md_time, msg_id);
    HtLog(HTLM_COM,"msg_id=[%s]", msg_id);
    memcpy(tHubMsg.tHubHead.msg_id, msg_id, 16);
    memcpy(tHubMsg.tHubHead.msg_type, "H000", 4);
    memcpy(tHubMsg.tHubHead.msg_length, "00000000", 8);
    memcpy(tHubMsg.tHubHead.msg_channel, HUB_PBLS_HEAD_CHANNEL, 14);
    
    sprintf(file_path, "%s/iodata/hub/outrt/%8.8s/", getenv("APPL"), md_time);
    mkdir(file_path, S_IRWXU|S_IRWXG|S_IRWXO);
    sprintf(file_name, "%s/iodata/hub/outrt/%8.8s/H000_%16.16s.MSG", 
                    getenv("APPL"), md_time, msg_id);
    
    sprintf(file_size, "%08d", sizeof(T_HUB_HEAD));
    memcpy(tHubMsg.file_name, file_name, strlen(file_name));
    memcpy(tHubMsg.file_size, file_size, 8);
    
    fp = fopen(file_name, "w");
    if(fp == NULL)
    {
        HtLog(HTLM_ERR,"open M999 RSP FILE [%s] failed!", file_name);
        return;
    }
    nRet = fwrite(&(tHubMsg.tHubHead), 1, sizeof(T_HUB_HEAD), fp);
    if(nRet != sizeof(T_HUB_HEAD))
    {
        HtLog(HTLM_ERR,"write M999 RSP to FILE [%s] failed!", file_name);
        fclose(fp);
        return;
    }
    fclose(fp);
    HtLog(HTLM_COM,"nCommonMsqSend=[%s]", &tHubMsg);
    nRet = nCommonMsqSend(sizeof(T_HUB_MSG), (char *)(&tHubMsg), CI_PAIDSWT, CI_PAIDCOMM);
    if (nRet != 0) 
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "PAIDSWT Send to PAIDCOMM FAIL [%d]\n", nRet);
		RecTivoliLogC( "PBLS", "PBHUBSWT", TIVOLI_MESSAGEQ, __FILE__, __LINE__,"CommonMsqSend Fail!ERRCODE[%d]", nRet );
        return;
    }
    
	
	icnt++;
	sprintf(wd_pbhubmsg.rsv1, "%08d", icnt);
    HtLog(HTLM_COM,"DbsPBHUBMSG DBS_IUPD=[%s]", wd_pbhubmsg.rsv1);
	nRet = DbsPBHUBMSG(DBS_IUPD, &wd_pbhubmsg);
	if (nRet != 0)
	{
    	HtLog(HTLM_ERR,	"DBS_UPDATE PBHUBMSG Error! nRet:[%d]\n", nRet);
    	DbRollbackTxn();
		return;
	}
	DbCommitTxn();
	return;    
}

/* Add by ZBR 2011-08-02 START */
/**********************************************************************/
/*  ����Topframe��smtpSend�����ʼ���                                  */
/*  �������֧���ֽ�����                                              */
/*  EMIAL_SUSER 100	���������˺ţ����ļ�pbls.cfg�����ã�              */
/*  EMIAL_SPASS 100	��������PWD�����ļ�pbls.cfg�����ã�		          */
/*  EMIAL_STO   1024���ռ��ˣ�֧�ֶ��ˣ�pbls.cfg�����ã���","�ָ�     */
/*  pSubject	256 ���ʼ����⣩                                      */
/*  pBody		2048���ʼ����ģ�                                      */
/*  ����ֵ��                                                          */
/*  0 -- �ɹ�                                                         */
/*  -1 - �����ļ����ռ��˵�ַΪ��                                     */
/*  -2 - �����ʼ�����ʧ��                                             */
/*  -3 - ��ȡ�����ļ�����                                             */
/**********************************************************************/
int smtpSendPbls (char *pSubject,char *pBody){
	int ret = 0;
	char hostName[20];
	unsigned int port = 0;
	char tmpPort [6];
	char sUser[100];
	char sPass[100];
	char sCharset[10];
	char sTo[1024];
	char sSubject[256];
	char sBody[2048];

	memset(hostName, 0, sizeof(hostName));
	memset(tmpPort, 0, sizeof(tmpPort));
	memset(sUser, 0, sizeof(sUser));
	memset(sPass, 0, sizeof(sPass));
	memset(sCharset, 0, sizeof(sCharset));
	memset(sTo, 0, sizeof(sTo));
	memset(sSubject, 0, sizeof(sSubject));
	memset(sBody, 0, sizeof(sBody));
	
	/*��ȡ���ã��õ�������Ϣ*/
    memset(cfgfile, 0, sizeof(cfgfile));
    sprintf(cfgfile, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);
	int eRet = 0;
    
    eRet = pflGetProfileString("EMAIL_CONFIG", "EMIAL_HOSTNAME", hostName,20, cfgfile);
	if (eRet != 0){
		/* ��ȡ�����ļ����� */
		HtLog(HTLM_ERR,	"��ȡ�����ļ�EMAIL_CONFIG-EMAIL_HOSTNAME����,[%d]\n", eRet);
		ret = -3;
		return ret;
	}
	eRet = pflGetProfileString("EMAIL_CONFIG", "EMIAL_PORT", tmpPort,5, cfgfile);
	if (eRet != 0){
		/* ��ȡ�����ļ����� */
		HtLog(HTLM_ERR,	"��ȡ�����ļ�EMAIL_CONFIG-EMIAL_PORT����,[%d]\n", eRet);
		ret = -3;
		return ret;
	} else {
		port = atoi (tmpPort);
	}
	eRet = pflGetProfileString("EMAIL_CONFIG", "EMIAL_SUSER", sUser,30, cfgfile);
	if (eRet != 0){
		/* ��ȡ�����ļ����� */
		HtLog(HTLM_ERR,	"��ȡ�����ļ�EMAIL_CONFIG-EMIAL_SUSER����,[%d]\n", eRet);
		ret = -3;
		return ret;
	}
	eRet = pflGetProfileString("EMAIL_CONFIG", "EMIAL_SPASS", sPass,30, cfgfile);
	if (eRet != 0){
		/* ��ȡ�����ļ����� */
		HtLog(HTLM_ERR,	"��ȡ�����ļ�EMAIL_CONFIG-EMIAL_SPASS����,[%d]\n", eRet);
		ret = -3;
		return ret;
	}
	eRet = pflGetProfileString("EMAIL_CONFIG", "EMIAL_STO", sTo,300, cfgfile);
	if (eRet != 0){
		/* ��ȡ�����ļ����� */
		HtLog(HTLM_ERR,	"��ȡ�����ļ�EMAIL_CONFIG-EMIAL_STO����,[%d]\n", eRet);
		ret = -3;
		return ret;
	}
	
	memcpy(sCharset , "gb2312", 6);
	memcpy(sSubject , pSubject, strlen(pSubject));
	memcpy(sBody    , pBody,    strlen(pBody));

	int smtpRet = 0;
	/* �����ռ��˵�ַ�б���ͬʱ�����ʼ� */
	if (strlen(sTo) != 0){
		char *pSmtp;
		pSmtp = strtok(sTo,",");
		
		smtpRet = smtpSend (hostName,port,sUser,sPass,sCharset,pSmtp,sSubject,sBody);
		if (smtpRet != 0){
			/* ���ͳ��� */
			HtLog(HTLM_ERR,	"����SMTP�ʼ�����,smtpSend�������[%d],�ռ��˵�ַ:[%s]\n", smtpRet,pSmtp);
			ret = -2;
		} else {
			HtLog(HTLM_ERR,	"�ʼ����ͳɹ����ռ��˵�ַ:[%s]\n",pSmtp);
		}
		
		while ( (pSmtp = strtok(NULL,",")) != NULL ){
			smtpRet = smtpSend (hostName,port,sUser,sPass,sCharset,pSmtp,sSubject,sBody);
			if (smtpRet != 0){
				/* ���ͳ��� */
				HtLog(HTLM_ERR,	"����SMTP�ʼ�����,smtpSend�������[%d],�ռ��˵�ַ:[%s]\n", smtpRet,pSmtp);
				ret = -2;
			} else {
				HtLog(HTLM_ERR,	"�ʼ����ͳɹ����ռ��˵�ַ:[%s]\n", pSmtp);
			}
		}
	} else {
		HtLog(HTLM_ERR,	"����SMTP�ʼ�����,�ռ��˵�ַΪ��\n");
		/* �ռ��˵�ַΪ�գ�δ�����ʼ� */
		ret = -1;
	}
	return ret;
}
/* Add by ZBR 2011-08-02 END */