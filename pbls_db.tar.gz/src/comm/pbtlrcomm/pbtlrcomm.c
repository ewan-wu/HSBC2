#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include "msglog.h"
#include "ipc.h"
#include "glb_def.h"
#include "htlog.h"

char logfile[256];
char cfgfile[256];

#define STCB_APHEADLEN    8
#define STCB_SERVICE_IDX  8
#define STCB_SERVICE_LEN  16

int tcpBind(int port);
int tcpAccept(int sockid);
int tcpReadN (int sd, char *buf, int nbytes);
int tcpWriteN (int sd, char *buf, int nbytes);
void Process(int sockid);
int tcpReadMsg(int sockid, char *rcvbuf);
int tcpWriteMsg(int sockid, char *sndbuf, long sndsize);
void comDebugString(FILE *fp, char *psBuf, int iLength, int iLine);
void signalHandler(int nSig);
void daemonInit(void);

int main(int argc, char *argv[])
{
	int sd, scd;
	int c;	
	int port = 2510;
	char sPort[9];
	long lReturn;
	short nRet;

	//����������
	if (argc != 2) 
	{
		fprintf(stderr, "Usage: %s <log-file>\n", argv[0]);
		exit(1);
	}

	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	
	//ȡ�����ļ�·��
	sprintf(cfgfile, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);

	//�������ļ�ȡ�������˿ں�
	memset(sPort, 0, sizeof(sPort));
	if (pflGetProfileString("TLR_COMM", "SERVER_PORT", sPort, 
		8, cfgfile) == 0)
	{
		port = atoi(sPort);
	}

	//��������ȡ��������־�ļ�·��
	nRet = GetLogName(argv[1], logfile);
	if (nRet != 0)
	{
		fprintf(stderr, "GetLogName error !\n");
	}

	//�������ݿ�
	lReturn = DbConnect();
    if (lReturn != 0)
    {
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"Connect to Database Error");
        exit(1);
    }
	
	//ȡ·������
	nRet = nLoadMsqDef();
    if (nRet != 0)
    {
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"load msq define error");
        exit(1);
	}

	//��ʼ��·����Ϣ
    nRet = nCommonMsqInit(CI_TLRCOMM);
    if (nRet != 0)
    {
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"msq init error");
        exit(1);
    }

	//��ʼ��·����Ϣ
    nRet = nCommonMsqInit(CI_TLRBDG);
    if (nRet != 0)
    {
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"msq init error");
        exit(1);
    }

	//�Ͽ����ݿ�����
	lReturn = DbDisConnect();
    if (lReturn != 0)
    {
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"Disconnect to Database Error");
        exit(1);
    }
	
	//�󶨶˿�
	if ((sd = tcpBind(port)) < 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"bind error");
		exit(1);
	}

	daemonInit();

	signal(SIGCLD, SIG_IGN);
	signal(SIGCHLD, SIG_IGN);

	//ѭ��
	while(1)
	{
		//��ȡ�˿��յ�������
		if ((scd = tcpAccept(sd)) < 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"accept error");
			close(sd);
			exit(1);
		}
	}
}

int tcpAccept(int sockid)
{
	int sd;
	pid_t	pid;

	size_t sa_length;
	struct sockaddr_in sa;
    struct linger soLinger;
	int soReuseAddr;
	int soKeepAlive;

	sa_length = sizeof (sa);

	//����socket����
	if ((sd = accept(sockid, (struct sockaddr *) &sa, &sa_length)) < 0)
	{
		fprintf(stderr, "Accept fail.\n");
		return -1;
	}

	//����socket����
	soLinger.l_onoff  = 0;
	soLinger.l_linger = 0;
	if (setsockopt (sd, SOL_SOCKET, SO_LINGER, (char *) &soLinger,
		sizeof (soLinger)) < 0)
	{
		fprintf(stderr, "Setsockopt fail.\n");
		close(sd);
		return -1;
	}

    soKeepAlive = 1;
	if (setsockopt (sd, SOL_SOCKET, SO_KEEPALIVE, &soKeepAlive,
		sizeof (int)) < 0)
	{
		fprintf(stderr, "Setsockopt fail.\n");
		close(sd);
		return -1;
	}

	soReuseAddr = 1;
	if (setsockopt (sd, SOL_SOCKET, SO_REUSEADDR, &soReuseAddr,
		sizeof (int)) < 0)
	{
		fprintf(stderr, "Setsockopt fail.\n");
		close(sd);
		return -1;
	}

	//fork���ӽ��̴����յ������ݣ������̹ر����ӷ���
	if ((pid = fork()) == -1)
	{
		fprintf(stderr, "Fork error:%d:%s\n", errno, strerror(errno));
		close(sd);
		return -1;
	}
	else 
	{
		if (pid != 0) /* parent process */
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"parent process %d ok", getpid());

			//�����̹ر����ӷ���
			close(sd);
			return sd;
		}
		else
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"child process %d ok", getpid());

			//�ӽ��̴����յ�������
			Process(sd);

			//������ɺ�ر����ӣ��˳�����
			shutdown(sd, 2);
			close(sd);
			exit(0);
		}
	}
}

void Process(int sockid)
{
	long rcvsize, sndsize;
	char rcvbuf[TLRCOMM_MAX_BUF_SIZE];
	char sndbuf[TLRCOMM_MAX_BUF_SIZE];
	long lMsgSource;
	long lPid = 0;
	short recvsize,sendsize;
	char sPid[9];
	short nRet;

	//ȡ���̺�
   	lPid = getpid();
	sprintf(sPid, "%8d", lPid);

	//ѭ��
	while(1)
	{
		memset(rcvbuf, 0, sizeof(rcvbuf));
		memset(sndbuf, 0, sizeof(sndbuf));

		sndsize = 0;
		sendsize = 0;
		rcvsize = 0;
		recvsize = 0;

		//��ȡ����
		if ((rcvsize = tcpReadMsg(sockid, rcvbuf)) < 0) return;
		
		SetTimeStart("begin");

		//������ͨ����Ϣ���з��͸�TellerBridge
		nRet = nCommonMsqSend(rcvsize, rcvbuf, lPid, CI_TLRBDG );
		if ( nRet != 0 )
		{
			ErrReport(CI_TLRCOMM,
                		EI_MESSAGEQUEUE,
                		errno,
                		CI_SEVERITY_SYSERROR,
                		ES_MSGQ_WRITE);

			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"nCommonMsqSend error! nRet=[%d], rcvsize=[%d]", nRet, rcvsize);
#ifdef _DEBUG
 			HtDebugString(logfile, rcvbuf, rcvsize, __FILE__, __LINE__);
#endif
			return;
		}

		alarm(45);

		//ͨ����Ϣ���н���TellerBridge��Ӧ������
		if ( nCommonMsqRecvT(&sendsize,sndbuf,&lMsgSource,lPid,CI_TLRCOMM) != 0 )
		{
			ErrReport(CI_TLRCOMM,
                    	EI_MESSAGEQUEUE,
                    	errno,
                    	CI_SEVERITY_SYSERROR,
                    	ES_MSGQ_READ);

			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"sndsize=[%d]",sendsize);
#ifdef _DEBUG
 			HtDebugString(logfile, sndbuf, sendsize, __FILE__, __LINE__);
#endif
			return;
		}
		
		/* add by Jasmine 2009-11-04 for BOA WebClient begin */
		
		sndbuf[sendsize] = '\n';
		sendsize ++;
		/* add by Jasmine 2009-11-04 for BOA WebClient end */

		sndsize = sendsize;

		GetTimeTotal("end");
		alarm(0);

		//��TellerBridge��Ӧ�����ݷ���socket
		if (tcpWriteMsg(sockid, sndbuf, sndsize) < 0) return; 
	}
}

int tcpBind(int port)
{
	struct sockaddr_in sa;
	int sd;
	int on = 1;

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"Enter TcpBind port=[%d]",port);
    memset (&sa, 0, sizeof (sa));                  /* set all zeros          */
	sa.sin_family = AF_INET;                       /* TCP stream socket      */
	sa.sin_addr.s_addr = inet_addr("0.0.0.0");     /* set IP address         */
	sa.sin_port = htons (port);                    /* server port number     */
	if (sa.sin_port == 0)                          /* invalid port number    */
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"htons error");
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		return -1;
	}
	
	if ((sd = socket (AF_INET, SOCK_STREAM, 0)) < 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"socket error");
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		return -1;
	}

	if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) == -1)
	{
	  	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"setsockopt REUSRADDR errno = %d", errno);
        return -1;
	}

    if (bind(sd, (struct sockaddr *) &sa, sizeof (sa)) < 0)
	{
		if (errno == EADDRINUSE)
		{
			fprintf(stderr, "Port %d already in use.\n", port);
			close(sd);
			return -1;
		}
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		close(sd);
		return -1;
	}

	if (listen(sd, 5) < 0)
	{
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		close(sd);
		return -1;
	}

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"Bind port %d ok.", port);

	return sd;
}

int tcpReadMsg(int sockid, char *rcvbuf)
{
	long size;
	
#ifdef _DEBUG
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"Enter ReadMsg, pid[%d]", getpid());
#endif
	//�ȶ���ͷ����
	if (tcpReadN(sockid, rcvbuf, STCB_APHEADLEN) != STCB_APHEADLEN)
	{
		fprintf(stderr, "Read socket error\n");
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"Read socket error");
		return -1;
	}
	//��ͷ���ݵ�1��2λ�������ݵĳ���
	size = (unsigned char)rcvbuf[0] * 256
			+ (unsigned char)rcvbuf[1];
	
	//�ٶ�ʣ�������
	if (tcpReadN(sockid, rcvbuf + STCB_APHEADLEN, size - STCB_APHEADLEN) != size - STCB_APHEADLEN)
	{
		return -1;
	}
#ifdef _DEBUG
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"Receive ...");
 	HtDebugString(logfile, rcvbuf, size, __FILE__, __LINE__);
#endif
	return size;
}

int tcpReadN (int sd, char *buf, int nbytes)
{

    int nleft = nbytes;                 /* number of bytes left to read  */
    int nread;                           /* number of bytes read this time*/

    /* read nbytes data from socket */
    while (nleft > 0)
    {
        nread = read (sd, buf, nleft); /* read socket */
        if (nread < 0)
        {
            return -1;                   /* read error */
        }
        if (nread == 0)
        {
            break;                         /* EOF; exit loop */
        }
        /* some data have been read */
        nleft -= nread;
        buf += nread;
    } /* end of while */

    /* actual number of bytes read */
    return (nbytes - nleft);             /* success */

} /* end of tcpReadN() */

int tcpWriteMsg(int sockid, char *sndbuf, long sndsize)
{
#ifdef _DEBUG
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"Enter WriteMsg");
#endif
	if (tcpWriteN(sockid, sndbuf, sndsize) != sndsize)
	{
		fprintf(stderr, "Write socket error.\n");
		return -1;
	}
#ifdef _DEBUG
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"Send ...");
 	HtDebugString(logfile, sndbuf, sndsize, __FILE__, __LINE__);
#endif
	return 0;
}

int tcpWriteN(int sd, char *buf, int nbytes)
{

    int nleft = nbytes;             /* number of bytes left to readi     */
    int nwritten;                   /* number of bytes written this time */

    /* write iNbytes data to socket */
    while (nleft > 0)
    {
        nwritten = write(sd, buf, nleft);    /* write socket */
        if (nwritten <= 0)
        {
            return -1;                       /* write error */
        }
        /* some data have been written */
        nleft -= nwritten;
        buf += nwritten;
    } /* end of while */

    /* actual number of bytes written */
    if (nleft == 0)
    {
         return nbytes;                      /* success */
    }

    return -1;                               /* write error; impossible */

} /* end of tcpWriteN() */

void comDebugString(FILE *fp, char *psBuf, int iLength, int iLine)
{
   int        i, j = 0;
   char       s[100], temp[5];

   fprintf(fp, "Debug Information from Line: %04d\n", iLine);

   for (i=0; i<iLength; i++)
   {
      if (j==0)
      {
         memset( s, ' ', 84);
         sprintf(temp,   " %03d:",i );
         memcpy( s, temp, 5);
         sprintf(temp,   ":%03d",i+15 );
         memcpy( &s[72], temp, 4);
      }
      sprintf( temp, "%02X ", (unsigned char)psBuf[i]);
      memcpy( &s[j*3+5+(j>7)], temp, 3);
      if ( isprint( psBuf[i]))
      {
         s[j+55+(j>7)]=psBuf[i];
      }
      else
      {
         s[j+55+(j>7)]='.';
      }
      j++;
      if ( j==16)
      {
         s[76]=0;
         fprintf(fp, "%s\n", s);
         j=0;
      }
   }
   if ( j)
   {
      s[76]=0;
      fprintf(fp, "%s\n", s);
   }
}

void daemonInit(void)
{
	int    i;
	pid_t   pid;

	if ((pid = fork()) != 0)
		exit(0);    /* parent terminates */

	/* 1st child continues */
	setsid();    /* become session leader */

	signal(SIGHUP, SIG_IGN);
	if ((pid = fork()) != 0)
		exit(0);    /* 1st child terminates */

	/**
	close(1);
	open("TellerComm.out", O_WRONLY|O_CREAT|O_APPEND, S_IRUSR|S_IWUSR);
	close(2);
	open("TellerComm.err", O_WRONLY|O_CREAT|O_APPEND, S_IRUSR|S_IWUSR);
	**/

	/* 2nd child continues */
	chdir("/");    /* change working directory */

	umask(0);      /* clear our file mode creation mask */
}

void signalHandler(int nSig)
{
	fprintf(stdout, "**INFO--INFO**: Signal [%d]\n", nSig);
	signal(nSig, signalHandler);
}
