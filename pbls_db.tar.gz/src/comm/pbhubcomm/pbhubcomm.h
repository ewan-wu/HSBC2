/*****************************************************************************/
/*  Shanghai HuaTeng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2003. All rights reserved.                                 */
/*                                                                           */
/*  File:        PAIDcomm.h                                                    */
/*  Description: Communication Server between DB PAID and PBLS                 */
/*                                                                           */
/*  History      Date     Description                                        */
/*  ~~~~~~~      ~~~~     ~~~~~~~~~~~                                        */
/*****************************************************************************/

#ifndef __PAIDCOMM_H
#define __PAIDCOMM_H

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <cmqc.h>

#include "msglog.h"
#include "swttoc.h"
#include "status.h"
#include "convert.h"
#include "wd_incl.h"
#include "glb_def.h"
#include "ipc.h"
#include "htlog.h"
#include "tivoli.h"
char	logfile[200];

char	gsMode[10];
char	gsMsgDate[8+1];
char	gsMsgSeq[8+1];

/*****************************************************************************/
/* IBM MQSeries includes for MQI                                             */
/*****************************************************************************/
/*#include "cmqc.h"*/

MQHCONN  gtHcon;                            /* connection handle             */
MQHOBJ   gtHobjI;                           /* object handle                 */
MQHOBJ   gtHobjO;                           /* object handle                 */
MQLONG   glOpenCodeI;                       /* MQOPEN completion code        */
MQLONG   glOpenCodeO;                       /* MQOPEN completion code        */
MQLONG   glCReason;                         /* reason code for MQCONN        */
char     gsMQQMName[50];                    /* queue manager name            */
char     gsMQQueueName[50];                 /* queue object name             */

MQMD     gtmd = {MQMD_DEFAULT};             /* Message Descriptor            */

long mq_connect(char *, MQHCONN *, MQLONG *);
long mq_disconnect(MQHCONN *, MQLONG);
long mq_open(char *, long, MQHCONN, MQHOBJ *, MQLONG *);
long mq_close(MQHCONN, MQHOBJ *, MQLONG);
long mq_get_message_wait(MQHCONN, MQHOBJ, MQMD *, long, MQLONG, char *, MQLONG *, MQLONG, MQLONG);
long mq_put_message(MQHCONN, MQHOBJ, MQMD *, long, char *, MQLONG, MQLONG);

void mq_QInit();
void mq_QFin();
MQLONG mq_QMsgGetWait(MQLONG, char *, MQLONG *);
MQLONG mq_QMsgPut(char *, MQLONG);

#define MQCOMM_MQ_SUCC		0L
#define MQCOMM_MQ_FAIL		-1L

#define MQCOMM_MQ_OPEN_MODE_READ			0x01   /* input  -- MQGET */
#define MQCOMM_MQ_OPEN_MODE_WRITE			0x02   /* output -- MQPUT */

#define MQCOMM_MQ_GET_MSG_ALL            1
#define MQCOMM_MQ_GET_MSG_CERTAIN        2

#define MQCOMM_MQ_PUT_MSG_NEW_ID         1
#define MQCOMM_MQ_PUT_MSG_KEEP_ID        2

#define MQ_IPC_LEN						1024*20

long		lWaitSec = MQWI_UNLIMITED;

typedef struct
{
	MQBYTE24 MsgId;
	MQBYTE24 CorrelId;
	MQLONG   Feedback;
}T_PBLSMsgInd;

T_PBLSMsgInd gtMsgInd;


/*****************************************************************************/
/* EXPAT includes                                                            */
/*****************************************************************************/

#define PAID_EL_INSTRUCTION_DETAIL	"INSTRUCTION_DETAIL"
#define PAID_AT_INSTRUCTION_TYPE		"INSTRUCTION_TYPE"
#define PAID_AT_DIRECTORY				"DIRECTORY"
#define PAID_AT_FILE					"FILE"

#define PAID_AT_INSTRUCTION_TYPE_GET	"GET"
#define PAID_AT_INSTRUCTION_TYPE_PUT	"PUT"


static char gsPAIDInstType[20];
static char gsPAIDFile[256];
static char gsPAIDPath[256];
static char gsPAIDDirectory[1024];
static char gsPAIDIp[50];

/*****************************************************************************/
void Shutdown(int sig);
void ReadSysSendMq();
void RecvMqWriteSys();
int nNewPAIDMsgSeqWithoutToctl(char *sIo, char *sMsgSeq);
void vInsertMsgdtlPAID(char *sMsgIo, char *sMsgType, char *sMsgSource, long lMsgLen, char *sMsgText);
void vUpdateMsgdtlPAID(char *sMsgType);
int CopyDataFile();

/********************************��������*************************************/
#define MSG_TYPE_PAID              "PAD"

/*****************************************************************************/
#endif

