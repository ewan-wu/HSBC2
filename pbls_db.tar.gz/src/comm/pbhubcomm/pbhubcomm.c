/*****************************************************************************/
/*  Shanghai HuaTeng Software Systems Co., Ltd.                              */
/*  Copyright (c) 2010. All rights reserved.                                 */
/*                                                                           */
/*  File:        pbhubcomm.c                                                */
/*  Description: Communication Server between BOA PAID and PBLS              */
/*                                                                           */
/*  History      Date     Description                                        */
/*  ~~~~~~~      ~~~~     ~~~~~~~~~~~                                        */
/*****************************************************************************/
/*  Notes:                                                                   */
/*    For incoming message, send T_MsgKeyData to PAIDbdg                       */
/*    For outgoing message, get "FileName" from xxxswt                       */
/*****************************************************************************/

#include "pbhubcomm.h"


/*****************************************************************************/
/* FUNC :  int main (int argc, char **argv)                                  */
/* OUTPUT: NONE                                                              */
/* DESC  : The main function of the program                                  */
/*****************************************************************************/
int main (int argc, char **argv) 
{
    long    lReturn;
    int     nRet;
    char    sFileName[1024];
    
    setbuf (stdout, NULL);
    setbuf (stderr, NULL);
    
    /* ���������� */ 
    if (argc != 3) 
    {
        fprintf (stderr, "Usage: \n");
        fprintf (stderr, "\t%s <Log File> <Mode in/out> \n", basename (argv[0]));
        fprintf (stderr, "\t\t <Mode in/out>: \n");
        fprintf (stderr, "\t\t\t\"in\" or \"i\" for mode IN, \n");
        fprintf (stderr, "\t\t\t\"out\" or \"o\" for mode OUT, \n");
        fprintf (stderr, "\t\t if <Mode in/out> is IN, \n");
        fprintf (stderr, "\t\t\tread from MQ Queue, \n");
        fprintf (stderr, "\t\t\twrite into System Message Queue \n");
        fprintf (stderr, "\t\t if <Mode in/out> is OUT, \n");
        fprintf (stderr, "\t\t\tread from System Message Queue, \n");
        fprintf (stderr, "\t\t\twrite into MQ Queue  \n");
        exit (1);
    }
    
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
    
    /* ����������ȷ�� */
    if (argv[2][0] != 'i' && argv[2][0] != 'o')
    {
        fprintf (stderr, "PAIDcomm: invalid mode [%s]\n", argv[2]);
        exit (1);
    }
    
    /* ��ȡ��־������ */
    nRet = GetLogName(argv[1], logfile);
    if (nRet != 0)
    {
        fprintf(stderr, "GetLogName error !\n");
    }
    
    strcpy(gsMode, argv[2]);
    
    memset(sFileName, 0, sizeof(sFileName));
    sprintf(sFileName, "%s/etc/%s", getenv("APPL"), PBLS_CFG_FILE);
    
    /* ��ȡPAIDͨѶIP */
    memset(gsPAIDIp, 0, sizeof(gsPAIDIp));
    nRet = pflGetProfileString("PAID_COMM", "PAID_IP",gsPAIDIp, 49, sFileName);
    if (nRet != 0)
    {
        strcpy(gsPAIDIp, "localhost");
    }
    
    /* ��ȡMQ QMANAGER NAME */
    memset(gsMQQMName, 0, sizeof(gsMQQMName));
    nRet = pflGetProfileString("PAID_COMM", "QMANAGER",gsMQQMName, 49, sFileName);
    if (nRet != 0)
    {
        strcpy(gsMQQMName, "QM.PBLS_PAID");
    }

    HtLog(HTLM_COM, "gsMQQMName=[%s]\n",gsMQQMName); 

    /* ��ȡMQ QUEUE NAME */
    memset(gsMQQueueName, 0, sizeof(gsMQQueueName));
    if (argv[2][0] == 'i')
    {
        nRet = pflGetProfileString("PAID_COMM", "QUEUE_IN",gsMQQueueName, 49, sFileName);
        if (nRet != 0)
        {
            strcpy(gsMQQueueName, "QUEUE.PAID.PBLS");
        }
    }
    else
    {
        nRet = pflGetProfileString("PAID_COMM", "QUEUE_OUT",gsMQQueueName, 49, sFileName);
        if (nRet != 0)
        {
            strcpy(gsMQQueueName, "QUEUE.PBLS.PAID");
        }
        
        memset(gsPAIDDirectory, 0, sizeof(gsPAIDDirectory));
        nRet = pflGetProfileString("PAID_COMM", "PAID_DIR",gsPAIDDirectory, 1000, sFileName);
        if (nRet != 0)
        {
            sprintf(gsPAIDDirectory, "%s/iodata/PAID/remote/", getenv("APPL"));
        }
    }
    HtLog(HTLM_COM, "gsMQQueueName=[%s]\n",gsMQQueueName); 
    
    /* �������ݿ� */
    lReturn = DbConnect();
    if (lReturn != 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Connect to Database Error");
        RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_DATABASE, __FILE__, __LINE__, "Connect Database Error!");
        exit(1);
    }
    
    /* ������Ϣ·������ */
    nRet = nLoadMsqDef();
    if (nRet != 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"load msq define error");
        RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_DATABASE, __FILE__, __LINE__, "Load Message Queue Define Error!");
        exit(1);
    }
    
    /* ��ʼ����Ϣ���� */
    nRet = nCommonMsqInit(CI_PAIDCOMM);
    if (nRet != 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"msq init error");
        RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_DATABASE, __FILE__, __LINE__, " Initialize Message Queue Error! ");
        exit(1);
    }

    nRet = nCommonMsqInit(CI_PAIDBDG);
    if (nRet != 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"msq init error");
        RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_DATABASE, __FILE__, __LINE__, "Initialize Message Queue Error!� ");
        exit(1);
    }
    
    /* ���Ӳ���MQ */
    mq_QInit();
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"connection MQ successful\n");
    
    ErrReport(CI_PAIDCOMM,
              EI_COMMUNICATION,
              COMM_S_INI,
              CI_SEVERITY_MANAGEMENT,
              WS_COMM_INITIALIZE);
    
    signal(SIGTERM, Shutdown);
    
    switch (gsMode[0])
    {
        case 'i':
            /*******************************************************/
            /* IN mode                                             */
            /* read from MQ Queue,                                 */
            /* then write into System Message Queue                */
            /*******************************************************/
            RecvMqWriteSys();
            break;
    
        case 'o':
            /*******************************************************/
            /* OUT mode                                            */
            /* read from System Message Queue,                     */
            /* then write into MQ Queue                            */
            /*******************************************************/
            ReadSysSendMq();
            break;
    
      } /* end of switch */
    
    /* �Ͽ� MQ���� */
    mq_QFin();
    HtLog(HTLM_COM,"�Ͽ� MQ����");
    
    ErrReport(CI_PAIDCOMM,
            EI_COMMUNICATION,
            COMM_S_END,
            CI_SEVERITY_MANAGEMENT,
            WS_COMM_END_ABNORMAL);
    
    /* �Ͽ����ݿ����� */
    lReturn = DbDisConnect();
    
    return 0;
}


void  Shutdown (int sig)
{
    if  (sig >= 0)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "hubcomm:info: signal [%d] received, paiccomm is down.\n",
                sig);
        }

    /* �Ͽ� MQ ���� */    
    mq_QFin();

    ErrReport(CI_PAIDCOMM,
            EI_COMMUNICATION,
            COMM_S_END,
            CI_SEVERITY_MANAGEMENT,
        WS_COMM_END_NORMAL);

    exit(0);
}


/*****************************************************************************/
/* MQ Base Functions                                                         */
/*            mq_connect                                                     */
/*            mq_disconnect                                                  */
/*            mq_open                                                        */
/*            mq_close                                                       */
/*            mq_get_message_wait                                            */
/*            mq_put_message                                                 */
/*****************************************************************************/

long mq_connect(char *sQMName, MQHCONN *ptHcon, MQLONG *plCReason)
{
    MQLONG      lCompCode;                 /* completion code               */

    /************************************************************************/
    /*   Connect to queue manager                                           */
    /************************************************************************/
    MQCONN(sQMName,                       /* queue manager                  */
           ptHcon,                        /* connection handle              */
           &lCompCode,                    /* completion code                */
           plCReason);                    /* reason code                    */

    /* report reason and stop if it failed     */
    if (lCompCode == MQCC_FAILED)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"[mq_connect]: MQCONN ended with reason code %ld\n", *plCReason);
            RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_IBMMQ, __FILE__, __LINE__, "MQ connect ended with reason code [%ld]",*plCReason);
        return MQCOMM_MQ_FAIL;
    }

    return MQCOMM_MQ_SUCC;
}

long mq_disconnect(MQHCONN *ptHcon, MQLONG lCReason)
{
    MQLONG      lCompCode;                 /* completion code               */
    MQLONG      lReason;                   /* reason code                   */

    /************************************************************************/
    /*   Disconnect from MQM if not already connected                       */
    /************************************************************************/
    if (lCReason != MQRC_ALREADY_CONNECTED )
    {
        MQDISC(ptHcon,                        /* connection handle          */
               &lCompCode,                    /* completion code            */
               &lReason);                     /* reason code                */
 
        /* report reason, if any     */
        if (lReason != MQRC_NONE)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "[mq_disconnect]: MQDISC ended with reason code %ld\n", lReason);
            RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_IBMMQ, __FILE__, __LINE__, "MQ disconnect ended with reason code [%ld]",lReason);
        }
    }

    return MQCOMM_MQ_SUCC;
}

long mq_open(char *sObjName, long lOpenMode, MQHCONN tHcon, MQHOBJ *ptHobj, MQLONG *plOpenCode)
{
    MQOD        tod = {MQOD_DEFAULT};      /* Object Descriptor             */
    MQLONG      lO_options;              /* MQOPEN options                */
    MQLONG      lReason;                 /* reason code                   */

    memset(tod.ObjectName, 0, sizeof(tod.ObjectName));
    strcpy(tod.ObjectName, (MQCHAR *)sObjName);
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"[mq_open]: MQOPEN Qname [%s]\n", tod.ObjectName);

    /************************************************************************/
    /*   Open the named message queue for input/output; exclusive or shared */
    /*   use of the queue is controlled by the queue definition here        */
    /************************************************************************/
    if (lOpenMode == MQCOMM_MQ_OPEN_MODE_WRITE)
    {
        /* open queue for output */  /* but not if MQM stopping      */
        lO_options =  MQOO_OUTPUT      + MQOO_FAIL_IF_QUIESCING;         
    }
    else 
    {
        if (lOpenMode == MQCOMM_MQ_OPEN_MODE_READ)
        {
                lO_options = MQOO_INPUT_AS_Q_DEF         /* open queue for input         */
                    | MQOO_FAIL_IF_QUIESCING;   /* but not if MQM stopping      */
                /*
                    + MQOO_FAIL_IF_QUIESCING;*/   /* but not if MQM stopping      */
            #if 0
            strcpy(tod.ObjectName, "PAIDASIA.PBLS");
            #endif
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"[mq_open]: MQOPEN Qname [%s]\n", tod.ObjectName);
        }
        else 
        {
            if (lOpenMode == 
                MQCOMM_MQ_OPEN_MODE_READ + MQCOMM_MQ_OPEN_MODE_WRITE)
            {
                lO_options = MQOO_INPUT_AS_Q_DEF
                        + MQOO_OUTPUT
                        + MQOO_FAIL_IF_QUIESCING;
            }
        }
    }

    MQOPEN(tHcon,                           /* connection handle            */
           &tod,                            /* object descriptor for queue  */
           lO_options,                      /* open options                 */
           ptHobj,                          /* object handle                */
           plOpenCode,                      /* completion code              */
           &lReason);                       /* reason code                  */

            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"[mq_open]: MQOPEN Qname [%s],[%x]\n", tod.ObjectName,lO_options);
    /* report reason, if any; stop if failed      */
    if (lReason != MQRC_NONE)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "[mq_open]: MQOPEN ended with reason code %ld\n", lReason);
        RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_IBMMQ, __FILE__, __LINE__, "MQOPEN ended with reason code [%ld]",lReason);
    }

    if (*plOpenCode == MQCC_FAILED)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "[mq_open]: unable to open queue for input/output\n");
        RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_IBMMQ, __FILE__, __LINE__, "unable to open queue for input/output");
            return MQCOMM_MQ_FAIL;
    }

    return MQCOMM_MQ_SUCC;
}

long mq_close(MQHCONN tHcon, MQHOBJ *ptHobj, MQLONG lOpenCode)
{
    MQLONG      lC_options;                /* MQCLOSE options               */
    MQLONG      lCompCode;                 /* completion code               */
    MQLONG      lReason;                   /* reason code                   */

    /************************************************************************/
    /*   Close the source queue (if it was opened)                          */
    /************************************************************************/
    if (lOpenCode != MQCC_FAILED)
    {
        lC_options = 0;                      /* no close options            */
        MQCLOSE(tHcon,                       /* connection handle           */
                ptHobj,                      /* object handle               */
                lC_options,
                &lCompCode,                  /* completion code             */
                &lReason);                   /* reason code                 */

        /* report reason, if any     */
        if (lReason != MQRC_NONE)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "[mq_close]: MQCLOSE ended with reason code %ld\n", lReason);
        }
    }

    return MQCOMM_MQ_SUCC;
}

long mq_get_message_wait(MQHCONN tHcon, MQHOBJ tHobj, MQMD *ptmd, long lGetMode,
        MQLONG lWaitInterval, char *sMsg, MQLONG *plMsgLen, 
        MQLONG lMaxMsgLen, MQLONG lOpenCode)
{
    MQGMO       tgmo = {MQGMO_DEFAULT};    /* get message options           */
    MQLONG      lCompCode;                 /* completion code               */
    MQLONG      lReason;                   /* reason code                   */

    /************************************************************************/
    /*   Get messages from the message queue                                */
    /*   Loop until there is a failure                                      */
    /************************************************************************/
    lCompCode = lOpenCode;           /* use MQOPEN result for initial test  */

    tgmo.Options = MQGMO_WAIT;           /* wait for new messages           */
    tgmo.WaitInterval = lWaitInterval;   /* 15 second limit for waiting     */

    if (lGetMode != MQCOMM_MQ_GET_MSG_CERTAIN)
    {   /* get all message */
        memcpy(ptmd->MsgId, MQMI_NONE, sizeof(ptmd->MsgId));
        memcpy(ptmd->CorrelId, MQCI_NONE, sizeof(ptmd->CorrelId));
    }

    memset(&gtMsgInd    ,0  ,sizeof(gtMsgInd));
    MQGET(tHcon,                       /* connection handle                 */
          tHobj,                       /* object handle                     */
          ptmd,                        /* message descriptor                */
          &tgmo,                       /* get message options               */
          lMaxMsgLen,                  /* buffer length                     */
          sMsg,                        /* message buffer                    */
          plMsgLen,                    /* message length                    */
          &lCompCode,                  /* completion code                   */
          &lReason);                   /* reason code                       */

    /* report reason, if any     */
    if (lReason != MQRC_NONE)
    {
        if (lReason == MQRC_NO_MSG_AVAILABLE)
        {   /* special report for normal end    */
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"[mq_get_message_wait]: no messages GET TIME OUT\n");
            RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_IBMMQ, __FILE__, __LINE__, "no messages GET TIME OUT");
            return MQCOMM_MQ_FAIL;
        }
        else    /* general report for other reasons */
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"[mq_get_message_wait]: MQGET ended with reason code %ld\n", lReason);
            RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_IBMMQ, __FILE__, __LINE__, "MQGET ended with reason code [%ld]",lReason);
            return MQCOMM_MQ_FAIL;
        }
    }
    
    /* ��ȡMQ �� Message identifier �� Correlation indentifier �� Feedback */
    memcpy(gtMsgInd.MsgId, ptmd->MsgId, sizeof(gtMsgInd.MsgId));
    memcpy(gtMsgInd.CorrelId, ptmd->CorrelId, sizeof(gtMsgInd.CorrelId));   
    gtMsgInd.Feedback = ptmd->Feedback;
    
    return MQCOMM_MQ_SUCC;
}

long mq_put_message(MQHCONN tHcon, MQHOBJ tHobj, MQMD *ptmd, long lPutMode,
        char *sMsg, MQLONG lMsgLen, MQLONG lOpenCode)
{
    MQPMO       tpmo = {MQPMO_DEFAULT};    /* put message options           */
    MQLONG      lCompCode;                 /* completion code               */
    MQLONG      lReason;                   /* reason code                   */

    /************************************************************************/
    /*   Loop until there is a failure                                      */
    /************************************************************************/
    lCompCode = lOpenCode;            /* use MQOPEN result for initial test */

    memcpy(ptmd->Format,              /* character string format            */
          MQFMT_STRING, (size_t)MQ_FORMAT_LENGTH);

    if (lPutMode == MQCOMM_MQ_PUT_MSG_KEEP_ID)
    {
        memcpy(ptmd->MsgId, gtMsgInd.MsgId , sizeof(ptmd->MsgId) );
        memcpy(ptmd->CorrelId, gtMsgInd.CorrelId, sizeof(ptmd->CorrelId) );
        ptmd->Feedback = gtMsgInd.Feedback;
        ptmd->MsgType  = MQMT_REPORT;
    }

        MQPUT(tHcon,                     /* connection handle               */
              tHobj,                     /* object handle                   */
              ptmd,                      /* message descriptor              */
              &tpmo,                     /* default options (datagram)      */
              lMsgLen,                   /* message length                  */
              sMsg,                      /* message buffer                  */
              &lCompCode,                /* completion code                 */
              &lReason);                 /* reason code                     */

        /* report reason, if any */
        if (lReason != MQRC_NONE)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "[mq_put_message]: MQPUT ended with reason code %ld\n", lReason);
            RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_IBMMQ, __FILE__, __LINE__, "MQPUT ended with reason code [%ld]",lReason);
            return MQCOMM_MQ_FAIL;
        }
        printf("\n");
        printf("Notification Text:\n");
        printf("%s\n", sMsg);

    return MQCOMM_MQ_SUCC;
}


/*****************************************************************************/
/* MQ App Functions                                                          */
/*            mq_QInit                                                       */
/*            mq_QFin                                                        */
/*            mq_QMsgGetWait                                                 */
/*            mq_QMsgPut                                                     */
/*****************************************************************************/

void mq_QInit()
{
    long        lReturn;

    /* connect MQM */
    lReturn = mq_connect(gsMQQMName, &gtHcon, &glCReason);
    if (lReturn != MQCOMM_MQ_SUCC)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "1st->can't connect MQM(Message Queue Manager), TRY AGAIN!\n");
        /* try again */
        lReturn = mq_connect(gsMQQMName, &gtHcon, &glCReason);
        if (lReturn != MQCOMM_MQ_SUCC)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "2nd->can't connect MQM(Message Queue Manager)\n");
             exit(1);
        }
    }

    /* open queues */
    if (gsMode[0] == 'i')
    {
        lReturn = mq_open(gsMQQueueName, MQCOMM_MQ_OPEN_MODE_READ, gtHcon, &gtHobjI, &glOpenCodeI);
        if (lReturn != MQCOMM_MQ_SUCC)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "can't open queue object IN [%s]-[%s]\n", gsMQQMName, gsMQQueueName);
              mq_disconnect(&gtHcon, glCReason);
            exit(1);
        }
    }
    else /* for 'o' */
    {
        lReturn = mq_open(gsMQQueueName, MQCOMM_MQ_OPEN_MODE_WRITE, gtHcon, &gtHobjO, &glOpenCodeO);
        if (lReturn != MQCOMM_MQ_SUCC)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                    "can't open queue object OUT [%s]-[%s]\n", gsMQQMName, gsMQQueueName);
            mq_disconnect(&gtHcon, glCReason);
            exit(1);
        }
    }

    return;
}


void mq_QFin()
{
    long        lReturn;

    /* close queues */
    if (gsMode[0] == 'i')
    {
        lReturn = mq_close(gtHcon, &gtHobjI, glOpenCodeI);
        if (lReturn != MQCOMM_MQ_SUCC)
        {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"can't close queue object IN\n");
        }
    }
    else /* 'o' and 'b' */
    {
        lReturn = mq_close(gtHcon, &gtHobjO, glOpenCodeO);
        if (lReturn != MQCOMM_MQ_SUCC)
        {
                HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"can't close queue object OUT\n");
        }
    }

    /* disconnect from MQM */
    lReturn = mq_disconnect(&gtHcon, glCReason);
    if (lReturn != MQCOMM_MQ_SUCC)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"can't disconnect MQM(Message Queue Manager)\n");
    }

    return;
}


MQLONG mq_QMsgGetWait(MQLONG lWaitInterval, char *sMsg, MQLONG *plMsgLen)
{
    long        lReturn;
    int         i;

    lReturn = mq_get_message_wait(gtHcon, gtHobjI, &gtmd, 
                /*
                MQCOMM_MQ_GET_MSG_CERTAIN, lWaitInterval, 
                */
                MQCOMM_MQ_GET_MSG_ALL, lWaitInterval, 
                sMsg, plMsgLen, MQ_IPC_LEN, glOpenCodeI);
    if (lReturn != MQCOMM_MQ_SUCC)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"can't get message IN \n");
        return -1;
    }

    return *plMsgLen;
}

MQLONG mq_QMsgPut(char *sMsg, MQLONG lMsgLen)
{
    long        lReturn;
    int         i;
    
    lReturn = mq_put_message(gtHcon, gtHobjO, &gtmd, MQCOMM_MQ_PUT_MSG_KEEP_ID, sMsg, lMsgLen, glOpenCodeO);
    if (lReturn != MQCOMM_MQ_SUCC)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"can't put message OUT \n");
        return -1;
    }
    
    return lMsgLen;
}


/***Add by han meirong 20110420 ****begin*****/
void ReadSysSendMq()
{
    int     nRet;
    short   nDataLen=0;
    long    lDataLen=0;
    char    sDataBuf[MQ_IPC_LEN];
    long    lMsgSource;
    T_HUB_MSG     tHubMsg;
    char  TmpFileName[512+1];
    char sFileName[512+1];
    char Length[8+1];
    int len;
    int ReadLen;
    FILE    *fp;

    for (;;)
    {
        /* read from Sys Q */
        memset(sDataBuf, 0, sizeof(sDataBuf));
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"ReadSysSendMq start!!!!!");
        nRet = nCommonMsqRecv(&nDataLen, sDataBuf, &lMsgSource, CI_PAIDCOMM);
        if (nRet != 0) {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"PAIDcomm: can't read from system queue %d\n", nRet);
            break;
        }
    		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"DataBuf:[%s]",sDataBuf);
        memset(&tHubMsg   ,0          ,sizeof(tHubMsg));
        memcpy(&tHubMsg   ,sDataBuf   ,sizeof(tHubMsg));
        HtLog(HTLM_COM,"sizeof(tHubMsg)[%04d]",sizeof(tHubMsg));
    
        memset(sFileName, 0, sizeof(sFileName));
        memset(Length, 0, sizeof(Length));
        memcpy(Length,tHubMsg.file_size,sizeof(tHubMsg.file_size)); 
        memcpy(sFileName,tHubMsg.file_name,sizeof(tHubMsg.file_name));
        HtLog(HTLM_COM,"MQ MSGIO=[%c]",tHubMsg.msg_io);
        HtLog(HTLM_COM,"MQ MSGFile=[%256.256s]",tHubMsg.file_name);
        HtLog(HTLM_COM,"MQ MSGID =[%16.16s]",tHubMsg.tHubHead.msg_id);
        HtLog(HTLM_COM,"MQ MSGTPYE =[%4.4s]",tHubMsg.tHubHead.msg_type);
        HtLog(HTLM_COM,"MQ MSGLen=[%8.8s]",tHubMsg.tHubHead.msg_length);
        HtLog(HTLM_COM,"MQ MSGChannel=[%14.14s]",tHubMsg.tHubHead.msg_channel);
        RightTrim(sFileName);

        fp = fopen(sFileName, "r");
        if (fp == NULL)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
                "nTransferPaidMqMsgToFile(): Open file error! [%s]\n", sFileName);
            break;
        }

        /**malloc the memory space***/
        len=atoi(Length);
        HtLog(HTLM_COM,"[%d]",len);
        char *ReadBuf=(char*)malloc(sizeof(char)*(len+1));
        if(ReadBuf==NULL)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"MALLOC FAIL!\n");
            fclose(fp);
            break;               
        }

        memset(ReadBuf    ,0  ,sizeof(char)*(len+1));
        ReadLen=fread(ReadBuf,1,len,fp);
        fclose(fp);

        /***compare the file Lenth***/
        if(ReadLen!=len)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"File Lenth Not Match !\n");
            free(ReadBuf);
            break;
        }
        HtLog(HTLM_COM,"MQ PUTBuf=[%s]",ReadBuf);
        /* put out message to Queue */
        if (mq_QMsgPut((char *)ReadBuf, len) < 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"PAIDcomm: put message to MQ Queue fail!\n");
            free(ReadBuf);
            break;
         }
         free(ReadBuf);
         HtLog(HTLM_COM,"MQ MSGFile=[%256.256s] PUT TO MQ SUCCESS",tHubMsg.file_name);         
    }
    
    return;
}

void RecvMqWriteSys()
{
    int     nRet;
    MQLONG  nDataLen;
    char    sDataBuf[MQ_IPC_LEN];
    char  sFileName[256+1];
    char    sMsgId[48+1];
    char    sMsgType[4+1];
        char    sCorrelId[48+1];
        char    Lenth[8+1];
    T_HUB_MSG tHubMsg;
    

    for (;;)
    {
        memset(&sMsgId   ,  0,sizeof(sMsgId   ));
        memset(&sCorrelId,  0,sizeof(sCorrelId));
          
        /* ��MQ�����ж�ȡPAID���͹����ı��� */
        memset(sDataBuf, 0, sizeof (sDataBuf));
        if (mq_QMsgGetWait((MQLONG)lWaitSec, sDataBuf, &nDataLen) < 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"PAIDcomm: get message from MQ Queue fail!\n");
            break;
        }

        HtDebugString(logfile, sDataBuf, nDataLen, __FILE__, __LINE__);
    
        /* ����Ϣ����ת��Ϊ�ļ�  */
        memset(sFileName,   0,  sizeof(sFileName));
        memset(sMsgType,   0,  sizeof(sMsgType));
        
         /* �鱨��֪ͨPbhubbdg */
    
        memset(&tHubMsg, ' ', sizeof(tHubMsg));
        /* Head Message */
        memcpy(&tHubMsg.tHubHead, sDataBuf, sizeof(tHubMsg.tHubHead));
        memcpy(sMsgType,tHubMsg.tHubHead.msg_type,sizeof(tHubMsg.tHubHead.msg_type));
        
        HtLog(HTLM_COM,"PUT IN nTransferPaidMqMsgToFile sMsgType=[%4.4s]\n",sMsgType);
        
        if (nTransferPaidMqMsgToFile(&nDataLen, sDataBuf, sMsgType, sFileName) != 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"PAIDcomm: can't write into file %d\n", nRet);
            RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_OTHERERR, __FILE__, __LINE__, "Transfer Messages to file failed");
            continue;
        }

        

        
        /* Head Message */
        //memcpy(&tHubMsg.tHubHead, sDataBuf, sizeof(tHubMsg.tHubHead));
        tHubMsg.msg_io = PBLS_MSG_IO_IN[0]; 
        memcpy(tHubMsg.file_name, sFileName, strlen(sFileName));
        memset(Lenth,0,sizeof(Lenth));
        sprintf(Lenth, "%08d", nDataLen);
        memcpy(tHubMsg.file_size, Lenth, sizeof(tHubMsg.file_size));
                       
        HtLog(HTLM_COM,"MQ2 MSGIO=[%c]",tHubMsg.msg_io);
        HtLog(HTLM_COM,"MQ2 MSGFile=[%256.256s]",tHubMsg.file_name);
        HtLog(HTLM_COM,"MQ2 MSGID =[%16.16s]",tHubMsg.tHubHead.msg_id);
        HtLog(HTLM_COM,"MQ2 MSGTPYE =[%4.4s]",tHubMsg.tHubHead.msg_type);
        HtLog(HTLM_COM,"MQ2 MSGLen=[%8.8s]",tHubMsg.tHubHead.msg_length);
        HtLog(HTLM_COM,"MQ2 MSGChannel=[%14.14s]",tHubMsg.tHubHead.msg_channel);
             
        /* Body Message */
        
        memset(sDataBuf, 0, sizeof (sDataBuf));
        memcpy(sDataBuf, (char *)&tHubMsg   ,sizeof(tHubMsg));
        nDataLen = sizeof(tHubMsg);

        HtDebugString(logfile, sDataBuf, nDataLen, __FILE__, __LINE__);

        nRet = nCommonMsqSend(nDataLen, sDataBuf, CI_PAIDCOMM, CI_PAIDBDG);
        if (nRet != 0)
        {
            HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__, "PAIDcomm: can't write into system queue %d\n", nRet);
            RecTivoliLogC( "PBLS", "PBPAIDCOMM", TIVOLI_MESSAGEQ, __FILE__, __LINE__, "CALL nCommonMsqSend ERROR ");
            continue;
        }   
    } /* for */
}
/***Add by han meirong 20110420 ****end*****/

/******************************************************* 
 * �������ܣ���PAID���͹����ı���д�뵽�ļ���
 * ���룺pnDataLen,sDataBuf,sMsgType
 * �����pFileName
 *******************************************************/
int nTransferPaidMqMsgToFile(long *pnDataLen, char *sDataBuf, char *sMsgType, char *pFileName)
{
    FILE *fp;
    char sFileName[512];
    char sFilePath[256];
    char sTime[21];
    char sDate[9];
    int len;
    int len_filename;
    
    memset(sTime,0,sizeof(sTime));
    memset(sDate,0,sizeof(sDate));
    
    HtLog(HTLM_COM,"GET THE sMsgType=[%4.4s]\n",sMsgType);
    
    #if 0
    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, sTime);
    #endif
    CommonGetCurrentTimeMilli(sTime);
    GetCurrentDateAll(GET_CURRENT_DATE_FLAG_ICBC, sDate);

    memset(sFilePath, 0, sizeof(sFilePath));
    memset(sFileName, 0, sizeof(sFileName));
    sprintf(sFilePath,"%s%s%s",getenv("APPL"),"/iodata/hub/inrt/",sDate);
    strcat(sFilePath,"/");
    mkdir(sFilePath, S_IRWXU|S_IRWXG|S_IRWXO);

    sprintf(sFileName, "%sRECV_%s_%4.4s.MSG", sFilePath,sTime,sMsgType);

    fp = fopen(sFileName, "w+");
    if (fp == NULL)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"nTransferPaidMqMsgToFile(): Open file error! [%s]\n", sFileName);
        return -1;
    }

    len = fwrite(sDataBuf, 1, *pnDataLen, fp);
    if (ferror(fp))
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"nTransferPaidMqMsgToFile(): Write file error! [%s]\n", sFileName);
        fclose(fp);
        return -2;
    }
    len_filename=strlen(sFileName);
    //strcpy(pFileName, (char *)basename(sFileName));
    memcpy(pFileName,sFileName,len_filename);
    fclose(fp);
    
    return 0;
}

int CopyDataFile()
{
    char sCmd[2048];
    char sDate[8+1];
    char sFilePath[255+1];
    char sPathFile[514+1];
    char sDestPath[255+1];
    int  nRet;
    
    memset(sCmd, 0, sizeof(sCmd));
    
    switch (gsMode[0])
    {
        case 'i': 
            memcpy(gsPAIDInstType, PAID_AT_INSTRUCTION_TYPE_GET, 3);
            break;
        case 'o': 
            memcpy(gsPAIDInstType, PAID_AT_INSTRUCTION_TYPE_PUT, 3);
            break;
    }

    /***************************************************************/
    /* "scp -i "+scp_identity+" "+destIP+":"+destDir+" "+localFile */
    /* "scp -p pbls@xxx:/xx/xx/xx/xx/file1 /xx/xx/xx/file1         */
    /***************************************************************/
    if (memcmp(gsPAIDInstType, PAID_AT_INSTRUCTION_TYPE_GET, 3) == 0)
    {
    }

    if (memcmp(gsPAIDInstType, PAID_AT_INSTRUCTION_TYPE_PUT, 3) == 0)
    {
        HtLog(HTLM_COM,"��������ļ����͵�Ŀ��������� .");

        memset(sPathFile    ,0  ,sizeof(sPathFile));
        RightTrim(gsPAIDPath);
        RightTrim(gsPAIDFile);
        strcpy(sPathFile    ,gsPAIDPath);
        strcat(sPathFile    ,gsPAIDFile);
        HtLog(HTLM_COM,"gsPAIDPath=[%s]",gsPAIDPath);
        HtLog(HTLM_COM,"gsPAIDFile=[%s]",gsPAIDFile);
        HtLog(HTLM_COM,"sPathFile =[%s]",sPathFile );
        
        memset(sDestPath    ,0  ,sizeof(sDestPath));
        nRet = GetSysPara("7009",sDestPath);
        if(nRet != 0)
        {
            HtLog(HTLM_COM,"��ȡPAIDȡ�ļ�·��ʧ�� sqlcode=[%d]",nRet);
        }
        RightTrim(sDestPath);
        replace_env_var(sDestPath);
        HtLog(HTLM_COM,"PAID ��ȡ�ļ�·��Ϊ[%s]",sDestPath);

        mkdir(sDestPath, S_IRWXU|S_IRWXG|S_IRWXO);

        sprintf(sCmd,"%s %s %s","cp -f",sPathFile,sDestPath);

        HtLog(HTLM_COM,"sCmd=[%s]",sCmd);
    
        if (system(sCmd) == -1)
        {
            HtLog(HTLM_ERR,"�������ļ����͵�Ŀ��·��ʧ�� ! ");
            return -1;  
        }

    }
    return 0;
}
