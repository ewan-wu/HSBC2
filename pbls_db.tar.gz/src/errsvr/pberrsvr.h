#ifndef _ERRSVR_H
#define _ERRSVR_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <signal.h>
#include <string.h>
#include <memory.h>

#include "msglog.h"
#include "msgque.h"
#include "wd_incl.h"
#include "glb_def.h"
#include "status.h"

#endif /* _ERRSVR_H */


