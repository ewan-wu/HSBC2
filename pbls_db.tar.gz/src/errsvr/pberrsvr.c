/*********************************************************************
*	Copyright 2000, Shanghai Huateng Software System Inc.        	 *
*	All rights Reserved.                                         	 *
*                                                                    *
*	This is UNPUBLISHED PROPRIETARY SOURCE CODE of Shanghai      	 *
*	Huateng Software System Inc.; the contents of this file may  	 *
*	not be disclosed to third parties, copied or duplicated in   	 *
*	any form, in whole or in part, without the prior written     	 *
*	permission of Shanghai Huateng Software System Inc.          	 *
*                                                                    *
*********************************************************************/

/*********************************************************************
*	Name	: errsvr.c                                               *
*	Desc	: sytem message report server                            *
*	Author:                                                          *
*	Date	:                                                        *
*	Function: 1. Accept system message from various servers          *
*             2. Send signal to umsctl server                        *
*	Location: $(TOPDIR)/src/errsvr                                   *
*                                                                    *
* 	Modify By:                                                       *
* 	Name    Date			What                                     * 
* 	----	----------	----------------------------------           *
**********************************************************************/
#include "pberrsvr.h"

#include "htlog.h"
char  logfile[256];

void vErrProcess(struct wd_pbsyslog_area *, pid_t);

char  sTime[15];

int main(int argc, char **argv)
{
 	int   	len;
 	long  	lReturn;
 	short 	nDataLen,nRet;
	long 	lMsgSource;
 	pid_t 	UmsctlPid;

 	struct
 	{
    	long mtype;
    	struct wd_pbsyslog_area buf;
 	} msgerr_buf;

    setbuf(stdout,NULL);    
    setbuf(stderr, NULL);

    if ( argc != 2 )
    {
        fprintf(stdout, "Usage: errsvr < logfile >\n");
        exit(0);
    }

    nRet = GetLogName(argv[1], logfile);
    if (nRet != 0 )
    {
        fprintf(stderr, "GetLogName error !\n");
    }

    lReturn = DbConnect();
    if (lReturn != 0)
    {
		HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        	"OPEN EBBANK DATABASE ERROR lReturn = %d..., EXIT 2\n", lReturn);
        exit(2);
    }
	HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        	"OPEN DATABASE Ok !\n");

	/*****************************/
   	/* Initial the message queue */
	/*****************************/
	nRet = nCommonMsqAllInit(CI_ERRSVR);
	if (nRet != 0) 
   	{
       	ErrReport(CI_ERRSVR, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_ERR_CONNECT);
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Connect ERRSRV MSGQ fail!\n");
        exit(3);
    }

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Connect ERRSRV MSGQ success!\n");

  	UmsctlPid = (pid_t) 0;

  	while(1)
   	{
		nRet = nCommonMsqRecv (&nDataLen, (char*)&msgerr_buf, 
								&lMsgSource, CI_ERRSVR);
   		
        if (nRet == -1)
        {
			if (errno != EINTR)
			{
				if (nCommonMsqAllInit(CI_ERRSVR) == -1)
				{
					HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
						"Connect ERRSRV MSGQ fail!\n");
					exit(1);
				}
			}
           	continue;
        }
		/***
       	if ((msgerr_buf.buf.msg_code == EI_INIT)&&
        	(msgerr_buf.buf.msg_src == CI_UMSCOMM))
        {
           		UmsctlPid = msgerr_buf.buf.msg_subcode;
       	   		GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC,  sTime );

				HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
	        		"receive UMSCTL pid = %d at %s\n", UmsctlPid, sTime);
        }
		***/

       	vErrProcess( &msgerr_buf.buf, UmsctlPid);
   
   } /* while (1) */
}
    
                                    
void vErrProcess (struct wd_pbsyslog_area *errorbuf, pid_t UmsctlPid)
{                        
  	int nRet;
	char sBankId[4];

  	GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC,  sTime );
	HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
  			"ERRSVR recv a msg at %s\n", sTime);

	/* set time in DB format */
	CommonGetCurrentTimeDB(errorbuf->rec_updt_time);
	//Ϊ��ɾ����ʷ����ʱ�����ѯ
	//CommonGetCurrentTimeDB(errorbuf->sys_log_time);
	CommonGetCurrentTime(errorbuf->sys_log_time);

	nRet = DbsPBSYSLOG(DBS_INSERT , errorbuf);
  	if ( nRet != 0 )    
  	{ 
		GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC,  sTime );
		HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"insert the table errlog error %d at %s\n", nRet, sTime);
		DbRollbackTxn();
    }
	if (nRet == 0) 
		DbCommitTxn();

  	if (errorbuf->msg_src == CI_E3COMM)
	{
		if ((errorbuf->msg_subcode == COMM_S_INI) ||
			(errorbuf->msg_subcode == COMM_S_RESTART))
		{
			nRet = SetSysStatus(SET_E3_STATUS, SET_STATUS_ON);
			HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"SetSysStatus(SET_E3_STATUS, SET_STATUS_ON) = %d at %s\n", 
				nRet, sTime);
		}
		if (errorbuf->msg_subcode == COMM_S_END)
		{
			nRet = SetSysStatus(SET_E3_STATUS, SET_STATUS_OFF);
			HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"SetSysStatus(SET_E3_STATUS, SET_STATUS_OFF) = %d at %s\n", 
				nRet, sTime);
		}
	}

  	if (errorbuf->msg_src == CI_ICBCCOMM || 
		errorbuf->msg_src == CI_CCBCOMM || 
		errorbuf->msg_src == CI_CITICCOMM || 
		errorbuf->msg_src == CI_CMBCOMM )
	{
		memset(sBankId, 0, sizeof(sBankId));
		switch (errorbuf->msg_src)
		{
			case CI_ICBCCOMM:
				strcpy(sBankId, PBLS_BANK_ID_ICBC);
				break;
			case CI_CCBCOMM:
				strcpy(sBankId, PBLS_BANK_ID_CCB);
				break;
			case CI_CITICCOMM:
				strcpy(sBankId, PBLS_BANK_ID_CITIC);
				break;
			case CI_CMBCOMM:
				strcpy(sBankId, PBLS_BANK_ID_CMB);
				break;
		}
		if ((errorbuf->msg_subcode == COMM_S_INI) ||
			(errorbuf->msg_subcode == COMM_S_RESTART))
		{
			nRet = SetPBStatus(sBankId, SET_STATUS_ON);
			HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"SetPBStatus(%s, SET_STATUS_ON) = %d at %s\n", 
				sBankId, nRet, sTime);
		}
		if (errorbuf->msg_subcode == COMM_S_END)
		{
			nRet = SetPBStatus(sBankId, SET_STATUS_OFF);
			HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"SetPBStatus(%s, SET_STATUS_OFF) = %d at %s\n", 
				sBankId, nRet, sTime);
		}
	}

	if (UmsctlPid != 0)
	{
     	if (kill(UmsctlPid, SIGUSR1) == -1)
       		perror("kill");
      	else
		{
			HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
          			"Errsvr send signal to umsctl %d\n", UmsctlPid);
		}
	}

	return;
}
