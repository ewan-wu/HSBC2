find . -name "*c"|xargs grep $1
