#ifndef     _HTLOG_H_
#define     _HTLOG_H_

#define  _DEBUG 
#include    <stdio.h>
#include    <stdlib.h>
#include    <stdarg.h>
#include    <fcntl.h>
#include    <time.h>
#include    <sys/types.h>
#include    <sys/stat.h>
#include    <string.h>

#define     SINGLE_LINE                 "-------------------------\n"

#define     DOUBLE_LINE                 "=========================\n"

#define     SIZE_UNIT                   ( 1024*1024 )

#define     CorporationTitle            "Shanghai Huateng Co. Ltd"

#define     HT_LOG_MODE_OFF             0
#define     HT_LOG_MODE_SIMPLE          1
#define     HT_LOG_MODE_ERR             2
#define     HT_LOG_MODE_COMPLEX         3
#define     HT_LOG_MODE_DEBUG           4

#define     HT_DEBUG_STRING_MODE_OFF    0
#define     HT_DEBUG_STRING_MODE_ON     1

#define     MAX_FILE_LEN                128
#define     SIZE_UNIT                   ( 1024*1024 )

#endif


int 	replace_env_var(char *str);
int	 	convert_env(char *str);
int 	GetLogName(char *infile, char *outfile);
int HtLog(char *logfile, int level, char *file, int line, char *fmt, ...);
short HtDebugString(	char *logfile, char *psBuf, int iLength,char *iFile, int iLine );
