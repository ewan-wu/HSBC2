/*************************************************************************/
/*  Kernel Banking System                                                */
/*  Copyright (c) 2002                                                   */
/*  Shanghai Huateng Software System Co., Ltd.                           */
/*  All Rights Reserved                                                  */
/*************************************************************************/

#ifndef _CMDATE_H
#define _CMDATE_H

typedef struct 
{
   short   nFunCd;              /* function code                     */
   char    sStartDay[9];        /* start day                         */
   char    sEndDay[9];          /* end day                           */
   int     nMonthCnt;           /* month count                       */
   int     nDayCntPer;          /* day count by 30 days per month    */
   int     nDayCntAct;          /* day count by actual               */
} T_COMM_GDATE;


extern int commDayCalc(T_COMM_GDATE *t_comm_gdate);
/****************************************************************************/
/* +-------+------------------------+-----------------------------------+   */
/* | FUNCD |          INPUT         |               OUTPUT              |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   1   |  sStartDay sEndDay     |  nDayCntAct                       |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   2   |  sStartDay sEndDay     |  nDayCntPer nMonthCnt             |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   3   |  sStartDay sEndDay     |  nDayCntPer nMonthCnt nDayCntAct  |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   4   |  sStartDay nMonthCnt   |  sEndDay                          |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   5   |  sStartDay nDayCntAct  |  sEndDay                          |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   6   |  sEndDay nDayCntAct    |  sStartDay                        |   */
/* |-------+------------------------+-----------------------------------|   */
/* |   7   |  sEndDay nMonthCnt     |  sStartDay                        |   */
/* +-------+------------------------+-----------------------------------+   */
/* |   8   |  sStartDay             |  sEndDay                          |   */
/* |       +------------------------+-----------------------------------+   */
/* |       |  Check date valid.                                         |   */
/* |       |  return : 0   OK.                                          |   */
/* |       |         : 1   not valid.                                   |   */
/* |       |           The monthend day in sEndDay.                     |   */
/* |       |           Especialy for loan.                              |   */
/* +-------+------------------------+-----------------------------------+   */
/* |   9   |  sStartDay sEndDay     |  nMonthCnt (nature month)         |   */
/* |-------+------------------------+-----------------------------------|   */
/****************************************************************************/

#endif
