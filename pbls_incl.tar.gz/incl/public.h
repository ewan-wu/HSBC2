#include "wd_incl.h"
/*add by yl 20130913 start*/
#include "htlog.h"
#include "glb_def.h"
#include "sysdef.h"
#include "msglog.h"
#include "ipc.h"
#include "swttoc.h"
#include "status.h"
#include "wd_incl.h"
#include <iconv.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>

/*add by yl 20130913 end*/
#define MAX_SRVMSQ_TXN_NUM          5000
#define MAX_TXNNOMAP_TXN_NUM        3000
#define TXNNO_MAP_INFC_LEN          4
#define TXNNO_MAP_OUTNO_LEN         8
#define TXNNO_MAP_FILLMAP_LEN       50
#define TXNNO_MAP_FILLVAL_LEN       50

/*add by yl 20130913 start*/

short LoadSrvMsq();
long nFindServerId(long lSrcSrvId, long lTxnNo, short nTxnStep);
long lGetTxnInCode ( long lSrvId, char* sTxnOutNo, char* sTxnRltNo );
short LoadTxnnoMap();
short nGetOutTxno(long sInfcID, long lClsTxnNo, char* sOutTxnNo);
short nGetClsTxno(long sInfcID, long* lClsTxnNo, char* sOutTxnNo);
short nGetFillMap(long sTxnNo, char*sfillMap, char*  sfillVal);
short nGetFleFlg(long sTxnNo);
short nGetFileFlag(long lSrvId,long lTxnNo);
short nGetFwdFlg(long sTxnNo);
char *RightTrim ( char *str );
char *LeftTrim( char *str );
char    *FloatToChar(double dAmount, char *caAmt);
void GetTokenStringStr(char *pString, char *pSeperate,char *sTmp);
void GetTokenStringChr(char *pString, char chSeperate,char *sTmp);
short FindCharPos(char *pString, char *pSeperate1, char *pSeperate3, char *pSeperate2, void *pLen);
void DeleteHeadingZero(char *pString,ULONG lTail);
void DeleteTailSpace(char *pString,ULONG lTail);
int DeleteTailSpaceLen(char *pString,ULONG lTail);
int CheckChn( char ch );
int MbStrCpy( char * Src, char * Desc, int iLen );
short nInitMsgQue(short nSwitchType, char *logfile);
int nNewTxnRefnoForPB(char *sBankId, char *sTxnRefno);
int nNewTxnRefnoForSystem(char *sTxnRefno);
int nFindSysRefnoByPBRefno(char *sBankId, char *sTxnRefno, char *sSysRefno, char *sStatus);
int nGetPBSTEODDays(char *sBankId, int nMaxDays, int *pnDays, char *sDate);
int nGetPBSTEODDays_Free(char *sBankId, int nMaxDays, int *pnDays, char *sDate, char *sStartDate, char *sEndDate);
int nSetPBSTEODFlag(char *sBankId, char *sStatus);
int nChkPBSTEODFlag(char *sBankId, char *sStatus);
long lCommonGetSrvId(char *sBankId, char *sSrvType);
int nRecordOpAcInfo(char *sBankId, char *sActno, char *sCurcd, char *sType,char *sName, char *sUserId, char *sDepId, char *sBranchId, char *sBranchName, char *sTlr, char *sDept);
int nCommonCheckDebitDup(char *sCustRefno);
int nCommonCheckDuplication(char *sE3Bulkno, char *sE3Refno, char *sValueDate, char *sSysRefno);
int nComCtrlTmpAdd(char *sTxno, char *sOpType, char *sOpDept, char *sOpTlr, char *sOpText1, char *sOpText2, char *sOpText3);
int nComCtrlTmpUpdate(char *sOpDept, char *sOpTlr, char *sOpTime, char *sCtrlDept, char *sCtrlTlr);
int nFindSysRefnoByCustRefno(char *sBankId, char *sCustRefno, char *sSysRefno);
int GetSyspara(const char *sParano, const char *sBrno, char *sParaval);
void IcbcGetOneDayBefore(char *sCurDate, char *sBefDate);
int code_convert(char *from_charset, char *to_charset,char *inbuf, int inlen,char *outbuf, int* outlen);
int u2g(char *inbuf, int inlen, char *outbuf, int* outlen);
int g2u(char *inbuf, int inlen, unsigned char* outbuf, int* outlen);
int g2e(char *inbuf, int inlen, unsigned char* outbuf, int* outlen);
void TrimUtfHead(unsigned char *inbuf, int inlen, int *outlen);
void AddNewLine(const char *inbuf, int inlen, int cnt, const char *newline, char *outbuf, int *outlen);
void ToHex(const unsigned char *inbuf, int inlen, char *outbuf, int *outlen);
void PrtHex(const unsigned char *inbuf, int inlen);
void  LeftPadZero( char *str, char *OutStr, int len);
int nGetPbankSendFlag(const char *sBankId, char cFlag, const char *sTime);
long lGetFileLength(const char *sFileName);
int CheckInterval(char *time1,char *time2 , int count );
int GetCurrentDateAll(int iFlag, char *sCurrentDate);
int GetCurrentTimeAll(int iFlag, char *sCurrentTime);
int nGetLastWorkDate(const char *sCurrDate, char *sLastNDate);
int nGetLastNDate(const char *sCurrDate, int n, char *sLastNDate);
int nGetForwardNDate(const char *sCurrDate, int n, char *sForwardNDate);
int RecRptLog(char *sPath, char *sName, char *sType, char *sStartTime);
char *LeftFillZero(char *sIn, int iLen);
char *GetFlagName(int type, char *sFlag);
char *apTrim(char *sIn, int iLen);

/*add by yl 20130913 end*/

struct wd_pbsrvmsq_area gSrvMsq[MAX_SRVMSQ_TXN_NUM];
struct wd_pbtxnomap_area gTxnnoMap[MAX_TXNNOMAP_TXN_NUM];



