#ifndef _IPC_H
#define _IPC_H

#define CR_CLSTXNNO_LEN         8
#define CR_TXNSTEP_LEN          4
#define CR_CLRRLTNO_LEN         8
#define CR_CLSSSN_LEN           6
#define CR_AMT_LEN              16
#define CR_TERMNO_LEN           2
#define CR_TERMSSN_LEN          8
#define CR_SRVID_LEN            8
#define CR_TERMID_LEN           8
#define CR_SRVNAME_LEN          10
#define CR_REFNO_LEN            14
#define CR_CLSTXNSTEP_LEN       1

#define DLEN_TRMSEQ     2
#define DLEN_EJFNO  7
#define DLEN_BRNO       3
#define DLEN_TASKID     2
#define DLEN_TXNCD  4
#define DLEN_TLRNO  8
#define DLEN_TLSRNO     7
#define DLEN_TLR_PASSWD     8
#define DLEN_MULTNO     6
#define DLEN_DATE   8
#define DLEN_TIME   6
#define IPC_RSV_LEN     14*1024
#define GEN_FLD_LEN     385
#define TEXT_FLD_LEN    IPC_RSV_LEN+GEN_FLD_LEN
#define TSK_ID_LEN                  2
#define SVC_NAME_LEN                12
#define DELTA_TITA_TOTA  9 /*sizeof(T_TitaLabel)-sizeof(T_TotaLabel)*/
#define TXNO_QUERY_RSP_MAX      9997
#define TXNO_QUERY_RSP_MIN      5001
#define IPC_WEB_RSV_LEN         9*1024

/* add by zr  begin */
#define DLEN_IP_ADDR                      15
/* add by zr  end   */

#define CR_TLRSSN_LEN       4
#define OUT_TXNNO_LEN       2
#define CR_OUTTXNNO_LEN     4
#define CR_CNAPS_PKT_LEN    8
#define CNS_MAX_PKT_LEN     9000
#define CMT_BIT                 3

#define MAX_PACKET_LEN      14*1024+2048
#define FLD_NAME_LEN           6


#define ULONG                  unsigned long
#define UINT                   unsigned int
#define USHORT                 unsigned short


typedef struct
{
    char      sClsTxnNo[CR_CLSTXNNO_LEN];
    char      sClsSsn[CR_CLSSSN_LEN];
    char      sSrcSrvId[CR_SRVID_LEN];
    char      sTxnStep[CR_TXNSTEP_LEN];
} T_IPCHeader;  /*len 26*/

typedef struct
{
    char    sOutTxnNo[8];   /*�ⲿ���״���*/
    char    sOutRltNo[8];   /*�ⲿ��ؽ��״���*/
    char    sBankNo[12];    /*�к�*/
    char    sTermNo[8];     /*�ն˺�*/
    char    sTermSsn[14];   /*�ն���ˮ��*/
    char    sTermTime[14];  /*�ն�ʼ��ʱ��*/
    char    sTlrNo[4];      /*��Ա��*/
    char    sTlrSsn[4];     /*��Ա��ˮ��*/
    char    sTxnType[2];    /*��������*/
    char    sOprType[2];    /*ҵ������*/
    char    sGbaseDate[8];  /*ָ�������*/

    char    sRefSsn[14];    /* ������ˮ��*/
    char    sRltSsn[14];    /*���������ˮ��*/
    char    sRspNo[4];      /* ����Ӧ����*/

    char    sPayAcc[18];    /*�������˺�*/
    char    sPayBnk[12];    /*�������к�*/
    char    sPayName[60];   /*����������*/
    char    sCurCode[3];    /*���ҷ���*/
    char    sTxnAmt[16];    /*���*/
    char    sRcvAcc[32];    /*�տ����˺�*/
    char    sRcvBnk[12];    /*�տ����к�*/
    char    sRcvName[60];   /*�տ�������*/
} T_FEGenFldDef;  /*len 329 */


typedef struct  HOST_LABEL
{
    char header[8];
} T_HostLabel;

typedef struct  TITA_LABEL
{
    char header[8];
    char clsno[6];                 /*  CLS ssn               */
    char termid[8];                /*  termid                */
    char htrmseq[DLEN_TRMSEQ];     /* correction old trmseq 2*/
    char hejfno[DLEN_EJFNO];       /*  correction old ejfno 7*/
    char opnbr[DLEN_BRNO];         /*  ����Ա�����к�       5*/
    char kinbr[DLEN_BRNO];         /*  ���������к�         5*/
    char trmseq[DLEN_TRMSEQ];      /*  terminal sequence   2 */
    char ejfno[DLEN_EJFNO];        /*  EJF no   7            */
    char taskid[DLEN_TASKID];      /*  �������ࣨ2λ��       */
    char tmtype;                   /*  terminal type         */
    char txno[DLEN_TXNCD];         /*  �ⲿ���״��루4λ��   */
    char hcode;                    /*  cancel transaction    */
    char supinit[2];               /*  supervisor code       */
    char tlrno[DLEN_TLRNO];        /*  ��Ա�ţ�8λ��         */
    char sptlrno[DLEN_TLRNO];      /*  supervisor's tlrno    */
    char otxtlrno[DLEN_TLRNO];     /*  verified tx tlrno     */
    char otxtlsrno[DLEN_TLSRNO];   /*  verified tx tlsrno  7 */
    char passwd[DLEN_TLR_PASSWD];  /*  shuffled password  8  */
    char nbcd;                     /*  nobook code           */
    char multtx;                   /*  multiple txn          */
    char multno[DLEN_MULTNO];      /*  multiple txn set no 6 */
    char ip_addr[DLEN_IP_ADDR];    /*  ip address 15         */
    char inq_id[8];                /* 8888 inquiry ID        */
} T_TitaLabel;

typedef struct TITA_LABEL T_TITA_LABEL;

#define   TITA_LABEL_LENGTH   (sizeof (T_TITA_LABEL))
struct  TITA_LABTEX
{
    T_TITA_LABEL label;
    char sTitaText[MAX_PACKET_LEN];
};
/* add by zr begin */
struct TXCOM_AREA
{
    char      apruntype;        /* application run type 1-online 2-batch  */
    char      txrsut;           /* txrsut , APCTL initial '0'             */
    char      tbsdy[DLEN_DATE]; /* today business date */
    char      nbsdy[DLEN_DATE]; /* next business date */
    char      lbsdy[DLEN_DATE]; /* last business date */
    char      nextdy[DLEN_DATE];/* next calendar date */
    char      lastdy[DLEN_DATE];/* last calendar date */
    char      batchdate[DLEN_DATE];/* batch date */
    char      actdate[DLEN_DATE];/* accounting date */
    char      auditdate[DLEN_DATE];/* post audit date */
    char      olstat;           /* online status */
    char      txtime[DLEN_TIME];/* Transaction time                       */
    short int totbox;           /* TOTA BOX count , APCTL initial 0       */
    long      rtncd;            /* return code    , APCTL initial 0       */
    char      prgnm[61];        /* program name , APCTL initial '    '    */
    char      msgid[5];         /* message id   , APCTL initial '    '    */
    long      response_id;      /* response destination , APCTL update    */
    int       srvid;            /* server id                              */
    char      datasource;       /* data source */
};
typedef struct TXCOM_AREA T_TXCOM_AREA;
/* add by zr end   */

typedef struct TITA_LABTEX T_TITA_LABTEX;

typedef struct TOTW_LABEL
{
    char    header[8];
    char    clsno[6];
    char    termid[8];             /*  termid               */
    char    refssn[14];
    char    kinbr[DLEN_BRNO];      /*  �к�              3  */
    char    trmseq[DLEN_TRMSEQ];   /*  terminal sequence 2  */
    char    ejfno[DLEN_EJFNO];     /*  EJF no            7  */
    char    taskid[DLEN_TASKID];   /*  task id           2  */
    char    txno[DLEN_TXNCD];      /*  �ⲿ���״���      4  */
    char    tlrno[DLEN_TLRNO];     /*  ��Ա��            8  */
    char    tlsrno[DLEN_TLSRNO];   /*  tlsrno            7  */
    char    tmtype;                /*  terminal type        */
    char    txdate[DLEN_DATE];     /*  transaction date  8  */
    char    txtime[DLEN_TIME];     /*  transaction time  6  */
    char    msgend;                /*  message end          */
    char    msgtype;               /*  message type         */
    char    msgno[4];              /*  message no           */
    char    msglng[4];             /*  message length       */
    char    process_flag;          /*  �ļ�������־         */
    char    inq_id[8];             /*  8888 inquiry ID      */
} T_TotaLabel;

typedef    struct    TOTW_LABEL     T_TOTW_LABEL;

#define   TOTA_LABEL_LENGTH   (sizeof (T_TOTW_LABEL))
struct    TOTW_LABTEX
{
    T_TOTW_LABEL label;
    char sTotaText[MAX_PACKET_LEN];
};
typedef    struct    TOTW_LABTEX    T_TOTW_LABTEX;

typedef struct
{
    T_TotaLabel tTotaLabel;
    char        sTotaText[IPC_WEB_RSV_LEN];
}T_MngBufToTlrDef;

typedef struct
{
    T_TitaLabel tTitaLabel;
    char        sTitaText[IPC_WEB_RSV_LEN];
} T_TlrText;

typedef struct
{
    T_IPCHeader   tIPCHeader;
    T_TlrText     tTlrText;
}T_MngBufFromTlrDef;


/*-----------------------------------------------------------------------------*/

typedef struct
{
    T_TitaLabel tTitaLabel;
    char        sRsv[TEXT_FLD_LEN];
} T_MsgText;

typedef struct
{
    T_IPCHeader   tIPCHeader;
    T_MsgText     tMsgText;
} T_SwtInBufDef;

typedef struct
{
    T_TotaLabel tTotaLabel;
    char        sRsv[TEXT_FLD_LEN];
} T_MsgOutText;

typedef struct
{
    T_IPCHeader   tIPCHeader;
    T_MsgOutText  tMsgText;
} T_SwtOutBufDef;

typedef struct
{
    T_TotaLabel     tTotaLabel;
    char            sRsv[TEXT_FLD_LEN]; /*�ı���*/
}T_TotaPktDef;

typedef struct
{
    T_IPCHeader     tIPCHeader;
    T_TotaPktDef    tTotaPkt;
}T_SwtTotaDef;


/* move from each module to here */
#define TLRCOMM_MAX_BUF_SIZE         20480

/**************************/
/* message key data       */
/**************************/
/* e3comm to e3bdg        */
/* ccbcomm to ccbbdg      */
/* icbccomm to icbcbdg    */
/**************************/
typedef struct
{
    char msg_date[8];              /* comm */
    char msg_seqno[8];             /* comm */
    char msg_type[3];              /* comm */
    char msg_io;                   /* comm */
    char msg_source;               /* comm */
    char msg_dtl_count[8];         /* bdg */
    char msg_exttype[3];           /* bdg */
    char msg_subtype[8];           /* bdg */
    char msg_file_name[256];       /* comm */
} T_MsgKeyData;

/**************************/
/* message key data back  */
/**************************/
/* ccbxxx to ccbcomm      */
/**************************/
typedef struct
{
    char msg_date[8];
    char msg_seqno[8];
    char msg_type[3];
    char msg_offset[8];
    char msg_file_name[256];
} T_MsgKeyDataBack;
/**************************/
/* icbcxxx to icbccomm    */
/**************************/
typedef struct
{
    char msg_date[8];
    char msg_seqno[8];
    char msg_type[3];
    char msg_offset[8];
    char msg_len[4];
    char msg_text[1025];
} T_MsgKeyDataIcbc;
/**************************/
/* citicxxx to citiccomm  */
/**************************/
typedef struct
{
    char msg_date[8];
    char msg_seqno[8];
    char msg_type[3];
    char msg_offset[8];
    char msg_lic_id[6];
    char msg_func_id[6];
    char msg_user_id[20];
    char msg_file_name[256];
} T_MsgKeyDataCitic;


#define PBLS_MSG_TYPE_PAID_XML         "PAD"
#define PBLS_MSG_TYPE_PAID_MAN_XML     "E3M"
#define PBLS_MSG_TYPE_CSV            "CSV"
#define PBLS_MSG_TYPE_ICBC           "002"
#define PBLS_MSG_TYPE_CCB            "005"
#define PBLS_MSG_TYPE_CITIC          "302"
#define PBLS_MSG_TYPE_CMB            "308"

#define PBLS_MSG_IO_IN               "I"
#define PBLS_MSG_IO_OUT              "O"

#define PBLS_MSG_SOURCE_ONLINE       "1"
#define PBLS_MSG_SOURCE_OFFLINE      "2"

#define PBLS_MSG_STATUS_WAIT_SEND    '1'
#define PBLS_MSG_STATUS_WAIT_CFM     '2'
#define PBLS_MSG_STATUS_SEND_SUCC    '3'
#define PBLS_MSG_STATUS_SEND_FAIL    '4'

/**************************/
/* message key data 2     */
/**************************/
/* e3bdg to e3swt         */
/* ccbbdg to ccbswt       */
/* icbcbdg to icbcswt     */
/**************************/
typedef struct
{
    T_IPCHeader     tIPCHeader;
    T_MsgKeyData    tMsgKeyData;
} T_SwtBufFromE3Bdg;

typedef struct
{
    T_IPCHeader     tIPCHeader;
    T_MsgKeyData    tMsgKeyData;
} T_SwtBufFromCCBBdg;

typedef struct
{
    T_IPCHeader     tIPCHeader;
    T_MsgKeyData    tMsgKeyData;
} T_SwtBufFromICBCBdg;

typedef struct
{
    T_IPCHeader     tIPCHeader;
    T_MsgKeyData    tMsgKeyData;
} T_SwtBufFromCITICBdg;

/*********************************/
/* E3 payment and collection IPC */
/*********************************/
typedef struct
{
    char InternalEnvelop[35];
    char InternalFileRef[35];
    char CustomerCreationDate[35];
    char CustomerCreationDateFormat[20];
    char MessageType[12];
    char MsgVersionNo[35];
    char ProcessingType[12];
    char TransactionType[3];
    char TransactionSubType[3];
    char InternalMsgRef[35];
    char Date[35];
    char OrdererPartyName1[35];
    char OrdererUnstructuredAddr1[35];
    char OrdererAcctNum[35];
    char OrdererAcctCcy[3];
    char Bic[11];
    char InternalTXNRef[35];
    char MessageNumber[35];
    char Ccy[3];
    char Amount[18];
    char CounterPartyName1[35];
    char CounterUnstructuredAddr1[35];
    char CounterAcctNum[35];
    char CounterAcctType[6];
    char CounterBankCode[24];
    char CounterBic[11];
    char CounterBankName[70];
    char FreeTextType[3];
    char FreeText1[35];
    char FreeText2[35];
    char TxnTotalAmount[35];
    char NumofTxn[12];
    char MsgTotalAmount[35];
    char NumofMessages[12];
    char FileTotalAmount[35];
    char NumofFiles[12];
    char FreeTextTypeSPL[3];
    char FreeText1SPL[35];
    char FreeText2SPL[35];
} T_E3Pay;

/*********************************/
/* E3 ack and feedback IPC       */
/*********************************/
#define IPC_E3_XML_NUM_OF_TXN_MAX 999
typedef struct
{
    char Recipient[35];
    char Originator[35];
    char ConvertDate[35];
    char ConvertDateFormat[20];
    char InternalEnvelop[35];
    char InternalFileRef[35];
    char CustomerCreationDate[35];
    char CustomerCreationDateFormat[20];
    char MessageType[12];
    char MsgVersionNo[35];
    char ProcessingType[12];
    char TransactionType[3];
    char TransactionSubType[3];
    char InternalMsgRef[35];
    char ReferenceQualifier[35];
    char ReferenceNo[35];
    char ValueDate[35];
    char ValueDateFormat[20];
    char OrdererAcctNum[35];
    char OrdererAcctCcy[3];
    char BankBranchCode[35];
    char Bic[11];
    char BankName[70];
    char ErrorNo[10];
    char ErrorMessage[140];
    char TxnType[35];
    char ProcessedDate[35];
    char ProcessedDateFormat[20];
    char AckLvl[35];
    struct {
    char InternalTXNRef[35];
    char ReferenceQualifier_Cust[35];
    char ReferenceNo_Cust[35];
    char DebitCreditMark[2];
    char Ccy[3];
    char Amount[18];
    char CounterPartyName1[35];
    char CounterUnstructuredAddr1[35];
    char CounterAcctNum[35];
    char CounterAcctCcy[3];
    char CounterAcctType[6];
    char CounterBankCode[35];
    char CounterBankName[70];
    char ErrorNo[10];
    char ErrorMessage[40];
    char TxnType[35];
    char ProcessedDate[35];
    char ProcessedDateFormat[20];
    char AckLvl[35];
    } tE3AckDtl[IPC_E3_XML_NUM_OF_TXN_MAX];
    char ProcessFlag;
    char TxnTotalAmount[18];
    char NumofTxn[18];
    char MsgTotalAmount[18];
    char NumofMessages[18];
    char FileTotalAmount[18];
    char NumofFiles[18];
} T_E3Ack;

typedef struct
{
    char Recipient[35];
    char Originator[35];
    char ConvertDate[35];
    char ConvertDateFormat[20];
    char InternalEnvelop[35];
    char InternalFileRef[35];
    char CustomerCreationDate[35];
    char CustomerCreationDateFormat[20];
    char MessageType[12];
    char MsgVersionNo[35];
    char ProcessingType[12];
    char TransactionType[3];
    char TransactionSubType[3];
    char InternalMsgRef[35];
    char ReferenceQualifier[35];
    char ReferenceNo[35];
    char ValueDate[35];
    char ValueDateFormat[20];
    char BookDate[35];
    char BookDateFormat[20];
    char MsgCcy[3];
    char MsgAmount[18];
    char OrdererAcctNum[35];
    char OrdererAcctCcy[3];
    char BankBranchCode[35];
    char Bic[11];
    char BankName[70];
    struct {
    char InternalTXNRef[35];
    char ReferenceQualifier_Cust[35];
    char ReferenceNo_Cust[35];
    /*
    char ReferenceQualifier_Pbls[35];
    char ReferenceNo_Pbls[35];
    */
    char DebitCreditMark[2];
    char Ccy[3];
    char Amount[18];
    char CounterPartyName1[35];
    char CounterUnstructuredAddr1[35];
    char CounterAcctNum[35];
    char CounterAcctType[6];
    char CounterBankCode[24];
    char CounterBic[11];
    char CounterBankName[60];
    char FreeTextType[3];
    char FreeText1[35];
    char FreeText2[35];
    char FreeText3[7];
    } tE3FeedbackDtl[IPC_E3_XML_NUM_OF_TXN_MAX];
    char ProcessFlag;
    char TxnTotalAmount[18];
    char NumofTxn[18];
    char MsgTotalAmount[18];
    char NumofMessages[18];
    char FileTotalAmount[18];
    char NumofFiles[18];
} T_E3Fdb;


/*****************************************/
/* CCB IPC                               */
/* 2460Req(in)      - 2460Rsp(out)       */
/* 1736Req(out)     - 1736Rsp(in)        */
/* 1737Req(out)     - 1737Rsp(in)        */
/* 1703Req(out)     - 1703Rsp(in)        */
/* 1735Req(out)     - 1735Rsp(in)        */
/* 1904Req(out)     - 1904Rsp(in)        */
/* 1539Req(out)     - 1539Rsp(in)        */
/* 1523Req_000(out) - 1523Rsp_100(in)    */
/* 1523Req_001(in)  - 1523Rsp_101(out)   */
/* 1104Req(out)     - 1104Rsp(in)        */
/* 1105Req(out)     - 1105Rsp(in)        */
/* 2478Req(out)     - 2478Rsp(in)        */
/* 3524Req(out)     - 3524Rsp(in)        */
/* 3525Req(out)     - 3525Rsp(in)        */
/* 3526Req(out)     - 3526Rsp(in)        */
/* 2461Req(in)      - 2461Rsp(out)       */
/*****************************************/
typedef struct
{
    char version[2];
    char txcode[4];
    char funccode[3];
    char channel[4];
    char subcenterid[4];
    char nodeid[16];
    char tellerid[6];
    char txseqid[8];
    char txdate[8];
    char txtime[6];
    char userid[16];
} T_CcbHeader;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char OrgSubCenterId[4];
    char OrgNodeId[16];
    char OrgTxSeqId[8];
    char TxStatus[2];
} T_CCB2461Req; /* in */

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char OperatorUserId[16];
    char OutUserId[16];
    char OutDepId[5];
    char OutBranchId[5];
    char OutBranchName[30];
    char OutAcctId[32];
    char OutAcctName[50];
    char InUserId[16];
    char InDepId[5];
    char InBranchId[5];
    char InBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char StipStatus;
    char CurCode[3];
    char StipType[2];
} T_CCB2460Req; /* in */

typedef struct
{
    T_CcbHeader tHeader;
    char espdate[8];
    char userid[16];
    char sessionid[16];
} T_CCB1736Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char espdate[8];
    char userid[16];
    char sessionid[16];
} T_CCB1737Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
    char userid[16];
    char depid[5];
    char acctid[32];
    char branchid[5];
    char startpos[6];
    char expreccount[6];
} T_CCB1703Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
    char userid[16];
    char depid[5];
    char acctid[32];
    char branchid[5];
} T_CCB1735Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
    char OperatorUserId[16];
    char OutUserId[16];
    char OutDepId[5];
    char OutBranchId[5];
    char OutBranchName[30];
    char OutAcctId[32];
    char OutAcctName[50];
    char CurCode[3];
    char TxAmount[18];
    char InUserId[16];
    char InDepId[5];
    char InBranchId[5];
    char InBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char StipFlag[2];
    char Memo[256];
} T_CCB1904Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char txdate[8];
    char sessionid[16];
    char orgsubcenterid[4];
    char orgtxseqid[8];
    char orgnodeid[16];
} T_CCB1539Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
} T_CCB1523Req_000; /* out */

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RecCount[16];
    char RespCode[5];
    char DtlTxSeqId[8];
    char OperatorUserId[16];
    char OutUserId[16];
    char OutDepId[5];
    char OutBranchId[5];
    char OutBranchName[30];
    char OutAcctId[32];
    char OutAcctName[50];
    char InUserId[16];
    char InDepId[5];
    char InBranchId[5];
    char InBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char TxAmount[18];
    char TxnEndFlag;
    char CurCode[3];
} T_CCB1523Req_001; /* in */

typedef struct
{
    T_CcbHeader tHeader;
    char userhostid[16];
    char userid[16];
    char logindate[8];
    char sendflag;
} T_CCB1104Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
    char userid[16];
    char userhostid[16];
} T_CCB1105Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
} T_CCB2478Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
} T_CCB3524Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
    char userid[16];
    char filename[64];
    char resfilename[64];
    char txdate[8];
} T_CCB3525Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char sessionid[16];
    char userid[16];
    char txdate[8];
    char batchno[2];
} T_CCB3526Req; /* out */

typedef struct
{
    T_CcbHeader tHeader;
    char RespCode[5];
    char RespMsg[256];
    char SessionId[16];
} T_CCBCommonRsp;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char RespMsg[256];
} T_CCBCommonRspSimple;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char RespMsg[256];
    char SessionId[16];
} T_CCB1104Rsp;

#define T_CCB1105Rsp T_CCBCommonRspSimple
#define T_CCB1904Rsp T_CCBCommonRspSimple
#define T_CCB3525Rsp T_CCBCommonRspSimple
#define T_CCB2460Rsp T_CCBCommonRsp

#define T_CCB1523Rsp_100 T_CCBCommonRspSimple
#define T_CCB1523Rsp_101 T_CCBCommonRsp

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char RespMsg[256];
    char FileName[64];
} T_CCB3526Rsp;

typedef struct
{
    char IDNO[20+1];
    char NAME[60+1];
    char ICBACNO[18+1];
    char AMOUNT[23+1];
    char TYPE[1+1];
    char TRNTYP[3+1];
    char REFNO[25+1];
    char BNKACNO[30+1];
    char TRNDT[10+1];
    char TRNSTS[1+1];
    char BNKREFNO[30+1];
    char DESCR[60+1];
    char CURRENCY[3+1];
} T_CCB3526Rsp_Detail;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char DtlTxSeqId[8];
    char OperatorUserId[16];
    char OutUserId[16];
    char OutDepId[5];
    char OutBranchId[5];
    char OutBranchName[30];
    char OutAcctId[32];
    char OutAcctName[50];
    char InUserId[16];
    char InDepId[5];
    char InBranchId[5];
    char InBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char TxAmount[18];
    char TxnEndFlag;
    char CurCode[3];
    char RespMsg[256];
} T_CCB1539Rsp;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char TotalRec[6];
    char RtnRecCount[6];
    char RecCount[16];
    char OutAcctId[32];
    char OutAcctName[50];
    char OutBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char InBranchName[30];
    char TxAmount[18];
    char CurCode[3];
    char DCFlag;
    char AbstractStr[20];
    char DtlTxTime[6];
    char VoucherId[8];
    char VoucherType[20];
    char RespMsg[256];
} T_CCB1703Rsp;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char RecCount[16];
    char AcctHostSeqId[19];
    char OrgSubTxSeqId[16];
    char OutAcctId[32];
    char OutAcctName[50];
    char OutBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char InBranchName[30];
    char TxAmount[18];
    char CurCode[3];
    char DCFlag;
    char AbstractStr[20];
    char DtlTxTime[6];
    char VoucherId[8];
    char VoucherType[20];
    char RespMsg[256];
} T_CCB1735Rsp;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RecCount[16];
    char RespCode[5];
    char EspDate[8];
    char DepId[5];
    char OutBranchName[30];
    char OutAcctId[32];
    char OutAcctName[50];
    char InBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char TxAmount[18];
    char CurCode[3];
    char DCFlag;
    char AbstractStr[20];
    char AcctBal[18];
    char DtlTxTime[6];
    char VoucherId[8];
    char VoucherType[20];
    char RespMsg[256];
} T_CCB1736Rsp;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RecCount[16];
    char RespCode[5];
    char EspDate[8];
    char DepId[5];
    char AcctId[32];
    char AcctName[50];
    char AcctBal[18];
    char CurCode[3];
    char OpenBranchName[30];
    char RespMsg[256];
} T_CCB1737Rsp;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char RecCount[16];
    char OperatorUserId[16];
    char OutUserId[16];
    char OutDepId[5];
    char OutBranchId[5];
    char OutBranchName[30];
    char OutAcctId[32];
    char OutAcctName[50];
    char InUserId[16];
    char InDepId[5];
    char InBranchId[5];
    char InBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char StipStatus;
    char CurCode[3];
    char StipType[2];
    char RespMsg[256];
} T_CCB2478Rsp;

typedef struct
{
    char TxCode[4];
    char FuncCode[3];
    char TxSeqId[8];
    char TxDate[8];
    char TxTime[6];
    char RespCode[5];
    char RecCount[16];
    char OperatorUserId[16];
    char OutUserId[16];
    char OutDepId[5];
    char OutBranchId[5];
    char OutBranchName[30];
    char OutAcctId[32];
    char OutAcctName[50];
    char InUserId[16];
    char InDepId[5];
    char InBranchId[5];
    char InBranchName[30];
    char InAcctId[32];
    char InAcctName[50];
    char StipStatus;
    char CurCode[3];
    char StipType[2];
    char RespMsg[256];
} T_CCB3524Rsp;


/*********************************/
/* ICBC IPC                      */
/* 01Req(out)  - 02Rsp(in)       */
/* 03Req(out)  - 04Rsp(in)       */
/* 05Req(out)  - 06Rsp(in)       */
/* 07Req(out)  - 08Rsp(in)       */
/*********************************/
#define IPC_ICBC_MSG_TYPE_LEN           2
#define IPC_ICBC_BANK_CODE_LEN          8

typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char PayType;
    char RefNo[16];
    char ValDate[8];
    char Amount[15];
    char OutBankId[8];
    char OutActNo[30];
    char OutActName[60];
    char InActNo[30];
    char InActName[60];
    char InBankId[8];
    char InBankName[60];
    char FBActNo[30];
    char FBActName[60];
    char Purpose[20];
    char Rsv[40];
    char ENC[28];
    char EndFlag;
} T_ICBC01Req;

/* "02" is generate by icbccomm_in */
typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char RefNo[16];
    char RetCode[4];
    char RetMesg[60];
    char EndFlag;
} T_ICBC02Rsp;

/* "98" is generate by icbccomm_in */
typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char RefNo[16];
    char RetCode[4];
    char EndFlag;
} T_ICBC98Rsp;

typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char InqDate[8];
    char Actno[30];
    char InqSeqno[2];
    char CityCode[4];
    char Sdate[8];
    char Edate[8];
    char MinAmt[17];
    char MaxAmt[17];
    char Rsv[40];
    char ENC[28];
    char EndFlag;
} T_ICBC03Req;

typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char RspSeq[6];
    char InqSeqno[2];
    char DtlCnt[4];
    char RspType;
} T_ICBC04RspP1;
typedef struct
{
    char CityCode[4];
    char ActNo[30];
    char TxDate[8];
    char VocNo[9];
    char TxDesc[40]; /* modify by zhongw 20081022 from 20 to 40 */
    char DbAmount[17];
    char CrAmount[17];
    char Rsv1[17];
    char SubActNo;
    char OppActNo[35]; /* modify by zhongw 20081022 from 30 to 35*/
    char BankName[60];
    char OppBankName[60];
    char CorpName[60];
    char TxType[3];
    char Purpose[40];
    char CurCd[3];
    char TxTime[6];
    char Remarks[100];
    char Rsv2[20];
    char Rsv3[20];
    char DtlFlag;
} T_ICBC04RspP2;    /* loop */
typedef struct
{
    char Rsv[40];
    char ENC[28];
    char EndFlag;
} T_ICBC04RspP3;

typedef struct
{
    T_ICBC04RspP1 tP1;
    T_ICBC04RspP2 tP2;
    T_ICBC04RspP3 tP3;
} T_ICBC04Rsp;

typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char RefNo[16];
    char Rsv[40];
    char ENC[28];
    char EndFlag;
} T_ICBC05Req;

typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char RefNo[16];
    char PayType;
    char VocNo[20];
    char ValDate[8];
    char Amount[15];
    char Purpose[20];
    char FBActNo[30];
    char FBActName[60];
    char OutBankId[8];
    char OutBankName[60];
    char OutActNo[30];
    char OutActName[60];
    char InActNo[30];
    char InActName[60];
    char InBankId[8];
    char InBankName[60];
    char RetCode[4];
    char ErrMsg[200];
    char TxTime[6];
    char Status[2];
    char OutActCity[20];
    char OutActCityCode[5];
    char OutActBrchCode[4];
    char InActCity[20];
    char RspTlr[16];
    char RspTime[14];
    char Rsv1[40];
    char Rsv2[20];
    char Rsv3[20];
    char ENC[28];
    char EndFlag;
} T_ICBC06Rsp;

typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char InqDate[8];
    char Actno[30];
    char CityCode[4];
    char CurCd[3];
    char Rsv[40];
    char ENC[28];
    char EndFlag;
} T_ICBC07Req;

typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char ActNo[30];
    char OpnBal[17];
    char CurrBal[17];
    char AvlBal[17];
    char ActType[3];
    char CurCd[3];
    char Rsv1[40];
    char Rsv2[20];
    char Rsv3[20];
    char ENC[28];
    char EndFlag;
} T_ICBC08Rsp;

/*****************************************/
/* CITIC IPC                             */
/* 200000Req(out)   - 200000Rsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char Attatch[256];
} T_CITIC200000Req; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char Attatch[256];
} T_CITIC200000Rsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 21021aReq(out)   - 21021aRsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char AccNo[19];
    char LowAmount[13];
    char UpAmount[13];
    char StartDate[8];
    char EndDate[8];
    char Attatch[256];
} T_CITIC21021aReq; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char AccNo[19];
    char AccName[42];
    char OpenBankName[42];
    char TranDate[8];
    char TranTime[6];
    char TranNo[14];
    char TranAmount[13];
    char CreditDebitFlag;
    char OppAccNo[32];
    char OppAccName[62];
    char OppOpenBankName[62];
    char Abstract[20];
    char CashTransferFlag;
    char UserId1[20];
    char UserName1[20];
    char UserId2[20];
    char UserName2[20];
    char Balance[13];
    char SpecialCode[20];
    char NonFinancialFlag;
    char ReversedFlag;
    char ValueDate[8];
    char HostTranCode[6];
    char AbstractCode1[20];
    char AbstractCode2[20];
    char Attatch[256];
} T_CITIC21021aRsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 210242Req(out)   - 210242Rsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char AccNo[19];
    char Year[4];
    char StartDate[8];
    char EndDate[8];
    char Attatch[256];
} T_CITIC210242Req; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char AccNo[19];
    char AccName[42];
    char OpenBankName[42];
    char CurrName[20];
    char PageNo[5];
    char ForwardBalance[13];
    char TranDate[8];
    char TranTime[6];
    char TranNo[14];
    char TranAmount[13];
    char ValueDate[8];
    char Balance[13];
    char OppAccNo[32];
    char OppAccName[62];
    char OppOpenBankName[62];
    char Abstract[20];
    char CreditDebitFlag;
    char SpecialCode[20];
    char Attatch[256];
} T_CITIC210242Rsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 22029aReq(out)   - 22029aRsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char ClientId[14];
    char TranPasswd[6];
    char PayType[2];
    char OutAccNo[19];
    char InAccNo[32];
    char InAccName[62];
    char OpenBankName[62];
    char OpenBankAddress[42];
    char CiticibAccFlag;
    char CityFlag;
    char TranAmount[13];
    char Abstract[20];
    char UserName[20];
    char IdNumber[18];
    char IdType;
    char Attatch[256];
} T_CITIC22029aReq; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char TranDate[8];
    char TranTime[6];
    char TranNo[14];
    char AccNo[19];
    char AccName[42];
    char OpenBankName[42];
    char CustAccNo[32];
    char CustAccName[62];
    char CustOpenBankName[62];
    char TranAmount[13];
    char Abstract[20];
    char Attatch[256];
} T_CITIC22029aRsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 220412Req(out)   - 220412Rsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char Attatch[256];
} T_CITIC220412Req; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char AccNo[19];
    char AccName[42];
    char CurrId[2];
    char CityId[2];
    char ServiceBitmap[10];
    char Attatch[256];
} T_CITIC220412Rsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 270562Req(out)   - 270562Rsp(in)      */
/*****************************************/
#define IPC_CITIC_XML_NUM_OF_TXN_MAX 99
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char TotalNumber[5];
    char TotalAmount[21];
    char TranPasswd[6];
    char PayDate[8];
    struct {
    char EmployeeNo[5];
    char EmployeeName[14];
    char InAccNo[19];
    char TranAmount[13];
    } tDetail[IPC_CITIC_XML_NUM_OF_TXN_MAX];
    char Attatch[256];
} T_CITIC270562Req; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char BatchNo;
    char TotalNumber[5];
    char TotalAmount[21];
    char PayDate[8];
    char Attatch[256];
} T_CITIC270562Rsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 270571Req(out)   - 270571Rsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char YearMonth[6];
    char Attatch[256];
} T_CITIC270571Req; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char CustomerName[42];
    char YearMonth[6];
    char OutAccNo[19];
    char PayDate[8];
    char BatchNo;
    char TotalNumber[5];
    char TotalAmount[21];
    char MsgId[7];
    char MsgText[30];
    char ErrPayDate[8];
    char ErrBatchNo;
    char ErrTotalNumber[5];
    char ErrTotalAmount[21];
    char Attatch[256];
} T_CITIC270571Rsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 27057aReq(out)   - 27057aRsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char YearMonth[6];
    char BatchNo;
    char OutAccNo[19];
    char Attatch[256];
} T_CITIC27057aReq; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char EmployeeNo[5];
    char EmployeeName[14];
    char InAccNo[19];
    char TranAmount[13];
    char MsgId[7];
    char MsgText[30];
    char Attatch[256];
} T_CITIC27057aRsp; /* in */

/*****************************************/
/* CITIC IPC                             */
/* 270593Req(out)   - 270593Rsp(in)      */
/*****************************************/
typedef struct
{
    char TranCode[6];
    char UserId[20];
    char LoginPasswd[6];
    char ClientId[14];
    char TranPasswd[6];
    char OutAccNo[19];
    char InAccNo[19];
    char TranAmount[13];
    char Abstract[20];
    char Attatch[256];
} T_CITIC270593Req; /* out */

typedef struct
{
    char TranCode[6];
    char StatusId[7];
    char StatusText[30];
    char TranDate[8];
    char TranTime[6];
    char TranNo[14];
    char AccNo[19];
    char AccName[42];
    char OpenBankName[42];
    char CustAccNo[19];
    char CustAccName[40];
    char CustOpenBankName[42];
    char TranAmount[13];
    char Abstract[20];
    char Attatch[256];
} T_CITIC270593Rsp; /* in */

typedef struct
{
    char TranCode[6];
    char UserId[20];
} T_CiticHeader;

/* ����11������ṹ��  add by zhongwei 20080312 */
typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char InqDate[8];
    char Actno[30];
    char CurCd[3];
    char InqFlag;      /* 1:�״β�ѯ��3:��ҳ��ѯ */
    char Timestamp[26];
    char Rsv[40];
    char ENC[28];
    char EndFlag;
} T_ICBC11Req;

/* ����12���ذ��ṹ��  add by zhongwei 20080312 */
typedef struct
{
    char BankId[IPC_ICBC_BANK_CODE_LEN];
    char MsgType[IPC_ICBC_MSG_TYPE_LEN];
    char Actno[30];
    char CurCd[3];
    char DtlCnt[4];
    /* add by zhongw 20080423 */
    char PageFlag;
} T_ICBC12RspP1;
typedef struct
{
    char TxTime[8];  /*��ʽΪ��HH.mm.ss */
    char VocNo[9];  /* modify by zhongw from 5 to 9 20080806 */
    char OppBank[8];
    char OppActno[30];
    char DbAmount[17];
    char Purpose[20];
    char TxType[3];
    char Remarks[100];
    char OppActName[60];
    char Cdflag;
    char TxDesc[20];
    char Timestamp[26];
    char CrAmount[17];
    char DbActno[30];
    char CrActno[30];
    char EndFlag;
} T_ICBC12RspP2;    /* loop */
typedef struct
{
    char Rsv[40];
    char ENC[28];
    char EndFlag;
} T_ICBC12RspP3;

typedef struct
{
    T_ICBC12RspP1 tP1;
    T_ICBC12RspP2 tP2;
    T_ICBC12RspP3 tP3;
} T_ICBC12Rsp;

/* PAIDCOMM  ��  PAIDBDG�Ľӿ� */
typedef struct
{
    char msg_date[8];              /* comm */
    char msg_seqno[8];             /* comm */
    char msg_type[3];              /* comm */
    char msg_io;                   /* comm */
    char msg_source;               /* comm */
    char msg_dtl_count[8];         /* bdg */
    char msg_exttype[3];           /* bdg */
    char msg_subtype[8];           /* bdg */
    char msg_file_path[256];       /* comm */
    char msg_file_name[256];       /* comm */
    char sMsgIdCoreId[96];         /* MsgId and Correlation id */
    char sRetCode[4];              /* ������ */
}T_PAID_HEAD;
typedef struct
{
    char BankId[8];
    char MsgType[2];
    char PayType;
    char RefNo[16];
    char ValDate[8];
    char Amount[15];
    char OutBankId[8];
    char OutActNo[30];
    char OutActName[60];
    char InActNo[30];
    char InActName[60];
    char InBankId[8];
    char InBankName[60];
    char FBActNo[30];
    char FBActName[60];
    char BenefInfo[44];
    char ENC[16];
    char EndFlag;
}T_PAID_01_MSG;
typedef struct
{
    T_PAID_HEAD     tPaidHead;
    T_PAID_01_MSG   tPaid01Msg;
}T_PAID_KEY_MSG;


/* ���Ľṹ */

typedef struct
{
    char msg_id[16];        /* �жϱ���Ψһ�� */
    char msg_type[4];       /* PAY1,BALE,BALA,M940,M942,M999 */
    char msg_length[8];     /* BODY���� */
    char msg_channel[14];   /* I-ICBC */
}T_HUB_HEAD;

/*comm->bdg bdg->swt*/
typedef struct
{
    char msg_io;            /* O-TO HUB, I-FROM HUB */
    T_HUB_HEAD tHubHead;
    char file_name[256];    /* �ļ��� */
    char file_size[8];      /* �ļ���С */
}T_HUB_MSG;

typedef struct
{
    char indicate;
    char cmt_type  [3 ];
    char brno      [3 ];
    char vdate     [8 ];
    char curcy     [3 ];
    char amount    [15];
    char sndbrno   [12];
    char payerbrno [12];
    char payeract  [32];
    char payername [70];
    char payeraddr [70];
    char rcvbrno   [12];
    char payeebrno [12];
    char payeeactno[32];
    char payeename [70];
    char payeeaddr [70];
    char txtype    [2 ];
    char seqno     [20];
    char narrative1[35];
    char narrative2[35];
    char narrative3[35];
    char narrative4[35];
}T_HUB_PAY1_MSG;

typedef struct
{
    char act_number[8];
    char act_index[8];
    char act_curcy[3];
    char act_value[32];
}T_HUB_BALE_MSG;

typedef struct
{
    char version                 [30  + 1];   /* �汾           CHAR    30     */
    char refernce                [30  + 1];   /* ���ı�ʶ       CHAR    30     */
    char business_code           [5   + 1];   /* ҵ���ܺ�     CHAR    5      */
    char trade_source            [1   + 1];   /* ���׻�����     CHAR    1      */
    char s_institution_identifier[30  + 1];   /* ������ʶ       CHAR    30     */
    char s_institution_name      [60  + 1];   /* ��������       CHAR    60     */
    char s_branch_identifier     [30  + 1];   /* ��֧��������   CHAR    30     */
    char s_branch_name           [60  + 1];   /* ��֧��������   CHAR    60     */
    char s_sub_branch_identifier [30  + 1];   /* �����         CHAR    30     */
    char s_sub_branch_name       [60  + 1];   /* ��������       CHAR    60     */
    char r_institution_identifier[30  + 1];   /* ������ʶ       CHAR    30     */
    char r_institution_name      [60  + 1];   /* ��������       CHAR    60     */
    char r_branch_identifier     [30  + 1];   /* ��֧��������   CHAR    30     */
    char r_branch_name           [60  + 1];   /* ��֧��������   CHAR    60     */
    char r_sub_branch_identifier [30  + 1];   /* �����         CHAR    30     */
    char r_sub_branch_name       [60  + 1];   /* ��������       CHAR    60     */
    char trade_date              [8   + 1];   /* ��������       CHAR    8      */
    char trade_time              [6   + 1];   /* ����ʱ��       CHAR    6      */
    char code                    [4   + 1];   /* ������         CHAR    4      */
    char info                    [128 + 1];   /* ������Ϣ       CHAR    128    */
}T_ICBC_GROUPHEADER;

typedef struct
{
    char icbc_cnaps_code[12 + 1];
    char icbc_cnaps_bic [11 + 1];
    char hsbc_cnaps_code[12 + 1];
    char hsbc_cnaps_bic [11 + 1];
    char busikind       [2  + 1];
    char busitype       [5  + 1];
}T_BANK_INFO;

typedef struct
{
    char indicate;
    char senddate [8 ];
    char vdate    [8 ];
    char hub_refno[30];
    char status   ;
    char code     [4];
    char info     [256];
}T_HUB_M999_MSG;

/*PKGNO(5)+ID(16)+STATUS(1)+CODE(4)+INFO(256)*/
typedef struct
{
	char msg_type [10];
    char pkgno    [5 ];
    char id       [16];
    char status   ;
    char code     [4];
    char info     [256];
}T_PBLS_M999_MSG;

/*TXDATE(8)+ACCOUNT(32)+CURCD(3)+AMOUNT(15)*/
typedef struct
{
	char msg_type[10];
    char txdate  [8 ];
    char account [32];
    char curcd   [3];
    char amount  [15];
}T_HUB_BALA_MSG;



typedef struct
{
    char mt_type[3+1];
    char account[32+1];
    char curcd  [3+1];
    char txdate[8+1];
    char start_date[8+1];
    char end_date[8+1];
    int  upd_type;
    char bal_seqno[16+1];
    char txn_seqno[16+1];
}T_UPDATE_STATCTL;


#endif
