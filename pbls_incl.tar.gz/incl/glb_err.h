#ifndef _GLB_ERR_H
#define _GLB_ERR_H

#define E_SYS_INVALID_TXNO           "System:Invalid Transaction Number!"
#define E_SYS_MSQ_SEND_ERR           "System:Message Queue Send Error!"
#define E_SYS_SEQCTL_OPR_ERR         "System:Sequence Number Operate Error!"
#define E_SYS_XML_GENERATE_ERR       "System:Generate XML File Error!"
#define E_SYS_FILE_OPR_ERR           "System:File Operate Error!"

#define E_SYS_TLRCTL_INVALID         "ERROR:User Invalid!"
#define E_SYS_TLRCTL_INS_ERR         "ERROR:User Add Failed!"
#define E_SYS_TLRCTL_UPD_STA_ERR     "ERROR:User Update Status Error!"
#define E_SYS_TADTLOG_INS_ERR        "ERROR:User Audit Log Insert Error!"
#define E_SYS_PBANKCTL_NOT_FOUND     "ERROR:Not found in Partner Bank Control!"
#define E_SYS_PBANKCTL_UPD_ERR       "ERROR:Partner Bank Control Update Error!"
#define E_SYS_SYSCTL_NOT_FOUND       "ERROR: System Control Not Found!"
#define E_SYS_SYSCTL_UPD_ERR         "ERROR: System Control Update Error!"
#define E_SYS_CUSTCTL_NOT_FOUND      "ERROR:A/C Control Record Not Found!"
#define E_SYS_CUSTCTL_UPD_ERR        "ERROR:A/C Control Record Update Error!"
#define E_SYS_CUSTCTL_DEL_ERR        "ERROR:A/C Control Record Delete Error!"
#define E_SYS_CUSTCTL_INS_ERR        "ERROR:A/C Control Record Insert Error!"
#define E_SYS_CUSTREG_NOT_FOUND      "ERROR:A/C Register Record Not Found!"
#define E_SYS_CUSTREG_INS_ERR        "ERROR:A/C Register Record Insert Error!"
#define E_SYS_CUSTREG_UPD_ERR        "ERROR:A/C Register Record Update Error!"
#define E_SYS_CUSTREG_DEL_ERR        "ERROR:A/C Register Record Delete Error!"
#define E_SYS_CTRLTMP_INS_ERR        "ERROR:Control Temp Table Insert Error!"
#define E_SYS_CTRLTMP_UPD_ERR        "ERROR:Control Temp Table Update Error!"

#define E_DB_PREPARE_CURSOR_ERR      30		//"Database:Prepare Cursor Error!"
#define E_DB_DECLARE_CURSOR_ERR      31		//"Database:Declare Cursor Error!"
#define E_DB_OPEN_CURSOR_ERR         32		//"Database:Open Cursor Error!"
#define E_DB_FETCH_CURSOR_ERR        33		//"Database:Fetch Cursor Error!"
#define E_DB_CLOSE_CURSOR_ERR        34		//"Database:Close Cursor Error!"
#define E_DB_SELECT_ERR              35		//"Database:SQL Select Error!"

#define E_0000_DEPTCTL_WORK_OFF      "ATTACH FAILED: DEPARTMENT CANNOT WORK!"
#define E_0000_DEPTCTL_INVALID       "ATTACH FAILED: DEPARTMENT INVALID!"

#define E_0012_TLRCTL_WORK_OFF       "FAILED: USER CANNOT WORK!"
#define E_0012_TLRCTL_NOT_LOGOFF     "FAILED: USER ALREADY LOGON OR EXIT ABNORMALLY!"
#define E_0012_TLRCTL_LOCK           "FAILED:USER IS LOCKED!ASK SYSTEM ADMINISTRATOR FOR HELP!"
#define E_0012_TLRCTL_RETRY_3        "FAILED: USER IS LOCKED AFTER 3 TIMES WRONG PASSWORD!"
#define E_0012_TLRCTL_PSWD_ERR       "FAILED: WRONG PASSWORD!"
#define E_0012_TLRCTL_INACTIVE       "FAILED:USER IS DEACTIVATED!ASK SYSTEM ADMINISTRATOR FOR HELP!"
#define E_0012_TLRCTL_PSWD_EXP       "FAILED:PASSWORD EXPIRED!ASK SYSTEM ADMINISTRATOR FOR HELP!"
#define E_0012_TLRCTL_INVALID        E_SYS_TLRCTL_INVALID
#define E_0012_TLRCTL_UPD_STA_ERR    E_SYS_TLRCTL_UPD_STA_ERR
#define E_0012_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR

#define E_0023_TLRCTL_WORK_OFF       "FAILED: USER CANNOT WORK!"
#define E_0023_TLRCTL_INVALID        E_SYS_TLRCTL_INVALID
#define E_0023_TLRCTL_UPD_STA_ERR    E_SYS_TLRCTL_UPD_STA_ERR
#define E_0023_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR

#define E_1001_SYSCTL_NOT_FOUND      E_SYS_SYSCTL_NOT_FOUND

#define E_1003_SYSCTL_NOT_FOUND      E_SYS_SYSCTL_NOT_FOUND
#define E_1003_PBANKCTL_NOT_FOUND    E_SYS_PBANKCTL_NOT_FOUND

#define E_1004_PBANKCTL_NOT_FOUND    E_SYS_PBANKCTL_NOT_FOUND

#define E_1901_HOLIDAY_NOT_FOUND     "ERROR:Not found in System Calendar!"

#define E_1905_DEPTCTL_NOT_FOUND     "ERROR: DEPARTMENT RECORD NOT FOUND!"
#define E_1907_TLRCTL_NOT_FOUND      "ERROR: USER RECORD NOT FOUND!"

#define E_4011_OPEN_FILE_ERROR       "ERROR:Can not open this file!"
#define E_4013_MSG_CONVERT_ERROR     "ERROR:Message Convert Error!"
#define E_4013_PROCESS_TXN_ERROR     "ERROR:Detail Processing Error!"

#define E_2005_DEPTCTL_INS_ERR       "ERROR: DEPT RECORD INSERT ERROR!"
#define E_2005_DEPTCTL_UPD_ERR       "ERROR: DEPT RECORD UPDATE ERROR!"
#define E_2005_DEPTCTL_DEL_ERR       "ERROR: DEPT RECORD DELETE ERROR!"
#define E_2005_DEPTCTL_IN_USE        "ERROR:User Exist, Cannot Delete Department!"
#define E_2005_DEPTCTL_NOT_FOUND     "ERROR: DEPT RECORD NOT FOUND!"
#define E_2005_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR

#define E_2007_TLRCTL_INS_ERR        E_SYS_TLRCTL_INS_ERR
#define E_2007_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR
#define E_2008_TLRCTL_UPD_ERR        "ERROR:TLR control Update Error!"
#define E_2009_TLRCTL_DEL_ERR        "ERROR:TLR control Delete Error!"


#define E_2010_TLRCTL_WORK_OFF       "FAILED: USER CANNOT WORK!"
#define E_2010_TLRCTL_OLD_PSWD_ERR   "FAILED: OLD PASSWORD WRONG!"
#define E_2010_TLRCTL_PSWD_DUPL      "FAILED: NEW PASSWORD DUPLICATED!"
#define E_2010_TLRCTL_INVALID        E_SYS_TLRCTL_INVALID
#define E_2010_TLRCTL_UPD_PSWD_ERR   "FAILED: UPDATE PASSWORD ERROR!"
#define E_2010_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR

#define E_2017_TLRCTL_INVALID        E_SYS_TLRCTL_INVALID
#define E_2017_TLRCTL_UPD_STA_ERR    E_SYS_TLRCTL_UPD_STA_ERR
#define E_2017_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR

#define E_4011_GET_SYSREFNO_ERR      "ERROR:Get System Refno Error!"
#define E_4011_TXNLOG_INS_ERR        "ERROR:Txn Log Insert Error!"

#define E_5011_TXNLOG_INS_ERR        "ERROR:Txn Log Insert Error!"
#define E_5011_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR
#define E_5011_GET_SYSREFNO_ERR      "ERROR:Get System Refno Error!"
#define E_5011_GET_PBREFNO_ERR       "ERROR:Get Partner Bank Refno Error!"

#define E_5012_TXNLOG_UPD_ERR        "ERROR:Txn Log Update Error!"
#define E_5012_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR

#define E_5013_TXNLOG_NOT_FOUND      "ERROR:Not found in Transaction Log!"
#define E_5013_TXNLOG_DEL_ERR        "ERROR:Txn Log Delete Error!"
#define E_5013_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR


#define E_5061_TXNLOG_INS_ERR        "ERROR:Txn Log Insert Error!"
#define E_5061_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR
#define E_5061_GET_SYSREFNO_ERR      "ERROR:Get System Refno Error!"
#define E_5061_GET_PBREFNO_ERR       "ERROR:Get Partner Bank Refno Error!"

#define E_5101_CUSTCTL_INS_ERR       E_SYS_CUSTCTL_INS_ERR

#define E_5102_CUSTCTL_NOT_FOUND     E_SYS_CUSTCTL_NOT_FOUND
#define E_5102_CUSTCTL_UPD_ERR       E_SYS_CUSTCTL_UPD_ERR

#define E_5103_CUSTCTL_DEL_ERR       E_SYS_CUSTCTL_DEL_ERR
#define E_5103_CUSTCTL_NOT_FOUND     E_SYS_CUSTCTL_NOT_FOUND

#define E_5113_CUSTREG_DEL_ERR       E_SYS_CUSTREG_DEL_ERR
#define E_5113_CUSTREG_NOT_FOUND     E_SYS_CUSTREG_NOT_FOUND


#define E_5801_TXNLOG_NOT_FOUND      "ERROR:Not found in Transaction Log!"


#define E_5901_PBANKCTL_NOT_FOUND    E_SYS_PBANKCTL_NOT_FOUND
#define E_5901_CUSTCTL_NOT_FOUND     E_SYS_CUSTCTL_NOT_FOUND

#define E_5902_OPACTMP_NOT_FOUND     "ERROR: Opp A/C Info Not Found!"

#define E_5921_CUSTREG_NOT_FOUND     E_SYS_CUSTREG_NOT_FOUND


#define E_8000_GEN_REPORT_FAIL       "SYSTEM: Generate Online Report Failed!"
#define E_8000_OPEN_FILE_ERROR       "SYSTEM: Open Report Data File Failed!"

#define E_9001_SYSCTL_NOT_FOUND      E_SYS_SYSCTL_NOT_FOUND
#define E_9001_SYSCTL_UPD_ERR        E_SYS_SYSCTL_UPD_ERR

#define E_9004_PBANKCTL_NOT_FOUND    E_SYS_PBANKCTL_NOT_FOUND
#define E_9004_PBANKCTL_UPD_ERR      E_SYS_PBANKCTL_UPD_ERR
#define E_9004_TADTLOG_INS_ERR       E_SYS_TADTLOG_INS_ERR

#define E_9021_PBPSWDDIC_NOT_FOUND    "ERROR:Not found in Password Dictionary!"
#define E_9021_PBPSWDDIC_FOUND   "ERROR:Already Existed in Password Dictionary!"
#define E_9021_PBPSWDDIC_INS_ERR    "ERROR:Password Dictionary Insert Error!"
#define E_9021_PBPSWDDIC_DEL_ERR    "ERROR:Password Dictionary Delete Error!"

#define E_9051_HOLIDAY_NOT_FOUND     "ERROR:Not found in System Calendar!"
#define E_9051_HOLIDAY_UPD_ERR       "ERROR:System Calendar Update Error!"

#define E_9075_SYSCTL_NOT_FOUND      E_SYS_SYSCTL_NOT_FOUND
#define E_9075_SYSCTL_UPD_ERR        E_SYS_SYSCTL_UPD_ERR
#define E_9075_PBANKCTL_NOT_FOUND    E_SYS_PBANKCTL_NOT_FOUND
#define E_9075_PBANKCTL_UPD_ERR      E_SYS_PBANKCTL_UPD_ERR
#define E_OPACTMP_ERR      		   "WARNINGS:Opposite Account Map Update Error!"

#define E_6017_PBCUSTBAL_FOUND_ERR   "ERROR:A/C Balance Record Found Error!"
#define E_6017_PBCUSTBAL_UPDATE_ERR  "ERROR:A/C Balance Record Update Error!"
#define E_6017_FLAG_ERROR_START_DATE "ERROR:Start Date not Balanced!"

/*----------------------------------------------------*/
#define E_TLR_INEXIST_LOGON                    58     /* ��¼ʧ�ܣ��Ƿ��Ĳ���Ա */
#define E_TLR_PASS_ERR                         57     /* ��¼ʧ�ܣ��������*/
#define E_TLR_WORK_OFF                         51     /* ��¼ʧ�ܣ��ò���Ա���ɹ��� */
#define E_TLR_STATUS_ON                        52     /* ��¼ʧ�ܣ��ò���Ա�ѵ�¼����һ�ն�,����δ����ǩ��  */
#define E_TLR_STATUS_LOCK                      53     /* ��¼ʧ�ܣ��ò���Ա�ѱ����� */
#define E_TLR_IP_LOGON                         54     /* ��¼ʧ�ܣ��û����в���Ա��¼��PBLSϵͳ */
#define E_TLR_S_INVALID                        56     /* ��¼ʧ�ܣ�����Ա��ʧЧ */
#define E_TLR_NOTEXIST                         66     /* �����ڴ˲���Ա */
#define E_AUTH_TYPE_ERR                       606     /* ��Ȩ��־���� */
#define E_TXN_SAMEPERSON_ERR                  607     /* ¼���������ȨԱ��ͬһ�˴��� */
#define E_TXN_SAMEPERSON_ERR_1                608     /* �����������ȨԱ��ͬһ�˴��� */
#define E_TXN_SAMEPERSON_ERR_2                605     /* ¼���븴��Ա��ͬһ�˴��� */
#define E_TXN_OPTYPE_ERR                      609     /* �������ʹ��� */
#define E_TXN_RECORD_EXIST                    611     /* ��ͬ��¼�Ѵ��� */
#define E_TXN_PASS_OVERTIME                   1111     /* ����Ա������� */
#define E_DB_TB_SYSPARA_RERR                  1160    /* ��ѯ������ */
#define E_DB_TB_TLRCTL_RERR                   1168    /* ��ѯ������ */
#define E_DB_TB_TLRCTL_WERR                   1169    /* ���±����� */
#define E_DB_TB_TLRROLEFUNC_RERR              1184    /* ��ѯ������ */
#define E_DB_TB_ACTEMAIL_RERR                 1268    /* ��ѯ������ */
#define E_DB_TB_TLRLOG_IERR                   1202    /* ��������� */
#define E_DB_TB_CUSTREG_WERR                  1813    /* ���±����� */
#define E_DB_TB_CUSTREG_IERR                  1816    /* ��������� */
#define E_DB_TB_CUSTREG_DERR                  1817    /* ɾ�������� */
#define E_DB_TB_CUSTREG_RERR                  1820    /* ��ѯ������ */
#define E_PB_CUSREG_EXSIT                     1822    /* �ͻ�ע����Ϣ�Ѵ��� */
#define E_PB_CUSTREG_NOT_EXSIT                1823    /* �޸�ɾ������ �ͻ�ע����Ϣ������ */
#define E_DB_PB_CUSTCTLTMP_RERR               1800    /* ��ѯ������ */
#define E_DB_PB_CUSTCTLTMP_WERR               1801    /* ���±����� */
#define E_DB_PB_CUSTCTLTMP_IERR               1802    /* ��������� */
#define E_DB_PB_CUSTCTLTMP_DERR               1804    /* ɾ�������� */
#define E_PB_CUSTCTLTMP_EXSIT                 1803    /* ����δ��Ȩ�Ŀͻ�������Ϣ */
#define E_DB_PB_CUSTCTL_RERR                  1805    /* ��ѯ������ */
#define E_DB_PB_CUSTCTL_WERR                  1806    /* ���±����� */
#define E_DB_PB_CUSTCTL_IERR                  1807    /* ��������� */
#define E_DB_PB_CUSTCTL_DERR                  1808    /* ɾ�������� */
#define E_PB_CUSTCTL_EXSIT                    1809    /* �������� �ͻ���Ϣ�Ѵ��� */
#define E_PB_CUSTCTL_NOT_EXSIT                1810    /* �޸�ɾ������ �ͻ���Ϣ������ */
#define E_PB_RECORD_PBTLRLOG_ERR              1811    /* ��¼����Ա������־��ʧ��    */
#define E_PARA_ERR                            1812    /* �������� */
#define E_CALL_API_ERR                        1813    /* ����API���� */
#define E_DB_PB_CUSTREGTMP_DERR               1814    /* ɾ�������� */
#define E_DB_TB_CUSTREGTMP_RERR               1815    /* ��ѯ������ */
#define E_DB_TB_CUSTREGTMP_IERR               1818    /* ��������� */
#define E_PB_CUSTREGTMP_EXSIT                 1819    /* �ͻ�ע����Ϣ�Ѵ��� */
#define E_DB_TB_CUSTREGTMP_WERR               1821    /* ���±����� */
#define E_PB_PBANKCTLTMP_EXSIT                1824    /* �������в����Ѵ��� */
#define E_PB_PBANKCTLTMP_NOT_EXSIT            1825    /* �޸�ɾ������ �������в��������� */
#define E_PB_SYSCTLTMP_EXSIT                  1826    /* �������� ϵͳ�����Ѵ��� */
#define E_PB_SYSCTLTMP_NOT_EXSIT              1827    /* �޸�ɾ������ ϵͳ���������� */
#define E_PB_SYSCTL_EXSIT                     1828    /* �������� ϵͳ�����Ѵ��� */
#define E_PB_SYSCTL_NOT_EXSIT                 1829    /* �޸�ɾ������ ϵͳ���������� */
#define E_PB_SYSTEM_CMD						1830    /* ����ϵͳ�����ű����� */
#define E_PB_FCY_AMT_ERR					1831   /* ��ҽ��ڲ��ܳ���14λ */


/* -------------���ݿ����д��������ɾ������------------- */
#define E_DB_ICBC_01_TXN_RERR	1900
#define E_DB_ICBC_01_TXN_WERR	1901
#define E_DB_ICBC_01_TXN_IERR	1902
#define E_DB_ICBC_01_TXN_DERR	1903
#define E_DB_ICBC_02_TXN_RERR	1904
#define E_DB_ICBC_02_TXN_WERR	1905
#define E_DB_ICBC_02_TXN_IERR	1906
#define E_DB_ICBC_02_TXN_DERR	1907
#define E_DB_ICBC_03_TXN_RERR	1908
#define E_DB_ICBC_03_TXN_WERR	1909
#define E_DB_ICBC_03_TXN_IERR	1910
#define E_DB_ICBC_03_TXN_DERR	1911
#define E_DB_ICBC_04_DETAIL_TXN_RERR	1912
#define E_DB_ICBC_04_DETAIL_TXN_WERR	1913
#define E_DB_ICBC_04_DETAIL_TXN_IERR	1914
#define E_DB_ICBC_04_DETAIL_TXN_DERR	1915
#define E_DB_ICBC_04_TXN_RERR	1916
#define E_DB_ICBC_04_TXN_WERR	1917
#define E_DB_ICBC_04_TXN_IERR	1918
#define E_DB_ICBC_04_TXN_DERR	1919
#define E_DB_ICBC_05_TXN_RERR	1920
#define E_DB_ICBC_05_TXN_WERR	1921
#define E_DB_ICBC_05_TXN_IERR	1922
#define E_DB_ICBC_05_TXN_DERR	1923
#define E_DB_ICBC_06_TXN_RERR	1924
#define E_DB_ICBC_06_TXN_WERR	1925
#define E_DB_ICBC_06_TXN_IERR	1926
#define E_DB_ICBC_06_TXN_DERR	1927
#define E_DB_ICBC_07_TXN_RERR	1928
#define E_DB_ICBC_07_TXN_WERR	1929
#define E_DB_ICBC_07_TXN_IERR	1930
#define E_DB_ICBC_07_TXN_DERR	1931
#define E_DB_ICBC_08_TXN_RERR	1932
#define E_DB_ICBC_08_TXN_WERR	1933
#define E_DB_ICBC_08_TXN_IERR	1934
#define E_DB_ICBC_08_TXN_DERR	1935
#define E_DB_ICBC_11_TXN_RERR	1936
#define E_DB_ICBC_11_TXN_WERR	1937
#define E_DB_ICBC_11_TXN_IERR	1938
#define E_DB_ICBC_11_TXN_DERR	1939
#define E_DB_ICBC_12_DETAIL_TXN_RERR	1940
#define E_DB_ICBC_12_DETAIL_TXN_WERR	1941
#define E_DB_ICBC_12_DETAIL_TXN_IERR	1942
#define E_DB_ICBC_12_DETAIL_TXN_DERR	1943
#define E_DB_ICBC_12_TXN_RERR	1944
#define E_DB_ICBC_12_TXN_WERR	1945
#define E_DB_ICBC_12_TXN_IERR	1946
#define E_DB_ICBC_12_TXN_DERR	1947
#define E_DB_PBBAICODETMP_RERR	1948
#define E_DB_PBBAICODETMP_WERR	1949
#define E_DB_PBBAICODETMP_IERR	1950
#define E_DB_PBBAICODETMP_DERR	1951
#define E_DB_PBBAICODE_RERR	1952
#define E_DB_PBBAICODE_WERR	1953
#define E_DB_PBBAICODE_IERR	1954
#define E_DB_PBBAICODE_DERR	1955
#define E_DB_PBBATCHCTL_RERR	1956
#define E_DB_PBBATCHCTL_WERR	1957
#define E_DB_PBBATCHCTL_IERR	1958
#define E_DB_PBBATCHCTL_DERR	1959
#define E_DB_PBBATCHSTS_RERR	1960
#define E_DB_PBBATCHSTS_WERR	1961
#define E_DB_PBBATCHSTS_IERR	1962
#define E_DB_PBBATCHSTS_DERR	1963
#define E_DB_PBCURCDTRANS_RERR	1964
#define E_DB_PBCURCDTRANS_WERR	1965
#define E_DB_PBCURCDTRANS_IERR	1966
#define E_DB_PBCURCDTRANS_DERR	1967
#define E_DB_PBCUSTBAL_RERR	1968
#define E_DB_PBCUSTBAL_WERR	1969
#define E_DB_PBCUSTBAL_IERR	1970
#define E_DB_PBCUSTBAL_DERR	1971
#define E_DB_PBCUSTCTLTMP_RERR	1972
#define E_DB_PBCUSTCTLTMP_WERR	1973
#define E_DB_PBCUSTCTLTMP_IERR	1974
#define E_DB_PBCUSTCTLTMP_DERR	1975
#define E_DB_PBCUSTCTL_RERR	1976
#define E_DB_PBCUSTCTL_WERR	1977
#define E_DB_PBCUSTCTL_IERR	1978
#define E_DB_PBCUSTCTL_DERR	1979
#define E_DB_PBCUSTDTL_RERR	1980
#define E_DB_PBCUSTDTL_WERR	1981
#define E_DB_PBCUSTDTL_IERR	1982
#define E_DB_PBCUSTDTL_DERR	1983
#define E_DB_PBCUSTREGTMP_RERR	1984
#define E_DB_PBCUSTREGTMP_WERR	1985
#define E_DB_PBCUSTREGTMP_IERR	1986
#define E_DB_PBCUSTREGTMP_DERR	1987
#define E_DB_PBCUSTREG_RERR	1988
#define E_DB_PBCUSTREG_WERR	1989
#define E_DB_PBCUSTREG_IERR	1990
#define E_DB_PBCUSTREG_DERR	1991
#define E_DB_PBDEPTCTL_RERR	1992
#define E_DB_PBDEPTCTL_WERR	1993
#define E_DB_PBDEPTCTL_IERR	1994
#define E_DB_PBDEPTCTL_DERR	1995
#define E_DB_PBERRCODE_RERR	1996
#define E_DB_PBERRCODE_WERR	1997
#define E_DB_PBERRCODE_IERR	1998
#define E_DB_PBERRCODE_DERR	1999
#define E_DB_PBERRLOG_RERR	2000
#define E_DB_PBERRLOG_WERR	2001
#define E_DB_PBERRLOG_IERR	2002
#define E_DB_PBERRLOG_DERR	2003
#define E_DB_PBHOLIDAYTMP_RERR	2004
#define E_DB_PBHOLIDAYTMP_WERR	2005
#define E_DB_PBHOLIDAYTMP_IERR	2006
#define E_DB_PBHOLIDAYTMP_DERR	2007
#define E_DB_PBHOLIDAY_RERR	2008
#define E_DB_PBHOLIDAY_WERR	2009
#define E_DB_PBHOLIDAY_IERR	2010
#define E_DB_PBHOLIDAY_DERR	2011
#define E_DB_PBICBCINQ_RERR	2012
#define E_DB_PBICBCINQ_WERR	2013
#define E_DB_PBICBCINQ_IERR	2014
#define E_DB_PBICBCINQ_DERR	2015
#define E_DB_PBICBCTXN_RERR	2016
#define E_DB_PBICBCTXN_WERR	2017
#define E_DB_PBICBCTXN_IERR	2018
#define E_DB_PBICBCTXN_DERR	2019
#define E_DB_PBMSGMONITORHIS_RERR	2020
#define E_DB_PBMSGMONITORHIS_WERR	2021
#define E_DB_PBMSGMONITORHIS_IERR	2022
#define E_DB_PBMSGMONITORHIS_DERR	2023
#define E_DB_PBMSGMONITOR_RERR	2024
#define E_DB_PBMSGMONITOR_WERR	2025
#define E_DB_PBMSGMONITOR_IERR	2026
#define E_DB_PBMSGMONITOR_DERR	2027
#define E_DB_PBMSQDEF_RERR	2028
#define E_DB_PBMSQDEF_WERR	2029
#define E_DB_PBMSQDEF_IERR	2030
#define E_DB_PBMSQDEF_DERR	2031
#define E_DB_PBOPACTMP_RERR	2032
#define E_DB_PBOPACTMP_WERR	2033
#define E_DB_PBOPACTMP_IERR	2034
#define E_DB_PBOPACTMP_DERR	2035
#define E_DB_PBPBANKCTLTMP_RERR	2036
#define E_DB_PBPBANKCTLTMP_WERR	2037
#define E_DB_PBPBANKCTLTMP_IERR	2038
#define E_DB_PBPBANKCTLTMP_DERR	2039
#define E_DB_PBPBANKCTL_RERR	2040
#define E_DB_PBPBANKCTL_WERR	2041
#define E_DB_PBPBANKCTL_IERR	2042
#define E_DB_PBPBANKCTL_DERR	2043
#define E_DB_PBPSWDERR_RERR	2044
#define E_DB_PBPSWDERR_WERR	2045
#define E_DB_PBPSWDERR_IERR	2046
#define E_DB_PBPSWDERR_DERR	2047
#define E_DB_PBRPTLOG_RERR	2048
#define E_DB_PBRPTLOG_WERR	2049
#define E_DB_PBRPTLOG_IERR	2050
#define E_DB_PBRPTLOG_DERR	2051
#define E_DB_PBSEQCTL_RERR	2052
#define E_DB_PBSEQCTL_WERR	2053
#define E_DB_PBSEQCTL_IERR	2054
#define E_DB_PBSEQCTL_DERR	2055
#define E_DB_PBSRVMSQ_RERR	2056
#define E_DB_PBSRVMSQ_WERR	2057
#define E_DB_PBSRVMSQ_IERR	2058
#define E_DB_PBSRVMSQ_DERR	2059
#define E_DB_PBSTATCTLHIS_RERR	2060
#define E_DB_PBSTATCTLHIS_WERR	2061
#define E_DB_PBSTATCTLHIS_IERR	2062
#define E_DB_PBSTATCTLHIS_DERR	2063
#define E_DB_PBSTATCTL_RERR	2064
#define E_DB_PBSTATCTL_WERR	2065
#define E_DB_PBSTATCTL_IERR	2066
#define E_DB_PBSTATCTL_DERR	2067
#define E_DB_PBSYSCTLTMP_RERR	2068
#define E_DB_PBSYSCTLTMP_WERR	2069
#define E_DB_PBSYSCTLTMP_IERR	2070
#define E_DB_PBSYSCTLTMP_DERR	2071
#define E_DB_PBSYSCTL_RERR	2072
#define E_DB_PBSYSCTL_WERR	2073
#define E_DB_PBSYSCTL_IERR	2074
#define E_DB_PBSYSCTL_DERR	2075
#define E_DB_PBSYSLOG_RERR	2076
#define E_DB_PBSYSLOG_WERR	2077
#define E_DB_PBSYSLOG_IERR	2078
#define E_DB_PBSYSLOG_DERR	2079
#define E_DB_PBTLRCTLTMP_RERR	2080
#define E_DB_PBTLRCTLTMP_WERR	2081
#define E_DB_PBTLRCTLTMP_IERR	2082
#define E_DB_PBTLRCTLTMP_DERR	2083
#define E_DB_PBTLRCTL_RERR	2084
#define E_DB_PBTLRCTL_WERR	2085
#define E_DB_PBTLRCTL_IERR	2086
#define E_DB_PBTLRCTL_DERR	2087
#define E_DB_PBTLRLOG_RERR	2088
#define E_DB_PBTLRLOG_WERR	2089
#define E_DB_PBTLRLOG_IERR	2090
#define E_DB_PBTLRLOG_DERR	2091
#define E_DB_PBTLRROLEFUNCTMP_RERR	2092
#define E_DB_PBTLRROLEFUNCTMP_WERR	2093
#define E_DB_PBTLRROLEFUNCTMP_IERR	2094
#define E_DB_PBTLRROLEFUNCTMP_DERR	2095
#define E_DB_PBTLRROLEFUNC_RERR	2096
#define E_DB_PBTLRROLEFUNC_WERR	2097
#define E_DB_PBTLRROLEFUNC_IERR	2098
#define E_DB_PBTLRROLEFUNC_DERR	2099
#define E_DB_PBTLRROLETMP_RERR	2100
#define E_DB_PBTLRROLETMP_WERR	2101
#define E_DB_PBTLRROLETMP_IERR	2102
#define E_DB_PBTLRROLETMP_DERR	2103
#define E_DB_PBTLRROLE_RERR	2104
#define E_DB_PBTLRROLE_WERR	2105
#define E_DB_PBTLRROLE_IERR	2106
#define E_DB_PBTLRROLE_DERR	2107
#define E_DB_PBTXNOMAP_RERR	2108
#define E_DB_PBTXNOMAP_WERR	2109
#define E_DB_PBTXNOMAP_IERR	2110
#define E_DB_PBTXNOMAP_DERR	2111
#define E_DB_RTE_SFD_MSG_RERR	2112
#define E_DB_RTE_SFD_MSG_WERR	2113
#define E_DB_RTE_SFD_MSG_IERR	2114
#define E_DB_RTE_SFD_MSG_DERR	2115

#define E_PBCUSTREG_RERR        2116
#define E_PBCUSTREG_NOT_EXSIT   2117
#define E_DB_PBICBCTXN_STA_ERR  2118
#define E_DB_PBICBCTXN_NO_RECD  2119
#define E_DB_PBICBCTXN_SND_ERR  2120
#define E_DE_DATE_ERR           2121
#define E_DE_PBBAICODETMP_EXSIT 2122
#define E_DE_PBBAICODE_EXSIT    2123
#define E_DE_PBBAICODE_NO_EXSIT 2124
#define E_DE_PBBAICODETMP_NO_EXSIT  2125
#define E_DB_PBTLRROLETMP_EXSIT     2126
#define E_DB_PBTLRROLETMP_NO_EXSIT  2127
#define E_DB_PBTLRROLE_EXSIT        2128
#define E_DB_PBTLRROLE_NO_EXSIT     2129
#define E_DB_PBTLRROLE_STA_ERR      2130
#define E_DB_PBTLRCTLTMP_STA_ERR    2131
#define E_DB_PBTLRCTL_STA_ERR       2132
#define E_DB_PBTLRCTL_NO_EXSIT      2133
#define E_DB_PBTLRCTLTMP_NO_EXSIT   2134
#define E_DB_PBHOLIDAYTMP_STA_ERR   2135
#define E_DB_PAYTIME_ERR            2136       /* ����ʱ����� */
#define E_DB_PBHOLIDAY_WORK_ERR     2137
#define E_DB_REG_RELATION_EXIST     2138      /* �ÿͻ�����ǩԼ��ע����Ϣ������ɾ��ע����Ϣ */
#define E_SYS_SYSTEM_ERR            2139      /* system call error */
#define E_DB_PBSYSPARA_RERR         2140      /* read table syspara error */
#define E_DB_INQTIME_ERR            2141      /* ���ڲ�ѯʱ�䷶Χ�� */
#define E_SYS_TRANSFER_CURCD_ERR    2142      /* ת������ʧ��  */
#define E_TLR_EXIST_ALREADY			2143	/* ����Ա�Ѵ��ڣ��������� */
#define E_PB_ACTNO_REPAIR_ERR       2144    /*���˺�����ڴ��޸��������޸�δ���*/
#define E_PB_ACTNO_REPAIRAUTH_ERR   2145    /*���˺�����ڴ��޸��������޸������*/
#define E_PBICBCTXN_STATUS_ERR   2146   /*�òο��ż�¼����״̬��Ϊ1-������*/
#define E_PBICBCTXN_OLDPWD_ERR   2147   /*������ʧ�ܣ�����Ա���������*/
#define E_DB_PBICBCTXN_NODATA    2148       /*��ѯPBICBCTXNû�з������������ݣ�*/
#define E_PB_ACTNO_REPAIR_DATE_ERR	2149	/*����޸�������ĳ������ϸ��¼��ȫ*/
#define E_SYS_TLRORPWD_WRONG_ERR	2150	/*����Ա�������������*/
#define E_DB_QUERY_NO_RECORD	2151	/*�ñʽ��ײ����ڣ���ѯ�޼�¼*/
/* ADD ON 20161129 BEGIN */
#define E_EXIT_ICBC_MONITOR_MAIL	2152	/*���˺��������ʼ����ѣ������ʼ��������ù��ܽ����˺�ɾ��������*/
#define E_INSERT_ICBC_MONITOR_TMP_ERR	2153	/*�����ICBC_MONITOR_TMP����*/
#define E_INSERT_ICBC_MONITOR_ERR	2154	/*�����ICBC_MONITOR����*/
#define E_RECORD_ALREADY_EXIST_ERR	2155	/*�ü�¼����ά���У���������˽�����ˡ�*/
#define E_RECORD_ALREADY_APPROVED_ERR	2156	/*�ü�¼�����ڻ��ѱ���ˣ���ˢ���б���*/
#define E_INSERT_ICBC_MONITOR_MAIL_TMP_ERR	2157	/*�����ICBC_MONITOR_MAIL_TMP����*/
#define E_INSERT_ICBC_MONITOR_MAIL_ERR	2158	/*�����ICBC_MONITOR_MAIL����*/
/* ADD ON 20161129 END */
#define ICBC_RETURN_OK				"0000"






/*----------------------------------------------------*/

#endif

