EXEC SQL BEGIN DECLARE SECTION;
	extern varchar  	H_PBSYSLOG_SYS_LOG_TIME	[ 21];
	extern int   		H_PBSYSLOG_MSG_SRC;
	extern int   		H_PBSYSLOG_MSG_CODE;
	extern int   		H_PBSYSLOG_MSG_SUBCODE;
	extern int   		H_PBSYSLOG_MSG_LEVEL;
	extern varchar  	H_PBSYSLOG_MSG_DESC	[ 61];
	extern varchar  	H_PBSYSLOG_REC_UPDT_TIME	[ 21];
EXEC SQL END DECLARE SECTION;
