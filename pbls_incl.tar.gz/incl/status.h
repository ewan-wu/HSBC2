#ifndef _STATUS_H
#define _STATUS_H

#define P_FLAG_ON                1
#define P_FLAG_OFF               0

#define SYS_STATUS               0
#define E3_STATUS                1
#define E3_RSND_FLAG             2

#define CHK_STATUS               SYS_STATUS
#define CHK_E3_STATUS            E3_STATUS
#define CHK_E3_RSND_FLAG         E3_RSND_FLAG
#define SET_STATUS               SYS_STATUS
#define SET_E3_STATUS            E3_STATUS
#define SET_E3_RSND_FLAG         E3_RSND_FLAG

#define STATUS_ON                1
#define STATUS_OFF               0
#define STATUS_BATCH             2
#define STATUS_BATCH_DONE        3

#define CHAR_STATUS_OFF               '0'
#define CHAR_STATUS_ON                '1'
#define CHAR_STATUS_BATCH             '2'
#define CHAR_STATUS_BATCH_DONE        '3'

#define CHK_STATUS_ON            STATUS_ON
#define CHK_STATUS_OFF           STATUS_OFF
#define CHK_STATUS_BATCH         STATUS_BATCH
#define CHK_STATUS_BATCH_DONE    STATUS_BATCH_DONE
#define SET_STATUS_ON            STATUS_ON
#define SET_STATUS_OFF           STATUS_OFF
#define SET_STATUS_BATCH         STATUS_BATCH
#define SET_STATUS_BATCH_DONE    STATUS_BATCH_DONE

#define COMM_S_INI               5150
#define COMM_S_RESTART           6150
#define COMM_S_END               7150

#define COMMON_STATUS_ON         '1'
#define COMMON_STATUS_OFF        '0'

/* txnlog status */
#define TXNLOG_STATUS_INPUT      '1'
#define TXNLOG_STATUS_APPROVE    '2'
#define TXNLOG_STATUS_SENDSUC    '3'
#define TXNLOG_STATUS_SENDFAL    '4'
#define TXNLOG_STATUS_MODIFY     '5'
#define TXNLOG_STATUS_DELETE     '6'
#define TXNLOG_STATUS_DELETED    '7'
#define TXNLOG_STATUS_CHECKED    '8'
#define TXNLOG_STATUS_MODIFIED   '9'
#define TXNLOG_STATUS_NEEDREPAIR 'R'
#define TXNLOG_STATUS_REJECT     'X'

/* txnlog sub status */
#define TXNLOG_SUB_STATUS_NORMAL     '0'
#define TXNLOG_SUB_STATUS_PROCESSING     '1'
#define TXNLOG_SUB_STATUS_SUCCESS   '2'
#define TXNLOG_SUB_STATUS_FAIL     '3'

/* ICBC FLAG */
#define ICBC_OB_FLAG_SINGLE           "0"
#define ICBC_OB_FLAG_BATCH            "1"

#define ICBC_TTY_FLAG_REALTIME        "1"
#define ICBC_TTY_FLAG_BATCH           "2"

/* txnlog source */
#define TXNLOG_SOURCE_E3              '1'
#define TXNLOG_SOURCE_MANUAL_INPUT    '2'
#define TXNLOG_SOURCE_MANUAL_UPL_E3   '3'
#define TXNLOG_SOURCE_MANUAL_UPL_CSV  '4'
#define TXNLOG_SOURCE_MANUAL_UPL_DD   '5'

/* txnlog crdb */
#define TXNLOG_CRDB_COLLECTION   'C'
#define TXNLOG_CRDB_PAYMENT      'D'

/* customer control */
#define CUSTCTL_STATUS_VALID       '1'
#define CUSTCTL_STATUS_INVALID     '2'
#define CUSTCTL_STATUS_BF_VALID    '3'
#define CUSTCTL_STATUS_BF_INVALID  '4'
#define CUSTCTL_MTSEQ_INIT         1
#define CUST_EDATE_DEFAULT         "39991231"

#define CUSTCTL_BSNS_FLAG1_PBLS    'P'
#define CUSTCTL_BSNS_FLAG1_MANL    'M'
#define CUSTCTL_BSNS_FLAG1_DEFAULT CUSTCTL_BSNS_FLAG1_PBLS

/* customer register */
#define CUSTREG_STIPTYPE_DIRECT    "00"
#define CUSTREG_STIPTYPE_INDIRECT  "10"
#define CUSTREG_TYPE_PAYMENT       'P'
#define CUSTREG_TYPE_COLLECTION    'C'
#define CUSTREG_STATUS_VALID       '1'
#define CUSTREG_STATUS_INVALID     '2'
#define CUSTREG_STATUS_BF_VALID    '3'
#define CUSTREG_STATUS_BF_INVALID  '4'

#define CUSTREG_O_ACTYPE_CORP      '0'
#define CUSTREG_O_ACTYPE_INDV      '1'

#define CUSTREG_O_ACTNO_NULL       "-"
#define CUSTREG_CURCD_DEFAULT         "CNY"
#define CUSTREG_CURCD_DEFAULT_ALIAS   "RMB"
#define ICBC_CURCD_RMB_CNY				      "CNY"
#define ICBC_CURCD_RMB_RMB				      "RMB"

#define HUB_PBLS_HEAD_CHANNEL		"I             "
#define CNAPS_CODE_LEN				12
#define BIC_CODE_LEN                11

#define PBLS_HUB_HEART				"PBLS-HUBH000H111"


#define CCB_STIP_STATUS_OPEN       '0'
#define CCB_STIP_STATUS_CLOSE      '1'

/* partner bank statement support flag */
#define PBANKCTL_ST_FLAG_YES     'Y'
#define PBANKCTL_ST_FLAG_NO      'N'

/* department work flag */
#define BDEPTCTL_WORK_FLAG_OFF   '0'
#define BDEPTCTL_WORK_FLAG_ON    '1'

/* department sys flag */
#define BDEPTCTL_SYS_FLAG_OFF    '0'
#define BDEPTCTL_SYS_FLAG_ON     '1'

/* teller work flag */
#define BTLRCTL_WORK_FLAG_INIT   '0'
#define BTLRCTL_WORK_FLAG_ON     '1'
#define BTLRCTL_WORK_FLAG_OFF    '2'

/* teller status */
#define BTLRCTL_STATUS_LOG_OFF   '0'
#define BTLRCTL_STATUS_LOG_ON    '1'
#define BTLRCTL_STATUS_LOCK      '2'

/* teller init flag */
#define BTLRCTL_INIT_FLAG_OFF    '0'
#define BTLRCTL_INIT_FLAG_ON     '1'

/* teller sign log action type */
/*
#define BSIGNLOG_ACTION_TYPE_SIGNON   '0'  * ��¼��ǩ�� *
#define BSIGNLOG_ACTION_TYPE_SIGNOFF  '1'  * ǩ�� *
#define BSIGNLOG_ACTION_TYPE_CHGPSWD  '2'  * ������ *
#define BSIGNLOG_ACTION_TYPE_RSTPSWD  '3'  * �������á�����ǿ�Ʊ�� *
#define BSIGNLOG_ACTION_TYPE_RCVPSWD  '4'  * ʧЧ����ָ� *
#define BSIGNLOG_ACTION_TYPE_RCVAUTH  '5'  * ����Ȩ�޻ָ� *
#define BSIGNLOG_ACTION_TYPE_UNLOCK1  '6'  * ������ǿ��ǩ�ˣ� *
#define BSIGNLOG_ACTION_TYPE_OTHERS   '9'
*/

/* teller password length (max) */
#define BTLRCTL_PASSWORD_MAX_LENGTH		12
#define BTLRCTL_PASSWORD_MAX_HIS		12

/* dept/tlr maintenance log action type */
/*
#define BSCMLOG_ACTION_TYPE_DEPT      '0'
#define BSCMLOG_ACTION_TYPE_TLR       '1'
#define BSCMLOG_ACTION_TYPE_TRM       '2'
#define BSCMLOG_ACTION_TYPE_OTHERS    '9'
*/

/* dept/tlr maintenance log action subtype */
/*
#define BSCMLOG_ACTION_SUBTYPE_ADD    '0'
#define BSCMLOG_ACTION_SUBTYPE_DEL    '1'
#define BSCMLOG_ACTION_SUBTYPE_UPD    '2'
#define BSCMLOG_ACTION_SUBTYPE_OTHERS '9'
*/

/* citic pay type */
#define CITIC_PAYTYPE_OUT   	'1'
#define CITIC_PAYTYPE_INER   	'2'
#define CITIC_PAYTYPE_SALARY   	'3'

/* citic city flag */
#define CITIC_CITY_IN    	'0'
#define CITIC_CITY_CROSS    '1'
#define CITIC_CITY_NULL    	'-'

/* citic citicib flag */
#define CITIC_CITICIB_CITIC    	'0'
#define CITIC_CITICIB_OTHER    	'1'
#define CITIC_CITICIB_NULL    	'-'

/* HUB AND PBLS HEART */
#define MAX_HUB_PBLS_COUNT 5
#endif


