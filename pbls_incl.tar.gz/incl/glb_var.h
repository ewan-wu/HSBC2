#ifndef __GLOBAL_VAR
#define __GLOBAL_VAR

char	gsDBTxdate[9];
char	gsDBTxtime[7];

#endif


