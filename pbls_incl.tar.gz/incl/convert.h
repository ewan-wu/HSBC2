#ifndef __CONVERT_H
#define __CONVERT_H

/* E3 XML */

#define E3_XML_MSG_TYPE_PAY       "PAY"
#define E3_XML_MSG_TYPE_ACK       "ACK"
#define E3_XML_MSG_TYPE_FDB       "FDB"
#define E3_XML_MSG_TYPE_940       "940"
#define E3_XML_MSG_TYPE_942       "942"
#define E3_XML_MSG_TYPE_LEN       3
#define E3_XML_MSG_SUB_TYPE_LEN   8

#define E3_XML_MSG_TYPE_F1        "MESSAGE"
#define E3_XML_MSG_TYPE_F2        "MessageIdentifier"
#define E3_XML_MSG_TYPE_F3        "MessageType"

#define E3_XML_NUM_OF_EVLP_H1     "ENVELOPE"

#define E3_XML_NUM_OF_FILE_H1     "FILE"
#define E3_XML_NUM_OF_FILE_H2     "InternalFileRef"
#define E3_XML_NUM_OF_FILE_F1     "ENVELOPETRAILER"
#define E3_XML_NUM_OF_FILE_F2     "NumofFiles"

#define E3_XML_NUM_OF_MSG_H1      "MESSAGE"
#define E3_XML_NUM_OF_MSG_H2      "InternalMsgRef"
#define E3_XML_NUM_OF_MSG_F1      "FILETRAILER"
#define E3_XML_NUM_OF_MSG_F2      "NumofMessages"

#define E3_XML_NUM_OF_TXN_H1      "TRANSACTION"
#define E3_XML_NUM_OF_TXN_H1A     "Transaction"
#define E3_XML_NUM_OF_TXN_H2      "InternalTXNRef"
#define E3_XML_NUM_OF_TXN_F1      "MESSAGETRAILER"
#define E3_XML_NUM_OF_TXN_F2      "NumofTxn"

#define E3_XML_NUM_OF_FILE_MAX     9
#define E3_XML_NUM_OF_MSG_MAX      9
#define E3_XML_NUM_OF_TXN_MAX      999

#define E3_XML_IPC_LEN_MAX         1024
#define E3_XML_DEPTH_MAX           64

#define E3_XML_TITLE "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"
#define E3_XML_OUT_RECIPIENT       "E3ASIA"
#define E3_XML_OUT_ORIGINATOR      "PBLS"

/* CCB XML */

#define CCB_XML_MSG_TYPE_LEN       4
#define CCB_XML_MSG_SUB_TYPE_LEN   3

#define CCB_XML_MSG_TYPE_F1        "Head"
#define CCB_XML_MSG_TYPE_F2        "TxCode"
#define CCB_XML_MSG_SUB_TYPE_F1    "Head"
#define CCB_XML_MSG_SUB_TYPE_F2    "FuncCode"

#define CCB_XML_NUM_OF_RCD_H1      "Body"
#define CCB_XML_NUM_OF_RCD_H2      "Record"
/*
#define CCB_XML_NUM_OF_RCD_H3      "DepId"
*/
#define CCB_XML_NUM_OF_RCD_F1      "Body"
#define CCB_XML_NUM_OF_RCD_F2      "RecCount"

#define CCB_XML_EL_SESSION_ID      "SessionId"
#define CCB_XML_SESSION_ID_NULL    "FFFFFFFFFFFFFFFF"
#define CCB_XML_BRANCHID_NULL      "00000"
#define CCB_XML_DEPID_NULL         "00000"
#define CCB_XML_USERID_NULL        "9999999999999999"

#define CCB_XML_RESP_CODE_SUCC        "E0000"
#define CCB_XML_RESP_CODE_FILE_RECV   "M0032"

#define CCB_XML_STAT_MSG_1         "1737000"
#define CCB_XML_STAT_MSG_2         "1736000"

#define CCB_XML_TITLE "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"

#define CCB_XML_NUM_OF_RCD_MAX      999

#define CCB_XML_IPC_LEN_MAX         1024
#define CCB_XML_DEPTH_MAX           10

#define CCB_STEOD_MAX_DAYS          30
#define CCB_TXDATE_TEMP             "ZSENDING"

/* ICBC */
#define ICBC_BUFF_LEN               20*1024
#define ICBC_MSG_TYPE_LEN           2
#define ICBC_BANK_CODE_LEN          8
#define ICBC_MSG_ENDDING            '!'
#define ICBC_MSG_ENDDING_STRING     "!"

#define ICBC_STEOD_MAX_DAYS         30


/* CITIC */
#define CITIC_XML_MSG_TYPE_LEN      6
#define CITIC_XML_MSG_SUB_TYPE_LEN  1

#define CITIC_XML_NUM_OF_RCD_MAX    999

#define CITIC_XML_IPC_LEN_MAX       1024
#define CITIC_XML_DEPTH_MAX         10

#define CITIC_XML_MSG_TYPE_F        "TRAN_CODE"
#define CITIC_XML_MSG_SUB_TYPE_RQ   "TRNRQ"
#define CITIC_XML_MSG_SUB_TYPE_RS   "TRNRS"
#define CITIC_XML_NUM_OF_RCD_H1     "TRNRS"

#define CITIC_XML_TITLE            "<?xml version=\"1.0\" encoding=\"GB2312\"?>"
#define CITIC_XML_EL_SESSION_ID    "SessionId"
#define CITIC_STEOD_MAX_DAYS       30
#define CITIC_TXDATE_TEMP          "ZSENDING"

#endif

