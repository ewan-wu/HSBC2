#ifndef GLB_EXT_H
#define GLB_EXT_H

extern  T_TXCOM_AREA      it_txcom;
extern  T_TITA_LABTEX     it_tita;
extern  T_TOTW_LABTEX     it_totw;
extern  char    gsErrDesc[255+1];
extern  char    gsDBTxdate[9];
extern  char    gsDBTxtime[7];
extern  char    gsBrno[4];
#endif

