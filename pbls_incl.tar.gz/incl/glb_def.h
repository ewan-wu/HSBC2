#ifndef __GLB_DEF_H
#define __GLB_DEF_H

#include <stdio.h> 
#include <stdlib.h> 
#include <math.h> 
#include <string.h> 

/******************************************************************************/
/*        DEFINE database duplicate key table service routine                 */
/*               porcess function code                                        */
/******************************************************************************/
#define  DBS_INI        0
#define  DBS_FIND       1
#define  DBS_LOCK       2
#define  DBS_UPDATE     3
#define  DBS_INSERT     4
#define  DBS_DELETE     5
#define  DBS_CLOSE      6
#define  DBS_IUPD       7
#define  DBS_IDEL       8
#define  DBS_LOCK_NOCURSOR  9

/******************************************************************************/
/*        DEFINE database porcess error code                        		  */
/******************************************************************************/
#define  DB_NOTFOUND    1403
#define  DB_ISNULL      -1405
#define  DB_OK          0

#define  SYS_OK         0
#define  SYS_FAIL       -1

/* for batch txt */
#define TXT_CREAT           0
#define TXT_APPEND          1
#define BULD_BUF_NOT_WRT    1
#define NOT_BULD_WRT_BUF    2
#define BULD_BUF_WRT_BUF    3

/* batch status */
#define BATCH_STATUS_NO_START       '0'
#define BATCH_STATUS_PROCESSING     '1'
#define BATCH_STATUS_ERROR          '2'
#define BATCH_STATUS_FINISH         '3'

/* batch type */
#define BATCH_TYPE_NIGHT            'N'
#define BATCH_TYPE_ONLINE           'O'

#define DLEN_BRNO                3      /* ��֧���� */
#define DLEN_DEPT                DLEN_BRNO
#define DLEN_TLRNO               8      /* ����Ա */
#define DLEN_DATE                8      /* ���� */
#define DLEN_TIME                6      /* ʱ�� */
#define DLEN_BH_FNAME           80      /* �������ļ��� */
#define DLEN_SDESC              20      /* ������ */
#define DLEN_DESC               180      /* ������ */

/* deleted by Jasmine 20100805
#define ERRTRACE      printf("Error Line = [%d]\n", __LINE__);
*/

#define PBLS_BANK_ID_DB            "000"
#define PBLS_BANK_ID_ICBC          "002"
#define PBLS_BANK_ID_CCB           "005"
#define PBLS_BANK_ID_CITIC         "302"
#define PBLS_BANK_ID_CMB           "308"

#define PBLS_BANK_SWIFT_CODE_ICBC  "ICBKCNBJXXX"
#define PBLS_BANK_SWIFT_CODE_CCB   "PCBCCNBJVIP"
#define PBLS_BANK_SWIFT_CODE_CITIC "CIBKCNBJXXX"
#define PBLS_BANK_SWIFT_CODE_CMB   "CMBCCNBXXXX"

#define PBLS_MANUAL_PROCESSING_TYPE        "ACH"
#define PBLS_MANUAL_TRANSACTION_TYPE       "DO"
#define PBLS_MANUAL_TRANSACTION_SUB_TYPE   "RMB"

#define PBLS_FREE_TEXT_TYPE        "PMD"
#define PBLS_FREE_TEXT_TYPE_SPL    "SPL"

/*
#define PBLS_FDB_SUCC_PAYMENT      "PROCPSUCC"
#define PBLS_FDB_SUCC_COLLECTION   "PROCCSUCC"
#define PBLS_FDB_FAIL_PAYMENT      "PROCPFAIL"
#define PBLS_FDB_FAIL_COLLECTION   "PROCCFAIL"
*/
#define PBLS_FDB_SUCC_PAYMENT      "PROCPAY"
#define PBLS_FDB_SUCC_COLLECTION   "PROCCOLL"
#define PBLS_FDB_FAIL_PAYMENT      "PROCPAY"
#define PBLS_FDB_FAIL_COLLECTION   "PROCCOLL"

#define PBLS_BRAHCHID_LEN_ICBC     8
#define PBLS_BRAHCHID_LEN_CCB      5
#define PBLS_BRAHCHID_LEN_CITIC    98
#define PBLS_BRAHCHID_LEN_CMB      99

#define PBLS_SYS_DEPT              "---"
#define PBLS_SYS_TLR               "--------"
#define PBLS_NULL_STRING_8         "--------"

#define PBLS_ICBC_CURCD_DEFAULT    "001"
#define PBLS_ENC_ORG_IDX_ICBC      "71200001"
#define PBLS_CFG_FILE              "pbls.cfg"
#define DBACT_CFG_FILE              "account.cfg"
#define PBLS_MANUAL_UPLOAD         "iodata/e3/upload"

/*--------------------add by zr --------------------*/
#define	TX_SUCCESS		'0'
#define	TX_MODIYPWD		'7'
#define TX_WILLPAST     '8'
#define TX_TLRWILLPAST  '9'
char    gsTBDate[9];
char    gsDBTxdate[9];
char    gsDBTxtime[7];
char    gsBrno[4];
char    gsErrDesc[256];
#define DLEN_LBRNO		12				/* �кţ���㣩 */
#define DLEN_IPADDR		15				/* IP��ַ */
/*--------------------------------------------------*/

/*--------------------add by Jasmine --------------------*/
#define	TX_REJECT		'1'
#define ERRTRACE		cmErrorInfo(__FILE__, __LINE__);cmErrorHandle
#define DLEN_ECODE		5				/* �������     */
#define DLEN_LDESC		255				/* ������ */
#define MSET(s)			memset(s, 0, sizeof(s))
#define MSETP(s)		memset(s, ' ', sizeof(s))
#define MSETS(s)		memset(&s, 0, sizeof(s))
#define MSETSP(s)		memset(&s, ' ', sizeof(s))
#define MCPYA(a,b)		memcpy(a, b, sizeof(a)-1)
#define MCPYB(a,b)		memcpy(a, b, sizeof(b)-1)
#define MCPYX(a,b)		memcpy(a, b, sizeof(a))
#define MCPYY(a,b)		memcpy(a, b, sizeof(b))
#define MCPYSA(a,b)		memcpy(&a, &b, sizeof(a))
#define MCPYSB(a,b)		memcpy(&a, &b, sizeof(b))
#define PERR(msg)		printf("%s [ERROR](%s %d):",GetCurTime2(),__FILE__,__LINE__);perror(msg)
#define HTLM_COM		logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__
#define HTLM_ERR		logfile, HT_LOG_MODE_ERR, __FILE__, __LINE__
#define DINFO			printf("[%s][%s:%d][DEBUG] ",GetCurTime2(),basename(__FILE__),__LINE__);printf
#define DLEN_PARA_VAL	1000
/* for GetCurrentDateAll: todo �����������ǰӦ�����к궼��Ϊ1 */
#define GET_CURRENT_DATE_FLAG_SYS	1		//����ϵͳ����
#define GET_CURRENT_DATE_FLAG_ICBC	1		//ICBC����
#define GET_CURRENT_DATE_FLAG_CUST	1		//�ͻ�ϵͳ����
#define GET_CURRENT_DATE_FLAG_RSV1	11		//Ԥ������1
#define GET_CURRENT_DATE_FLAG_RSV2	12		//Ԥ������2
#define GET_CURRENT_DATE_FLAG_RSV3	13		//Ԥ������3
#define GET_CURRENT_DATE_FLAG_RSV4	14		//Ԥ������4
#define GET_CURRENT_DATE_FLAG_RSV5	15		//Ԥ������5
#define GET_CURRENT_DATE_FLAG_RSV6	16		//Ԥ������6
#define GET_CURRENT_DATE_FLAG_RSV7	17		//Ԥ������7
#define GET_CURRENT_DATE_FLAG_RSV8	18		//Ԥ������8
#define GET_CURRENT_DATE_FLAG_RSV9	19		//Ԥ������9
#define GET_CURRENT_DATE_FLAG_RSV10	20		//Ԥ������10

/* ICBC MSG CODE */
#define ICBC_RMB_PAYMENT_REQ "10017"
#define ICBC_RMB_PAYMENT_RSP "10017"
#define ICBC_FCY_PAYMENT_REQ "10020"
#define ICBC_FCY_PAYMENT_RSP "10020"

#define ICBC_RMB_INQUIRY_REQ "10015"
#define ICBC_RMB_INQUIRY_RSP "10015"
#define ICBC_FCY_INQUIRY_REQ "10004"
#define ICBC_FCY_INQUIRY_RSP "10004"

#define ICBC_ACT_DETAILS_REQ "40004"
#define ICBC_ACT_DETAILS_RSP "40004"
#define ICBC_ACT_BALANCE_REQ "40005"
#define ICBC_ACT_BALANCE_RSP "40005"

#define ICBC_BANK_DLTY01     "DLTY"

/* ICBC MSG CODE */
#define ICBC_RMB_PAYMENT_REQ_VALUE 10017
#define ICBC_RMB_PAYMENT_RSP_VALUE 10017
#define ICBC_FCY_PAYMENT_REQ_VALUE 10020
#define ICBC_FCY_PAYMENT_RSP_VALUE 10020

#define ICBC_RMB_INQUIRY_REQ_VALUE 10015
#define ICBC_RMB_INQUIRY_RSP_VALUE 10015
#define ICBC_FCY_INQUIRY_REQ_VALUE 10004
#define ICBC_FCY_INQUIRY_RSP_VALUE 10004

#define ICBC_ACT_DETAILS_REQ_VALUE 40004
#define ICBC_ACT_DETAILS_RSP_VALUE 40004
#define ICBC_ACT_BALANCE_REQ_VALUE 40005
#define ICBC_ACT_BALANCE_RSP_VALUE 40005

#define ICBC_BANK_DLTY01_VALUE     88888 


/*--------------------------------------------------*/

#endif
