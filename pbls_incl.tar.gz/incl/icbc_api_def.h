/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  icbc api define.
 *
 *  $Id$
 *
 * FileName: icbc_api_def.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2010/08/11         zy                       Create.
 *
 */

#ifndef _ICBC_API_DEF_H_20100811175812_
#define _ICBC_API_DEF_H_20100811175812_

/*------------------------ Include files ------------------------*/

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/
#define DLEN_ICBC_ID 16
#define DLEN_ICBC_DATE 8
#define DLEN_ICBC_BIZ_EXTDATA 32
#define DLEN_ICBC_QUE_OBJNAME 32

#define DLEN_ICBC_ACCT 30
#define DLEN_ICBC_ADDR 20
#define DLEN_ICBC_ADDR_CODE 4
#define DLEN_ICBC_ADDR_CODE2 5
#define DLEN_ICBC_ALL_COUNT 6
#define DLEN_ICBC_AMOUNT 15
#define DLEN_ICBC_AMOUNT2 17
#define DLEN_ICBC_ATTR 3
#define DLEN_ICBC_BRNO 8
#define DLEN_ICBC_BUZ_TYPE 3
#define DLEN_ICBC_CHECKER 16
#define DLEN_ICBC_CURRENCY 3
#define DLEN_ICBC_CUR_COUNT 4
#define DLEN_ICBC_ERR_CODE 4
#define DLEN_ICBC_ERR_DESC 200
#define DLEN_ICBC_ERR_MSG 20
#define DLEN_ICBC_FLAG 1
#define DLEN_ICBC_INDEX 2
#define DLEN_ICBC_NAME 60
#define DLEN_ICBC_NODE_ID 4
#define DLEN_ICBC_OPPOSITE_ACCT 35
#define DLEN_ICBC_PAY_TYPE 1
#define DLEN_ICBC_PKG_ID 16
#define DLEN_ICBC_PKG_NO 7
#define DLEN_ICBC_PKG_TYPE 2
#define DLEN_ICBC_REMARKS 100
#define DLEN_ICBC_RSV1 40
#define DLEN_ICBC_RSV2 17
#define DLEN_ICBC_RSV3 20
#define DLEN_ICBC_RSV4 1
#define DLEN_ICBC_RT_CODE 4
#define DLEN_ICBC_SEND_ID 8
#define DLEN_ICBC_STATUS 2
#define DLEN_ICBC_SUB_ACCT 1
#define DLEN_ICBC_SUMMARY 40
#define DLEN_ICBC_SUMMARY2 20
#define DLEN_ICBC_TIME 14
#define DLEN_ICBC_TIME2 6
#define DLEN_ICBC_TIME_STAMP 26
#define DLEN_ICBC_TXN_STATUS 2
#define DLEN_ICBC_TYPE 1
#define DLEN_ICBC_TYPE2 2
#define DLEN_ICBC_USAGE 30
#define DLEN_ICBC_USAGE2 40
#define DLEN_ICBC_USAGE3 20

#define	DLEN_ICBC_MAXSQL 4096	/* SQL Buffer ���� */

/*ҵ����״̬����*/
#define ICBC_STATUS_NOTPROC "00"    /*������,�ѵ���/��¼��*/
#define ICBC_STATUS_SEND    "01"    /*�ѷ���*/
#define ICBC_STATUS_CANCEL  "02"    /*��ȡ��*/
#define ICBC_STATUS_PROC    "03"    /*�Ѵ���,��ԭ������Ӧ*/
#define ICBC_STATUS_REFUSED "20"    /*�Ѿܾ�*/

/*-------------------------------*/
/*ICBC*/
/*-------------------------------*/
#define TYPE_OUT_TXN "1"
#define TYPE_IN_TXN  "2"

#define ICBC_SERVER_NO "0001"

/*-------------------------------*/
/*ICBC ���ĸ�ʽ����*/
/*-------------------------------*/
#define ICBC_IPC_PKGFMT_ING "  "     /*���Ը�ʽ*/
#define ICBC_IPC_PKGFMT_PBC "01"     /*���и�ʽ*/
#define ICBC_IPC_PKGFMT_SWT_PBC "02" /*SWT������ͨѶ�ı��ĸ�ʽ*/

#if 0
#pragma mark -
#pragma mark < Global functions declaration >
#endif
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif
    
#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /* _ICBC_API_DEF_H_20100811175812_ */
/*--------------------- End -------------------------------------*/
