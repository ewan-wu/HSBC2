#ifndef __SE_ITF_H__
#define __SE_ITF_H__

/*��ʷ������Ϣ*/
/* typedef T_TB_PAYINFO aTisHvPayinfoUpd; */
typedef struct
{
    char    null;
}aTosHvPayinfoUpd;

/* �����Ÿ��� */
typedef struct
{
    char    sDate[DLEN_DATE+1];
    char    sBrno[DLEN_BRNO+1];
    char    sType[DLEN_TYPE+1];
}aTisHvRemitctlUpd;

typedef struct
{
    double     dSeqno;
}aTosHvRemitctlUpd;

/* �����к�ӳ����� */
typedef struct
{
    char    sActBnkName[DLEN_BRNAME+1];
    char    sOurActno[DLEN_ACTNO+1];
    char    sOppActno[DLEN_ACTNO+1];
    char    sMapBrno[DLEN_BRNO+1];
    char    sMapBnkName[DLEN_BRNAME+1];
}aTisBankNameMapUpd;

typedef struct
{
    char    null;
}aTosBankNameMapUpd;

#endif
