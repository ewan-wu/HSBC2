#define     TIVOLI_DATABASE     1
#define     TIVOLI_SOCKET       2
#define     TIVOLI_MESSAGEQ     3
#define     TIVOLI_SYSCMD       4
#define     TIVOLI_BUSINESS     5
#define     TIVOLI_IBMMQ        6
#define     TIVOLI_OTHERERR     7
