#ifndef _SWTTOC_H
#define _SWTTOC_H

/* Definition of IPC Structure between SWITCH and TOCTL */
typedef struct
{
    long    MsgType;
    long    nMsgCode;
	long	nSwitchPID;
	short	nReplyCode;

	char	cDeptId;
	char	cPayType;
	char	sSysSeqNum[4];
} SwtToSSNReqDef;

#define SEQCTL_RCD_ID_SWIFTSEQ		"SWIFTSEQ"
#define SEQCTL_RCD_ID_RETRYSEQ		"RETRYSEQ"
#define SEQCTL_RCD_ID_SYSTXNRF		"SYSTXNRF"
#define SEQCTL_RCD_ID_E3MSGIN 		"MSGIS0E3"
#define SEQCTL_RCD_ID_E3MSGOUT 		"MSGOS0E3"
#define SEQCTL_RCD_ID_CCBMSGIN 		"MSGIS005"
#define SEQCTL_RCD_ID_CCBMSGOUT 	"MSGOS005"
#define SEQCTL_RCD_ID_ICBCMSGIN 	"MSGIS002"
#define SEQCTL_RCD_ID_ICBCMSGOUT 	"MSGOS002"
#define SEQCTL_RCD_ID_CITICMSGIN 	"MSGIS302"
#define SEQCTL_RCD_ID_CITICMSGOUT 	"MSGOS302"
#define SEQCTL_RCD_ID_CMBMSGIN 		"MSGIS308"
#define SEQCTL_RCD_ID_CMBMSGOUT 	"MSGOS308"
#define SEQCTL_RCD_ID_CCBBATCHNO 	"BATCH005"

#define SEQCTL_SEQSTR_MAX_LEN		8

typedef struct
{
    long    MsgType;
    long    nMsgCode;
	long	nSwitchPID;
	short	nReplyCode;

	char	sSeqType[8];  /* type of sequence number (rcd_id in SEQCTL) */
	short	nSeqLen;
	char	sSeqStr[SEQCTL_SEQSTR_MAX_LEN];
} SwtToSEQReqDef;

/* function in libcom.a */
short SwtSnd2ToSSN (SwtToSSNReqDef *);
short SwtSnd2ToSEQ (SwtToSEQReqDef *);

#define NORMAL_FIRST       1
#define NORMAL_SECOND      2
#define REVERSAL_FIRST     3

#define BANKCODE_LEN	6

typedef long    MsgTypeDef;

typedef struct
{
    MsgTypeDef    MsgType;
    long          nMsgCode;
    char          cSsnCode;
    long          lSrvId;
    short         nTransCode;
    short         nReplyCode;
    long          nSwitchPID;
    char          sOBCode[BANKCODE_LEN];
    char          sCBCode[BANKCODE_LEN];
    char          sTerminalCode[8];
    char          sSysSeqNum[6];
} SwtToReqDef;

#endif
