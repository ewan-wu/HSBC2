#ifndef _MSGQUE_H
#define _MSGQUE_H

#include "ipc.h"

#define MSG_FLAG          0660
#define MAX_MSGQUEUE      30			/* NEED */

#define IPC_MSG_SIZE		MAX_PACKET_LEN
typedef struct {
    long     lMsgType;
    long     lMsgCode;
    char     sText[IPC_MSG_SIZE];
} IPCMsgDef;

/* functions in libcom.a */
#define HOST_SESSION_HEADER_LEN		8
#define HOST_SESSION_RULE_POSI		3
#define HOST_AP_HEADER_LEN			(6+2+16+2+12)

typedef struct
{
	char	sTxnID[6];
	char	sApFunLen[2];
	char	sApFun[16];
	char	sApTimeOut[2];
	char	sUserDef[12];
	char	sSessionHeader[HOST_SESSION_HEADER_LEN];
	char	sData[IPC_MSG_SIZE];
} BufSndToHostDef;

typedef struct
{
	char	sSessionHeader[HOST_SESSION_HEADER_LEN];
	char	sData[IPC_MSG_SIZE];
} BufRcvFromHostDef;

typedef struct
{
	long	lLineCode;
	char	sData[IPC_MSG_SIZE];
} BufRcvFromNetDef;

/* functions in libcom.a */
short nCommomMsqInit(long);
short nCommomMsqAllInit(long);
short nCommonMsqSend(short, char *, long, long);
short nCommonMsqOutSend(short, char *, long, long);
short nCommonMsqRecv(short *, char *, long *, long);
short nCommonMsqRecvNoWait(short *, char *, long *, long);

#endif  /* _MSGQUE_H */
