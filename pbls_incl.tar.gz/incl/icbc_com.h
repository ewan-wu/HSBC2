/*
 * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 * ICBC Common Lib
 *
 * $Id: icbc_com.h 735 2010-03-17 01:55:55Z yuy $
 *
 * FileName: icbc_com.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2010/01/14        YY                        Create.
 */
#ifndef _ICBCCOM_H_20100114160929_
#define _ICBCCOM_H_20100114160929_

/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#define	ICBC_MSGID_SEQ	"10"

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/
#ifdef __cplusplus
extern "C" {
#endif
    
    /**
     * icbcGetNextSeq
     *
     * @param sSeqName: Sequence����
     * @param piSeqValue: ��һ��Sequenceֵ
     *
     * @return 0:�ɹ�
     *       ��0:ʧ��
     *
     */
    int	icbcGetNextSeq(char *sSeqName, int *piSeqValue);
    
    /**
     * icbcGetNextId
     *
     * @param sId: ���Id, 16λ, ��ʽ: YYYYMMDD + ˳���(8),
     *             ����������Ӧ����Ϊ16+1=17λ
     *
     * @return 0:�ɹ�
     *       ��0:ʧ��
     *
     */
    int	icbcGetNextId(char *sId);
    
    /**
     * icbcGetNextSendId
     *
     * @param sId: ���Id, 16λ, ��ʽ: YYYYMMDD + ˳���(8),
     *             ����������Ӧ����Ϊ16+1=17λ
     *
     * @return 0:�ɹ�
     *       ��0:ʧ��
     *
     */
    int
    icbcGetNextSendId(char *sId);
    
    /**
     * icbcGetNextMsgId
     *
     * @param sMsgId: ���MsgId, 20λ,
     *          ��ʽ: ��ʶ��(2) + ��������YYYYMMDDHH(10) + ˳���(8)
     *                ����������Ӧ����Ϊ20+1=21λ
     *
     * @return 0:�ɹ�
     *       ��0:ʧ��
     *
     */
    int	icbcGetNextMsgId(char *sMsgId);

#ifdef __cplusplus
}
#endif

#endif /*_ICBCCOM_H_20100114160929_*/
/*-----------------------------  End ------------------------------------*/
