/*
 *
 * 
 * topmq listener module.
 * 
 * 
 * FileName: topmq_lsr.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_LSR_H_20100119172610_
#define _TOPMQ_LSR_H_20100119172610_
/*--------------------------- Include files -----------------------------*/
#include "topmq_def.h"
#include "topmq_chl.h"
/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_LSR_H_20100119172610_*/
/*-----------------------------  End ------------------------------------*/
