/*
 *
 * 
 * topmq log print funcitons.
 * 
 * 
 * FileName: topmq_log.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_LOG_H_20100208150857_
#define _TOPMQ_LOG_H_20100208150857_
/*--------------------------- Include files -----------------------------*/
#include "log_info.h"
/*--------------------------- Macro define ------------------------------*/
#define LOG_ERROR 1
#define LOG_TRACE 5
#define MODE_DEF 3

#define TMQ_DebugString(f, s, n) logDebugString((f), MODE_DEF, __FILE__, __LINE__, __FUNCTION__, (s), (#s), (n))
/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

int TMQ_LogInit(void);
int TMQ_LogSetQMName(char *psQMName);
int TMQ_LogSetAppName(char *psAppName);
int TMQ_LogSetLevel(int iLogLevel);

int TMQ_LogPrint(char *psLogFile, int iLevel, char *psLevelStr, char *psFile, int iLine, const char *psFunction, char *psFmt, ...);

#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_LOG_H_20100208150857_*/
/*-----------------------------  End ------------------------------------*/
