/*
 *
 * 
 * object datasource define.
 * 
 * 
 * FileName: topmq_object_datasource.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_OBJECT_DATASOURCE_H_20110601205349_
#define _TOPMQ_OBJECT_DATASOURCE_H_20110601205349_
/*--------------------------- Include files -----------------------------*/
#include "topmq_object.h"
/*--------------------------- Macro define ------------------------------*/
#define VAR_TOPMQ_OBJ_DS_LOADFUN "TMQ_ObjDSLoad"

/*---------------------------- Type define ------------------------------*/
/*-----------------------------------------------------------*/
/*object database interface*/
/*-----------------------------------------------------------*/
typedef int (*PFN_TMQ_OBJDBCREATE)(char *psName, int iOptions);
typedef int (*PFN_TMQ_OBJDBDELETE)(char *psName, int iOptions);
typedef int (*PFN_TMQ_OBJDBOPEN)(char *psName, int iOptions);
typedef int (*PFN_TMQ_OBJDBCLOSE)(char *psName, int iOptions);

typedef T_TMQ_OBJ_DB_HANDLE (*PFN_TMQ_OBJDBCONN)(char *psName, int iOptions);
typedef int (*PFN_TMQ_OBJDBDISCONN)(T_TMQ_OBJ_DB_HANDLE hDB, int iOptions);

typedef int (*PFN_TMQ_OBJDBISEXIST)(char *psName);
typedef int (*PFN_TMQ_OBJDBISOPEN)(char *psName);

typedef int (*PFN_TMQ_OBJADD)(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, char *psAttrNames[], char *psAttrs[], int iOptions);
typedef int (*PFN_TMQ_OBJDEL)(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iOptions);
typedef int (*PFN_TMQ_OBJSETATTR)(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, char *psAttrNames[], char *psAttrs[]);
typedef int (*PFN_TMQ_OBJGETATTR)(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, char *psAttrNames[], char *psAttrs[]);
typedef T_TMQ_OBJ_CUR_HANDLE (*PFN_TMQ_OBJCUROPEN)(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName);
typedef int (*PFN_TMQ_OBJCURFETCH)(T_TMQ_OBJ_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur, int iAttrNum, char *psAttrNames[], char *psAttrs[]);
typedef int (*PFN_TMQ_OBJCURUPDATE)(T_TMQ_OBJ_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur, int iAttrNum, char *psAttrNames[], char *psAttrs[]);
typedef int (*PFN_TMQ_OBJCURCLOSE)(T_TMQ_OBJ_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur);

typedef int (*PFN_TMQ_OBJISEXIST)(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName);

typedef char * (*PFN_TMQ_OBJGETERROR)(void);
typedef int (*PFN_TMQ_OBJGETRCODE)(void);


typedef struct {
    PFN_TMQ_OBJDBCREATE         pfnDBCreate ;
    PFN_TMQ_OBJDBDELETE         pfnDBDelete ;
    PFN_TMQ_OBJDBOPEN           pfnDBOpen   ;
    PFN_TMQ_OBJDBCLOSE          pfnDBClose  ;
    PFN_TMQ_OBJDBCONN           pfnDBConn   ;
    PFN_TMQ_OBJDBDISCONN        pfnDBDisConn;
    
    PFN_TMQ_OBJDBISEXIST        pfnDBIsExist;
    PFN_TMQ_OBJDBISOPEN         pfnDBIsOpen ;
    
    PFN_TMQ_OBJADD              pfnAdd      ;
    PFN_TMQ_OBJDEL              pfnDel      ;
    PFN_TMQ_OBJSETATTR          pfnSetAttr  ;
    PFN_TMQ_OBJGETATTR          pfnGetAttr  ;
    PFN_TMQ_OBJCUROPEN          pfnCurOpen  ;
    PFN_TMQ_OBJCURFETCH         pfnCurFetch ;
    PFN_TMQ_OBJCURUPDATE        pfnCurUpdate;
    PFN_TMQ_OBJCURCLOSE         pfnCurClose ;
    
    PFN_TMQ_OBJISEXIST          pfnObjIsExist  ;
    
    PFN_TMQ_OBJGETERROR         pfnGetError ;
    PFN_TMQ_OBJGETRCODE         pfnGetRCode ;
} T_TMQ_OBJ_DS_ITF;

/*--------------------------------------------------*/
/*--------------------------------------------------*/
typedef T_TMQ_OBJ_DS_ITF * (*PFN_TMQ_OBJDSLOAD)(int iOptions);
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

T_TMQ_OBJ_DS_ITF * TMQ_ObjDSLoad(int iOptions);

#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_OBJECT_DATASOURCE_H_20110601205349_*/
/*-----------------------------  End ------------------------------------*/
